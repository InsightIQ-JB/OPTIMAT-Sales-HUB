# Bouwprompt voor Codex — OPTIMAT Sales Hub

Plak de volledige onderstaande opdracht in Codex. Voeg ook `RESATEC-ivo-broncode-2026-10-27.zip` en `RESATEC-ivo-LEESMIJ-2026-10-27.md` toe. Het volledige tekstscript is een alternatieve leesversie van dezelfde export; de ZIP bevat de afzonderlijke bronbestanden.

---

Je bent mijn senior productontwikkelaar en full-stack engineer. Bouw een gebruiksklaar marketing- en salesplatform voor OPTIMAT Group, met als werktitel **OPTIMAT Sales Hub**.

Lever een werkende applicatie met een database, accounts, server-side toegangsrechten en een betrouwbare WordPress-koppeling. Een visuele demo met fictieve cijfers is alleen een afzonderlijke testomgeving, geen eindresultaat. Werk zelfstandig door aan alle onderdelen waarvoor je voldoende informatie hebt. Maak redelijke keuzes expliciet en vraag alleen naar informatie die een concrete volgende stap werkelijk blokkeert.

## 1. Doel en gebruikers

Alle relevante aanvragen van **https://www.optimat-group.com/** en **https://kdt.optimat-group.com/** moeten automatisch samenkomen. Marketing ziet waar aanvragen vandaan komen, de salesmanager verdeelt ze, verkopers volgen ze op en management ziet de voortgang en resultaten.

Het platform moet dagelijks prettig werken op een pc én smartphone, via één responsive webapp. Het gebruiksgemak van HubSpot is een referentie. Een bestaande HubSpot-account of -licentie is geen vereiste.

Maak standaard vier rollen:

- **Verkoper:** eigen toegewezen aanvragen, bedrijven, verkoopkansen en taken bekijken en bijwerken; eigen dashboard en kaart.
- **Salesmanager:** het teamoverzicht, intake, toewijzing, herverdeling, pipeline en teamrapportage beheren.
- **Marketing/management:** alle toegestane commerciële gegevens en rapporten lezen en exporteren; marketing mag bron- en campagnevelden beheren via een afzonderlijke permissie.
- **Beheerder:** gebruikers, rollen, formulieren, veldmapping, integraties en instellingen beheren.

Controleer deze rechten op de server, ook bij directe API-aanroepen, zoekresultaten, kaartdata, bijlagen, tellingen en exports. Een verkoperselectie of verborgen knop in de interface is geen toegangscontrole. Gebruik persoonlijke accounts en instelbare teamrechten; neem geen gebruikersnamen of toegangslijsten over uit Resatec.

## 2. Onderzoek eerst de werkelijke bronnen

Inspecteer de bestaande projectomgeving en beide WordPress-installaties voor zover toegang beschikbaar is. Inventariseer alle actieve formulieren, inclusief pop-ups, producttemplates, taalversies, landingspagina's, beursinschrijvingen en embedded formulieren. Stel per formulier vast: website, formulierplugin/provider, ID, taal, doel, velden, verborgen velden, productcontext, opslag en geschikte server-side integratiehook.

Neem geen specifieke formulierplugin aan op basis van de zichtbare website. Maak een formulierregister waarin ook nieuwe formulieren ontdekt en opgevolgd kunnen worden. Markeer de inventaris als onvolledig zolang alleen publieke pagina's konden worden bekeken.

Houd rekening met demo-, showroom-, offerte-, brochure-, contact-, event-, opleidings- en softwareaanvragen. Leg alle aangeleverde zakelijke velden vast, ook wanneer formulieren onderling verschillen.

Omdat optimat-group.com meerdere activiteiten bevat, ondersteun je een instelbare businessunit: Wood, Stone, Glass en Onbekend. Prioriteit is Wood/HOMAG en KDT, maar bronwebsite, businessunit en machinemerk blijven afzonderlijke velden. Een aanvraag op optimat-group.com kan bijvoorbeeld over KDT gaan. Leid ontbrekende gegevens niet met zekerheid af uit alleen het domein.

Registreer het doel van andere formulieren, zoals support, vacatures en nieuwsbrieven, met passende routing en rechten. Zet die inzendingen niet automatisch in de commerciële pipeline en toon sollicitatiegegevens niet in verkoopdossiers.

## 3. Betrouwbare WordPress-integratie

Bouw een onderhoudbare WordPress-connector of passende server-side adapters voor de daadwerkelijk gebruikte formulierplugins. Gebruik een gedeeld ontvangstcontract in de applicatie. Bestaande formulieren, bevestigingsmails, brochurelevering en de bezoekerservaring moeten blijven werken.

De gewenste gegevensstroom:

1. Een formulier is gevalideerd en de inzending is duurzaam vastgelegd in WordPress of de connector.
2. Een lokale outbox bewaart het te versturen event, ook wanneer de salesapp tijdelijk niet bereikbaar is.
3. De connector verstuurt het event via HTTPS met authenticatie en ondertekening.
4. De app valideert en bewaart de ontvangst transactioneel vóór een succesvolle ontvangstbevestiging.
5. Achtergrondverwerking maakt of koppelt de aanvraag, het bedrijf, de contactpersoon en eventueel de verkoopkans. Geocodering en verrijking blokkeren de ontvangst niet.
6. De bevoegde gebruikers zien de nieuwe aanvraag automatisch in hun scherm.

Richt de normale doorlooptijd in op **maximaal 15 seconden na een succesvolle formulierinzending**, meetbaar in een integratietest. Toon bij vertraging de actuele synchronisatiestatus. Gebruik realtime updates of passende automatische verversing met reconnect en inhaalverwerking.

Vereisten:

- At-least-once aflevering met een idempotente ontvanger: herlevering mag geen extra aanvraag creëren.
- Een stabiele unieke sleutel per website, provider, formulier en oorspronkelijke submission-ID; genereer en bewaar zelf een ID als de bron er geen heeft.
- Onderscheid een nieuw event, een herlevering en een echte wijziging van een bestaande inzending. Gebruik event-ID, bronversie en brontijdstippen om herhaalde en te laat ontvangen wijzigingen correct te verwerken.
- Ondertekende requests met een afzonderlijk geheim per bron, timestampcontrole en veilige rotatie. Ondertekening moet met legitieme retries blijven werken.
- Retries met oplopende wachttijd, een blijvende wachtrij voor mislukte events, handmatig opnieuw aanbieden en een diagnosepagina. Kies een betrouwbare scheduler; vermeld wanneer een servercron nodig is.
- Voer periodieke reconciliatie uit met broninzendingen waar de provider dit ondersteunt. Toon oncontroleerbare bronnen expliciet.
- Een mislukte CRM-koppeling mag een succesvolle bezoekersaanvraag niet verliezen of het formulier blokkeren.
- Bewaar de oorspronkelijke zakelijke waarden, veld-ID's, labels, types, opties en mappingversie. Nieuwe zakelijke velden blijven zichtbaar onder ‘Extra formuliergegevens’ tot mapping is ingesteld.
- Neem geen CAPTCHA-tokens, wachtwoorden, honeypotinhoud, authenticatiegegevens of onnodige trackingdata over als zakelijke leadvelden.
- Ondersteun compoundvelden, meerkeuzevelden, datums, URL's, meertalige labels en toegestane bijlagen.
- Bestaande intakegegevens kunnen worden aangevuld; bronupdates mogen geen verkopersnotities, eigenaar, taken of verkoopstatus overschrijven.
- Eénrichtingsverkeer vanuit WordPress is de standaard. Schrijf CRM-statussen niet terug naar de publieke formulieren zonder een aparte noodzaak.

Bouw veldmapping per formulier met voorbeeldweergave, versiegeschiedenis en een testmogelijkheid. Maak voor historische gegevens een import met voorbeeldcontrole, duplicaatcontrole en een importverslag. Dateer oude inzendingen op hun oorspronkelijke datum en markeer onbekende historische statussen als onbekend.

Als WordPress-toegang ontbreekt, bouw dan de app, connector, configuratiescherm en contracttests alvast. Lever concrete installatie-instructies en een lijst met ontbrekende toegang. Claim pas een live koppeling nadat een echte testinzending vanuit elke aangesloten bron is ontvangen.

## 4. Gegevensmodel en leadfiches

Maak afzonderlijke entiteiten voor **formulierinzendingen/aanvragen, bedrijven, vestigingen, contactpersonen, verkoopkansen, activiteiten en taken**. Een bedrijf kan meerdere contactpersonen, aanvragen en verkoopkansen hebben. Een aanvraag kan meerdere machine-interesses en intenties bevatten. Koppel verkoopkansen expliciet aan hun aanvragen.

Een brochureaanvraag is waardevolle interesse, maar geen automatisch gekwalificeerde verkoopkans. Een brochureformulier waarin iemand ook een offerte aanvraagt, moet beide intenties behouden en de offerte-intentie duidelijk tonen. Maak opvolging mogelijk zonder eerst een verkoopkans te moeten aanmaken.

Laat de aanvraagfiche overzichtelijk zien:

- Bedrijf, ondernemings-/btw-nummer indien aanwezig, contactpersoon, functie, telefoon, e-mail en voorkeurstaal.
- Adres, postcode, gemeente, provincie/regio, land en betrokken vestiging; ontbrekende gegevens blijven herkenbaar leeg.
- Bronwebsite, formuliernaam en -type, formulier-ID, taal, productpagina en oorspronkelijke inzenddatum.
- Businessunit, merk, machinecategorie, model(len), productlink, brochure en oorspronkelijke machinebenaming.
- Het volledige bericht en alle overige zakelijke formuliervelden, gegroepeerd met hun labels.
- Eigenaar, opvolgstatus, prioriteit, laatste betekenisvolle contactactie en volgende taak met datum.
- Gekoppelde verkoopkansen, indicatieve waarde, verwachte afsluitdatum en eventueel winst- of verliesreden.
- Tijdlijn met inzendingen, gesprekken, notities, taken, wijzigingen, toewijzingen en bijlagen, inclusief actor en tijdstip.
- Campagne- en herkomstgegevens voor zover werkelijk beschikbaar: UTM-velden, verwijzer, campagne en toegestane advertentie-identifiers.
- Relevante toestemming/doelbinding met tijdstip, bron en tekstversie indien aanwezig. Een aanvraag of KBO-record wordt niet automatisch een nieuwsbriefinschrijving.

Normaliseer machinecategorieën en modellen in een beheerbare catalogus; behoud altijd de aangeleverde waarde. Ondersteun onder andere CNC/nesting, kantenaanlijmers, zaagtechniek, boren/deuvelen, schuren, automatisatie en massief/houtskeletbouw, zonder een gesloten lijst in code vast te zetten.

Gebruik betrouwbare sleutels voor matching, zoals een gevalideerd ondernemingsnummer met land. E-mail is een aanwijzing voor een contactpersoon, geen universele sleutel voor een bedrijf. Naam, telefoon en domein mogen suggesties geven; onzekere matches vereisen controle. Een herhaalde aanvraag blijft als eigen gebeurtenis bestaan. Ondersteun gecontroleerd samenvoegen met behoud van historie en verwijzingen.

## 5. Intake, toewijzing en dagelijkse opvolging

De homepage is een bruikbare werkomgeving met nieuwe en niet-toegewezen aanvragen, taken voor vandaag, achterstallige opvolging en recente activiteit. Nieuwe aanvragen komen binnen als duidelijke kaarten: bedrijf, regio, aanvraagtype, machine, tijdstip, eigenaar en opvolgactie.

De salesmanager kan één of meerdere aanvragen toewijzen of herverdelen. Bewaar wie dat deed en wanneer. Laat bij een bekend bedrijf de bestaande eigenaar zien, maar laat een nieuwe broninzending geen eigenaar stilzwijgend wijzigen. Nieuwe aanvragen blijven zichtbaar als te beoordelen werk. Voorzie interne meldingen voor een nieuwe toewijzing; e-mailmeldingen zijn instelbaar en linken naar de fiche.

Bied snelle acties: bellen, mailen via de bestaande mailclient, taak plannen, notitie toevoegen, eigenaar wijzigen en status aanpassen. Het aanklikken van een telefoon- of mailknop bewijst geen werkelijk contact. Laat een verkoper een uitgevoerde contactactie met één eenvoudige handeling registreren.

Gebruik een beperkte, instelbare opvolgflow voor aanvragen: **Nieuw → Te contacteren → Gecontacteerd → In wacht → Afgerond**. Bewaar waarom iets is afgerond, bijvoorbeeld ‘verkoopkans aangemaakt’, ‘informatievraag beantwoord’, ‘niet relevant’ of ‘spam’. Spam en testdata worden afzonderlijk uitgesloten van commerciële cijfers.

Gebruik voor echte verkoopkansen een pipeline met **Gekwalificeerd → Demo/afspraak → Offerte → Onderhandeling → Verkocht**, plus **Verloren** en een wachtstatus. Een verkoper moet eenvoudig stappen kunnen overslaan of later aanvullen. Verplicht alleen gegevens die voor een specifieke actie noodzakelijk zijn. Vraag bij ‘In wacht’ om een opvolgdatum en bij ‘Verloren’ om een reden. Verkocht omvat geregistreerde waarde en afsluitdatum; zonder waarde telt de kans wel als gewonnen, met een zichtbare datakwaliteitsmelding.

Voorzie een tabel en een Kanban-weergave, met dezelfde filters. Status wijzigen kan met drag-and-drop én een keuzemenu op mobiel. Alle overgangen en heropeningen blijven controleerbaar in de historie. Vermijd administratieve stappen die een eenvoudige telefoonopvolging onnodig zwaar maken.

Optionele automatische verdeling op regio, taal, businessunit of merk komt na een goede handmatige intake. Regels zijn zichtbaar, aanpasbaar en omkeerbaar.

## 6. Benelux-kaart

Bouw een kaart van België, Nederland en Luxemburg met filters op verkoper, periode, aanvraagtype, businessunit, merk, machine, status en prioriteit. Toon actieve verkoopkansen en aanvragen als afzonderlijk selecteerbare lagen. Cluster markers en groepeer meerdere aanvragen op hetzelfde adres.

Een marker toont een compacte fiche en opent het volledige dossier. Gebruik dezelfde toegangsrechten en filters als in de lijst. Voeg een legenda en ‘zoeken in dit kaartgebied’ toe. Een lijst naast de kaart blijft bruikbaar wanneer markers dicht bij elkaar liggen.

Geocodeer adressen op de server via een toegestane provider met passende gebruiksvoorwaarden, capaciteit en kosten. Bewaar coördinaten, bron, precisie en controledatum. Gebruik land in de postcodezoekopdracht. Een postcodecentrum is een benadering en krijgt een ander symbool dan een geverifieerd adres. Geen willekeurige pin bij ontbrekende gegevens: toon zulke dossiers onder ‘Locatie ontbreekt’. Ondersteun correctie en respecteer een handmatig bevestigde locatie.

De kaart heeft een functionele foutmelding en lijstfallback bij een providerstoring. Registreer aanvragen buiten de Benelux wel, met een aparte filter.

## 7. Dashboards en managementrapporten

Maak één gedeeld filtermodel voor dashboards, lijsten, kaart en exports: periode, verkoper/team, bronwebsite, businessunit, land/regio, merk/model, aanvraagtype, campagne en status. Bied opgeslagen weergaven en vergelijking met een vorige periode.

De persoonlijke startpagina toont eigen nieuwe aanvragen, ontbrekende vervolgacties, achterstallige taken, actieve offertes, open verkoopkansen en geregistreerde verkopen.

Management ziet minimaal:

- Aanvragen, unieke bedrijven, contactpersonen en gekwalificeerde verkoopkansen als afzonderlijke aantallen.
- Verdeling naar website, formulier, aanvraagtype, machine, land en verkoper.
- Niet-toegewezen aanvragen, opvolgingsgraad, eerste contacttijd en achterstallige acties.
- Open pipelinewaarde, geregistreerde offertewaarde, gewonnen waarde, verloren waarde en gemiddelde verkoopcyclus.
- Funnel, cohortconversie en winratio, met doorklik naar de dossiers achter elk cijfer.
- Datakwaliteit: ontbrekende eigenaren, locaties, waarden of brondata; kandidaten voor duplicaten; synchronisatiefouten.

Leg de definities vast in code, documentatie en korte tooltips:

- **Aanvragen:** unieke geldige inzendingen; herleveringen tellen niet opnieuw.
- **Eerste contacttijd:** tijd van ontvangst tot de eerste geregistreerde menselijke contactactie; een automatische ontvangstmail telt niet. Toon mediaan en p90, plus het aandeel nog niet gecontacteerd.
- **Opvolgingsgraad:** aandeel aanvragen uit het gekozen instroomcohort met een geregistreerde contactactie op de peildatum. Ongecontacteerde aanvragen blijven in de noemer.
- **Lead-naar-verkoopconversie:** aandeel geldige commerciële aanvragen uit een instroomcohort dat op de peildatum aan minstens één gewonnen verkoopkans is gekoppeld; tel elke aanvraag maximaal één keer. Toon daarnaast conversie op bedrijfsniveau en de omvang van het cohort.
- **Winratio:** gewonnen verkoopkansen / (gewonnen + verloren verkoopkansen), geselecteerd op afsluitdatum. Open kansen tellen niet mee in die noemer.
- **Pipelinewaarde:** som van geregistreerde bedragen van open verkoopkansen. Een gewogen forecast is afzonderlijk en gebruikt instelbare kansen; label deze als schatting.
- **Geregistreerde verkoopwaarde:** som van gewonnen kansen op afsluitdatum; noem dit geen gefactureerde omzet zonder boekhoudkoppeling.

Maak duidelijk onderscheid tussen ‘instroom tijdens deze periode’, ‘afgesloten tijdens deze periode’ en een actuele pipelinefoto. Bewaar historie voor rapporten op een vroegere peildatum. Gebruik tijdzone Europe/Brussels voor weergave en consistente UTC-opslag.

Een verkoopkans die aan meerdere aanvragen is gekoppeld, mag financieel maar één keer meetellen. Bewaar de oorspronkelijke websitebron; rapporteer eerste aanvraagbron en laatste aanvraagbron apart. Noem dit geen volledige marketingattributie wanneer sessiehistorie ontbreekt. Ontbrekende campagnekosten betekenen dat CPL en ROI niet berekend kunnen worden. Toon onbekende waarden als onbekend en niet als nul.

Bewaar de eigenaar bij aanvraag, de toewijzingshistorie en de eigenaar bij afsluiten. Laat rapporten expliciet kiezen tussen huidige portefeuille en resultaat op afsluitmoment, zodat een herverdeling resultaten niet stilzwijgend herschrijft.

Lever CSV/XLSX-export en een overzichtelijk afdrukbaar/PDF-managementrapport met actieve filters, peildatum en KPI-definities. Exports respecteren dezelfde rechten en beschermen tegen spreadsheetformules in gebruikersinvoer. Dashboard en export gebruiken dezelfde rekenlogica.

## 8. KBO-prospectie als aanvullende module

Maak deze module onafhankelijk van de WordPress-intake. De dagelijkse leadopvolging moet volledig werken zonder KBO-account.

Gebruik uit de Resatec-export uitsluitend bruikbare patronen voor bedrijfszoekopdrachten, verrijking en contact-/dossierweergave. Relevante bestanden binnen de ZIP zijn:

- `site/lib/bce-prospection.ts`
- `site/app/api/prospection/bce/route.ts`
- `site/public/prospection.html`
- `site/public/assets/dashboard-client-explorer.js`

Belangrijke vaststellingen over deze export:

- `prospection.html` is een iframe-wrapper naar een afzonderlijke prospectieapp. De volledige broncode en database van die afzonderlijke app zijn niet opgenomen.
- De aanwezige KBO-adapter gebruikt server-side credentials en bevat filters gericht op retail, waaronder sectorcode `47`. Neem zulke Resatec-specifieke filters en postcode-/provincieheuristieken niet over als OPTIMAT-logica.
- De export bevat geen operationele accounts, wachtwoorden of live klantendatabase. De bestaande hosting en authenticatie zijn geen automatisch beschikbare infrastructuur voor dit project.

Gebruik een officiële of aantoonbaar gelicentieerde KBO-databron. Onderzoek vóór implementatie of de vereiste activiteit-/regiozoekopdrachten beter via toegestane Open Data of de Public Search-webservice kunnen worden uitgevoerd. Scrape de publieke zoekwebsite niet. Verifieer actuele voorwaarden, toegangsrechten, quota en kosten; hergebruik geen Resatec-credentials.

Gewenste functies: zoeken op bedrijfsnaam of ondernemingsnummer; zoeken/filteren op regio, postcode, relevante activiteit en actieve status waar de bron dit ondersteunt; bedrijfsfiche bekijken; controleren op een bestaand dossier; een geselecteerd bedrijf toevoegen als prospect en toewijzen aan een verkoper.

Laat geschikte NACE-BEL-activiteiten voor houtbewerking, interieurbouw, meubelproductie en verwante doelgroepen door marketing beheren, inclusief codeversie. Stel geen zogenaamd volledige doelgroep samen op basis van ongecontroleerde codes. Presenteer bedrijfsomvang, contactgegevens of machinebehoefte alleen wanneer die werkelijk uit een beschikbare bron komen.

Bewaar databron, actualisatiedatum en matchzekerheid. Verrijk een bestaand dossier met een zichtbare vergelijking; overschrijf geen handmatig bevestigde gegevens zonder controle. Nieuwe prospects tellen afzonderlijk van inkomende formulieraanvragen en beïnvloeden hun conversiecijfers niet.

Respecteer de beperkingen op hergebruik van persoonsgegevens voor directe marketing. Richt KBO-prospectie standaard op toegestane gegevens van rechtspersonen en sluit natuurlijke personen uit van deze prospectieselectie. Ook gegevens bij rechtspersonen kunnen persoonsgegevens bevatten. Deze beperking mag gewone, vrijwillig ingestuurde aanvragen van zelfstandigen niet uit de WordPress-intake weren. Automatiseer geen ongevraagde mailing vanuit de prospectietool.

Voor Nederland en Luxemburg blijft handmatige invoer/CSV-import beschikbaar. Toon KBO-dekking alleen voor België; beloof geen KvK- of Luxemburgse databron zonder een aparte integratie.

## 9. Ontwerp en mobiele ervaring

Ontwerp een rustige, moderne werkapp met OPTIMAT-identiteit: donkerblauw als basis, veel witruimte, goed contrast, consistente kaarten en duidelijke acties. Gebruik bestaande merkassets indien beschikbaar; gebruik `#131830` als voorlopige donkerblauwe basis. Vormgeving moet het dagelijks werk ondersteunen.

Desktopnavigatie: Overzicht, Aanvragen, Verkoopkansen, Bedrijven, Kaart, Taken, Rapporten, Prospectie en Instellingen. Verberg onderdelen waarvoor iemand geen rechten heeft. Geef iedere fiche een deelbare beveiligde URL.

Op mobiel: een compacte navigatie, grote aanraakvlakken, snelle zoekfunctie, kaarten in plaats van brede tabellen en vaste acties voor bellen, mailen en opvolgen. Ondersteun toetsenbordbediening, duidelijke focus, leesbare grafieken, lege toestanden en herstelbare foutmeldingen. Gebruik kleur nooit als enige statusindicatie.

Toon laad-, opslag-, synchronisatie- en verbindingsstatus helder. Bij verbindingsverlies mag een wijziging niet ten onrechte ‘opgeslagen’ lijken. Voorkom dat gelijktijdige edits elkaars notities of toewijzingen stilzwijgend overschrijven. Een installeerbare PWA is wenselijk; volledige offline bewerking en een native app zijn geen voorwaarde voor versie 1.

## 10. Technische uitvoering en beheer

Gebruik de bestaande geschikte projectstack als die aanwezig is. Kies anders een onderhoudbare, getypeerde frontend/backend met een relationele database, migraties, transacties en betrouwbare achtergrondtaken. Onderbouw de keuze kort. Gebruik geen browser-localStorage als centrale CRM-database en sla geen productiedata op in een publieke repository.

Accounts moeten praktisch bruikbaar zijn voor sales op pc en mobiel. Ondersteun uitnodigingen en intrekking van toegang; gebruik waar passend bestaande organisatieaanmelding. Neem niet automatisch de ChatGPT-aanmeldafhankelijkheid van Resatec over. Gebruik productie-authenticatie zonder testbypasses.

Voorzie server-side validatie, veilige sessies, bescherming van mutaties, beperkte bestandsuploads, private bijlagen, secrets buiten de client, auditlogging en bruikbare backups met beschreven herstelprocedure. Houd ruwe inzendingen en persoonsgegevens uit algemene foutlogs. Maak bewaartermijnen, gerichte export en verwijdering instelbaar zonder onnodige kopieën te laten voortbestaan. Gebruik een passende productieomgeving en documenteer hosting en verwerkers voor de beheerder.

Maak één beheerpagina voor bronverbindingen: laatste succesvolle ontvangst, connectorstatus, wachtrij, mislukte events, formuliermapping en testresultaten. Toon geen operationele foutmeldingen aan onbevoegde verkopers.

Seeddata zijn fictief, duidelijk gelabeld en gescheiden van productie. Bij nul echte leads toont productie een nuttige lege toestand. Externe diensten zonder configuratie krijgen een eerlijke status ‘nog niet gekoppeld’; alleen een demonstratiemodus gebruikt fixtures.

## 11. Bouwvolgorde en oplevering

Werk in samenhangende stappen door:

1. **Brononderzoek en fundament:** formulierregister, gegevensmodel, rollen, ontwerp en technische opzet.
2. **Werkende basisversie:** echte database, accounts, intake, fiche, toewijzing, taken, pipeline en betrouwbare connector voor de aangetroffen formulieren.
3. **Overzicht en rapportage:** Benelux-kaart, dashboards, filters, exports en historische import.
4. **Aanvullende prospectie:** KBO-provider, bedrijfsverrijking en prospectselectie, mits toegang beschikbaar is; anders volledige adapter met expliciete configuratiestatus.

Stel de koppeling niet uit tot na een uitgebreide visuele demo. Lever per stap een bruikbaar resultaat op en ga door naar de volgende stap voor zover die niet wordt geblokkeerd. Publicatie naar productie en wijzigingen aan live WordPress-formulieren gebeuren pas binnen de daarvoor verleende toegang en opdracht.

Lever de volledige broncode, database-migraties, WordPress-connector, installatiehandleiding, omgevingsvariabelen zonder geheimen, formuliermapping, importinstructies, beheerhandleiding en KPI-definities. Vermeld externe diensten en verwachte kostendragers zonder ongeverifieerde prijzen te verzinnen. Beschrijf concreet wat werkt, wat getest is en welke accounts of bronrechten nog nodig zijn.

## 12. Aantoonbare acceptatiecriteria

Verifieer minimaal deze scenario's met betekenisvolle integratie- en end-to-endtests:

1. Een demo-, offerte- en brochureaanvraag komt vanuit elke aangesloten website binnen met alle zakelijke velden en correcte machine-/productcontext. Test per daadwerkelijk aangetroffen provider en mapping, ook taalvarianten en nieuwe onbekende velden.
2. Dezelfde inzending drie keer aanbieden levert één aanvraag op. Een nieuwe aanvraag van hetzelfde bedrijf behoudt haar eigen historie. Een latere bronwijziging overschrijft geen verkoopnotitie of eigenaar.
3. Na tijdelijke onbereikbaarheid van de app worden in WordPress bewaarde events alsnog correct verwerkt; de wachtrij en foutstatus zijn controleerbaar.
4. Een manager wijst een aanvraag toe; de juiste verkoper ziet die op pc en mobiel. Een andere verkoper kan het dossier ook via een directe URL, API, export of kaart niet opvragen.
5. Opvolgstatus, taak en verkoopfase blijven behouden na herladen en zijn op een tweede apparaat bijgewerkt. Een gelijktijdige wijziging wordt correct afgehandeld.
6. Twee aanvragen kunnen naar dezelfde verkoopkans verwijzen zonder dubbele financiële telling. Een gewonnen kans telt met bedrag en afsluitdatum; een ontbrekend bedrag blijft zichtbaar als ontbrekend.
7. Testadressen in België, Nederland en Luxemburg verschijnen correct; een postcodecentrum is als benadering herkenbaar en een ontbrekend adres produceert geen verzonnen marker.
8. Lijst, kaart, dashboard en export volgen dezelfde filters en rechten. KPI's worden met een kleine bekende testdataset inclusief open, verloren, heropende en herverdeelde kansen nagerekend.
9. Een brochureaanvraag blijft apart herkenbaar van een offerteaanvraag; een gecombineerde aanvraag behoudt beide intenties. KBO-prospects tellen niet als websiteleads.
10. De belangrijkste mobiele taken werken op circa 390 px schermbreedte zonder horizontaal scrollen: fiche openen, bellen, notitie opslaan, taak plannen en fase aanpassen.
11. De app blijft bruikbaar als KBO, geocodering of notificatie-e-mail tijdelijk uitvalt. Ontbrekende configuratie wordt nergens als werkende live integratie voorgesteld.
12. Bij oplevering is de dekking per website, provider en formulier zichtbaar: live getest, alleen contractmatig getest, uitgesloten met reden of nog te configureren.

Begin met het onderzoek en bouw vervolgens de eerste complete gegevensstroom: **WordPress-inzending → betrouwbare ontvangst → aanvraagfiche → toewijzing → verkopersopvolging → managementcijfer**. Werk daarna door totdat de beschreven onderdelen zijn opgeleverd of een specifieke externe afhankelijkheid aantoonbaar blokkeert.

---

## Referenties voor de uitvoerende Codex-sessie

Deze verwijzingen zijn gecontroleerd op 27 oktober 2026 en vervangen de inventarisatie in de daadwerkelijke WordPress-omgeving niet.

- [OPTIMAT: voorbeeld productpagina met brochure- en offerteformulier](https://www.optimat-group.com/producten/heesemann-breedbandschuurmachines/). Het brochureformulier bevat ook een vraag naar prijsindicatie/offerte; bewaar die extra intentie.
- [KDT: voorbeeld machinepagina met offerte- en brochureacties](https://kdt.optimat-group.com/machine/kn-3710-nesting-cnc/).
- [KDT: contactformulier](https://kdt.optimat-group.com/contact/).
- [FOD Economie: Webservice Public Search](https://economie.fgov.be/nl/themas/ondernemingen/kruispuntbank-van/diensten-voor-iedereen/hergebruik-van-publieke/kruispuntbank-van).
- [FOD Economie: KBO Open Data, toegang en beperkingen op hergebruik](https://economie.fgov.be/nl/themas/ondernemingen/kruispuntbank-van/diensten-voor-iedereen/hergebruik-van-publieke/kruispuntbank-van-0).
- De meegeleverde Resatec-ZIP is bronmateriaal voor beoordeling en gerichte herbruikbare patronen; geen opdracht om IVO, administratieve fiches, PDF-/Outlook-integratie, NFC of een offertegenerator te kopiëren.
