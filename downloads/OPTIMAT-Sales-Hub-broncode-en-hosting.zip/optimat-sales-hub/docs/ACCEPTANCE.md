# Acceptatie en dekkingsgrenzen

Dit document onderscheidt lokale contract-/integratietests van werkelijke WordPress-, provider- en productietests. Voer de vermelde commando’s uit en bewaar de actuele resultaten bij de release. De aanwezigheid van een testbestand bewijst niet dat die test al geslaagd is.

## Uitgevoerde controles op 27 oktober 2026

- `npm test`: 44 tests geslaagd, geen mislukt of overgeslagen. Dit omvat HTTP-authenticatie/intake, CRM/KPI-rekenlogica, teamrechten, historische filters, kaartrechten, private bijlagen/verwijdering, KBO-/geocodingcontracten, Brussels-datumgrenzen en werkelijk CLI-backup/herstel.
- `PLAYWRIGHT_CHROMIUM_EXECUTABLE=/usr/bin/chromium npm run test:e2e`: vier browsertests geslaagd op de gebouwde frontend: desktopopvolging/pipeline, mobiel 390 px inclusief fasekeuze zonder documentoverflow geweigerde directe toegang voor een andere verkoper en de Gravity Forms-configuratie van twee bronnen met opeenvolgende mappingversies. De fixture draait uitsluitend in een afzonderlijke in-memory database.
- `npm run build`: TypeScript-controle en productiebuild geslaagd als onderdeel van de browserrunner.
- Connector: PHP-syntaxcontrole en 71 connector-/Gravity Forms-controles en 23 geïsoleerde bijlagencontroles geslaagd met de PHP-WebAssembly-runtime, zoals beschreven in WORDPRESS. Geen live WordPress-/MySQL-/providercheck.
- Productiecontainer: multistage Docker-build geslaagd; loginpagina en gezondheid HTTP 200, onbevoegde CRM-toegang 401, UID 1000, alleen-lezen systeem, private volumes 0700, back-up 0600 en behoud van bronregistraties/back-up na herstart. Compose en Caddy gevalideerd; geen publieke hosting, DNS of live TLS ingesteld. Testcontainer en testvolumes zijn opgeruimd.
- Ondertekende HTTP-ontvangst tot zichtbare aanvraag met de automatische serverwerker: circa één seconde in de lokale contracttest; de 15-seconden-doelstelling is niet vanaf een echt WordPress-formulier gemeten.

De Playwright-browserdownload werd door het cloudnetwerk geweigerd; de reeds geïnstalleerde Chromium is gebruikt. Dit verandert geen TLS-, checksum- of ondertekeningscontrole.

## Geautomatiseerde contracttests

`npm test` start betekenisvolle HTTP-integratietests met tijdelijke SQLite-databases. De tests maken persoonlijke synthetische accounts en een synthetische ondertekende bron. Productiedata worden niet gebruikt of gezaaid.

| Scenario                                                                                                  | Bewijs in broncode     | Grens                                                                      |
| --------------------------------------------------------------------------------------------------------- | ---------------------- | -------------------------------------------------------------------------- |
| Ondertekende ontvangst en verwerking                                                                      | `tests/intake.test.ts` | Synthetisch contract; geen live WordPress                                  |
| Drie afleveringen leveren één event en aanvraag                                                           | `tests/intake.test.ts` | Werkelijke unieke sleutels in SQLite                                       |
| Hogere bronversie bewaart eigenaar/notitie/taak; oude versie zet niets terug                              | `tests/intake.test.ts` | Bronverwerking, geen providerspecifieke wijzigingshook                     |
| Nieuwe aanvraag met hetzelfde gevalideerde ondernemingsnummer blijft eigen aanvraag                       | `tests/intake.test.ts` | Geen onzekere automatische naam-/domeinmerge                               |
| Brochure én offerte-intentie blijven behouden                                                             | `tests/intake.test.ts` | Mapping van werkelijke formulieren nog te valideren                        |
| Onbekende zakelijke velden zichtbaar, CAPTCHA verwijderd                                                  | `tests/intake.test.ts` | Reële providers/compoundvelden apart controleren                           |
| Toewijzing en verkopersafscherming op detail, lijst, kaart, rapport en CSV                                | `tests/intake.test.ts` | Per directe API-route gecontroleerd                                        |
| Conflicterende versies geven 409                                                                          | `tests/intake.test.ts` | Geen stilzwijgende overschrijving                                          |
| Persoonlijke sessie, CSRF en ongeldige Origin                                                             | `tests/auth.test.ts`   | Echte cookie-/HTTP-stroom                                                  |
| Eenmalige uitnodiging en ingetrokken account                                                              | `tests/auth.test.ts`   | Geen mailaflevering bewezen                                                |
| Automatische serverwerker verwerkt ondertekende ontvangst binnen 15 seconden                              | `tests/intake.test.ts` | Gemeten vanaf HTTP-ontvangst; live WordPress-doorlooptijd nog niet bewezen |
| Rotatie accepteert vorige sleutel alleen zolang geconfigureerd; gewijzigde event-ID-inhoud geeft conflict | `tests/intake.test.ts` | Afzonderlijke synthetische brongeheimen                                    |
| Onjuiste/verlopen HMAC wordt niet opgeslagen                                                              | `tests/intake.test.ts` | Retry moet actuele aflevertimestamp gebruiken                              |

Aanvullende scenario’s staan in `tests/crm.test.ts`, `tests/geocoding.test.ts`, `tests/kbo.test.ts`, `tests/privacy.test.ts`, `tests/time.test.ts`, `tests/backup.test.ts`, `tests/gravity-sync.test.ts` en `tests/e2e.spec.ts`. Controleer de actuele runners opnieuw na relevante wijzigingen.

## Broninventaris

| Website                 | Provider/formulier-ID                                | Dekking bij eerste onderzoek                                                 |
| ----------------------- | ---------------------------------------------------- | ---------------------------------------------------------------------------- |
| `www.optimat-group.com` | Gravity Forms door gebruiker bevestigd; IDs onbekend | Publieke pagina’s geblokkeerd door cloudnetwerkbeleid; geen WP-beheertoegang |
| `kdt.optimat-group.com` | Gravity Forms door gebruiker bevestigd; IDs onbekend | Publieke pagina’s geblokkeerd door cloudnetwerkbeleid; geen WP-beheertoegang |

Het formulierregister blijft onvolledig totdat een bevoegde beheerder alle actieve formulieren, taalversies, pop-ups, templates, verborgen productvelden en niet-commerciële formulieren heeft geïnventariseerd. De gebruiker heeft Gravity Forms voor beide websites bevestigd; de geïnstalleerde versie en echte formulier-ID’s zijn nog niet vanuit WordPress gecontroleerd. Er wordt geen provider afgeleid uit domein of visuele vormgeving.

Voor productie zijn per werkelijk formulier nodig: website, provider, ID, taal, doel/routing, velddefinitie, mappingversie, bekende intenties, bronopslag, integratiehook, bronwijzigingsgedrag en testresultaat. Sollicitaties mogen niet in commerciële dossiers terechtkomen. Support en nieuwsbriefinschrijvingen krijgen passende eigen routing en rechten.

## Gravity Forms-uitbreiding

Zie [GRAVITY-FORMS.md](GRAVITY-FORMS.md) voor de twee afzonderlijke bronverbindingen, ondertekende formulierinventaris, gecontroleerde veldmapping en installatie-/acceptatiestappen. `tests/gravity-sync.test.ts` controleert het metadataontvangstcontract; de browser-suite bevat een afzonderlijke configuratiestroom met twee bronnen en twee opeenvolgende mappingversies. Alleen synthetische metadata wordt hiervoor gebruikt. Geen van deze tests installeert een plugin op de echte websites. De actuele browserrunner heeft vier tests zonder mislukkingen uitgevoerd; de Gravity-configuratietest ontving metadata via de echte ondertekende route en sloeg mappingversies 2 en 3 op. De gerichte HTTP-suite controleert daarnaast een vastgehouden entry tot mapping is goedgekeurd, compound-ID’s en herstel zonder overschreven verkoopsopvolging.

## Handmatige acceptatie vóór productie

- Dien vanuit elke aangesloten website een demo-, offerte- en brochureformulier in, inclusief taalvarianten en gecombineerde intenties. Controleer bestaande mails en brochurelevering.
- Zet de app tijdelijk uit, dien in WordPress in en herstel de app. Controleer de outbox, retries, wachtrij en uiteindelijke éénmalige verwerking. Meet normale doorlooptijd vanaf succesvolle formulierinzending; streef maximaal 15 seconden na installatie van geschikte servercron.
- Controleer op twee apparaten de zichtbaarheid van een managerstoewijzing en opgeslagen taken/statussen. Probeer als een andere verkoper directe beveiligde URLs en exports.
- Koppel twee aanvragen aan één verkoopkans. Controleer één financiële telling, winst/verliesredenen, heropening, eigenaar bij afsluiten en ontbrekende waarde.
- Gebruik gecontroleerde BE/NL/LU-locaties. Bevestig dat adresprecisie en postcodebenadering verschillen, onbekende locaties geen marker krijgen en provideruitval een bruikbare lijst houdt.
- Reken cohortconversie, contacttijd, winratio en pipeline na met een bekende dataset. Controleer dezelfde filters in lijst, kaart, dashboard en export; toon onbekende waarden niet als nul.
- Controleer op circa 390 px: dossier openen, bellen/mailen, menselijke contactactie registreren, notitie opslaan, taak plannen en fase aanpassen zonder horizontaal scrollen.
- Controleer backups/herstel, beveiligde hosting en bewaartermijn-/verwijderprocedures met testgegevens.

## Externe afhankelijkheden

WordPress-livekoppeling vereist installatierechten, werkelijke providerinventaris en brongeheimen. KBO vereist een officiële of aantoonbaar gelicentieerde bron, actuele voorwaarden/quota/kosten en eventuele credentials; de officiële documentatie was vanuit deze omgeving niet bereikbaar. Kaart/geocodering en notificatiemail vereisen goedgekeurde leveranciersconfiguratie. Geen van deze diensten wordt zonder aantoonbare aansluiting als operationeel weergegeven.

De Resatec-tekstexport is onderzocht op gerichte patronen. De losse prospectieapp achter het iframe ontbreekt. Resatec-retailfilters, postcodeheuristieken, toegangsregels en hosting vormen geen OPTIMAT-functionaliteit.
