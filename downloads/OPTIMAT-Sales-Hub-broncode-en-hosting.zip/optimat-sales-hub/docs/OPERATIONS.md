# Beheer en exploitatie

## Hosting en gegevens

Gebruik één Node.js 24+-instantie achter een HTTPS-reverse-proxy. Bewaar het SQLite-bestand en de WAL-bestanden op een persistent lokaal volume met beperkte filesystemrechten. Gebruik geen vluchtige containerlaag voor klantgegevens. De synchronisatiewerker draait in het applicatieproces; het proces moet dus permanent draaien en automatisch herstarten. Meerdere replicas op hetzelfde SQLite-bestand zijn geen ondersteunde productieopstelling.

Zet `NODE_ENV=production` en `APP_URL` op de precieze HTTPS-oorsprong. Productiesessies gebruiken een Secure/HttpOnly/SameSite-cookie. Sla geheimen op in de hostingsecretmanager. De bronconfiguratie bevat alleen een variabelenaam, nooit een geheim. HMAC-ondertekening, wachtwoordhashing en KBO WS-Security-digests worden lokaal berekend en vereisen daarvoor de echte sleutel/wachtwoordwaarde in de beveiligde hostingomgeving. Proxygeheimen die alleen een placeholder aan het proces leveren zijn hiervoor niet bruikbaar: de proxy kan geen reeds berekende lokale digest vervangen. Configureer deze cryptografische geheimen daarom bij de daadwerkelijke WordPress-/apphost; plaats ze niet in een cloudconcept of repository. Onderzoek en leg voor ingebruikname de gekozen hostingpartij, locatie, verwerkersovereenkomst en eventuele subverwerkers vast.

Kosten worden bepaald door hosting, opslag/backups, kaarttegels, geocodering, mail en eventueel gelicentieerde KBO-toegang. Deze oplevering doet geen ongeverifieerde prijsbelofte. Stuur geen CRM-velden naar een leverancier voordat de beheerder de doelbinding en voorwaarden heeft beoordeeld.

## Accounts en rechten

Maak de eerste beheerder uitsluitend aan via de bootstrap-CLI en deel diens wachtwoord via een beveiligd kanaal. Maak daarna persoonlijke accounts met uitnodigingen. Een uitnodiging is tijdelijk en eenmalig. Deel links gericht; plaats ze niet in issues, algemene logs of deze repository.

Intrekken of wijzigen van toegang beëindigt bestaande sessies. Verkopers zijn beperkt tot toegewezen aanvragen en hun eigen verkoopkansen. Marketing/management heeft standaard leestoegang; een bron-/campagnebeheermachtiging moet afzonderlijk worden toegekend en op de server worden afgedwongen. Voor managers en management beperkt een ingevuld team de toegewezen dossiers tot dat team; zonder team is de rol organisatiebreed. Niet-toegewezen commerciële intake blijft te beoordelen werk. Een beheerder behoudt organisatiebrede toegang. Teamtoegang en herverdeling worden ook bij directe API-aanroepen gecontroleerd. Een verborgen menuknop vervangt nooit de servercontrole.

## Synchronisatiebeheer

Controleer in Instellingen de bronstatus, laatste ontvangst, formulierdekking en verwerkingswachtrij. “Contractmatig getest” is niet “live getest”. Voer bij ingebruikname voor elke website/provider/formulier/taal een echte testinzending uit en controleer alle zakelijke velden, productcontext, extra intenties en de bestaande bevestigingsmail/brochurelevering.

Herlevering van hetzelfde event levert geen nieuwe aanvraag op. Een bronupdate gebruikt een hogere bronversie en behoudt verkopersnotities, taken en toewijzing. Verouderde updates mogen nieuwere brongegevens niet terugzetten. De connector maakt voor iedere retry een actuele afleverhandtekening; de oorspronkelijke inzenddatum blijft behouden.

Bij uitval bewaart WordPress eerst de inzending in de lokale outbox. Laat servercron de outbox afhandelen; uitsluitend bezoekersgestuurde WP-Cron is onvoldoende voor een doorlooptijddoel van 15 seconden. Herstel daarna de verbinding, speel mislukte events opnieuw af en controleer aantallen. De Gravity Forms-module gebruikt opgeslagen bronentries voor gecontroleerde reconciliatie; controleer de expliciete toelatingslijst, checkpoint, laatste afgeronde cyclus en fouten volgens GRAVITY-FORMS. Een ondersteunde providerfunctie is nog geen live geverifieerde bron. Andere providers blijven oncontroleerbaar via reconciliatie totdat hun eigen adapter is uitgevoerd en getest. Gravity Forms-bestanden gebruiken een afzonderlijke ondertekende route met type-/groottecontrole en private opslag. De installatie en bronrechten op beide websites blijven vereist.

## Backups en herstel

Gebruik `npm run backup` om een consistente SQLite-backup te maken; met `BACKUP_DIR` kies je de privélocatie. De CLI maakt alleen een databasebackup. Bewaar het private `ATTACHMENT_DIR` daarnaast in een bijbehorende versleutelde bestandssnapshot. Stop tijdelijk mutaties wanneer database en bestanden samen worden vastgelegd, zodat verwijderde of nieuw toegevoegde bijlagen niet tussen de twee snapshots vallen. Maak backups buiten de publieke webroot. Versleutel ze, beperk toegang en stel een eindige bewaartermijn vast. Een schema-export of Git-repository is geen klantgegevensbackup.

Herstelprocedure:

1. Stop de applicatie en de connectoraflevering tijdelijk; laat WordPress de outbox bewaren.
2. Bewaar de huidige database voor gecontroleerde diagnose op een afgeschermde locatie.
3. Zet de gekozen consistente databasebackup terug op het pad uit `DB_PATH`, met dezelfde beperkte rechten. Herstel de bijbehorende private bijlagen naar `ATTACHMENT_DIR`; een databasebackup alleen herstelt geen bestandsinhoud.
4. Start de applicatie en voer migraties/gezondheidscontrole uit. Controleer accounts, recente aanvragen, taken en kansen.
5. Herstart connectoraflevering en speel achtergebleven events af. Controleer idempotentie en ontbrekende events tegen broninzendingen waar mogelijk.
6. Leg herstelpunt, gegevensverliesvenster en resultaat vast. Test deze procedure vóór productie en daarna periodiek met een geïsoleerde kopie.

Live processen en verbindingen horen niet bij een cloudsnapshot. Start het applicatieproces opnieuw na herstel en verifieer ontvangst én verwerking.

## Bewaartermijnen, gerichte inzage en verwijdering

Stel een passende bewaartermijn in en beoordeel aanvragen, events, auditregels, backups en WordPress-outbox samen. Een instelwaarde is pas een uitgevoerde verwijdering wanneer een gecontroleerde verwijderprocedure de betrokken gegevens werkelijk heeft afgehandeld. De beheer-API biedt een kandidatenlijst via `GET /api/admin/privacy/retention`, een gerichte dossierexport via `GET /api/admin/privacy/requests/:id/export` en versiegecontroleerde verwijdering via `DELETE /api/admin/privacy/requests/:id` met `{version, reason}`. Gebruik daarvoor een normale beheerderssessie en het CSRF-token. Bestandsverwijderingen worden op een private opruimwachtrij herprobeerd. Dit verwijdert niet automatisch bronsubmissies en backups. Er is geen automatische bulkvernietiging op basis van alleen de ingestelde termijn.

Aanvraaggegevens en KBO-records zijn geen nieuwsbriefopt-in. Bewaar aangeleverde toestemming en tekstversie alleen waar beschikbaar. Houd CAPTCHA-/wachtwoordvelden, ruwe aanvraaginhoud en persoonsgegevens uit algemene foutlogs. Exports bevatten persoonsgegevens: deel ze gericht en verwijder tijdelijke kopieën.

## Gates voor externe diensten

KBO blijft uit tot `KBO_ENABLED=true`, `KBO_TERMS_CONFIRMED=true` en bruikbare `BCE_WS_USERNAME`/`BCE_WS_PASSWORD` aanwezig zijn. Bevestig actuele voorwaarden, quota en kosten rechtstreeks met de provider voordat die gates worden aangezet. Naam-/nummerzoeken hebben contracttests; postcode-/regio-/activiteitzoeken en niet-Belgische databronnen zijn niet geïmplementeerd en worden niet beloofd.

Geocodering gebruikt een Photon-compatibel HTTPS-endpoint uit `GEOCODING_URL` en vereist `GEOCODING_TERMS_CONFIRMED=true`. Kaarttegels gebruiken `MAP_TILE_URL` plus geldige `MAP_TILE_ATTRIBUTION`. Bekijk de bijbehorende voorwaarden, privacy, capaciteit en kosten. Deze gates zijn beheerbevestigingen, geen bewijs dat er al een succesvolle live request is uitgevoerd.

## Monitoring

Monitor procesherstarts, databasebeschikbaarheid, schijfruimte, backupresultaat, wachtrijleeftijd en mislukte events. Een open poort bewijst geen werkende intake: verstuur een afzonderlijk herkenbaar synthetisch contractevent en controleer duurzame ontvangst én verwerking. Doe dat in een testbron/testdatabase, zodat commerciële cijfers niet vervuilen.

Een klik op bellen of mailen telt niet als contactactie. Alleen een expliciet geregistreerd gesprek, menselijke e-mail of afspraak mag in opvolgingscijfers meetellen. Rapporteer geregistreerde verkoopwaarde niet als gefactureerde omzet zonder boekhoudkoppeling.
