# Hosting en een eerste eigen URL

De Sales Hub heeft **nog geen hostingaccount, geregistreerde URL of publieke installatie**. De bestanden in `deploy/` bereiden een zelfstandige installatie voor. Ze maken geen account aan, veranderen geen DNS, bestellen niets en publiceren niets op WordPress.

Een mogelijke naam is `sales.optimat-group.com`. Dat is uitsluitend een voorstel: beschikbaarheid, DNS-beheer en toestemming zijn niet geverifieerd. Kies een hostnaam die de organisatie daadwerkelijk beheert. Gebruik diezelfde HTTPS-oorsprong als app-URL en later als bestemming van beide WordPress-connectors.

## Geschikte host

Gebruik één Linux-VM of containerhost met Docker Engine en Docker Compose v2, persistent lokaal opslagvolume en inkomende TCP-poorten 80/443 (UDP 443 is optioneel). Begin met één app-instantie; SQLite en de in-process wachtrij zijn niet bedoeld voor meerdere replica's of een gedeeld netwerkbestandssysteem. Houd voldoende vrije schijfruimte voor database, bijlagen en backups. Een gewone WordPress-sharedhosting ondersteunt niet automatisch een permanent Node.js 24-proces of Docker; vraag de host dit specifiek.

De beheerder moet vooraf een host/account, locatie, verwerkersovereenkomst, toegang voor beheer en externe backupopslag kiezen. Kosten kunnen ontstaan voor VM, opslag, backups en optionele providers. Deze handleiding kent geen account of ongeverifieerde prijzen toe. Gebruik productiegegevens pas nadat opslag, beveiligde toegang, herstel en toepasselijke verwerkersafspraken zijn geregeld.

Architectuur: internet → Caddy op 80/443 → app op het private Compose-netwerk, poort 3000 → lokale SQLite/private bestanden. De database, bijlagen, backups en Caddy-certificaten krijgen aparte blijvende Docker-volumes. De API krijgt geen hostpoort; `TRUST_PROXY=1` is uitsluitend geschikt met deze ene vertrouwde reverse proxy. Publiceer poort 3000 niet naast Caddy.

## Eenmalige installatie op de gekozen host

Deze commando's zijn voor de toekomstige Linux-host, vanuit de root van deze repository. Ze zijn geen opdracht om tijdens ontwikkeling een productieomgeving te publiceren.

1. Installeer Docker via de officiële distributie-instructies en haal deze repository naar een afgeschermde map op de host. Gebruik de bestaande checkout; een Git-worktree is niet nodig.
2. Laat de DNS-beheerder een A-record (en uitsluitend indien de host werkende IPv6 heeft een AAAA-record) voor de gekozen hostnaam naar deze host verwijzen. Open de vereiste firewallpoorten en controleer dat geen andere webserver 80/443 gebruikt. Caddy kan pas daarna openbare certificaten uitgeven.
3. Maak de lokale configuratie:

   ```bash
   umask 077
   cp deploy/environment.example deploy/.env
   chmod 600 deploy/.env
   ```

   Vul `PUBLIC_DOMAIN` in zonder `https://`, poort of pad. Laat externe diensten uit totdat hun toegang beschikbaar is. Bewaar echte geheimen uitsluitend in de beveiligde hostingomgeving of dit beperkte, niet bijgehouden configuratiebestand. Het image bevat geen `.env`, database of klantgegevens. Docker-hostbeheerders kunnen containeromgevingsvariabelen inspecteren: beperk daarom ook toegang tot de Docker-daemon.

4. Definieer in een Bash-terminal een korte helper; de volgende stappen gebruiken die:

   ```bash
   dc() { docker compose --env-file deploy/.env -f deploy/compose.yaml "$@"; }
   dc config --quiet
   dc build --pull app
   dc up -d app
   dc exec -T app node -e "fetch('http://127.0.0.1:3000/api/health').then(async r=>{if(!r.ok||(await r.json()).status!=='ok')process.exit(1)}).catch(()=>process.exit(1))"
   dc exec -T app npm run sources:init
   ```

   `config --quiet` valideert zonder configuratiewaarden af te drukken. Gebruik geen volledige `docker compose config`-uitvoer in logs of chat: die kan echte geheimen bevatten. De app voert database-migraties bij het opstarten uit. `sources:init` registreert de twee WordPress-bronnen zonder leads of live verbindingen aan te maken.

Een host met een bedrijfsproxy kan extra buildinstellingen nodig hebben. Gebruik uitsluitend de vertrouwde root-CA van die organisatie; schakel TLS-verificatie niet uit. De Dockerfile ondersteunt een optionele BuildKit-secret `npm_ca` die alleen tijdens `npm ci` wordt gemount. Voorbeeld, met een door de beheerder gecontroleerd CA-bestand en reeds ingestelde proxyvariabelen:

```bash
docker build --build-arg HTTP_PROXY --build-arg HTTPS_PROXY --build-arg NO_PROXY --secret id=npm_ca,src=/beveiligd/pad/organisatie-ca.pem --tag optimat-sales-hub:local .
```

De proxywaarden zijn Docker-standaardbuildargumenten; voeg ze niet als `ENV` toe aan het image. Het CA-bestand wordt niet naar het runtime-image gekopieerd. Op een host zonder zo'n proxy zijn deze opties niet nodig.

5. Maak één persoonlijke beheerder met invoer via de beveiligde hostterminal. Het wachtwoord staat niet in de commandoregel of shellgeschiedenis. Voer dit uit met shelltracing uit:

   ```bash
   set +x
   read -rp 'Beheerdersnaam: ' ADMIN_NAME
   read -rp 'E-mail beheerder: ' ADMIN_EMAIL
   read -rsp 'Wachtwoord (minimaal 12 tekens): ' ADMIN_PASSWORD
   printf '\n'
   export ADMIN_NAME ADMIN_EMAIL ADMIN_PASSWORD
   dc exec -e ADMIN_NAME -e ADMIN_EMAIL -e ADMIN_PASSWORD app npm run bootstrap
   unset ADMIN_NAME ADMIN_EMAIL ADMIN_PASSWORD
   ```

   Voer bootstrap pas uit nadat de app gezond is. Er kan maar één eerste beheerder worden gemaakt; gebruik daarna persoonlijke uitnodigingen. Plaats bootstrapwaarden niet in `deploy/.env` en deel ze niet in chat. De container draait als gebruiker `node`; `/data` en zijn private submappen zijn alleen voor die gebruiker toegankelijk. Het opstartproces gebruikt `umask 077`.

6. Start HTTPS op de echte host:

   ```bash
   dc up -d caddy
   dc ps
   ```

   Controleer op de eigen HTTPS-URL de login, een persoonlijke sessie en een lege CRM-startpagina. Controleer het geldige TLS-certificaat en een nieuwe uitnodiging op een tweede apparaat. `GET /api/health` moet `{ "status": "ok" }` teruggeven. Een gezond proces alleen bewijst nog geen werkende WordPress-intake.

## WordPress daarna aansluiten

Gebruik [GRAVITY-FORMS.md](GRAVITY-FORMS.md) voor de broninventarisatie, expliciete toelatingslijst, mapping, outbox en scheduler. Stel per website een ander cryptografisch willekeurig gedeeld geheim in op de apphost en in de connector. Gebruik `OPTIMAT_WP_MAIN_SECRET` en `OPTIMAT_WP_KDT_SECRET` uit de voorbeeldconfiguratie. Dit zijn echte lokale HMAC-sleutels: een proxyplaceholder kan de lokaal berekende handtekening niet vervangen. De optionele vorige sleutel geldt alleen tijdens een begrensde rotatie en moet ook via `previous_secret_env` in de bron zijn aangewezen.

Na een wijziging in de hostingconfiguratie: `dc up -d app` en controleer de gezondheid opnieuw. Installeer de connector alleen met verleende WordPress-rechten. Controleer echte aanvragen per bron, formulier en taal en bevestig dat bestaande e-mails/brochurelevering intact blijven. Pas na deze controles is de bron live getest.

## Backups, herstel en updates

- `dc exec -T app npm run backup` maakt een consistente databasebackup in het private backupvolume. Dit is **geen** volledige bestandsbackup en geen externe backup. Bewaar de bijbehorende private bijlagen samen met de database volgens [OPERATIONS.md](OPERATIONS.md), versleutel ze buiten deze host en stel een bewaartermijn in. Regel een dagelijkse scheduler en controleer diens resultaat; Compose voegt geen backupservice of externe opslag toe.
- Maak vóór een versie-update een herstelbaar database- én bijlagenherstelpunt. Voer daarna `dc build --pull app` en `dc up -d app` uit; controleer gezondheid, login, recente dossiers en intake. Beoordeel migraties vooraf. Alleen een oud image terugzetten herstelt een gemigreerde database niet.
- Docker-volumes blijven bij `dc down` behouden. **`dc down -v` verwijdert de CRM-volumes en is geen normale update- of stopopdracht.** Volumes op één host beschermen niet tegen hostverlies.
- Test herstel op een geïsoleerde kopie vóór productie en periodiek daarna. Controleer accounts, bijlagen, taken, aantallen en connectorherlevering. De herstelprocedure staat in OPERATIONS.md.
- Beperk SSH/Docker-toegang, houd host en base-images bijgewerkt en controleer logs, schijfruimte, wachtrijleeftijd en verlopen backups. Caddy logt standaard geen request-accesslog in deze configuratie. Vermijd persoonsgegevens en querystrings in algemene logs.

De image-tags `node:24-bookworm-slim` en `caddy:2-alpine` volgen ondersteunde hoofdversies. Leg voor een formele productierelease de daadwerkelijk geteste image-digests vast en herbouw gecontroleerd bij beveiligingsupdates. De huidige configuratie maakt geen specifieke beveiligingscertificering of productiegereedheid zonder deze operationele controles aannemelijk.

## Wat nog buiten deze repository moet gebeuren

De organisatie kiest de host, DNS-naam, veilige beheertoegang en backupbestemming. Daarna kunnen de installatiestappen op die host worden uitgevoerd. Een lokale image-/containercheck in de ontwikkelomgeving registreert geen domein, geeft geen publieke TLS-test, publiceert niets en bewijst niet dat de toekomstige host bereikbaar is. Kaart-/geocoding-, mail- en KBO-toegang blijven afzonderlijke optionele configuraties; hun ontbreken blokkeert de dagelijkse intake en opvolging niet.
