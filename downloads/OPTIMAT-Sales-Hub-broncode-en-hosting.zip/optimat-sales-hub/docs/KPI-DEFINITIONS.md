# KPI-definities

Deze definities komen uit `server/reporting.ts`; dashboard en Excel gebruiken dezelfde berekening. UTC-opslag, weergave en kalenderdagfilters in Europe/Brussels.

| Maatstaf                     | Definitie                                                                                                                                                                                       |
| ---------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `requests`                   | Unieke geldige commerciële inzendingen uit het instroomcohort; herleveringen, spam en testdata uitgesloten.                                                                                     |
| `companies`                  | Unieke bedrijven gekoppeld aan dit instroomcohort; losse prospects tellen niet mee.                                                                                                             |
| `opportunities`              | Unieke gekwalificeerde verkoopkansen gekoppeld aan het instroomcohort.                                                                                                                          |
| `follow_up_rate`             | Aandeel aanvragen uit het instroomcohort met minstens één geregistreerde menselijke contactactie op de peildatum. Ongecontacteerde aanvragen blijven in de noemer.                              |
| `median_first_contact_hours` | Mediaan uren van ontvangst tot de eerste geregistreerde bel-, mail- of gespreksactie; automatische ontvangstmail en notities tellen niet.                                                       |
| `p90_first_contact_hours`    | 90e percentiel met lineaire interpolatie van dezelfde contacttijden.                                                                                                                            |
| `lead_conversion`            | Aandeel commerciële aanvragen uit het instroomcohort gekoppeld aan minstens één gewonnen verkoopkans; elke aanvraag telt maximaal één keer.                                                     |
| `company_conversion`         | Aandeel bedrijven uit het instroomcohort met minstens één gewonnen verkoopkans gekoppeld aan dat cohort.                                                                                        |
| `win_ratio`                  | Gewonnen / (gewonnen + verloren) kansen op afsluitdatum binnen de periode. Open kansen uitgesloten.                                                                                             |
| `open_pipeline_value`        | Actuele pipelinefoto op peildatum: som van geregistreerde bedragen van open kansen; ontbrekende waarden zijn onbekend.                                                                          |
| `won_value`                  | Som geregistreerde waarde van gewonnen kansen met afsluitdatum in de periode; geen gefactureerde omzet.                                                                                         |
| `quote_value`                | Pipelinefoto: geregistreerde bedragen van kansen in offertefase op de peildatum.                                                                                                                |
| `lost_value`                 | Geregistreerde bedragen van verloren kansen met afsluitdatum in de periode.                                                                                                                     |
| `ownership`                  | Rechten volgen de huidige portefeuille. Bij ownership=at_close wordt de geselecteerde verkoper op afsluitmoment gefilterd voor afsluitcijfers; cohort en pipeline blijven huidige portefeuille. |

Ontbrekende waarden zijn onbekend. Geen cohort of geen afgesloten kansen betekent een onbekend percentage, geen nulpercentage. Historische filterdimensies en verkoopfase/waarde/koppelingen worden opgeslagen vanaf aanmaak; bij bestaande gegevens is het eerste bekende migratiemoment de grens. Historische vrije-tekstzoekopdrachten gebruiken de huidige toegankelijke dossiertekst.

CSV bevat het gekozen cohort; Excel bevat dezelfde cohortregels en de KPI-berekening. Open pipeline is een aparte foto op peildatum, afsluitcijfers gebruiken afsluitdatum. De printweergave kan als PDF worden opgeslagen. Campagnekosten, gefactureerde omzet en volledige sessieattributie ontbreken: CPL, ROI en factuuromzet worden niet verzonnen.
