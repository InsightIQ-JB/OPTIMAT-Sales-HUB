# WordPress / Gravity Forms → OPTIMAT Sales Hub

## Status en dekking

De gebruiker heeft bevestigd dat **beide WordPress-websites Gravity Forms gebruiken**. De connector is daar specifiek voor ingericht: `GFAPI`-formulier-/veldinventaris, hooks na opgeslagen inzendingen en updates, duurzame outbox, persoonlijke servergeheimen per bron, exacte veldmapping, gecombineerde intenties, privébijlagen en herhaalbare bronreconciliatie. De werkelijk geïnstalleerde Gravity Forms-versies, formulier-ID’s, taalvarianten en live bronontvangst zijn nog niet geverifieerd: er is geen WordPress-beheertoegang verstrekt en publieke inspectie kreeg een proxy-403.

| Website               | Provider                                | Status                                                                 |
| --------------------- | --------------------------------------- | ---------------------------------------------------------------------- |
| www.optimat-group.com | Gravity Forms, door gebruiker bevestigd | Connector/installatie en formulierinventaris nog live te verifiëren    |
| kdt.optimat-group.com | Gravity Forms, door gebruiker bevestigd | Afzonderlijke bron/geheim; nog live te verifiëren                      |
| Lokale PHP-tests      | GFAPI-/WordPress-/database-/HTTP-fakes  | Contractmatig getest; geen live WordPress-integratie                   |
| CF7 / Elementor       | Conditionele reserveadapters            | Niet als OPTIMAT-provider geclaimd; geen opgeslagen-entryreconciliatie |

Een echte testinzending per bron, formulier en taalvariant is nodig voordat een beheerder dekking op ‘live getest’ mag zetten. Controleer bevestigingsmails, brochurelevering en de bezoekerservaring. De connector past Gravity Forms-validatie, notificaties en bevestigingen niet aan.

Voor het volledige traject in de applicatie, zie [GRAVITY-FORMS.md](GRAVITY-FORMS.md).

## Installatie per WordPress-website

1. Vereisten: WordPress ≥6.3, PHP ≥8.1 met JSON/mbstring, actieve Gravity Forms met `GFAPI`, MySQL/MariaDB met InnoDB, HTTPS en WP-CLI voor de aanbevolen serverworker. De tabellen worden met InnoDB aangemaakt. Controleer dat de host die engine niet vervangt. Verifieer de geïnstalleerde Gravity Forms-versie op een acceptatiekopie.
2. Kopieer `wordpress/optimat-sales-hub` naar `wp-content/plugins/optimat-sales-hub` en activeer de plug-in. Gebruik voor een eerste test een ontwikkel-/acceptatiekopie. Plug-inversie-updates voeren de eigen schemavernieuwing uit; klantformulieren worden niet gewijzigd.
3. Maak in Sales Hub → Instellingen een aparte bron per website. Gebruik de werkelijke HTTPS-site-URL en een aparte servervariabele, bijvoorbeeld `OPTIMAT_WP_MAIN_SECRET` respectievelijk `OPTIMAT_WP_KDT_SECRET`. Stel verschillende cryptografisch willekeurige geheimen van minstens 32 bytes in via de hostingsecretsvoorziening. De waarde hoort niet in browser, chat, broncode of Git.
4. Stel op de betreffende WordPress-host hetzelfde brongeheim beschikbaar als `OPTIMAT_HUB_SECRET` (omgeving of reeds veilig geïnjecteerde PHP-constant). De app heeft de **echte geheime bytes** nodig voor lokale HMAC-berekening; een netwerkproxy-placeholder is geen vervanging. De WordPress-instellingenpagina toont alleen aanwezigheid.
5. Open WordPress → Instellingen → OPTIMAT Sales Hub. Stel de definitieve HTTPS-basis-URL van Sales Hub zonder `/api`, het aangemaakte bron-ID en de bewaartermijn voor geleverde payloads in. Redirects zijn niet ondersteund; behoud TLS-verificatie. Houd bij bron-/geheimwijzigingen rekening met nog niet geleverde events voor de oude bron.
6. De sectie **‘Gravity Forms: N formulieren gevonden’** leest actieve en inactieve formulieren met `GFAPI::get_forms()`. Open ieder formulier. Controleer doel, taal, verborgen zakelijke velden, exacte input-ID’s en originele keuzeopties. Nieuwe formulieren blijven ‘Nog te classificeren’ en uitgeschakeld. Pop-ups/templates zijn pas volledig gedekt nadat hun gebruikte GF-formulieren en taalvarianten zijn geverifieerd.
7. Kies per commercieel formulier **‘Commerciële ontvangst vrijgeven na controle’**, doel ‘Commercieel’, taal, basisintenties en waar nodig exacte aanvullende intentieregels. Ondersteunde andere doelen zijn Support, Sollicitaties en Nieuwsbrief; hun inzendgegevens worden niet naar verkoop gekopieerd. Bewaar met **‘Formulierinstellingen bewaren’**.
8. Kies **‘Inventaris synchroniseren’**. De veilige schema-inventaris gaat via dezelfde duurzame outbox naar Sales Hub. Configureer daar de mapping met exact dezelfde veld-ID’s. De app bewaart events voor nog niet beoordeelde/mappende formulieren als wachtend werk; een broninventaris is geen vervanging van de centrale mappingbeslissing. Het centrale beheer wordt niet stilzwijgend overschreven door WordPress.
9. Configureer tijdsynchronisatie, uitgaand HTTPS naar Sales Hub en de workers hieronder. Maak vervolgens echte testinzendingen. Gebruik bekende testgegevens en controleer zowel de bezoekersflow als het CRM-dossier, rechten, intenties en cijfers.

## Compoundvelden, keuzes en intenties

De connector bewaart zowel het samengestelde ouderveld als afzonderlijke subinput-ID’s. Een naamveld `2` kan bijvoorbeeld `2.3` en `2.6` hebben; een adresveld `3` kan `3.1` en `3.3` hebben. De ouderwaarde behoudt alle oorspronkelijke subwaarden en hun labels; subinputvelden zijn afzonderlijk te mappen. Checkboxen behouden de ingestuurde waarden, oorspronkelijke opties en subinput-ID’s. Verborgen zakelijke productvelden blijven beschikbaar; CAPTCHA-, wachtwoord-, authenticatie-, honeypot-, kaartbetaal- en andere beveiligingsvelden worden verwijderd. Machine of businessunit wordt niet uit een hostname geraden.

Een brochureformulier met een offertekeuze behoudt bijvoorbeeld basisintentie `brochure` en voegt `quote` toe via een **daadwerkelijk gecontroleerde** veldregel:

```json
[{ "field_id": "7.1", "equals": "Ja, offerte", "add": ["quote"] }]
```

Dit voorbeeld bewijst geen echt OPTIMAT-veld. De vergelijking gebruikt de exacte oorspronkelijke veldwaarde, zonder herkenning op naam/vrije tekst. Niet gekozen of anders gespelde waarden activeren de regel niet. Taalvarianten krijgen passende expliciete regels. Basisintenties blijven behouden.

Alle nieuwe niet-gevoelige zakelijke velden blijven als extra formuliergegevens beschikbaar tot mapping is ingesteld. De oorspronkelijke GF-`date_created` wordt de inzenddatum; `date_created` en `date_updated` blijven tevens als broncontext bewaard. De eventwijzigingstijd komt uit de GF-`date_updated`, met `date_created` als fallback, in UTC. De lokale identiteitsindex bewaart die brontijd onder een rijlock: een vertraagde oudere snapshot wordt genegeerd, ook als de nieuwere waarneming geen gewijzigde zakelijke waarden bevatte. De connector maakt eigen monotone bronversies per website/provider/formulier/entry-ID; een ongewijzigde snapshot veroorzaakt geen nieuw event. Een echte wijziging krijgt een nieuw event-ID en hogere bronversie, terwijl verkopersgegevens buiten de bronvelden behouden blijven.

## Betrouwbare workers en doorlooptijd

Een succesvolle capture commit eerst naar de lokale transactionele outbox en identiteitsindex. Een korte asynchrone lokale kick probeert een worker te wekken; de bezoeker wacht nooit op een Sales Hub-aanroep. Voor bereikbaarheid zonder bezoekersverkeer zijn echte serverworkers nodig. WP-Cron is slechts een verkeersafhankelijke fallback: aflevering iedere minuut, reconciliatie iedere minuut, inventarissynchronisatie iedere vijf minuten.

Aanbevolen schema per WordPress-host:

| Command                                      | Interval          | Functie                                                         |
| -------------------------------------------- | ----------------- | --------------------------------------------------------------- |
| `wp optimat-hub dispatch`                    | Iedere 5 seconden | Tekstevents, inventaris en private bijlagen afleveren           |
| `wp optimat-hub gravity reconcile --pages=5` | Iedere minuut     | Bestaande gewijzigde/mislukte broninzendingen herstellen        |
| `wp optimat-hub gravity sync`                | Iedere 5 minuten  | Formulierinventaris en connector-/reconciliatiestatus verversen |

Gebruik bijvoorbeeld een systemd-oneshot met een timer `OnUnitActiveSec=5s`, `AccuracySec=1s`, onder het WordPress-gebruikersaccount, met een absolute WP-CLI-locatie en `--path=/pad/naar/wordpress`. Maak analoge timers voor de andere intervallen. Geen onbeperkt overlappende processen: outbox- en reconciliatieleases voorkomen dat hetzelfde werk gelijktijdig wordt geclaimd. Een workercrash wordt na het verlopen van de lease hersteld.

Met normale belasting, actieve worker, actuele centrale mapping en bereikbare diensten moet een live end-to-endtest vanaf formuliervalidatie tot zichtbaar dossier **≤15 seconden** meten. Die doelstelling is niet gegarandeerd bij verkeersafhankelijke WP-Cron, storingen, wachtrijen, nog ontbrekende mapping of onvoldoende capaciteit. Inventarissynchronisatie iedere vijf minuten houdt de connectorstatus actueel; alleen een echte testinzending bewijst formulierdekking.

## Ontvangst, ondertekening en herstel

Inzendingen gaan naar `POST /api/webhooks/{source_id}`. Inventaris gaat naar `POST /api/connectors/{source_id}/sync` met `kind: "gravity_inventory"`, een event-ID, connectorversie, exacte `home_url('/')`, generatietijd, complete formulier-/veldschema’s en reconciliatiestatus. Inventaris bevat geen entrywaarden of upload-URL’s en is duurzaam gequeued; een netwerkstoring verliest geen zojuist ontdekte formulieren. Een volgende volledige inventaris herbevestigt de actuele schema’s.

Voor beide routes:

- `Content-Type: application/json`.
- `X-Optimat-Timestamp`: actuele Unix-seconden voor deze afleverpoging.
- `X-Optimat-Signature`: hex `HMAC-SHA256(secret, timestamp + "." + exacte_raw_JSON_bytes)`.

Iedere retry vernieuwt timestamp en handtekening, terwijl event-ID/body gelijk blijven. Alleen HTTP 202 met JSON `{ "accepted": true, "event_id": "het-verzonden-event-id", ... }` telt als ontvangstbewijs. Een HTML-pagina met HTTP 200 of een verkeerd event-ID niet. De app bewaart een geldig event transactioneel vóór bevestiging. Herleveringen tellen niet opnieuw.

De outbox gebruikt oplopende retrybackoff met jitter, vanaf ongeveer tien seconden tot zes uur; na twaalf mislukte pogingen gaat een event naar de blijvende failed-queue. Beheerders zien alleen event-ID, provider/formulier, status, pogingenaantal, HTTP-status en beperkte foutcode. Geen ruwe persoonsgegevens of secrets in algemene logs. **‘Opnieuw aanbieden’** is beveiligd met `manage_options` en een nonce en behoudt het oorspronkelijke event-ID.

Geheimrotatie: configureer in Sales Hub het nieuwe huidige geheim plus het oude als `previous_secret_env`; roteer WordPress; controleer nieuwe ontvangstbewijzen; verwijder de oude binding pas na het afgesproken rotatievenster. Queuepayloads bevatten geen geheim en hoeven niet te worden herschreven.

## Reconciliatie en historische inzendingen

`GFAPI::get_entries()` leest uitsluitend actieve entries van expliciet vrijgegeven commerciële formulieren, op oplopend numeriek entry-ID. Iedere aanroep is begrensd op pagina’s van vijftig entries en maximaal twintig pagina’s. De cursor wordt **pas na duurzame capture** per entry opgeslagen. Een crash tussen de eventcommit en cursoropslag leidt tot een veilige herlezing; geen overgeslagen entry. Bij opslag-/contractfouten pauzeert de cursor vóór de fout. Herstel de oorzaak en kies **‘Reconciliatie hervatten’** of gebruik CLI.

De eerste scan en een nieuw vrijgegeven formulier krijgen een volledige controle. Volgende scans gebruiken een `date_updated`-venster met twee uur overlap. Omdat de werkelijk geïnstalleerde provider-/API-versie nog niet geverifieerd is, wordt bovendien **automatisch ten minste dagelijks een volledige ID-scan gestart**. Een fout/onstabiel resultaat bij incrementele filtering schakelt veilig naar een volledige scan over; een stille niet-werkende datumfilter kan daardoor niet permanent wijzigingen missen. Een lopende volledige scan hervat op zijn cursor en wordt niet telkens opnieuw gestart. Ook wijzigingen via een API-pad zonder beschikbare hook worden zo hersteld.

CLI:

```sh
wp optimat-hub gravity inventory
wp optimat-hub gravity sync
wp optimat-hub gravity reconcile --pages=5
wp optimat-hub gravity reconcile --full --pages=5
wp optimat-hub gravity reconcile --full --replay --pages=5
wp optimat-hub gravity test
```

`--full` start/hervat een volledige scan; `--replay` maakt expliciet nieuwe hogere bronversies van ongewijzigde entries, bijvoorbeeld om oude reeds bevestigde maar destijds uitgesloten events na configuratieherstel opnieuw te verwerken. Gebruik replay bewust en begrensd: herhaalde nieuwe voltooide replayrondes zijn nieuwe bronobservaties. Normale reconciliatie veroorzaakt geen extra events voor ongewijzigde entries. `gravity test` doet alleen een synthetische compound-/intentiecontrole, verzendt geen nep-inzending en claimt geen live koppeling.

Een volledige scan kan historische broninzendingen ophalen. Controleer vooraf doelbinding, commerciële selectie en bewaarbeleid; behoud de oorspronkelijke inzenddatum en verzin geen historische contactacties. Voor een beheerder die eerst individuele historische records wil bekijken, blijft de appimport met preview/duplicaatcontrole beschikbaar. Verwijderen, spammarkering of terugschrijven naar de publieke bron wordt niet automatisch als CRM-mutatie doorgevoerd. Spam/trash-entry’s worden niet als nieuwe commerciële inzending gekopieerd.

## Privébijlagen

De afzonderlijke module `includes/gravity-attachments.php` verwerkt uitsluitend per formulier expliciet toegestane `fileupload`-veld-ID’s onder **‘Bijlagevelden’**. Leeg betekent geen bestandsoverdracht. Alleen ingeschakelde commerciële formulieren komen in aanmerking. De module leest uitsluitend werkelijk lokale bestanden binnen geverifieerde Gravity Forms-/WordPress-uploadroots, zonder externe URL’s op te halen. Zij begrenst grootte, controleert inhoudstype/magic bytes en checksum en gebruikt een eigen duurzame queue met retries, ook wanneer het CRM-entryevent nog niet verwerkt is.

De tekst-/inventarisevents bevatten geen bestanden of publieke uploadlinks. Ondersteunde private bestandstypen zijn PDF, PNG en JPEG tot 5 MiB. Download in Sales Hub volgt de dossierrechten; de WordPress-uploadbron zelf moet door de WordPress-host passend worden beschermd. De module maakt een reeds publiek toegankelijk GF-uploadpad niet achteraf privé. Niet-lokale/offloaded bestanden en andere types worden expliciet geweigerd tot een ondersteunde adapter beschikbaar is. Verifieer de echte uploadconfiguratie en transporttests per website.

## Bewaring en operationeel beheer

Geleverde tekst-/inventarispayloads worden dagelijks na de ingestelde termijn verwijderd (standaard dertig dagen). Pending/failed events worden niet automatisch gewist. De identiteitsindex bewaart bron-ID’s/payloadhashes voor latere updates; reconciliatie bewaart een checkpoint zonder entrywaarden. Stem bronopslag, outbox, private bijlagen, CRM, backups en gerichte verwijdering op elkaar af. Na een gerichte privacyverwijdering mag een volgende reconciliatie niet ongewenst hetzelfde dossier terugbrengen; de CRM-tombstone voorkomt herinvoer van dezelfde bronidentiteit, en de bron moet volgens beleid worden verwijderd/beperkt.

Een defecte lokale database kan geen duurzame outbox beloven. De connector toont een beperkte beheerdersmelding en laat de bezoekersflow intact; herstel de lokale database en de reeds door Gravity Forms opgeslagen entry. Backup en herstel omvatten de eigen plug-intabellen, WordPress/GF-bronopslag, bijlagen en veilig afzonderlijk beheerde secrets.

## Tests herhalen

```sh
php -l wordpress/optimat-sales-hub/includes/connector.php
php -l wordpress/optimat-sales-hub/includes/gravity.php
php -l wordpress/optimat-sales-hub/includes/gravity-attachments.php
php wordpress/optimat-sales-hub/tests/contract.php
php wordpress/optimat-sales-hub/tests/gravity.php
php wordpress/optimat-sales-hub/tests/gravity-attachments.php
```

`gravity.php` bevat de 34 algemene controles plus zevenendertig specifieke GF-controles, totaal **71**. De tests gebruiken synthetische WordPress-/GFAPI-/database-/HTTP-fakes; zij testen echte plug-inmethoden en geregistreerde hooks, maar geen live providerinstallatie of MySQL-transacties. Tijdens de bouw is een PHP-WebAssembly-runtime gebruikt wegens ontbrekende native PHP-CLI. Afzonderlijke bijlagencontroles worden in de betreffende testuitvoer gerapporteerd.

Live acceptatie blijft nodig: demo/offerte/brochure/gecombineerde aanvragen per website/formulier/taal; alle zakelijke velden en subinputs; onbekende velden; bevestiging/brochurelevering; ≤15 seconden; drie herleveringen; bronupdate zonder verlies van verkopersgegevens; outageherstel; fullscan na gemiste hook; private bijlagen; niet-commerciële uitsluiting; persoonlijke rechten en rapportagetellingen.

Contractgrenzen worden vóór verzending gecontroleerd: provider 80, formulier-ID 191, formuliernaam 200, submission-ID 200 en taal 20 UTF-16-code-eenheden; maximaal 300 zakelijke velden met veld-ID 200, label 500 en type 60, **500 opties** per veld en twintig intenties van maximaal tachtig. Inventory ondersteunt maximaal vijfhonderd formulieren en vijfhonderd schema-velden per formulier; compoundsubinputs tellen mee. Extreme diepte/grootte of tekstpayload boven 900 kB, inventaris boven 1,9 MB, geeft een zichtbare `contract_limit` zonder stilzwijgende afkapping. Controleer in dat geval het bronrecord en de adapter/het gecontroleerde contract.
