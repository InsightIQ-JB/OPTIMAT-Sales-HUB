# Gravity Forms aansluiten op beide OPTIMAT-websites

De gebruiker heeft bevestigd dat beide websites Gravity Forms gebruiken. De integratie gebruikt daarom Gravity Forms-entry-ID’s, de server-side formulierstructuur en opgeslagen inzendingen. Dit is gebruikersinformatie over de provider; er is nog geen WordPress-installatie of echt formulier-ID vanuit deze sessie geïnspecteerd. Een succesvolle contracttest is geen live koppeling.

## Wat de beheerder voorbereidt

Gebruik twee aparte bronnen, ook als beide websites op dezelfde WordPress-host draaien:

| WordPress-site                  | Bron in Sales Hub             | Naam van servervariabele |
| ------------------------------- | ----------------------------- | ------------------------ |
| `https://www.optimat-group.com` | OPTIMAT Group (Gravity Forms) | `OPTIMAT_WP_MAIN_SECRET` |
| `https://kdt.optimat-group.com` | KDT (Gravity Forms)           | `OPTIMAT_WP_KDT_SECRET`  |

Op elke WordPress-installatie heet de lokale geheime variabele `OPTIMAT_HUB_SECRET`. De **waarde** moet overeenkomen met de waarde van uitsluitend haar eigen bron op de appserver. Gebruik twee verschillende cryptografisch willekeurige geheimen van minstens 32 bytes. HMAC wordt lokaal berekend: een netwerkproxy-placeholder is geen bruikbare geheime waarde voor deze berekening. Plaats echte waarden veilig bij de app- en WordPress-host, nooit in het formulierregister, browsercode, Git of chat.

Verder nodig: HTTPS met geldige TLS-keten, een publiek bereikbare productie-app-URL, WordPress-beheerrechten op beide installaties, actieve Gravity Forms, PHP 8.1+ met de in WORDPRESS genoemde extensies, InnoDB en een betrouwbare serverworker. De huidige lokale ontwikkelpoort is geen bruikbaar afleveradres voor een externe WordPress-server.

## 1. Twee bronnen registreren

Voer bij installatie `npm run sources:init` uit om de twee bekende WordPress-bronnen idempotent te registreren. Bestaande broninstellingen blijven behouden; er worden geen geheime waarden of testaanvragen aangemaakt. Meld je daarna als beheerder aan bij Sales Hub. Open **Instellingen → Bronverbindingen** en gebruik de afzonderlijke registratieknoppen voor OPTIMAT Group en KDT. Daarmee worden bronmetadata opgeslagen; de app vraagt en toont geen geheime waarde.

Noteer per website het getoonde bron-ID en de productie-app-URL. Controleer dat de server de bijbehorende geheime variabele heeft. “Bron geregistreerd” betekent nog niet dat een connector contact heeft gemaakt. Connectorcontact, formulierinventaris en laatste echte inzending hebben aparte statussen.

## 2. WordPress-plugin installeren

Download de connector-ZIP vanuit de bronpagina in Sales Hub. Installeer die op een acceptatiekopie van iedere website via **WordPress → Plugins → Nieuwe plugin → Plugin uploaden**. Activeer de plugin en open **Instellingen → OPTIMAT Sales Hub**.

Vul de definitieve HTTPS-app-URL en het bij die website horende bron-ID in. Configureer de lokale `OPTIMAT_HUB_SECRET` via de WordPress-host. Gebruik geen geheim van de andere website. De plugin mag bestaande formulieren, bevestigingsmails en brochurelevering niet vervangen.

## 3. Formulierinventaris synchroniseren

Klik in de WordPress-connector op **Inventaris synchroniseren**. De sectie **Gravity Forms: N formulieren gevonden** toont de gevonden formulieren. Met WP-CLI kan dezelfde opdracht als `wp optimat-hub gravity sync` worden uitgevoerd. `wp optimat-hub gravity inventory` toont uitsluitend de gecontroleerde metadata voor een lokale beheercontrole. Deze ondertekende metadata bevat formulier-ID’s, naam, actieve status, veld-ID’s, labels, types, keuzemogelijkheden, compoundvelden en zakelijke verborgen velden. Inzendwaarden, standaardwaarden, CAPTCHA’s en wachtwoorden horen niet in de inventaris.

De app valideert de eigen bronhandtekening en de website-identiteit. Een inventaris voor KDT kan niet met het OPTIMAT-hoofdgeheim worden aangeboden. De inventaris maakt geen aanvragen aan en verandert geen reeds beheerde mapping of doelbinding. Oude inventarissen mogen nieuwe bronmetadata niet terugzetten.

Open opnieuw **Bronverbindingen** en controleer per website de heartbeat, ontvangen inventaris en gevonden formulieren. De inventaris kan onvolledig zijn: controleer paginering, inactieve formulieren, taalversies, pop-ups en templates in WordPress. Een volledige formulierstructuur betekent bovendien nog niet dat elk formulier inhoudelijk is goedgekeurd voor verkoop.

## 4. Doelbinding en veldmapping beoordelen

Open **Formuliermapping**. Kies een werkelijk gevonden formulier met **Bewerken**, of open het vanuit de bronkaart met **Velden en mapping controleren**. Een nieuw gevonden formulier begint als **Nog te beoordelen**, zonder automatisch geactiveerde commerciële intake.

Kies de juiste routing: commercieel, support, sollicitaties of nieuwsbrief. Alleen goedgekeurde commerciële formulieren horen in de verkoopintake. De WordPress-connector gebruikt daarnaast een expliciete toelatingslijst; doelbinding in de app is geen opdracht om ieder formulier op de website naar CRM te sturen.

Koppel de echte Gravity Forms-veld-ID’s met de keuzelijst **Opslaan als** aan bedrijf, contact, adres, machine, model en andere CRM-velden. Voorstellen zijn hulpmiddelen; ze worden pas overgenomen als de beheerder ze expliciet toepast en opslaat. Controleer vooral compoundvelden zoals naam en adres en verborgen product-/taalvelden. Zakelijke velden zonder mapping blijven als extra formuliergegevens beschikbaar.

De versie in de editor is de huidige opgeslagen versie. Opslaan controleert die versie en maakt vervolgens de volgende versie. Na een gelijktijdige wijziging wordt geen andere mapping stilzwijgend overschreven: open de actuele formulierconfiguratie opnieuw en vergelijk de wijziging.

Gebruik **Synthetisch voorbeeld maken** en **Voorbeeld testen** voor een eerste veldcontrole. Dit zijn verzonnen testwaarden; hiermee wordt nog geen echte formulierveldwaarde of providerhook gevalideerd.

## 5. Commerciële formulieren gecontroleerd vrijgeven

Klap in de WordPress-connector het juiste Gravity-formulier open. Stel **Doel**, **Taal** en **Basisintenties** in en vink alleen bij goedgekeurde commerciële formulieren **Commerciële ontvangst vrijgeven na controle** aan. Klik op **Formulierinstellingen bewaren**. Gebruik de werkelijke formulier-ID’s. Een brochureformulier met een extra offertekeuze moet beide intenties behouden. Configureer **Extra intentieregels** met bijvoorbeeld `[{"field_id":"7.1","equals":"Ja","add":["quote"]}]`, uitsluitend nadat veld-ID en waarde in dat echte formulier gecontroleerd zijn. Dit is een voorbeeld, geen vastgesteld OPTIMAT-veld. Gebruik hiervoor het werkelijk gevonden veld-ID en de werkelijke geselecteerde waarde; leid offerte-intentie niet af uit vrije tekst, domein of formuliernaam.

Controleer apart businessunit, merk en oorspronkelijke website. Een aanvraag via de hoofdwebsite is niet automatisch HOMAG/Wood; ontbrekende waarden blijven onbekend. Vul bij **Bijlagevelden** alleen expliciet gecontroleerde Gravity-`fileupload`-veld-ID’s in, gescheiden door komma’s. Leeg betekent geen bestandsoverdracht. Alleen PDF, PNG en JPEG van maximaal 5 MB per bestand worden overgedragen via de begrensde private route en geschikte lokale bronopslag; een publieke upload-URL wordt nooit als CRM-bijlage gepresenteerd. Een onbekend bestandstype of onveilig bronpad blijft geweigerd.

## 6. Serverworker, herstel en reconciliatie

Configureer de serverworker op iedere WordPress-installatie volgens [WORDPRESS.md](WORDPRESS.md). De aanbevolen vijfseconden-cyclus handelt de lokale outbox af zonder te wachten op bezoekersverkeer. Alleen de minuutfallback van WP-Cron bewijst de 15-seconden-doelstelling niet.

Configureer naast de vijfseconden-dispatch ook een verkeersvrije serverplanning voor `wp optimat-hub gravity reconcile --pages=5` iedere minuut en `wp optimat-hub gravity sync` iedere vijf minuten. De ingebouwde WP-Cron-fallback heeft dezelfde minuut-/vijfminuutcadans, maar is afhankelijk van bezoekersverkeer.

Gravity Forms bewaart inzendingen met een stabiel entry-ID. De connector kan bronentries periodiek vergelijken met de eigen identiteits-/outboxadministratie en gemiste of gewijzigde commerciële entries opnieuw aanbieden. Laat uitsluitend goedgekeurde formulieren reconciliëren. Controleer checkpoint, laatste poging/resultaat, paginering en foutstatus; een mislukte bronquery mag niet als een afgeronde reconciliatie gelden. Eerdere uitsluitingen, bronverwijderingen en bewaartermijnen moeten ook aan WordPress-zijde worden opgevolgd.

De reconciliatie verwerkt maximaal 50 entries per pagina en bewaart het laatste duurzaam vastgelegde entry-ID per formulier. `--pages` begrenst één CLI-aanroep tot 1–20 pagina’s. Een volgende aanroep hervat de cursor. Een incrementele cyclus heeft twee uur overlap; dagelijks volgt een volledige hercontrole. Bij een niet-ondersteund wijzigingsfilter wordt op een volledige scan teruggevallen. Controleer dit gedrag ook met de werkelijk geïnstalleerde Gravity Forms-versie.

```bash
wp optimat-hub gravity test
wp optimat-hub gravity sync
wp optimat-hub gravity reconcile --pages=5
wp optimat-hub gravity reconcile --full --pages=5
```

`gravity test` controleert synthetische compound-/intentieregelnormalisatie en verstuurt geen fictieve productieaanvraag. De WordPress-beheerknoppen **Reconciliatie hervatten** en **Volledige hercontrole starten/hervatten** volgen hetzelfde begrensde herstelpad. Gebruik `--full --replay` uitsluitend voor expliciet gecontroleerd herstel: die optie biedt bronentries met nieuwe bronversies aan en vervangt geen gewone idempotente retry. Een mislukte cyclus bewaart de laatst veilige cursor en toont een beperkte foutcode.

Een retry krijgt een nieuwe aflevertimestamp en handtekening, maar behoudt event-ID, bronversie en oorspronkelijke inzenddatum. Het ontvangstbewijs moet de verzonden event-ID bevestigen. Herlevering maakt geen tweede aanvraag; een hogere bronversie mag geen eigenaar, taak of verkopersnotitie vervangen.

## 7. Live acceptatie per website

Voer deze stappen afzonderlijk op OPTIMAT Group en KDT uit:

1. Controleer een echte demo-, offerte-, brochure- en gecombineerde aanvraag, inclusief taal-/productvarianten en alle extra zakelijke velden.
2. Controleer dat bevestigingsmails en brochurelevering hetzelfde blijven werken en dat de bronentry duurzaam in Gravity Forms staat.
3. Controleer de fiche, bron, bedrijf/contactkoppeling, machinecontext en oorspronkelijke datum in Sales Hub. Meet de tijd van succesvolle inzending tot zichtbaarheid, bij normale bereikbaarheid maximaal 15 seconden.
4. Bied dezelfde entry/event herhaald aan; er blijft één aanvraag. Een nieuwe entry van hetzelfde bedrijf blijft een aparte aanvraag.
5. Maak Sales Hub tijdelijk onbereikbaar op een acceptatieomgeving. Controleer normale bezoekersbevestiging, lokale outbox en herstel na terugkeer.
6. Wijzig een opgeslagen entry en controleer bronversie, mapping, behoud van opvolging en het weigeren van een verouderde wijziging.
7. Controleer een toegestane PDF/PNG/JPEG-bijlage en een geweigerd bestandstype/grootte; controleer dat een andere verkoper niet kan downloaden.
8. Controleer een bewust gemiste entry via reconciliatie, inclusief checkpoint na meerdere pagina’s en herhaling zonder dubbele dossiers.
9. Controleer dat sollicitatie-/support-/nieuwsbriefvelden niet in commerciële fiches, kaart of exports terechtkomen.

Pas daarna kan de relevante bron/provider/formulierdekking als live getest worden vastgelegd. Deze sessie heeft geen WordPress-accounts of installatieopdracht op de live websites ontvangen en kan die status dus niet claimen.

## Contract en diagnose

Inventaris: `POST /api/connectors/{source_id}/sync`, met `kind: "gravity_inventory"`, een unieke event-ID, connectorversie, website-URL, bronmoment, volledigheidsvlag, formulieren en reconciliatiestatus. Ondertekening gebruikt dezelfde `X-Optimat-Timestamp` en `X-Optimat-Signature` als gewone intake: HMAC-SHA256 over `timestamp + "." + exacte JSON-bytes`.

Een heartbeat bewijst uitsluitend geauthenticeerd connectorcontact. Een ontvangen inventaris bewijst metadataoverdracht. Een succesvolle formulierontvangst en juiste fiche zijn afzonderlijke bewijzen. De beheerpagina toont die verschillen; verkopers krijgen geen operationele schema-/connectorgegevens.
