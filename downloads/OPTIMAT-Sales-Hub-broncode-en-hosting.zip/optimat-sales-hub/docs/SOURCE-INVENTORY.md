# OPTIMAT WordPress source research

Date: 2026-10-27. Scope: read-only access to three publicly referenced pages.

| URL                                                                        | Observed result                                       |
| -------------------------------------------------------------------------- | ----------------------------------------------------- |
| https://www.optimat-group.com/producten/heesemann-breedbandschuurmachines/ | Environment HTTPS proxy denied CONNECT: 403 Forbidden |
| https://kdt.optimat-group.com/machine/kn-3710-nesting-cnc/                 | Environment HTTPS proxy denied CONNECT: 403 Forbidden |
| https://kdt.optimat-group.com/contact/                                     | Environment HTTPS proxy denied CONNECT: 403 Forbidden |

No HTML was received. No provider, plugin, form ID, actual field names, active integration hook, or form inventory was verified. Do not infer any of these from the domains or the reference prompt.

Required network destinations for subsequent read-only public research: `www.optimat-group.com`, `optimat-group.com`, `kdt.optimat-group.com` (preserve the rest of the existing allowlist). Even after public access is enabled, WordPress administrative/provider configuration access is required for a complete inventory including hidden forms, popup templates, and actual durable submission storage.

The uploaded build prompt states that the reference OPTIMAT brochure form can additionally request pricing/quotation. This is document-supplied context, not independently observed website evidence; preserve multiple intents in the intake contract rather than forcing one exclusive type.

Safe interim delivery: provider-neutral receipt contract, explicit unmapped fields, per-source disabled/unconfigured status, form registry with `inventory_incomplete`, and contract tests. A real WordPress integration must not be claimed until a test submission from every connected source has arrived and actual provider hooks have been verified.

## Implementatiestatus

De meegeleverde bouwprompt is de functionele specificatie; de Resatec-export is alleen referentiemateriaal. Er is geen Resatec-applicatie, accountlijst of sectorfilter gekopieerd.

In het bronregister kunnen beheerders websites, providers, formulieren, doelbinding en versiegebonden veldmapping toevoegen. Bij entryontvangst nog onbekende formulieren uit een geauthenticeerde bron worden geregistreerd met status `contract_only`; de Gravity-inventaris gebruikt `discovered` en begint zonder goedgekeurde routing. Dat is geen bewijs dat alle live formulieren gedekt zijn. Bronwebsite en businessunit/merk zijn afzonderlijk. Support, nieuwsbrieven en sollicitaties worden niet als commerciële dossiers verwerkt.

De eerste live inventaris moet per website alle actieve formulieren, taalvarianten, product-/pop-uptemplates, provider-ID, oorspronkelijke opslag, verborgen productvelden en zakelijke velden controleren. Daarna: configureer expliciete mappings, installeer de adapter in staging, doorloop een echte testinzending inclusief brochure/offertecombinatie, bevestigingsmail, download en retries. Noteer het resultaat per formulier in het dekkingsregister. Een generieke connectorhook is beschikbaar voor een andere provider; de ingebouwde adapters zijn alleen conditioneel en moeten per geïnstalleerde provider-versie worden geverifieerd.

Netwerkdomeinen zijn in het cloudconfiguratieconcept opgenomen; dat wijzigt het lopende netwerkbeleid niet automatisch. WordPress-/providerbeheer is niet beschikbaar in deze sessie. Geen formulieren of live websites gewijzigd.

## Aanvullende gebruikersbevestiging: Gravity Forms

De gebruiker heeft na het publieke brononderzoek expliciet bevestigd dat zowel de hoofdwebsite als KDT Gravity Forms gebruiken en gevraagd de integratie daarop uit te werken. Dit vult de providerkeuze in; het vervangt geen controle van geïnstalleerde versies, echte formulier-ID’s, verborgen velden, taalvarianten, bronentries of live hookgedrag.

De nieuwe connector kan de Gravity Forms-structuur als ondertekende metadata aanbieden. De app toont aparte heartbeat-, inventaris-, mapping- en inzendstatussen. Nieuw ontdekte formulieren worden eerst beoordeeld; mappingsuggesties zijn geen automatische mapping. Het installatie- en verificatiepad staat in GRAVITY-FORMS.md. Beide sites blijven ongekoppeld totdat de plugin met de juiste bron-ID en het afzonderlijke brongeheim geïnstalleerd is en er werkelijke testinzendingen ontvangen en gecontroleerd zijn.
