import { useCallback, useEffect, useState, type FormEvent } from 'react';
import {
  AlertCircle,
  Check,
  Copy,
  Link2,
  RefreshCw,
  ShieldCheck,
  Users,
  Plug,
  FileInput,
  SlidersHorizontal,
} from 'lucide-react';
import { LABELS, ROLES, type User } from '../shared/domain';

type Api = <T = any>(path: string, options?: RequestInit) => Promise<T>;
type Props = { user: User; api: Api; onChanged: () => void };
type Tab = 'sources' | 'mapping' | 'import' | 'users' | 'catalog' | 'retention';
const body = (value: unknown, method = 'POST'): RequestInit => ({
  method,
  body: JSON.stringify(value),
});
const coverageLabels: Record<string, string> = {
  not_configured: 'Nog te configureren',
  contract_tested: 'Contractmatig getest',
  live_tested: 'Live getest',
  excluded: 'Uitgesloten',
  pending: 'In wachtrij',
  processed: 'Verwerkt',
  failed: 'Mislukt',
  dead: 'Handmatig herstel nodig',
  ignored: 'Oudere versie genegeerd',
};
const SOURCE_PRESETS = [
  {
    name: 'OPTIMAT Group (Gravity Forms)',
    site_url: 'https://www.optimat-group.com',
    secret_env: 'OPTIMAT_WP_MAIN_SECRET',
  },
  {
    name: 'KDT (Gravity Forms)',
    site_url: 'https://kdt.optimat-group.com',
    secret_env: 'OPTIMAT_WP_KDT_SECRET',
  },
];
const TARGETS = [
  'company_name',
  'name',
  'email',
  'phone',
  'enterprise_number',
  'country',
  'address',
  'postcode',
  'city',
  'region',
  'business_unit',
  'brand',
  'machine',
  'model',
  'message',
  'language',
  'campaign',
  'job_title',
];
const TARGET_LABELS: Record<string, string> = {
  company_name: 'Bedrijfsnaam',
  name: 'Contactpersoon',
  email: 'E-mail',
  phone: 'Telefoon',
  enterprise_number: 'Ondernemingsnummer',
  country: 'Land',
  address: 'Straat en huisnummer',
  postcode: 'Postcode',
  city: 'Gemeente',
  region: 'Provincie / regio',
  job_title: 'Functie',
  business_unit: 'Businessunit',
  brand: 'Merk',
  machine: 'Machinecategorie',
  model: 'Machinemodel',
  message: 'Bericht',
  language: 'Voorkeurstaal',
  campaign: 'Campagne',
};
const purposeLabels: Record<string, string> = {
  unclassified: 'Nog te beoordelen',
  commercial: 'Commerciële aanvraag',
  support: 'Support',
  recruitment: 'Vacature',
  newsletter: 'Nieuwsbrief',
};
const parseObject = (value: any): Record<string, any> => {
  try {
    const parsed = typeof value === 'string' ? JSON.parse(value) : value;
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  } catch {
    return {};
  }
};
const parseArray = (value: any): any[] => {
  try {
    const parsed = typeof value === 'string' ? JSON.parse(value) : value;
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};
const originHost = (value: string) => {
  try {
    return new URL(value).hostname.replace(/^www\./, '').toLowerCase();
  } catch {
    return '';
  }
};
function fieldRows(schema: any): any[] {
  return parseArray(schema).flatMap((field: any) => [
    { ...field, id: String(field.id), compound: false },
    ...parseArray(field.inputs).map((input: any) => ({
      ...input,
      id: String(input.id),
      label: `${field.label || field.id} · ${input.label || input.id}`,
      type: input.type || field.type,
      compound: true,
    })),
  ]);
}
function syntheticFields(schema: any) {
  return parseArray(schema).map((field: any) => ({
    id: String(field.id),
    label: field.label || String(field.id),
    type: field.type || 'text',
    ...(field.options ? { options: field.options } : {}),
    value: field.inputs?.length
      ? Object.fromEntries(
          field.inputs.map((input: any) => [
            String(input.id),
            { label: input.label || String(input.id), value: 'Voorbeeld' },
          ]),
        )
      : ['checkbox', 'multiselect'].includes(field.type)
        ? []
        : field.type === 'email'
          ? 'contact@example.invalid'
          : field.type === 'number'
            ? '0'
            : field.type === 'date'
              ? '2026-01-01'
              : 'Voorbeeld',
  }));
}
const date = (value: unknown) =>
  value
    ? new Date(String(value)).toLocaleString('nl-BE', { timeZone: 'Europe/Brussels' })
    : 'Nog niet ontvangen';
function JsonResult({ value }: { value: unknown }) {
  return value == null ? null : (
    <pre
      className="json-result"
      style={{
        whiteSpace: 'pre-wrap',
        overflowWrap: 'anywhere',
        background: '#f6f7fa',
        padding: 16,
        borderRadius: 10,
        maxHeight: 360,
        overflow: 'auto',
        fontSize: 12,
      }}
    >
      {JSON.stringify(value, null, 2)}
    </pre>
  );
}
function Input({
  label,
  ...props
}: React.InputHTMLAttributes<HTMLInputElement> & { label: string }) {
  return (
    <label className="field">
      <span>{label}</span>
      <input {...props} />
    </label>
  );
}

export default function Settings({ user, api, onChanged }: Props) {
  const [tab, setTab] = useState<Tab>('sources');
  const [data, setData] = useState<any>({ sources: [], forms: [], events: [] });
  const [users, setUsers] = useState<any[]>([]);
  const [catalog, setCatalog] = useState<any[]>([]);
  const [settings, setSettings] = useState<any>({});
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [source, setSource] = useState({
    name: '',
    site_url: '',
    secret_env: '',
    previous_secret_env: '',
  });
  const [form, setForm] = useState({
    source_id: '',
    provider: 'gravity',
    form_id: '',
    name: '',
    purpose: 'unclassified',
    version: 1,
  });
  const [mapping, setMapping] = useState('{}');
  const [sample, setSample] = useState('[]');
  const [preview, setPreview] = useState<unknown>(null);
  const [history, setHistory] = useState<unknown>(null);
  const [importSource, setImportSource] = useState('');
  const [importText, setImportText] = useState('[]');
  const [importResult, setImportResult] = useState<unknown>(null);
  const [importChecked, setImportChecked] = useState(false);
  const [invitation, setInvitation] = useState({
    email: '',
    name: '',
    role: 'seller',
    team_id: '',
    marketing_permission: false,
  });
  const [invitationUrl, setInvitationUrl] = useState('');
  const [catalogForm, setCatalogForm] = useState({ category: '', model: '', brand: '' });
  const [retentionDays, setRetentionDays] = useState('730');

  const load = useCallback(async () => {
    const results = await Promise.allSettled([
      api('/api/integrations'),
      api('/api/admin/users'),
      api('/api/catalog'),
      api('/api/admin/settings'),
    ]);
    const failures: string[] = [];
    results.forEach((result, i) => {
      if (result.status === 'rejected') {
        failures.push(result.reason?.message || 'Een onderdeel kon niet worden geladen.');
        return;
      }
      const value: any = result.value;
      if (i === 0) setData(value);
      if (i === 1) setUsers(value.users || []);
      if (i === 2) setCatalog(value.items || []);
      if (i === 3) {
        setSettings(value.settings || value);
        setRetentionDays(String((value.settings || value).retention_days ?? 730));
      }
    });
    setLoading(false);
    if (failures.length) setError([...new Set(failures)].join(' '));
  }, [api]);
  useEffect(() => {
    if (user.role === 'admin') void load();
  }, [load, user.role]);

  useEffect(() => {
    if (user.role !== 'admin' || !['sources', 'mapping'].includes(tab)) return;
    let alive = true;
    const timer = setInterval(() => {
      void api('/api/integrations')
        .then((value) => {
          if (alive) setData(value);
        })
        .catch(() => {});
    }, 5000);
    return () => {
      alive = false;
      clearInterval(timer);
    };
  }, [api, tab, user.role]);
  async function run(action: () => Promise<void>, message?: string) {
    setBusy(true);
    setError('');
    setNotice('');
    try {
      await action();
      if (message) setNotice(message);
      onChanged();
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'Opslaan is mislukt. Je wijzigingen zijn niet opgeslagen.',
      );
    } finally {
      setBusy(false);
    }
  }
  const submit = (action: () => Promise<void>, message?: string) => (event: FormEvent) => {
    event.preventDefault();
    void run(action, message);
  };
  function chooseForm(id: string) {
    const existing = (data.forms || []).find((item: any) => item.id === id);
    setHistory(null);
    setPreview(null);
    if (!existing) return;
    setForm({
      source_id: existing.source_id,
      provider: existing.provider,
      form_id: String(existing.form_id),
      name: existing.name,
      purpose: existing.purpose || 'unclassified',
      version: Number(existing.version || existing.mapping_version || 1),
    });
    try {
      setMapping(
        JSON.stringify(
          typeof existing.mapping === 'string'
            ? JSON.parse(existing.mapping)
            : existing.mapping || JSON.parse(existing.mapping_json || '{}'),
          null,
          2,
        ),
      );
    } catch {
      setMapping('{}');
    }
    setSample(
      JSON.stringify(syntheticFields(existing.field_schema || existing.field_schema_json), null, 2),
    );
  }

  const currentRegistered = (data.forms || []).find(
    (item: any) =>
      item.source_id === form.source_id &&
      item.provider === form.provider &&
      String(item.form_id) === form.form_id,
  );
  const discoveredFields = fieldRows(
    currentRegistered?.field_schema || currentRegistered?.field_schema_json,
  );
  const currentMapping = parseObject(mapping);
  const suggestions = parseObject(currentRegistered?.mapping_suggestions);
  const setTarget = (fieldId: string, target: string) => {
    const value = { ...parseObject(mapping) };
    if (target) value[fieldId] = target;
    else delete value[fieldId];
    setMapping(JSON.stringify(value, null, 2));
    setPreview(null);
  };
  const chooseAndOpen = (id: string) => {
    chooseForm(id);
    setTab('mapping');
  };
  const copyText = (value: string) => {
    if (!navigator.clipboard) {
      setError('Selecteer de getoonde tekst en kopieer handmatig.');
      return;
    }
    void navigator.clipboard
      .writeText(value)
      .then(() => setNotice('Gekopieerd.'))
      .catch(() => setError('Selecteer de getoonde tekst en kopieer handmatig.'));
  };
  if (user.role !== 'admin')
    return (
      <div className="card empty">
        <ShieldCheck size={28} />
        <h2>Beheerdersrechten nodig</h2>
        <p>Bronverbindingen en persoonlijke accounts worden door de beheerder beheerd.</p>
      </div>
    );
  const tabs: { key: Tab; label: string; icon: typeof Plug }[] = [
    { key: 'sources', label: 'Bronverbindingen', icon: Plug },
    { key: 'mapping', label: 'Formuliermapping', icon: SlidersHorizontal },
    { key: 'import', label: 'Historische import', icon: FileInput },
    { key: 'users', label: 'Accounts & rechten', icon: Users },
    { key: 'catalog', label: 'Machinecatalogus', icon: SlidersHorizontal },
    { key: 'retention', label: 'Bewaarbeleid', icon: ShieldCheck },
  ];
  return (
    <div className="stack settings">
      <div
        className="tabs"
        role="tablist"
        aria-label="Instellingen"
        style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 8 }}
      >
        {tabs.map(({ key, label, icon: Icon }) => (
          <button
            type="button"
            role="tab"
            aria-selected={tab === key}
            key={key}
            className={`btn tab ${tab === key ? 'btn-primary' : 'btn-secondary'}`}
            onClick={() => {
              setTab(key);
              setError('');
              setNotice('');
            }}
          >
            <Icon size={16} />
            {label}
          </button>
        ))}
      </div>
      {error && (
        <div className="error" role="alert">
          <AlertCircle size={18} /> {error}
        </div>
      )}
      {notice && (
        <div className="notice" role="status">
          <Check size={18} /> {notice}
        </div>
      )}
      {loading ? (
        <div className="card muted">Instellingen worden geladen…</div>
      ) : (
        <>
          {tab === 'sources' && (
            <>
              <section className="card stack">
                <div className="section-heading">
                  <div>
                    <span className="eyebrow">WORDPRESS · GRAVITY FORMS</span>
                    <h2>Verbind de twee websites</h2>
                    <p className="muted">
                      Registreer elke WordPress-omgeving apart. Formulieren en veld-ID’s worden
                      daarna veilig opgehaald door de connector.
                    </p>
                  </div>
                  <a className="btn btn-secondary" href="/api/integrations/wordpress.zip">
                    <Plug size={16} />
                    WordPress-plugin downloaden
                  </a>
                </div>
                <ol
                  style={{
                    margin: 0,
                    paddingLeft: 21,
                    fontSize: 12,
                    lineHeight: 1.9,
                    color: '#65748a',
                  }}
                >
                  <li>Registreer hieronder OPTIMAT Group en KDT als afzonderlijke bron.</li>
                  <li>
                    Installeer de connector-ZIP via{' '}
                    <strong>WordPress → Plugins → Nieuwe plugin → Plugin uploaden</strong> op beide
                    sites. Voer de bron-ID en app-URL in, en configureer hetzelfde brongeheim veilig
                    op de server en in WordPress.
                  </li>
                  <li>
                    Synchroniseer de formulieren vanuit de connector. Beoordeel het doel en de
                    veldmapping per werkelijk gevonden formulier.
                  </li>
                  <li>
                    Activeer pas na controle de commerciële formulieren. Verstuur vervolgens een
                    herkenbare testinzending per bron en controleer de ontvangst.
                  </li>
                </ol>
                <div className="notice">
                  <ShieldCheck size={18} />
                  <span>
                    Een brongeheim wordt hier nooit gevraagd of getoond. Je vult een geheim
                    uitsluitend in de beveiligde server- en WordPress-configuratie in. Registratie
                    en formulierinventarisatie zijn nog geen bewijs van een werkende live intake.
                  </span>
                </div>
                <div className="form-grid">
                  {SOURCE_PRESETS.map((preset) => {
                    const existing = (data.sources || []).find(
                      (item: any) => originHost(item.site_url) === originHost(preset.site_url),
                    );
                    return (
                      <div
                        key={preset.secret_env}
                        className="card stack"
                        style={{ gap: 12, background: '#fafbf8' }}
                      >
                        <div>
                          <h3>{preset.name}</h3>
                          <p className="muted" style={{ fontSize: 11, overflowWrap: 'anywhere' }}>
                            {preset.site_url}
                          </p>
                        </div>
                        <button
                          className="btn btn-primary"
                          disabled={busy || Boolean(existing)}
                          onClick={() =>
                            void run(async () => {
                              await api('/api/integrations/sources', body(preset));
                              await load();
                            }, 'Bron geregistreerd. Gebruik de bron-ID hieronder om de WordPress-connector te koppelen.')
                          }
                        >
                          {existing ? 'Bron al geregistreerd' : `${preset.name} registreren`}
                        </button>
                        <small className="muted">
                          Servervariabele: <code>{preset.secret_env}</code>
                        </small>
                      </div>
                    );
                  })}
                </div>
              </section>
              <section className="card stack">
                <div className="section-heading">
                  <div>
                    <h2>Bronverbindingen</h2>
                    <p className="muted">
                      Afzonderlijke status, formulierdekking en laatste ontvangst per website.
                    </p>
                  </div>
                  <button
                    className="btn btn-secondary btn-small"
                    onClick={() => void run(load)}
                    disabled={busy}
                  >
                    <RefreshCw size={16} />
                    Vernieuwen
                  </button>
                </div>
                {!data.sources?.length ? (
                  <div className="empty">
                    <Plug size={28} />
                    <h3>Nog geen website geregistreerd</h3>
                    <p>
                      Gebruik de twee bronknoppen om de Gravity Forms-omgevingen voor te bereiden.
                    </p>
                  </div>
                ) : (
                  data.sources.map((site: any) => {
                    const forms = (data.forms || []).filter(
                      (item: any) => item.source_id === site.id,
                    );
                    const connector =
                      typeof site.connector_status === 'object'
                        ? site.connector_status || {}
                        : { status: site.connector_status };
                    const heartbeat =
                      site.last_heartbeat_at ||
                      connector.last_heartbeat_at ||
                      site.inventory_received_at;
                    return (
                      <article className="card stack" key={site.id} style={{ gap: 15 }}>
                        <div className="section-heading">
                          <div>
                            <h3>{site.name}</h3>
                            <p className="muted" style={{ overflowWrap: 'anywhere' }}>
                              {site.site_url}
                            </p>
                          </div>
                          <span className="badge">
                            {site.status === 'live_tested'
                              ? 'Live test bevestigd'
                              : site.last_received_at
                                ? 'Ontvangst geregistreerd'
                                : 'Nog niet live getest'}
                          </span>
                        </div>
                        <div className="form-grid">
                          <div>
                            <span className="data-label">Bron-ID voor WordPress</span>
                            <code style={{ fontSize: 11, overflowWrap: 'anywhere' }}>
                              {site.id}
                            </code>
                            <button
                              className="btn btn-text"
                              style={{ marginLeft: 10 }}
                              onClick={() => copyText(site.id)}
                            >
                              <Copy size={13} />
                              Kopiëren
                            </button>
                          </div>
                          <div>
                            <span className="data-label">Sales Hub-app-URL</span>
                            <code style={{ fontSize: 11, overflowWrap: 'anywhere' }}>
                              {window.location.origin}
                            </code>
                          </div>
                          <div>
                            <span className="data-label">Laatste connectorcontact</span>
                            <strong style={{ fontSize: 12 }}>{date(heartbeat)}</strong>
                            <small className="muted" style={{ display: 'block' }}>
                              Status:{' '}
                              {connector.status === 'connected'
                                ? 'Connector bereikbaar'
                                : connector.status === 'stale'
                                  ? 'Contact verouderd'
                                  : ['missing_secret', 'secret_missing'].includes(connector.status)
                                    ? 'Brongeheim ontbreekt'
                                    : 'Nog niet gekoppeld'}
                            </small>
                          </div>
                          <div>
                            <span className="data-label">Servergeheim beschikbaar</span>
                            <strong style={{ fontSize: 12 }}>
                              {site.secret_configured || site.configured
                                ? 'Ingesteld'
                                : 'Nog niet ingesteld'}
                            </strong>
                            <small className="muted" style={{ display: 'block' }}>
                              <code>{site.secret_env}</code>
                            </small>
                          </div>
                          <div>
                            <span className="data-label">Formulierinventaris</span>
                            <strong style={{ fontSize: 12 }}>
                              {site.inventory_complete
                                ? 'Synchronisatie ontvangen'
                                : 'Nog onvolledig'}
                            </strong>
                            <small className="muted" style={{ display: 'block' }}>
                              {date(site.inventory_received_at)} · {forms.length} formulier(en)
                            </small>
                          </div>
                          <div>
                            <span className="data-label">Laatste formulierontvangst</span>
                            <strong style={{ fontSize: 12 }}>
                              {date(site.last_received_at || site.last_success_at)}
                            </strong>
                          </div>
                        </div>
                        <div className="notice">
                          <span>
                            Neem deze bron-ID en app-URL over in de WordPress-connector.
                            Formulierontvangst en inventarisatie worden apart gecontroleerd; een
                            ontvangen inventaris activeert geen commerciële intake.
                          </span>
                        </div>
                        {forms.length ? (
                          <div className="table-wrap">
                            <table>
                              <thead>
                                <tr>
                                  <th>Ontdekt formulier</th>
                                  <th>Doel / routing</th>
                                  <th>Velden</th>
                                  <th>Dekking</th>
                                  <th>Controle</th>
                                </tr>
                              </thead>
                              <tbody>
                                {forms.map((item: any) => (
                                  <tr key={item.id}>
                                    <td>
                                      <strong>{item.name}</strong>
                                      <small>
                                        {item.provider} · ID {item.form_id}
                                      </small>
                                    </td>
                                    <td>
                                      {purposeLabels[item.purpose] ||
                                        item.purpose ||
                                        'Nog te beoordelen'}
                                    </td>
                                    <td>
                                      {
                                        fieldRows(item.field_schema || item.field_schema_json)
                                          .length
                                      }
                                    </td>
                                    <td>
                                      {coverageLabels[item.coverage] || 'Nog te configureren'}
                                    </td>
                                    <td>
                                      <button
                                        className="btn btn-secondary btn-small"
                                        onClick={() => chooseAndOpen(item.id)}
                                      >
                                        Velden en mapping controleren
                                      </button>
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        ) : (
                          <p className="muted" style={{ fontSize: 12 }}>
                            Nog geen formulierinventaris ontvangen. Installeer de connector en start
                            daar de synchronisatie.
                          </p>
                        )}
                      </article>
                    );
                  })
                )}
              </section>
              <section className="card">
                <h2>Website registreren</h2>
                <form
                  className="stack"
                  onSubmit={submit(async () => {
                    await api(
                      '/api/integrations/sources',
                      body({
                        ...source,
                        previous_secret_env: source.previous_secret_env || undefined,
                      }),
                    );
                    setSource({ name: '', site_url: '', secret_env: '', previous_secret_env: '' });
                    await load();
                  }, 'Bron geregistreerd. Configureer het brongeheim en de connector op de website.')}
                >
                  <div className="form-grid">
                    <Input
                      label="Naam"
                      required
                      value={source.name}
                      onChange={(e) => setSource({ ...source, name: e.target.value })}
                      placeholder="OPTIMAT Group"
                    />
                    <Input
                      label="Website-URL"
                      type="url"
                      required
                      value={source.site_url}
                      onChange={(e) => setSource({ ...source, site_url: e.target.value })}
                      placeholder="https://www.optimat-group.com"
                    />
                    <Input
                      label="Naam omgevingsvariabele voor brongeheim"
                      required
                      pattern="[A-Z][A-Z0-9_]*"
                      value={source.secret_env}
                      onChange={(e) => setSource({ ...source, secret_env: e.target.value })}
                      placeholder="OPTIMAT_WP_SECRET"
                    />
                    <Input
                      label="Vorige geheime variabele bij rotatie (optioneel)"
                      value={source.previous_secret_env}
                      onChange={(e) =>
                        setSource({ ...source, previous_secret_env: e.target.value })
                      }
                      placeholder="OPTIMAT_WP_SECRET_PREVIOUS"
                    />
                  </div>
                  <p className="muted">
                    Voer hier alleen de naam van de variabele in. Geheimen horen in de
                    serveromgeving en de WordPress-configuratie, nooit in formuliermapping of
                    browsercode.
                  </p>
                  <div>
                    <button className="btn btn-primary" disabled={busy}>
                      Bron registreren
                    </button>
                  </div>
                </form>
              </section>
              <section className="card">
                <h2>Recente ontvangsten</h2>
                <p className="muted">
                  Mislukte verwerking blijft beschikbaar voor diagnose en opnieuw aanbieden.
                </p>
                {!data.events?.length ? (
                  <p className="muted">Er zijn nog geen events ontvangen.</p>
                ) : (
                  <div className="table-wrap">
                    <table>
                      <thead>
                        <tr>
                          <th>Event</th>
                          <th>Status</th>
                          <th>Ontvangen</th>
                          <th>Pogingen</th>
                          <th>Actie</th>
                        </tr>
                      </thead>
                      <tbody>
                        {data.events.map((event: any) => (
                          <tr key={event.id}>
                            <td>
                              <code>{event.event_id || event.id}</code>
                              <div className="muted">
                                {event.form_name || event.form_id || event.provider || ''}
                              </div>
                            </td>
                            <td>
                              <span className="badge">
                                {coverageLabels[event.status] || event.status}
                              </span>
                              {(event.error_code || event.last_error) && (
                                <div className="muted">{event.error_code || event.last_error}</div>
                              )}
                            </td>
                            <td>{date(event.received_at || event.created_at)}</td>
                            <td>{event.attempts ?? 0}</td>
                            <td>
                              {['failed', 'pending', 'dead'].includes(event.status) && (
                                <button
                                  className="btn btn-secondary btn-small"
                                  disabled={busy}
                                  onClick={() =>
                                    void run(async () => {
                                      await api(
                                        `/api/integrations/events/${event.id}/retry`,
                                        body({}),
                                      );
                                      await load();
                                    }, 'Event opnieuw in de wachtrij geplaatst.')
                                  }
                                >
                                  <RefreshCw size={14} />
                                  Opnieuw
                                </button>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </section>
            </>
          )}
          {tab === 'mapping' && (
            <>
              <section className="card">
                <h2>Formulierregister</h2>
                <p className="muted">
                  Elk formulier heeft een eigen provider, doel en versie van de veldmapping.
                  Niet-commerciële formulieren komen niet in de verkoopintake.
                </p>
                {data.forms?.length ? (
                  <div className="table-wrap">
                    <table>
                      <thead>
                        <tr>
                          <th>Formulier</th>
                          <th>Website</th>
                          <th>Provider / ID</th>
                          <th>Doel</th>
                          <th>Zakelijke velden</th>
                          <th>Dekking</th>
                          <th>Mapping</th>
                        </tr>
                      </thead>
                      <tbody>
                        {data.forms.map((f: any) => (
                          <tr key={f.id}>
                            <td>{f.name}</td>
                            <td>
                              {data.sources?.find((site: any) => site.id === f.source_id)?.name ||
                                f.source_id}
                            </td>
                            <td>
                              {f.provider}
                              <div className="muted">{f.form_id}</div>
                            </td>
                            <td>{purposeLabels[f.purpose] || f.purpose || 'Nog te beoordelen'}</td>
                            <td>{fieldRows(f.field_schema || f.field_schema_json).length}</td>
                            <td>
                              {coverageLabels[f.coverage || f.status] ||
                                f.coverage ||
                                f.status ||
                                'Nog te configureren'}
                            </td>
                            <td>
                              <div className="row">
                                <button
                                  className="btn btn-secondary btn-small"
                                  onClick={() => chooseForm(f.id)}
                                >
                                  Bewerken
                                </button>
                                <button
                                  className="btn btn-secondary btn-small"
                                  disabled={busy}
                                  onClick={() =>
                                    void run(async () =>
                                      setHistory(
                                        await api(`/api/integrations/form-history/${f.id}`),
                                      ),
                                    )
                                  }
                                >
                                  Historie
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <p className="muted">Nog geen formulieren geregistreerd.</p>
                )}
                <JsonResult value={history} />
              </section>
              <section className="card">
                <h2>Mapping aanmaken of wijzigen</h2>
                <form
                  className="stack"
                  onSubmit={submit(async () => {
                    const value = JSON.parse(mapping);
                    if (!value || Array.isArray(value) || typeof value !== 'object')
                      throw new Error('De mapping moet een JSON-object zijn.');
                    const saved = await api<any>(
                      '/api/integrations/forms',
                      body({ ...form, mapping: value }),
                    );
                    setForm((current) => ({ ...current, version: saved.version }));
                    await load();
                    setPreview(null);
                  }, 'Formuliermapping opgeslagen. Bestaande versies blijven in de historie.')}
                >
                  <div className="form-grid">
                    <label className="field">
                      <span>Bronwebsite</span>
                      <select
                        required
                        value={form.source_id}
                        onChange={(e) => setForm({ ...form, source_id: e.target.value })}
                      >
                        <option value="">Kies een bron</option>
                        {data.sources?.map((s: any) => (
                          <option key={s.id} value={s.id}>
                            {s.name}
                          </option>
                        ))}
                      </select>
                    </label>
                    <Input
                      label="Formuliernaam"
                      required
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                    />
                    <Input
                      label="Provider (geverifieerde pluginnaam)"
                      required
                      value={form.provider}
                      onChange={(e) => setForm({ ...form, provider: e.target.value })}
                    />
                    <Input
                      label="Oorspronkelijk formulier-ID"
                      required
                      value={form.form_id}
                      onChange={(e) => setForm({ ...form, form_id: e.target.value })}
                    />
                    <label className="field">
                      <span>Doel / routing</span>
                      <select
                        aria-label="Doel / routing"
                        value={form.purpose}
                        onChange={(e) => setForm({ ...form, purpose: e.target.value })}
                      >
                        <option value="unclassified">
                          Nog te beoordelen (intake niet geactiveerd)
                        </option>
                        <option value="commercial">Commerciële aanvraag</option>
                        <option value="support">Support (buiten verkooppipeline)</option>
                        <option value="recruitment">Vacature (afgeschermde routing)</option>
                        <option value="newsletter">Nieuwsbrief (buiten verkooppipeline)</option>
                      </select>
                    </label>
                    <Input
                      label="Huidige versie (controle op gelijktijdige wijzigingen)"
                      required
                      min={1}
                      type="number"
                      readOnly
                      value={form.version}
                      onChange={(e) => setForm({ ...form, version: Number(e.target.value) })}
                    />
                  </div>
                  {form.purpose === 'unclassified' && (
                    <div className="notice">
                      <AlertCircle size={18} />
                      <span>
                        Kies eerst een passende routing. Een ontdekt formulier komt niet automatisch
                        in de commerciële intake. Sollicitatie-, support- en nieuwsbriefgegevens
                        horen niet in een verkoopdossier.
                      </span>
                    </div>
                  )}
                  {currentRegistered && currentRegistered.version !== form.version && (
                    <div className="error">
                      De opgeslagen mapping is intussen gewijzigd. Open dit formulier opnieuw via
                      het formulierregister vóór je wijzigingen opslaat.
                    </div>
                  )}
                  <section className="stack" style={{ gap: 14 }}>
                    <div className="section-heading">
                      <div>
                        <h3>Gevonden Gravity Forms-velden</h3>
                        <p className="muted">
                          Gebruik de echte veld-ID’s uit de gesynchroniseerde formulierstructuur.
                          Suggesties worden pas overgenomen wanneer je ze uitdrukkelijk toepast.
                        </p>
                      </div>
                      {Object.keys(suggestions).length > 0 && (
                        <button
                          type="button"
                          className="btn btn-secondary"
                          disabled={busy}
                          onClick={() => {
                            setMapping(
                              JSON.stringify({ ...suggestions, ...parseObject(mapping) }, null, 2),
                            );
                            setPreview(null);
                            setNotice(
                              'Mappingsuggesties staan in de editor. Controleer ze en klik daarna op Mapping opslaan om ze te activeren.',
                            );
                          }}
                        >
                          Mappingsuggesties toepassen
                        </button>
                      )}
                    </div>
                    {discoveredFields.length ? (
                      <div className="table-wrap">
                        <table>
                          <thead>
                            <tr>
                              <th>Veld-ID / label</th>
                              <th>Type / opties</th>
                              <th>Suggestie</th>
                              <th>Opslaan als</th>
                            </tr>
                          </thead>
                          <tbody>
                            {discoveredFields.map((field: any) => (
                              <tr key={field.id}>
                                <td>
                                  <strong>{field.label || field.id}</strong>
                                  <small>
                                    {field.compound ? 'Subveld · ' : ''}ID {field.id}
                                  </small>
                                </td>
                                <td>
                                  {field.type || 'Onbekend'}
                                  {parseArray(field.options).length > 0 && (
                                    <small style={{ whiteSpace: 'normal', maxWidth: 230 }}>
                                      {parseArray(field.options)
                                        .map((option: any) =>
                                          typeof option === 'object'
                                            ? option.label || option.text || option.value
                                            : String(option),
                                        )
                                        .join(' · ')}
                                    </small>
                                  )}
                                </td>
                                <td>
                                  {suggestions[field.id]
                                    ? TARGET_LABELS[suggestions[field.id]] || suggestions[field.id]
                                    : 'Geen voorstel'}
                                </td>
                                <td>
                                  <select
                                    style={{
                                      maxWidth: 220,
                                      fontSize: 11,
                                      padding: 8,
                                      border: '1px solid #dfe4ec',
                                      borderRadius: 6,
                                    }}
                                    aria-label={`CRM-veld voor ${field.label || field.id} (${field.id})`}
                                    value={currentMapping[field.id] || ''}
                                    onChange={(event) => setTarget(field.id, event.target.value)}
                                  >
                                    <option value="">Extra formuliergegevens bewaren</option>
                                    {TARGETS.map((target) => (
                                      <option key={target} value={target}>
                                        {TARGET_LABELS[target]}
                                      </option>
                                    ))}
                                  </select>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    ) : (
                      <div className="notice">
                        Nog geen veldschema ontvangen voor dit formulier. Synchroniseer eerst de
                        Gravity Forms-inventaris vanuit WordPress. De geavanceerde JSON-editor
                        blijft beschikbaar voor gecontroleerde handmatige configuratie.
                      </div>
                    )}
                    <div className="row">
                      <button
                        type="button"
                        className="btn btn-secondary btn-small"
                        disabled={!discoveredFields.length}
                        onClick={() => {
                          setSample(
                            JSON.stringify(
                              syntheticFields(
                                currentRegistered.field_schema ||
                                  currentRegistered.field_schema_json,
                              ),
                              null,
                              2,
                            ),
                          );
                          setPreview(null);
                        }}
                      >
                        Synthetisch voorbeeld maken
                      </button>
                      <small className="muted">
                        Voorbeelden bevatten uitsluitend verzonnen testwaarden. Er worden geen live
                        formulierinzendingen ingelezen in deze editor.
                      </small>
                    </div>
                  </section>
                  <details>
                    <summary style={{ cursor: 'pointer', fontSize: 12, color: '#65748a' }}>
                      Geavanceerde JSON-veldmapping
                    </summary>
                    <label className="field">
                      <span>Veldmapping (veld-ID → CRM-veld)</span>
                      <textarea
                        rows={8}
                        spellCheck={false}
                        value={mapping}
                        onChange={(e) => setMapping(e.target.value)}
                        placeholder={'{ "bedrijf": "company_name", "e-mail": "email" }'}
                      />
                    </label>
                  </details>
                  <p className="muted">
                    Beschikbaar: company_name, name, email, phone, enterprise_number, country,
                    address, postcode, city, business_unit, brand, machine, model, message,
                    language, campaign. Onbekende zakelijke velden blijven zichtbaar in de fiche.
                    Neem geen wachtwoorden of CAPTCHA-tokens op.
                  </p>
                  <label className="field">
                    <span>Synthetische voorbeeldvelden voor test (JSON-array)</span>
                    <textarea
                      rows={6}
                      spellCheck={false}
                      value={sample}
                      onChange={(e) => setSample(e.target.value)}
                      placeholder={
                        '[{"id":"bedrijf","label":"Bedrijf","type":"text","value":"Voorbeeld"}]'
                      }
                    />
                  </label>
                  <div className="row">
                    <button
                      type="button"
                      className="btn btn-secondary"
                      disabled={busy}
                      onClick={() =>
                        void run(async () =>
                          setPreview(
                            await api(
                              '/api/integrations/preview',
                              body({ fields: JSON.parse(sample), mapping: JSON.parse(mapping) }),
                            ),
                          ),
                        )
                      }
                    >
                      Voorbeeld testen
                    </button>
                    <button className="btn btn-primary" disabled={busy}>
                      Mapping opslaan
                    </button>
                  </div>
                  <JsonResult value={preview} />
                </form>
              </section>
            </>
          )}
          {tab === 'import' && (
            <section className="card">
              <h2>Historische aanvragen importeren</h2>
              <p className="muted">
                Importeer het ontvangstcontract als JSON. Controleer eerst duplicaten en fouten.
                Oorspronkelijke inzenddatums blijven behouden; onbekende historische
                verkoopstatussen worden niet verzonnen.
              </p>
              <form
                className="stack"
                onSubmit={submit(async () => {
                  setImportResult(
                    await api(
                      '/api/integrations/import/preview',
                      body({ source_id: importSource, events: JSON.parse(importText) }),
                    ),
                  );
                  setImportChecked(true);
                })}
              >
                <label className="field">
                  <span>Bronwebsite</span>
                  <select
                    required
                    value={importSource}
                    onChange={(e) => {
                      setImportSource(e.target.value);
                      setImportChecked(false);
                    }}
                  >
                    <option value="">Kies een bron</option>
                    {data.sources?.map((s: any) => (
                      <option value={s.id} key={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="field">
                  <span>Bestand openen (.json)</span>
                  <input
                    type="file"
                    accept="application/json,.json"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file)
                        void file
                          .text()
                          .then((text) => {
                            setImportText(text);
                            setImportChecked(false);
                          })
                          .catch(() => setError('Bestand kon niet worden gelezen.'));
                    }}
                  />
                </label>
                <label className="field">
                  <span>Events (JSON-array)</span>
                  <textarea
                    rows={14}
                    spellCheck={false}
                    value={importText}
                    onChange={(e) => {
                      setImportText(e.target.value);
                      setImportChecked(false);
                    }}
                  />
                </label>
                <div className="row">
                  <button className="btn btn-secondary" disabled={busy}>
                    Voorbeeld en duplicaten controleren
                  </button>
                  <button
                    type="button"
                    className="btn btn-primary"
                    disabled={busy || !importChecked}
                    onClick={() =>
                      void run(async () => {
                        setImportResult(
                          await api(
                            '/api/integrations/import/commit',
                            body({ source_id: importSource, events: JSON.parse(importText) }),
                          ),
                        );
                        setImportChecked(false);
                        await load();
                      }, 'Import verwerkt. Bekijk het importverslag voor fouten en duplicaten.')
                    }
                  >
                    Gecontroleerde import uitvoeren
                  </button>
                </div>
              </form>
              <JsonResult value={importResult} />
            </section>
          )}
          {tab === 'users' && (
            <>
              <section className="card">
                <h2>Persoonlijke accounts</h2>
                <p className="muted">
                  Toegang wordt op de server gecontroleerd. Verkopers zien alleen hun toegewezen
                  dossiers. Salesmanagers en management met een team-ID zien hun team en
                  niet-toegewezen intake; een leeg team geeft hen organisatiebrede toegang.
                  Beheerders hebben organisatiebrede toegang.
                </p>
                <div className="table-wrap">
                  <table>
                    <thead>
                      <tr>
                        <th>Gebruiker</th>
                        <th>Rol</th>
                        <th>Team</th>
                        <th>Status</th>
                        <th>Marketingvelden</th>
                        <th>Toegang</th>
                      </tr>
                    </thead>
                    <tbody>
                      {users.map((u: any) => (
                        <tr key={u.id}>
                          <td>
                            <strong>{u.name}</strong>
                            <div className="muted">{u.email}</div>
                          </td>
                          <td>
                            <select
                              aria-label={`Rol van ${u.name}`}
                              value={u.role}
                              disabled={busy || u.id === user.id}
                              onChange={(e) =>
                                void run(async () => {
                                  await api(
                                    `/api/admin/users/${u.id}`,
                                    body({ role: e.target.value }, 'PATCH'),
                                  );
                                  await load();
                                }, 'Rol bijgewerkt.')
                              }
                            >
                              {ROLES.map((role) => (
                                <option key={role} value={role}>
                                  {LABELS[role]}
                                </option>
                              ))}
                            </select>
                          </td>
                          <td>
                            <form
                              className="row"
                              onSubmit={(event) => {
                                event.preventDefault();
                                const fields = new FormData(event.currentTarget);
                                void run(async () => {
                                  await api(
                                    `/api/admin/users/${u.id}`,
                                    body(
                                      {
                                        team_id: String(fields.get('team_id') || '').trim() || null,
                                      },
                                      'PATCH',
                                    ),
                                  );
                                  await load();
                                }, 'Team bijgewerkt. De server past de nieuwe toegangsgrens meteen toe.');
                              }}
                            >
                              <input
                                aria-label={`Team van ${u.name}`}
                                name="team_id"
                                defaultValue={u.team_id || ''}
                                placeholder="Organisatiebreed"
                                maxLength={100}
                                disabled={busy}
                                style={{
                                  width: 145,
                                  padding: '8px 9px',
                                  border: '1px solid #dfe4ec',
                                  borderRadius: 6,
                                  fontSize: 11,
                                }}
                              />
                              <button className="btn btn-secondary btn-small" disabled={busy}>
                                Team opslaan
                              </button>
                            </form>
                          </td>
                          <td>
                            <span className="badge">{u.active ? 'Actief' : 'Ingetrokken'}</span>
                          </td>
                          <td>
                            <label>
                              <input
                                type="checkbox"
                                aria-label={`Marketingpermissie ${u.name}`}
                                checked={Boolean(u.marketing_permission)}
                                disabled={busy || u.id === user.id}
                                onChange={(e) =>
                                  void run(async () => {
                                    await api(
                                      `/api/admin/users/${u.id}`,
                                      body({ marketing_permission: e.target.checked }, 'PATCH'),
                                    );
                                    await load();
                                  })
                                }
                              />{' '}
                              Beheren
                            </label>
                          </td>
                          <td>
                            <button
                              className="btn btn-secondary btn-small"
                              disabled={busy || u.id === user.id}
                              onClick={() =>
                                void run(async () => {
                                  await api(
                                    `/api/admin/users/${u.id}`,
                                    body({ active: !u.active }, 'PATCH'),
                                  );
                                  await load();
                                }, 'Accounttoegang bijgewerkt.')
                              }
                            >
                              {u.active ? 'Toegang intrekken' : 'Opnieuw activeren'}
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </section>
              <section className="card">
                <h2>Collega uitnodigen</h2>
                <form
                  className="stack"
                  onSubmit={submit(async () => {
                    const result = await api<any>(
                      '/api/admin/invitations',
                      body({ ...invitation, team_id: invitation.team_id || undefined }),
                    );
                    const returned =
                      result.url ||
                      result.invitation_url ||
                      `/invite?token=${encodeURIComponent(result.token)}`;
                    setInvitationUrl(new URL(returned, window.location.origin).href);
                  }, 'Uitnodiging aangemaakt. Deel de eenmalige link via een beveiligd kanaal.')}
                >
                  <div className="form-grid">
                    <Input
                      label="Naam"
                      required
                      value={invitation.name}
                      onChange={(e) => setInvitation({ ...invitation, name: e.target.value })}
                    />
                    <Input
                      label="Zakelijk e-mailadres"
                      type="email"
                      required
                      value={invitation.email}
                      onChange={(e) => setInvitation({ ...invitation, email: e.target.value })}
                    />
                    <label className="field">
                      <span>Rol</span>
                      <select
                        value={invitation.role}
                        onChange={(e) => setInvitation({ ...invitation, role: e.target.value })}
                      >
                        {ROLES.map((role) => (
                          <option key={role} value={role}>
                            {LABELS[role]}
                          </option>
                        ))}
                      </select>
                    </label>
                    <Input
                      label="Team-ID (leeg: organisatiebreed voor manager/management)"
                      maxLength={100}
                      value={invitation.team_id}
                      onChange={(e) => setInvitation({ ...invitation, team_id: e.target.value })}
                    />
                  </div>
                  <label>
                    <input
                      type="checkbox"
                      checked={invitation.marketing_permission}
                      onChange={(e) =>
                        setInvitation({ ...invitation, marketing_permission: e.target.checked })
                      }
                    />{' '}
                    Bron- en campagnevelden beheren
                  </label>
                  <div>
                    <button className="btn btn-primary" disabled={busy}>
                      Uitnodiging aanmaken
                    </button>
                  </div>
                </form>
                {invitationUrl && (
                  <div className="notice stack" style={{ marginTop: 20 }}>
                    <div>
                      <Link2 size={17} /> Eenmalige uitnodigingslink
                    </div>
                    <input aria-label="Uitnodigingslink" readOnly value={invitationUrl} />
                    <button
                      className="btn btn-secondary"
                      onClick={() => {
                        if (!navigator.clipboard) {
                          setError(
                            'Kopiëren is niet beschikbaar. Selecteer de link en kopieer handmatig.',
                          );
                          return;
                        }
                        void navigator.clipboard
                          .writeText(invitationUrl)
                          .then(() => setNotice('Uitnodigingslink gekopieerd.'))
                          .catch(() =>
                            setError(
                              'Kopiëren is niet beschikbaar. Selecteer de link en kopieer handmatig.',
                            ),
                          );
                      }}
                    >
                      <Copy size={15} />
                      Link kopiëren
                    </button>
                    <p className="muted">
                      Deze link geeft toegang tot het account. Deel hem alleen met de uitgenodigde
                      collega.
                    </p>
                  </div>
                )}
              </section>
            </>
          )}
          {tab === 'catalog' && (
            <section className="card">
              <h2>Machinecatalogus</h2>
              <p className="muted">
                Beheer normalisaties zonder de oorspronkelijke machinebenaming te verliezen.
              </p>
              <div className="table-wrap">
                <table>
                  <thead>
                    <tr>
                      <th>Categorie</th>
                      <th>Merk</th>
                      <th>Model</th>
                    </tr>
                  </thead>
                  <tbody>
                    {catalog.length ? (
                      catalog.map((item: any) => (
                        <tr key={item.id}>
                          <td>{item.category}</td>
                          <td>{item.brand || '—'}</td>
                          <td>{item.model || '—'}</td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={3} className="muted">
                          Nog geen catalogusitems.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
              <form
                className="stack"
                style={{ marginTop: 24 }}
                onSubmit={submit(async () => {
                  await api('/api/catalog', body(catalogForm));
                  setCatalogForm({ category: '', brand: '', model: '' });
                  await load();
                }, 'Catalogusitem opgeslagen.')}
              >
                <div className="form-grid">
                  <Input
                    label="Categorie"
                    required
                    value={catalogForm.category}
                    onChange={(e) => setCatalogForm({ ...catalogForm, category: e.target.value })}
                  />
                  <Input
                    label="Merk (optioneel)"
                    value={catalogForm.brand}
                    onChange={(e) => setCatalogForm({ ...catalogForm, brand: e.target.value })}
                  />
                  <Input
                    label="Model (optioneel)"
                    value={catalogForm.model}
                    onChange={(e) => setCatalogForm({ ...catalogForm, model: e.target.value })}
                  />
                </div>
                <div>
                  <button className="btn btn-primary" disabled={busy}>
                    Catalogusitem toevoegen
                  </button>
                </div>
              </form>
            </section>
          )}
          {tab === 'retention' && (
            <section className="card">
              <h2>Bewaarbeleid</h2>
              <p className="muted">
                Bewaartermijnen zijn een beheerderskeuze. Maak vóór verwijdering een gecontroleerde
                selectie en respecteer de afspraken met betrokkenen.
              </p>
              <form
                className="stack"
                onSubmit={submit(async () => {
                  const result = await api<any>(
                    '/api/admin/settings',
                    body({ retention_days: Number(retentionDays) }, 'PATCH'),
                  );
                  setSettings(result.settings || result);
                }, 'Bewaarbeleid opgeslagen.')}
              >
                <Input
                  label="Bewaartermijn in dagen"
                  type="number"
                  min={30}
                  max={3650}
                  required
                  value={retentionDays}
                  onChange={(e) => setRetentionDays(e.target.value)}
                />
                <div>
                  <button className="btn btn-primary" disabled={busy}>
                    Bewaarbeleid opslaan
                  </button>
                </div>
              </form>
              <p className="muted" style={{ marginTop: 20 }}>
                Back-ups en herstel worden server-side uitgevoerd. Zie de beheerhandleiding voor
                versleutelde opslag, bewaartermijnen van back-ups en gerichte export/verwijdering.
              </p>
              <JsonResult value={Object.keys(settings).length ? settings : null} />
            </section>
          )}
        </>
      )}
    </div>
  );
}
