import React, { useCallback, useEffect, useState } from 'react';
import {
  ArrowDownToLine,
  ArrowRight,
  ArrowUpRight,
  Bell,
  Building2,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Clock3,
  Download,
  FileText,
  Filter,
  LayoutDashboard,
  LayoutGrid,
  List,
  ListTodo,
  LogOut,
  Mail,
  MapPin,
  Menu,
  MessageSquare,
  MoreHorizontal,
  Phone,
  Plus,
  RefreshCw,
  Search,
  Settings2,
  ShieldCheck,
  Sparkles,
  Target,
  TrendingUp,
  Users,
  X,
  WifiOff,
  BriefcaseBusiness,
} from 'lucide-react';
import { LABELS, REQUEST_STATUSES, STAGES, ROLES, type User } from '../shared/domain';
import Settings from './Settings';
import MapView from './MapView';
import Prospecting from './Prospecting';

type Row = Record<string, any>;
type API = <T = any>(path: string, options?: RequestInit) => Promise<T>;
const money = (v: any) =>
  v === null || v === undefined
    ? 'Onbekend'
    : new Intl.NumberFormat('nl-BE', {
        style: 'currency',
        currency: 'EUR',
        maximumFractionDigits: 0,
      }).format(Number(v));
const date = (v: any, withTime = false) =>
  v && !Number.isNaN(new Date(v).getTime())
    ? new Intl.DateTimeFormat('nl-BE', {
        dateStyle: 'medium',
        ...(withTime ? { timeStyle: 'short' as const } : {}),
        timeZone: 'Europe/Brussels',
      }).format(new Date(v))
    : 'Niet ingevuld';
const label = (v: any) => LABELS[v] || v || 'Onbekend';
const intents = (r: Row) => {
  try {
    return typeof r.intents === 'string' ? JSON.parse(r.intents) : r.intents || [];
  } catch {
    return [];
  }
};
const initials = (s: string = '?') =>
  s
    .split(' ')
    .map((x) => x[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();
const parseJson = (s: any, fallback: any = []) => {
  try {
    return typeof s === 'string' ? JSON.parse(s) : (s ?? fallback);
  } catch {
    return fallback;
  }
};
const qs = (filters: Row) => {
  const p = new URLSearchParams();
  Object.entries(filters).forEach(([k, v]) => v && p.set(k, String(v)));
  return p.toString();
};
const sections = [
  ['overview', 'Overzicht', LayoutDashboard],
  ['requests', 'Aanvragen', FileText],
  ['opportunities', 'Verkoopkansen', Target],
  ['companies', 'Bedrijven', Building2],
  ['map', 'Kaart', MapPin],
  ['tasks', 'Taken', ListTodo],
  ['reports', 'Rapporten', TrendingUp],
  ['prospecting', 'Prospectie', Search],
  ['settings', 'Instellingen', Settings2],
] as const;
const titles: Row = {
  overview: ['Goed werk begint met overzicht.', 'Alle aanvragen en vervolgacties op één plek.'],
  requests: ['Van aanvraag naar gesprek.', 'Beoordeel nieuwe interesse en plan de volgende stap.'],
  opportunities: [
    'Elke kans een stap verder.',
    'Een heldere pipeline voor de kansen die ertoe doen.',
  ],
  companies: [
    'De mensen achter de bedrijven.',
    'Eén dossier, met alle aanvragen en verkoopkansen.',
  ],
  map: ['Je portefeuille in beeld.', 'Aanvragen en verkoopkansen op de Benelux-kaart.'],
  tasks: ['Ruimte voor de volgende stap.', 'Plan, volg op en houd je afspraken bij.'],
  reports: [
    'Inzicht dat richting geeft.',
    'Betrouwbare cijfers, van aanvraag tot geregistreerde verkoop.',
  ],
  prospecting: ['Vind je volgende gesprek.', 'Gerichte prospectie, apart van je websiteaanvragen.'],
  settings: ['Een betrouwbare basis.', 'Beheer je team, bronnen en integraties.'],
};
function Button({ children, ...props }: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button type="button" className="btn btn-secondary" {...props}>
      {children}
    </button>
  );
}
function Empty({
  icon: Icon = FileText,
  title,
  children,
  action,
}: {
  icon?: any;
  title: string;
  children?: React.ReactNode;
  action?: React.ReactNode;
}) {
  return (
    <div className="empty">
      <span className="empty-icon">
        <Icon size={25} />
      </span>
      <h3>{title}</h3>
      <p>{children}</p>
      {action}
    </div>
  );
}
function Status({ value }: { value: any }) {
  return <span className={`badge status-${value}`}>{label(value)}</span>;
}
function Loading() {
  return (
    <div className="loading" role="status">
      <RefreshCw size={20} className="spin" /> Gegevens laden…
    </div>
  );
}
function Stat({
  title,
  value,
  detail,
  icon: Icon = TrendingUp,
  accent = false,
}: {
  title: string;
  value: any;
  detail: string;
  icon?: any;
  accent?: boolean;
}) {
  return (
    <article className={`stat ${accent ? 'stat-accent' : ''}`}>
      <div className="stat-label">
        {title}
        <Icon size={18} />
      </div>
      <strong>{value}</strong>
      <span>{detail}</span>
    </article>
  );
}
function useData<T = any>(api: API, path: string, tick: number = 0) {
  const [data, setData] = useState<T | null>(null),
    [error, setError] = useState(''),
    [loading, setLoading] = useState(true);
  useEffect(() => {
    let alive = true;
    setLoading(true);
    api<T>(path)
      .then((d) => {
        if (alive) {
          setData(d);
          setError('');
        }
      })
      .catch((e) => {
        if (alive) setError(e.message);
      })
      .finally(() => {
        if (alive) setLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [api, path, tick]);
  return { data, error, loading };
}
function ErrorBox({ error }: { error: string }) {
  return error ? (
    <div className="error" role="alert">
      {error}
    </div>
  ) : null;
}

export default function App() {
  const [user, setUser] = useState<User | null>(null),
    [csrf, setCsrf] = useState(''),
    [boot, setBoot] = useState(true),
    [path, setPath] = useState(location.pathname),
    [mobile, setMobile] = useState(false),
    [offline, setOffline] = useState(false),
    [tick, setTick] = useState(0),
    [lastSync, setLastSync] = useState<Date | null>(null),
    [filters, setFilters] = useState<Row>({}),
    [globalError, setGlobalError] = useState('');
  const navigate = useCallback((p: string) => {
    history.pushState({}, '', p);
    setPath(p);
    setMobile(false);
    window.scrollTo(0, 0);
  }, []);
  useEffect(() => {
    const cb = () => setPath(location.pathname);
    window.addEventListener('popstate', cb);
    return () => window.removeEventListener('popstate', cb);
  }, []);
  const api = useCallback<API>(
    async (p, opts = {}) => {
      const headers = new Headers(opts.headers);
      if (opts.body) headers.set('content-type', 'application/json');
      if (csrf) headers.set('x-csrf-token', csrf);
      let response: Response;
      try {
        response = await fetch(p, { ...opts, headers, credentials: 'same-origin' });
        setOffline(false);
      } catch {
        setOffline(true);
        throw new Error(
          'Geen verbinding. Je wijziging is niet opgeslagen. Probeer opnieuw zodra de verbinding is hersteld.',
        );
      }
      const d = await response.json().catch(() => ({}));
      if (!response.ok) {
        if (response.status === 401 && !p.includes('/auth/login')) setUser(null);
        throw new Error(d.error || `De aanvraag is mislukt (${response.status}).`);
      }
      return d;
    },
    [csrf],
  );
  useEffect(() => {
    fetch('/api/auth/me', { credentials: 'same-origin' })
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (d?.user) {
          setUser(d.user);
          setCsrf(d.csrf);
        }
      })
      .catch(() => setOffline(true))
      .finally(() => setBoot(false));
  }, []);
  useEffect(() => {
    if (!user) return;
    const sync = () =>
      fetch('/api/health')
        .then((r) => {
          if (!r.ok) throw Error();
          setOffline(false);
          setLastSync(new Date());
          setTick((t) => t + 1);
        })
        .catch(() => setOffline(true));
    sync();
    const timer = setInterval(sync, 5000);
    return () => clearInterval(timer);
  }, [user]);
  const changed = () => {
    setTick((t) => t + 1);
    setLastSync(new Date());
  };
  const { data: staff } = useData<{ users: User[] }>(api, user ? '/api/users' : '/api/health');
  const users = staff?.users || [];
  const section = path.split('/')[1] || 'overview';
  const detailId = path.split('/')[2];
  const writable = user?.role !== 'management';
  if (boot)
    return (
      <div className="auth-background">
        <Loading />
      </div>
    );
  if (!user)
    return (
      <Auth
        api={api}
        inviteToken={new URLSearchParams(location.search).get('token') || ''}
        onLogin={(d) => {
          setUser(d.user);
          setCsrf(d.csrf);
          navigate('/overview');
        }}
      />
    );
  const title = titles[section] || titles.overview;
  return (
    <div className="app-shell">
      {mobile && (
        <button
          className="mobile-scrim"
          aria-label="Navigatie sluiten"
          onClick={() => setMobile(false)}
        />
      )}
      <aside className={`sidebar ${mobile ? 'is-open' : ''}`}>
        <a
          className="brand"
          href="/overview"
          onClick={(e) => {
            e.preventDefault();
            navigate('/overview');
          }}
        >
          <span className="brand-word">
            OPTIMAT<span className="brand-dot">.</span>
          </span>
          <span className="brand-subtitle">SALES HUB</span>
        </a>
        <div className="workspace-switch">
          <span className="workspace-icon">O</span>
          <span>
            OPTIMAT Group<small>Commerciële werkplek</small>
          </span>
          <ChevronDown size={15} />
        </div>
        <span className="nav-caption">WERKPLEK</span>
        <nav aria-label="Hoofdnavigatie">
          {sections
            .filter(([id]) => id !== 'settings' || user.role === 'admin')
            .map(([id, title, Icon]) => (
              <a
                key={id}
                href={`/${id}`}
                className={`nav-link ${section === id ? 'active' : ''}`}
                onClick={(e) => {
                  e.preventDefault();
                  navigate(`/${id}`);
                }}
              >
                <Icon size={19} />
                <span>{title}</span>
                {section === id && <span className="nav-active-dot" />}
              </a>
            ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="sidebar-note">
            <ShieldCheck size={18} />
            <span>
              Persoonlijke werkplek<small>Gegevens veilig in één omgeving</small>
            </span>
          </div>
          <button
            className="profile"
            onClick={async () => {
              try {
                await api('/api/auth/logout', { method: 'POST' });
                setUser(null);
                setCsrf('');
              } catch (e: any) {
                setGlobalError(e.message);
              }
            }}
            title="Afmelden"
          >
            <span className="avatar">{initials(user.name)}</span>
            <span>
              {user.name}
              <small>{label(user.role)}</small>
            </span>
            <LogOut size={16} />
          </button>
        </div>
      </aside>
      <div className="workspace">
        <header className="topbar">
          <div className="breadcrumbs">
            <button
              className="icon-button mobile-toggle"
              aria-label="Navigatie openen"
              onClick={() => setMobile(true)}
            >
              <Menu size={22} />
            </button>
            <span>Werkplek</span>
            <ChevronRight size={14} />
            <strong>{sections.find((s) => s[0] === section)?.[1] || 'Overzicht'}</strong>
          </div>
          <div className="topbar-actions">
            <span
              className={`sync-indicator ${offline ? 'disconnected' : ''}`}
              title={
                lastSync ? `Laatst gecontroleerd: ${lastSync.toLocaleTimeString('nl-BE')}` : ''
              }
            >
              {offline ? <WifiOff size={13} /> : <span />}
              {offline ? 'Verbinding verbroken' : 'Automatische synchronisatie'}
            </span>
            <Notifications api={api} tick={tick} navigate={navigate} />
            <span className="today">
              {new Intl.DateTimeFormat('nl-BE', {
                day: 'numeric',
                month: 'short',
                timeZone: 'Europe/Brussels',
              }).format(new Date())}
            </span>
            <span className="avatar avatar-small">{initials(user.name)}</span>
          </div>
        </header>
        <main>
          <ErrorBox error={globalError} />
          {offline && (
            <div className="error" role="status">
              Je bent tijdelijk offline. Wijzigingen worden pas bevestigd na een succesvolle opslag.
            </div>
          )}
          {!detailId && (
            <div className="page-heading">
              <div>
                <span className="eyebrow">
                  {section === 'overview' ? 'JOUW SALES HUB' : 'OPTIMAT SALES HUB'}
                </span>
                <h1>{title[0]}</h1>
                <p>{title[1]}</p>
              </div>
              {['requests', 'opportunities', 'reports', 'map'].includes(section) && (
                <span className="live-label">
                  <span />
                  Actuele gegevens
                </span>
              )}
            </div>
          )}
          {['requests', 'opportunities', 'map', 'reports', 'companies', 'overview'].includes(
            section,
          ) &&
            !detailId && (
              <FilterBar
                filters={filters}
                setFilters={setFilters}
                users={users}
                user={user}
                api={api}
              />
            )}
          {section === 'overview' && (
            <Overview api={api} query={qs(filters)} tick={tick} navigate={navigate} />
          )}
          {section === 'requests' &&
            (detailId ? (
              <RequestDetail
                id={detailId}
                api={api}
                users={users}
                user={user}
                tick={tick}
                onChanged={changed}
                navigate={navigate}
              />
            ) : (
              <RequestList
                api={api}
                query={qs(filters)}
                tick={tick}
                navigate={navigate}
                user={user}
                users={users}
                onChanged={changed}
              />
            ))}
          {section === 'opportunities' && (
            <Opportunities
              api={api}
              query={qs(filters)}
              tick={tick}
              users={users}
              writable={writable}
              onChanged={changed}
              navigate={navigate}
            />
          )}
          {section === 'companies' &&
            (detailId ? (
              <CompanyDetail
                id={detailId}
                api={api}
                users={users}
                user={user}
                writable={writable}
                tick={tick}
                onChanged={changed}
                navigate={navigate}
              />
            ) : (
              <Companies
                api={api}
                query={qs(filters)}
                tick={tick}
                users={users}
                writable={writable}
                onChanged={changed}
                navigate={navigate}
              />
            ))}
          {section === 'tasks' && (
            <Tasks
              api={api}
              tick={tick}
              writable={writable}
              onChanged={changed}
              navigate={navigate}
            />
          )}
          {section === 'reports' && <Reports api={api} query={qs(filters)} tick={tick} />}
          {section === 'map' && (
            <MapView
              api={api}
              query={qs(filters)}
              user={user}
              onOpenRequest={(id) => navigate(`/requests/${id}`)}
              onOpenCompany={(id) => navigate(`/companies/${id}`)}
            />
          )}
          {section === 'prospecting' && (
            <Prospecting
              api={api}
              user={user}
              query={qs(filters)}
              onOpenCompany={(id) => navigate(`/companies/${id}`)}
              onOpenRequest={(id) => navigate(`/requests/${id}`)}
            />
          )}
          {section === 'settings' && user.role === 'admin' && (
            <Settings user={user} api={api} onChanged={changed} />
          )}
        </main>
        <footer className="app-footer">
          <span>
            OPTIMAT Group <span>·</span> Sales Hub
          </span>
          <span>Weergave in Europe/Brussels</span>
        </footer>
      </div>
    </div>
  );
}

function Auth({
  api,
  onLogin,
  inviteToken,
}: {
  api: API;
  onLogin: (d: any) => void;
  inviteToken: string;
}) {
  const [error, setError] = useState(''),
    [busy, setBusy] = useState(false);
  return (
    <div className="auth-background">
      <div className="auth-art">
        <a className="brand">
          <span className="brand-word">
            OPTIMAT<span className="brand-dot">.</span>
          </span>
          <span className="brand-subtitle">SALES HUB</span>
        </a>
        <div>
          <span className="eyebrow">MEER OVERZICHT. MEER VOORUITGANG.</span>
          <h1>
            Goede relaties.
            <br />
            Sterke resultaten.
          </h1>
          <p>
            Van de eerste aanvraag tot de volgende mijlpaal.
            <br />
            Je commerciële werkdag begint hier.
          </p>
          <div className="auth-lines">
            <span />
            <span />
            <span />
            <span />
          </div>
        </div>
        <small>De commerciële werkplek van OPTIMAT Group</small>
      </div>
      <div className="auth-form-wrap">
        <div className="auth-mobile-brand">
          OPTIMAT<span>.</span> <small>SALES HUB</small>
        </div>
        <form
          className="auth-form"
          onSubmit={async (e) => {
            e.preventDefault();
            setBusy(true);
            setError('');
            const f = new FormData(e.currentTarget);
            try {
              const d = await api(inviteToken ? '/api/auth/accept-invite' : '/api/auth/login', {
                method: 'POST',
                body: JSON.stringify(
                  inviteToken
                    ? { token: inviteToken, name: f.get('name'), password: f.get('password') }
                    : { email: f.get('email'), password: f.get('password') },
                ),
              });
              onLogin(d);
            } catch (e: any) {
              setError(e.message);
            } finally {
              setBusy(false);
            }
          }}
        >
          <span className="eyebrow">WELKOM BIJ OPTIMAT</span>
          <h1>{inviteToken ? 'Je account activeren' : 'Goed je weer te zien.'}</h1>
          <p>
            {inviteToken
              ? 'Kies een persoonlijk wachtwoord om aan de slag te gaan.'
              : 'Meld je aan bij je persoonlijke saleswerkplek.'}
          </p>
          <ErrorBox error={error} />
          {inviteToken ? (
            <label className="field">
              Je naam
              <input name="name" autoComplete="name" required />
            </label>
          ) : (
            <label className="field">
              E-mailadres
              <input
                type="email"
                name="email"
                placeholder="naam@optimat-group.com"
                autoComplete="username"
                required
              />
            </label>
          )}
          <label className="field">
            Wachtwoord
            <input
              type="password"
              name="password"
              autoComplete={inviteToken ? 'new-password' : 'current-password'}
              minLength={inviteToken ? 12 : 1}
              required
            />
          </label>
          <button className="btn btn-primary auth-submit" disabled={busy}>
            {busy ? 'Even geduld…' : inviteToken ? 'Account activeren' : 'Aanmelden'}
            <ArrowRight size={18} />
          </button>
          <div className="auth-help">
            <ShieldCheck size={17} />
            <span>
              Persoonlijke accounts met veilige toegang.
              <br />
              Nog geen account? Vraag je beheerder om een uitnodiging.
            </span>
          </div>
        </form>
      </div>
    </div>
  );
}

function FilterBar({
  filters,
  setFilters,
  users,
  user,
  api,
}: {
  filters: Row;
  setFilters: (f: Row) => void;
  users: User[];
  user: User;
  api: API;
}) {
  const [expanded, setExpanded] = useState(false);
  const [viewsTick, setViewsTick] = useState(0),
    [viewError, setViewError] = useState('');
  const { data: views } = useData(api, '/api/views', viewsTick);
  const change = (k: string, v: string) => setFilters({ ...filters, [k]: v });
  return (
    <div className="filter-block">
      <div className="filter-bar">
        <label className="search-field">
          <Search size={17} />
          <input
            aria-label="Zoeken"
            placeholder="Zoek bedrijf, contact of machine…"
            value={filters.search || ''}
            onChange={(e) => change('search', e.target.value)}
          />
        </label>
        <div className="filter-controls">
          {user.role !== 'seller' && (
            <select
              aria-label="Verkoper"
              value={filters.owner || ''}
              onChange={(e) => change('owner', e.target.value)}
            >
              <option value="">Alle verkopers</option>
              <option value="unassigned">Niet toegewezen</option>
              {users
                .filter((u) => u.role === 'seller' || u.role === 'manager' || u.role === 'admin')
                .map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.name}
                  </option>
                ))}
            </select>
          )}
          <select
            aria-label="Businessunit"
            value={filters.business_unit || ''}
            onChange={(e) => change('business_unit', e.target.value)}
          >
            <option value="">Alle businessunits</option>
            {['Wood', 'Stone', 'Glass', 'Unknown'].map((x) => (
              <option key={x} value={x}>
                {label(x)}
              </option>
            ))}
          </select>
          <button
            className={`btn btn-secondary filter-toggle ${expanded ? 'selected' : ''}`}
            onClick={() => setExpanded(!expanded)}
          >
            <Filter size={16} />
            Filters
            {Object.values(filters).filter(Boolean).length > 0 && (
              <span className="count-pill">{Object.values(filters).filter(Boolean).length}</span>
            )}
          </button>
        </div>
      </div>
      {expanded && (
        <div className="extended-filters">
          <div className="saved-views">
            <select
              aria-label="Opgeslagen weergave"
              defaultValue=""
              onChange={(e) => {
                const v = views?.items?.find((i: Row) => i.id === e.target.value);
                if (v) setFilters(v.filters);
              }}
            >
              <option value="">Opgeslagen weergave kiezen</option>
              {views?.items?.map((v: Row) => (
                <option key={v.id} value={v.id}>
                  {v.name}
                </option>
              ))}
            </select>
            <button
              className="btn btn-secondary btn-small"
              onClick={async () => {
                const name = prompt('Naam voor deze persoonlijke weergave');
                if (!name) return;
                try {
                  await api('/api/views', {
                    method: 'POST',
                    body: JSON.stringify({
                      name,
                      filters: Object.fromEntries(
                        Object.entries(filters)
                          .filter(([, v]) => v)
                          .map(([k, v]) => [k, String(v)]),
                      ),
                    }),
                  });
                  setViewsTick((t) => t + 1);
                  setViewError('');
                } catch (e: any) {
                  setViewError(e.message);
                }
              }}
            >
              Weergave opslaan
            </button>
            {viewError && <ErrorBox error={viewError} />}
          </div>
          <label className="field">
            Van
            <input
              type="date"
              value={filters.from || ''}
              onChange={(e) => change('from', e.target.value)}
            />
          </label>
          <label className="field">
            Tot en met
            <input
              type="date"
              value={filters.to || ''}
              onChange={(e) => change('to', e.target.value)}
            />
          </label>
          <label className="field">
            Land
            <select
              value={filters.country || ''}
              onChange={(e) => change('country', e.target.value)}
            >
              <option value="">Alle landen</option>
              {['BE', 'NL', 'LU'].map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>
          </label>
          <label className="field">
            Aanvraagtype
            <select value={filters.intent || ''} onChange={(e) => change('intent', e.target.value)}>
              <option value="">Alle types</option>
              {['brochure', 'quote', 'demo', 'contact', 'event', 'training', 'software'].map(
                (x) => (
                  <option key={x}>{x}</option>
                ),
              )}
            </select>
          </label>
          <label className="field">
            Bronwebsite
            <input
              placeholder="Domein of bron-ID"
              value={filters.source || ''}
              onChange={(e) => change('source', e.target.value)}
            />
          </label>
          <label className="field">
            Merk
            <input value={filters.brand || ''} onChange={(e) => change('brand', e.target.value)} />
          </label>
          <label className="field">
            Peildatum rapport
            <input
              type="datetime-local"
              value={
                filters.as_of
                  ? new Date(
                      new Date(filters.as_of).getTime() -
                        new Date(filters.as_of).getTimezoneOffset() * 60000,
                    )
                      .toISOString()
                      .slice(0, 16)
                  : ''
              }
              onChange={(e) =>
                change('as_of', e.target.value ? new Date(e.target.value).toISOString() : '')
              }
            />
          </label>
          <label className="field">
            Resultaat toewijzen
            <select
              value={filters.ownership || 'current'}
              onChange={(e) => change('ownership', e.target.value)}
            >
              <option value="current">Huidige portefeuille</option>
              <option value="at_close">Eigenaar bij afsluiten</option>
            </select>
          </label>
          <label className="field">
            Campagne
            <input
              value={filters.campaign || ''}
              onChange={(e) => change('campaign', e.target.value)}
            />
          </label>
          <label className="field">
            Status
            <select value={filters.status || ''} onChange={(e) => change('status', e.target.value)}>
              <option value="">Alle statussen</option>
              {REQUEST_STATUSES.map((s) => (
                <option key={s} value={s}>
                  {label(s)}
                </option>
              ))}
            </select>
          </label>
          <button className="btn btn-text" onClick={() => setFilters({})}>
            Filters wissen
          </button>
        </div>
      )}
    </div>
  );
}

function Overview({
  api,
  query,
  tick,
  navigate,
}: {
  api: API;
  query: string;
  tick: number;
  navigate: (p: string) => void;
}) {
  const { data: report, error } = useData(api, `/api/reports?${query}`, tick);
  const { data: req } = useData(api, `/api/requests?${query}`, tick);
  const { data: tasks } = useData(api, '/api/tasks', tick);
  const m = report?.metrics || {};
  return (
    <>
      <ErrorBox error={error} />
      <div className="stats-grid">
        <Stat
          title="Aanvragen"
          value={m.requests ?? '—'}
          detail="Unieke geldige inzendingen"
          icon={FileText}
        />
        <Stat
          title="Open verkoopkansen"
          value={m.open_count ?? '—'}
          detail="Aanvragen en kansen blijven apart"
          icon={Target}
        />
        <Stat
          title="Open pipelinewaarde"
          value={m.open_pipeline_value == null ? '—' : money(m.open_pipeline_value)}
          detail="Geregistreerde bedragen · actuele foto"
          icon={TrendingUp}
          accent
        />
        <Stat
          title="Opvolgingsgraad"
          value={m.follow_up_rate == null ? '—' : `${Math.round(m.follow_up_rate * 100)}%`}
          detail="Instroomcohort met menselijk contact"
          icon={CheckCircle2}
        />
      </div>
      <div className="overview-grid">
        <section className="card intake-card">
          <div className="section-heading">
            <div>
              <span className="eyebrow">NIEUWE INTERESSE</span>
              <h2>Je aanvragen in beweging</h2>
            </div>
            <button className="btn btn-text" onClick={() => navigate('/requests')}>
              Alle aanvragen
              <ArrowUpRight size={16} />
            </button>
          </div>
          {!req ? (
            <Loading />
          ) : !req.items?.length ? (
            <Empty title="Klaar voor de eerste aanvraag" icon={FileText}>
              Nieuwe websiteaanvragen komen hier samen zodra je WordPress-bronnen zijn gekoppeld. Je
              ziet altijd echte gegevens.
            </Empty>
          ) : (
            <div className="request-card-list">
              {req.items.slice(0, 5).map((r: Row) => (
                <RequestCard key={r.id} r={r} onClick={() => navigate(`/requests/${r.id}`)} />
              ))}
            </div>
          )}
          <div className="card-footnote">
            <span className="mini-dot" />
            Aanvragen, bedrijven en verkoopkansen worden afzonderlijk bijgehouden.
          </div>
        </section>
        <section className="card">
          <div className="section-heading">
            <div>
              <span className="eyebrow">VANDAAG & BINNENKORT</span>
              <h2>Volgende stappen</h2>
            </div>
            <CalendarDays size={20} className="muted" />
          </div>
          {!tasks ? (
            <Loading />
          ) : !tasks.items?.filter((t: Row) => !t.completed).length ? (
            <Empty title="Een heldere agenda" icon={CalendarDays}>
              Je hebt momenteel geen openstaande taken. Plan een vervolgactie vanuit een
              aanvraagfiche.
            </Empty>
          ) : (
            <div className="task-preview">
              {tasks.items
                .filter((t: Row) => !t.completed)
                .slice(0, 5)
                .map((t: Row) => (
                  <button
                    key={t.id}
                    className="task-preview-item"
                    onClick={() => navigate(`/requests/${t.request_id}`)}
                  >
                    <span className="task-circle" />
                    <span>
                      <strong>{t.title}</strong>
                      <small>
                        {date(t.due_at)} · {t.company_name || 'Aanvraag'}
                      </small>
                    </span>
                    <ChevronRight size={16} />
                  </button>
                ))}
            </div>
          )}
          <button className="btn btn-secondary full-width" onClick={() => navigate('/tasks')}>
            Naar mijn taken
            <ArrowRight size={16} />
          </button>
        </section>
      </div>
      <div className="insight-banner">
        <div className="insight-mark">
          <Sparkles size={24} />
        </div>
        <div>
          <h3>Inzicht begint bij goede opvolging.</h3>
          <p>
            Registreer een gesprek en plan de volgende stap. Zo groeit je overzicht mee met je werk.
          </p>
        </div>
        <button className="btn btn-secondary" onClick={() => navigate('/reports')}>
          Bekijk rapporten
          <ArrowUpRight size={16} />
        </button>
      </div>
    </>
  );
}
function RequestCard({ r, onClick }: { r: Row; onClick: () => void }) {
  const types = intents(r);
  return (
    <button className="request-card" onClick={onClick}>
      <span className="company-avatar">{initials(r.company_name || '?')}</span>
      <div className="request-card-body">
        <div className="request-card-title">
          <strong>{r.company_name || 'Bedrijf nog onbekend'}</strong>
          <Status value={r.status} />
        </div>
        <div className="request-card-meta">
          <span>{r.machine || r.model || r.form_name || 'Nieuwe aanvraag'}</span>
          <span className="meta-separator">·</span>
          <span>
            {[r.postcode, r.city, r.country].filter(Boolean).join(' ') || 'Locatie ontbreekt'}
          </span>
        </div>
        <div className="request-card-bottom">
          {types.map((x: string) => (
            <span key={x} className="type-label">
              {x}
            </span>
          ))}
          <span>{date(r.submitted_at || r.created_at, true)}</span>
          <span>{r.owner_name || 'Niet toegewezen'}</span>
        </div>
      </div>
      <ChevronRight size={17} />
    </button>
  );
}
function RequestList({
  api,
  query,
  tick,
  navigate,
  user,
  users,
  onChanged,
}: {
  api: API;
  query: string;
  tick: number;
  navigate: (p: string) => void;
  user: User;
  users: User[];
  onChanged: () => void;
}) {
  const { data, error, loading } = useData(api, `/api/requests?${query}`, tick);
  const [view, setView] = useState('cards');
  const [selected, setSelected] = useState<string[]>([]),
    [bulkOwner, setBulkOwner] = useState(''),
    [bulkError, setBulkError] = useState(''),
    [bulkBusy, setBulkBusy] = useState(false);
  const canAssign = ['admin', 'manager'].includes(user.role);
  const select = (id: string) =>
    setSelected((old) => (old.includes(id) ? old.filter((x) => x !== id) : [...old, id]));
  return (
    <section className="card">
      <div className="section-heading">
        <div>
          <h2>
            Alle aanvragen{' '}
            <span className="heading-count">{data?.total ?? data?.items?.length ?? 0}</span>
          </h2>
          <p className="muted">Elke inzending blijft als eigen aanvraag bewaard.</p>
        </div>
        <div className="segmented">
          <button
            aria-label="Kaartweergave"
            className={view === 'cards' ? 'active' : ''}
            onClick={() => setView('cards')}
          >
            <LayoutGrid size={17} />
          </button>
          <button
            aria-label="Tabelweergave"
            className={view === 'table' ? 'active' : ''}
            onClick={() => setView('table')}
          >
            <List size={17} />
          </button>
        </div>
      </div>
      <ErrorBox error={error || bulkError} />
      {canAssign && Boolean(data?.items?.length) && (
        <div className="bulk-toolbar">
          <label className="checkbox-label">
            <input
              type="checkbox"
              checked={Boolean(selected.length) && selected.length === data.items.length}
              onChange={(e) =>
                setSelected(e.target.checked ? data.items.map((r: Row) => r.id) : [])
              }
            />
            Alles selecteren
          </label>
          <span>{selected.length} geselecteerd</span>
          <select
            aria-label="Toewijzen aan"
            value={bulkOwner}
            onChange={(e) => setBulkOwner(e.target.value)}
          >
            <option value="">Niet toegewezen</option>
            {users
              .filter((u) => ['seller', 'manager', 'admin'].includes(u.role))
              .map((u) => (
                <option key={u.id} value={u.id}>
                  {u.name}
                </option>
              ))}
          </select>
          <button
            className="btn btn-secondary btn-small"
            disabled={!selected.length || bulkBusy}
            onClick={async () => {
              setBulkBusy(true);
              setBulkError('');
              let failed = 0;
              for (const id of selected) {
                const r = data.items.find((x: Row) => x.id === id);
                if (!r) continue;
                try {
                  await api(`/api/requests/${id}`, {
                    method: 'PATCH',
                    body: JSON.stringify({ version: r.version, owner_id: bulkOwner || null }),
                  });
                } catch {
                  failed++;
                }
              }
              setSelected([]);
              onChanged();
              setBulkBusy(false);
              if (failed)
                setBulkError(
                  `${failed} toewijzing(en) zijn niet opgeslagen. Controleer de actuele eigenaar en probeer opnieuw.`,
                );
            }}
          >
            {bulkBusy ? 'Toewijzen…' : 'Selectie toewijzen'}
          </button>
        </div>
      )}
      {loading && !data ? (
        <Loading />
      ) : !data?.items?.length ? (
        <Empty title="Geen aanvragen gevonden">
          Zodra een aangesloten formulier een aanvraag verstuurt, staat die hier klaar voor
          beoordeling en opvolging. Controleer eventueel je filters.
        </Empty>
      ) : view === 'cards' ? (
        <div className="request-card-list">
          {data.items.map((r: Row) => (
            <div className="selectable-request" key={r.id}>
              {canAssign && (
                <input
                  type="checkbox"
                  aria-label={`${r.company_name || 'Aanvraag'} selecteren`}
                  checked={selected.includes(r.id)}
                  onChange={() => select(r.id)}
                />
              )}
              <RequestCard r={r} onClick={() => navigate(`/requests/${r.id}`)} />
            </div>
          ))}
        </div>
      ) : (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                {canAssign && <th />}
                <th>Bedrijf</th>
                <th>Aanvraag</th>
                <th>Status</th>
                <th>Eigenaar</th>
                <th>Ontvangen</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {data.items.map((r: Row) => (
                <tr key={r.id}>
                  {canAssign && (
                    <td>
                      <input
                        type="checkbox"
                        aria-label={`${r.company_name || 'Aanvraag'} selecteren`}
                        checked={selected.includes(r.id)}
                        onChange={() => select(r.id)}
                      />
                    </td>
                  )}
                  <td>
                    <button className="text-link" onClick={() => navigate(`/requests/${r.id}`)}>
                      {r.company_name || 'Onbekend bedrijf'}
                    </button>
                    <small>{r.contact_name || r.email}</small>
                  </td>
                  <td>
                    {intents(r).join(', ') || r.form_name}
                    <small>{r.machine || r.model || 'Machine onbekend'}</small>
                  </td>
                  <td>
                    <Status value={r.status} />
                  </td>
                  <td>{r.owner_name || 'Niet toegewezen'}</td>
                  <td>{date(r.submitted_at || r.created_at)}</td>
                  <td>
                    <button
                      className="icon-button"
                      aria-label="Aanvraag openen"
                      onClick={() => navigate(`/requests/${r.id}`)}
                    >
                      <ArrowUpRight size={17} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}

function RequestDetail({
  id,
  api,
  users,
  user,
  tick,
  onChanged,
  navigate,
}: {
  id: string;
  api: API;
  users: User[];
  user: User;
  tick: number;
  onChanged: () => void;
  navigate: (p: string) => void;
}) {
  const { data, error, loading } = useData(api, `/api/requests/${id}`, tick);
  const [tab, setTab] = useState('timeline'),
    [actionError, setActionError] = useState(''),
    [busy, setBusy] = useState(false),
    [success, setSuccess] = useState('');
  const writable = user.role !== 'management';
  const mutate = async (path: string, body: any, method = 'POST') => {
    setBusy(true);
    setActionError('');
    setSuccess('');
    try {
      await api(path, { method, body: JSON.stringify(body) });
      setSuccess('Opgeslagen');
      onChanged();
      return true;
    } catch (e: any) {
      setActionError(e.message);
      return false;
    } finally {
      setBusy(false);
    }
  };
  if (loading && !data) return <Loading />;
  if (!data) return <ErrorBox error={error || 'Aanvraag niet gevonden.'} />;
  const r = data.request || {},
    c = data.company || {},
    contact = data.contact || {},
    loc = data.location || {};
  const fields = parseJson(data.fields || r.fields, []);
  const patch = (body: Row) =>
    mutate(`/api/requests/${id}`, { version: r.version, ...body }, 'PATCH');
  return (
    <>
      <button className="btn btn-text back-link" onClick={() => navigate('/requests')}>
        ← Alle aanvragen
      </button>
      <div className="detail-heading">
        <div className="company-avatar large">{initials(c.name || r.company_name || '?')}</div>
        <div>
          <div className="row">
            <span className="eyebrow">AANVRAAG · {date(r.submitted_at || r.created_at)}</span>
            <Status value={r.status} />
          </div>
          <h1>{c.name || r.company_name || 'Onbekend bedrijf'}</h1>
          <p>
            {r.machine || r.model || r.form_name || 'Machine nog onbekend'}{' '}
            <span className="muted">· {intents(r).join(' + ') || 'Aanvraag'}</span>
          </p>
        </div>
        {c.id && (
          <button className="btn btn-secondary" onClick={() => navigate(`/companies/${c.id}`)}>
            Bedrijfsdossier
            <ArrowUpRight size={16} />
          </button>
        )}
      </div>
      <ErrorBox error={error || actionError} />
      {Boolean(r.is_test || r.is_spam) && (
        <div className="notice" style={{ marginBottom: 16 }} role="status">
          {r.is_test ? 'Testaanvraag' : 'Spam'} · deze aanvraag en uitsluitend daaraan gekoppelde
          verkoopkansen tellen niet mee in commerciële cijfers.
        </div>
      )}
      {success && (
        <div className="notice success" role="status">
          <Check size={17} />
          {success}
        </div>
      )}
      <div className="detail-grid">
        <div className="stack">
          <section className="card">
            <div className="section-heading">
              <h2>Contact & aanvraag</h2>
              <span className="badge">{r.language || contact.language || 'Taal onbekend'}</span>
            </div>
            <div className="contact-grid">
              <div>
                <span className="data-label">Contactpersoon</span>
                <strong>{contact.name || r.contact_name || 'Niet ingevuld'}</strong>
                <span>{contact.job_title || contact.position || ''}</span>
              </div>
              <div>
                <span className="data-label">Bedrijf</span>
                <strong>{c.name || 'Niet ingevuld'}</strong>
                <span>{c.enterprise_number || 'Ondernemingsnummer ontbreekt'}</span>
              </div>
              <div>
                <span className="data-label">E-mail</span>
                {contact.email ? (
                  <a href={`mailto:${contact.email}`}>{contact.email}</a>
                ) : (
                  <span>Niet ingevuld</span>
                )}
              </div>
              <div>
                <span className="data-label">Telefoon</span>
                {contact.phone ? (
                  <a href={`tel:${contact.phone}`}>{contact.phone}</a>
                ) : (
                  <span>Niet ingevuld</span>
                )}
              </div>
              <div>
                <span className="data-label">Adres</span>
                <span>
                  {[loc.address, loc.postcode, loc.city, loc.country].filter(Boolean).join(', ') ||
                    'Locatie ontbreekt'}
                </span>
              </div>
              <div>
                <span className="data-label">Businessunit · merk</span>
                <span>
                  {label(r.business_unit)} · {r.brand || 'Merk onbekend'}
                </span>
              </div>
            </div>
            {r.message && (
              <div className="message-box">
                <span className="data-label">Bericht</span>
                <p>{r.message}</p>
              </div>
            )}
            <div className="source-strip">
              <span>
                Bron: {r.source_name || r.source_url || r.site_url || r.source_id || 'Onbekend'}
              </span>
              <span>{r.form_name || r.form_id || 'Formulier onbekend'}</span>
              {typeof r.product_url === 'string' && /^https?:\/\//.test(r.product_url) && (
                <a href={r.product_url} target="_blank" rel="noreferrer">
                  Productpagina ↗
                </a>
              )}
            </div>
          </section>
          <section className="card">
            <div className="tabs">
              <button
                className={`tab ${tab === 'timeline' ? 'active' : ''}`}
                onClick={() => setTab('timeline')}
              >
                Tijdlijn
              </button>
              <button
                className={`tab ${tab === 'fields' ? 'active' : ''}`}
                onClick={() => setTab('fields')}
              >
                Formuliergegevens
              </button>
              <button
                className={`tab ${tab === 'opportunities' ? 'active' : ''}`}
                onClick={() => setTab('opportunities')}
              >
                Verkoopkansen <span>{data.opportunities?.length || 0}</span>
              </button>
              <button
                className={`tab ${tab === 'attachments' ? 'active' : ''}`}
                onClick={() => setTab('attachments')}
              >
                Bijlagen
              </button>
            </div>
            {tab === 'timeline' && (
              <>
                {writable && (
                  <form
                    className="activity-form"
                    onSubmit={async (e) => {
                      e.preventDefault();
                      const form = e.currentTarget;
                      const f = new FormData(form);
                      if (
                        await mutate(`/api/requests/${id}/activities`, {
                          kind: f.get('kind'),
                          body: f.get('body'),
                        })
                      )
                        form.reset();
                    }}
                  >
                    <label className="field">
                      Registreer een actie
                      <select name="kind" aria-label="Registreer een actie">
                        <option value="note">Interne notitie</option>
                        <option value="call">Telefoongesprek uitgevoerd</option>
                        <option value="email">Persoonlijke e-mail verstuurd</option>
                        <option value="meeting">Afspraak uitgevoerd</option>
                      </select>
                    </label>
                    <label className="field">
                      <span className="sr-only">Inhoud van de actie</span>
                      <textarea
                        name="body"
                        placeholder="Wat is besproken? Wat is de volgende stap?"
                        required
                        rows={3}
                      />
                    </label>
                    <div className="row justify-between">
                      <small className="muted">
                        Een klik op bellen of mailen registreert geen contactactie.
                      </small>
                      <button className="btn btn-primary" disabled={busy}>
                        <Plus size={16} />
                        Actie opslaan
                      </button>
                    </div>
                  </form>
                )}
                <div className="timeline">
                  {!data.activities?.length ? (
                    <div className="empty compact">
                      <MessageSquare size={22} />
                      <p>Hier verschijnt de geschiedenis van dit dossier.</p>
                    </div>
                  ) : (
                    data.activities.map((a: Row) => (
                      <div className="timeline-item" key={a.id}>
                        <span className="timeline-dot">
                          {a.kind === 'call' ? (
                            <Phone size={13} />
                          ) : a.kind === 'email' ? (
                            <Mail size={13} />
                          ) : (
                            <MessageSquare size={13} />
                          )}
                        </span>
                        <div>
                          <div className="row justify-between">
                            <strong>
                              {(
                                {
                                  note: 'Notitie',
                                  call: 'Telefoongesprek',
                                  email: 'E-mail',
                                  meeting: 'Afspraak',
                                  submission: 'Websiteaanvraag',
                                  task: 'Taak',
                                  status: 'Statuswijziging',
                                  assignment: 'Toewijzing',
                                  pipeline: 'Verkoopfase',
                                } as Row
                              )[a.kind] ||
                                a.action ||
                                label(a.kind)}
                            </strong>
                            <time>{date(a.created_at, true)}</time>
                          </div>
                          <p>{a.body || a.summary || 'Dossier bijgewerkt'}</p>
                          <small>{a.actor_name || 'Systeem'}</small>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </>
            )}
            {tab === 'attachments' && <Attachments id={id} api={api} writable={writable} />}
            {tab === 'fields' && (
              <div>
                <div className="notice">
                  Oorspronkelijke zakelijke waarden blijven bewaard. Onbekende velden worden niet
                  stilzwijgend verwijderd.
                </div>
                <dl className="business-fields">
                  {fields.length ? (
                    fields.map((f: Row, i: number) => (
                      <div key={f.id || i}>
                        <dt>
                          {f.label || f.id}
                          <small>
                            {f.id} · {f.type}
                          </small>
                        </dt>
                        <dd>
                          {typeof f.value === 'object'
                            ? JSON.stringify(f.value)
                            : String(f.value ?? 'Niet ingevuld')}
                        </dd>
                      </div>
                    ))
                  ) : (
                    <div className="empty compact">Geen extra zakelijke formuliervelden.</div>
                  )}
                </dl>
              </div>
            )}
            {tab === 'opportunities' && (
              <div className="stack">
                {data.opportunities?.map((o: Row) => (
                  <div className="linked-opportunity" key={o.id}>
                    <div>
                      <strong>{o.title}</strong>
                      <small>{money(o.amount)}</small>
                    </div>
                    <Status value={o.stage} />
                  </div>
                ))}
                {!data.opportunities?.length && (
                  <div className="notice">
                    Nog geen gekwalificeerde verkoopkans. Opvolgen kan zonder er een aan te maken.
                  </div>
                )}
                {writable && (
                  <form
                    className="form-grid"
                    onSubmit={async (e) => {
                      e.preventDefault();
                      const f = new FormData(e.currentTarget);
                      await mutate(`/api/requests/${id}/opportunities`, {
                        title: f.get('title'),
                        amount: f.get('amount') === '' ? null : Number(f.get('amount')),
                        stage: 'qualified',
                      });
                    }}
                  >
                    <label className="field">
                      Titel nieuwe verkoopkans
                      <input name="title" required placeholder="Bijvoorbeeld CNC-investering" />
                    </label>
                    <label className="field">
                      Indicatieve waarde (€)
                      <input name="amount" type="number" min="0" step="0.01" />
                    </label>
                    <button className="btn btn-primary" disabled={busy}>
                      <Plus size={16} />
                      Verkoopkans aanmaken
                    </button>
                  </form>
                )}
                {writable && (
                  <form
                    className="form-grid"
                    onSubmit={async (e) => {
                      e.preventDefault();
                      const f = new FormData(e.currentTarget);
                      await mutate(`/api/opportunities/${f.get('opportunity_id')}/requests`, {
                        request_id: id,
                      });
                    }}
                  >
                    <label className="field">
                      Bestaande verkoopkans koppelen
                      <input
                        name="opportunity_id"
                        placeholder="ID van de bestaande verkoopkans"
                        required
                      />
                    </label>
                    <button className="btn btn-secondary" disabled={busy}>
                      Koppelen
                    </button>
                  </form>
                )}
              </div>
            )}
          </section>
        </div>
        <aside className="stack">
          <section className="card followup-card">
            <div className="section-heading">
              <h2>Opvolging</h2>
              <Target size={19} />
            </div>
            <label className="field">
              Status
              <select
                aria-label="Status"
                disabled={!writable || busy}
                value={r.status}
                onChange={(e) => {
                  const status = e.target.value;
                  const reason =
                    status === 'closed' ? prompt('Waarom rond je deze aanvraag af?') : undefined;
                  const follow =
                    status === 'waiting' ? prompt('Opvolgdatum (JJJJ-MM-DD)') : undefined;
                  if ((status === 'closed' && !reason) || (status === 'waiting' && !follow)) return;
                  patch({
                    status,
                    ...(reason ? { close_reason: reason } : {}),
                    ...(follow ? { follow_up_at: new Date(follow).toISOString() } : {}),
                  });
                }}
              >
                {REQUEST_STATUSES.map((s) => (
                  <option key={s} value={s}>
                    {label(s)}
                  </option>
                ))}
              </select>
            </label>
            <label className="field">
              Eigenaar
              <select
                aria-label="Eigenaar"
                value={r.owner_id || ''}
                disabled={!['admin', 'manager'].includes(user.role) || busy}
                onChange={(e) => patch({ owner_id: e.target.value || null })}
              >
                <option value="">Niet toegewezen</option>
                {users
                  .filter((u) => ['seller', 'manager', 'admin'].includes(u.role))
                  .map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.name}
                    </option>
                  ))}
              </select>
            </label>
            <label className="field">
              Prioriteit
              <select
                aria-label="Prioriteit"
                value={r.priority || 'normal'}
                disabled={!writable || busy}
                onChange={(e) => patch({ priority: e.target.value })}
              >
                <option value="low">Laag</option>
                <option value="normal">Normaal</option>
                <option value="high">Hoog</option>
              </select>
            </label>
            {r.follow_up_at && (
              <div className="notice">
                <Clock3 size={16} />
                Opvolgen op {date(r.follow_up_at)}
              </div>
            )}
            {['admin', 'manager'].includes(user.role) && (
              <div className="classification-controls">
                <span className="data-label">Classificatie voor rapportage</span>
                <label className="checkbox-label">
                  <input
                    type="checkbox"
                    checked={Boolean(r.is_test)}
                    disabled={busy}
                    onChange={(e) => patch({ is_test: e.target.checked })}
                  />
                  Testaanvraag
                </label>
                <label className="checkbox-label">
                  <input
                    type="checkbox"
                    checked={Boolean(r.is_spam)}
                    disabled={busy}
                    onChange={(e) => patch({ is_spam: e.target.checked })}
                  />
                  Spam
                </label>
                {Boolean(r.is_test || r.is_spam) && (
                  <div className="notice">
                    Uitgesloten van commerciële cijfers en de gewone intake. Je kunt de markering
                    hier herstellen via deze beveiligde dossier-URL.
                  </div>
                )}
                <button
                  className="btn btn-secondary btn-small"
                  disabled={busy || (Boolean(r.is_spam) && r.status === 'closed')}
                  onClick={() => patch({ status: 'closed', close_reason: 'spam', is_spam: true })}
                >
                  Afsluiten als spam
                </button>
              </div>
            )}
            <div className="quick-actions">
              {contact.phone && (
                <a className="btn btn-secondary" href={`tel:${contact.phone}`}>
                  <Phone size={17} />
                  Bellen
                </a>
              )}
              {contact.email && (
                <a className="btn btn-secondary" href={`mailto:${contact.email}`}>
                  <Mail size={17} />
                  Mailen
                </a>
              )}
            </div>
          </section>
          <section className="card" id="request-tasks">
            <div className="section-heading">
              <h2>Volgende taken</h2>
              <ListTodo size={19} />
            </div>
            {data.tasks
              ?.filter((t: Row) => !t.completed)
              .map((t: Row) => (
                <div className="task-line" key={t.id}>
                  <button
                    disabled={!writable || busy}
                    className="check-button"
                    aria-label={`${t.title} afronden`}
                    onClick={() =>
                      mutate(`/api/tasks/${t.id}`, { version: t.version, completed: true }, 'PATCH')
                    }
                  >
                    <Check size={13} />
                  </button>
                  <div>
                    <strong>{t.title}</strong>
                    <small>{date(t.due_at, true)}</small>
                  </div>
                </div>
              ))}
            {!data.tasks?.filter((t: Row) => !t.completed).length && (
              <p className="muted">Nog geen openstaande taak.</p>
            )}
            {writable && (
              <form
                className="stack compact-stack"
                onSubmit={async (e) => {
                  e.preventDefault();
                  const form = e.currentTarget,
                    f = new FormData(form);
                  if (
                    await mutate(`/api/requests/${id}/tasks`, {
                      title: f.get('title'),
                      due_at: new Date(String(f.get('due_at'))).toISOString(),
                    })
                  )
                    form.reset();
                }}
              >
                <label className="field">
                  Nieuwe taak
                  <input name="title" required placeholder="Bijvoorbeeld terugbellen" />
                </label>
                <label className="field">
                  Datum en tijd
                  <input name="due_at" type="datetime-local" required />
                </label>
                <button className="btn btn-secondary" disabled={busy}>
                  <Plus size={16} />
                  Taak plannen
                </button>
              </form>
            )}
          </section>
          {user.role === 'admin' && (
            <section className="card">
              <h2 style={{ marginBottom: 15 }}>Gegevensbeheer</h2>
              <a
                className="btn btn-secondary full-width"
                href={`/api/admin/privacy/requests/${id}/export`}
              >
                Gerichte dossierexport
              </a>
              <button
                style={{ marginTop: 10 }}
                className="btn btn-danger full-width"
                onClick={async () => {
                  const reason = prompt('Reden voor definitieve verwijdering van deze aanvraag');
                  if (
                    !reason ||
                    !confirm(
                      'Deze aanvraag en gekoppelde bijlagen definitief verwijderen? Gedeelde bedrijfsgegevens en verkoopkansen blijven behouden.',
                    )
                  )
                    return;
                  if (
                    await mutate(
                      `/api/admin/privacy/requests/${id}`,
                      { version: r.version, reason },
                      'DELETE',
                    )
                  )
                    navigate('/requests');
                }}
              >
                Aanvraag verwijderen
              </button>
            </section>
          )}
          {(user.role === 'admin' ||
            (user.role === 'management' && Boolean(user.marketing_permission))) && (
            <MarketingFields request={r} api={api} onChanged={onChanged} />
          )}
          <div className="dossier-id">
            Dossier {id}
            <br />
            Laatste wijziging {date(r.updated_at, true)}
          </div>
        </aside>
      </div>
      <div className="mobile-dossier-actions">
        {contact.phone && (
          <a href={`tel:${contact.phone}`}>
            <Phone size={17} />
            Bellen
          </a>
        )}
        {contact.email && (
          <a href={`mailto:${contact.email}`}>
            <Mail size={17} />
            Mailen
          </a>
        )}
        <button
          onClick={() =>
            document
              .getElementById('request-tasks')
              ?.scrollIntoView({ behavior: 'smooth', block: 'start' })
          }
        >
          <CalendarDays size={17} />
          Opvolgen
        </button>
      </div>
    </>
  );
}

function Opportunities({
  api,
  query,
  tick,
  users,
  writable,
  onChanged,
  navigate,
}: {
  api: API;
  query: string;
  tick: number;
  users: User[];
  writable: boolean;
  onChanged: () => void;
  navigate: (p: string) => void;
}) {
  const { data, error, loading } = useData(api, `/api/opportunities?${query}`, tick),
    [view, setView] = useState('kanban'),
    [edit, setEdit] = useState<Row | null>(null),
    [actionError, setActionError] = useState(''),
    [busy, setBusy] = useState(false);
  const items: Row[] = data?.items || [];
  const patch = async (o: Row, body: Row) => {
    setActionError('');
    setBusy(true);
    try {
      await api(`/api/opportunities/${o.id}`, {
        method: 'PATCH',
        body: JSON.stringify({ version: o.version, ...body }),
      });
      setEdit(null);
      onChanged();
    } catch (e: any) {
      setActionError(e.message);
    } finally {
      setBusy(false);
    }
  };
  const move = (o: Row, stage: string) => {
    if (stage === o.stage) return;
    if (['won', 'lost', 'waiting'].includes(stage)) {
      setEdit({ ...o, stage });
      return;
    }
    patch(o, { stage });
  };
  return (
    <>
      <ErrorBox error={error || actionError} />
      <div className="section-heading opportunities-heading">
        <div className="row">
          <h2>
            Verkoopkansen <span className="heading-count">{items.length}</span>
          </h2>
          <span className="muted">
            {money(
              items
                .filter((o) => !['won', 'lost'].includes(o.stage))
                .reduce((n, o) => n + (Number(o.amount) || 0), 0),
            )}{' '}
            open waarde
          </span>
        </div>
        <div className="segmented">
          <button className={view === 'kanban' ? 'active' : ''} onClick={() => setView('kanban')}>
            <LayoutGrid size={16} />
            Kanban
          </button>
          <button className={view === 'table' ? 'active' : ''} onClick={() => setView('table')}>
            <List size={16} />
            Tabel
          </button>
        </div>
      </div>
      {loading && !data ? (
        <Loading />
      ) : !items.length ? (
        <section className="card">
          <Empty icon={Target} title="Ruimte voor je eerste verkoopkans">
            Maak een kans aan vanuit een aanvraag zodra er concrete, gekwalificeerde interesse is.
            Een brochuredownload wordt niet automatisch een verkoopkans.
          </Empty>
        </section>
      ) : view === 'kanban' ? (
        <div className="kanban">
          {STAGES.map((stage) => (
            <section
              className="kanban-column"
              key={stage}
              onDragOver={(e) => {
                if (writable) e.preventDefault();
              }}
              onDrop={(e) => {
                e.preventDefault();
                const id = e.dataTransfer.getData('text/plain');
                const o = items.find((i) => i.id === id);
                if (o && writable) move(o, stage);
              }}
            >
              <div className="kanban-heading">
                <span className={`stage-dot stage-${stage}`} />
                <h3>{label(stage)}</h3>
                <span>{items.filter((o) => o.stage === stage).length}</span>
              </div>
              <small className="kanban-total">
                {money(
                  items
                    .filter((o) => o.stage === stage)
                    .reduce((n, o) => n + (Number(o.amount) || 0), 0),
                )}
              </small>
              {items
                .filter((o) => o.stage === stage)
                .map((o) => (
                  <article
                    className="opportunity-card"
                    key={o.id}
                    draggable={writable}
                    onDragStart={(e) => e.dataTransfer.setData('text/plain', o.id)}
                  >
                    <button className="opportunity-open" onClick={() => setEdit(o)}>
                      <span className="eyebrow">{o.company_name || 'Bedrijf'}</span>
                      <h3>{o.title}</h3>
                      <strong>{money(o.amount)}</strong>
                    </button>
                    {o.amount == null && <span className="quality-warning">Waarde ontbreekt</span>}
                    <div className="opportunity-card-footer">
                      <span className="avatar avatar-mini">{initials(o.owner_name || '?')}</span>
                      <span>{o.owner_name || 'Niet toegewezen'}</span>
                    </div>
                    {writable && (
                      <select
                        aria-label={`Fase van ${o.title}`}
                        value={o.stage}
                        onChange={(e) => move(o, e.target.value)}
                      >
                        {STAGES.map((s) => (
                          <option key={s} value={s}>
                            {label(s)}
                          </option>
                        ))}
                      </select>
                    )}
                  </article>
                ))}
            </section>
          ))}
        </div>
      ) : (
        <section className="card table-wrap">
          <table>
            <thead>
              <tr>
                <th>Kans</th>
                <th>Bedrijf</th>
                <th>Fase</th>
                <th>Waarde</th>
                <th>Verkoper</th>
                <th>Verwacht / afgesloten</th>
              </tr>
            </thead>
            <tbody>
              {items.map((o) => (
                <tr key={o.id}>
                  <td>
                    <button className="text-link" onClick={() => setEdit(o)}>
                      {o.title}
                    </button>
                  </td>
                  <td>
                    <button
                      className="text-link"
                      onClick={() => navigate(`/companies/${o.company_id}`)}
                    >
                      {o.company_name}
                    </button>
                  </td>
                  <td>
                    <Status value={o.stage} />
                  </td>
                  <td>{money(o.amount)}</td>
                  <td>{o.owner_name || 'Niet toegewezen'}</td>
                  <td>{date(o.closed_at || o.expected_close_at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      )}
      {edit && (
        <div className="modal-overlay" role="presentation" onClick={() => setEdit(null)}>
          <section
            className="modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="opp-title"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="section-heading">
              <div>
                <span className="eyebrow">VERKOOPKANS</span>
                <h2 id="opp-title">{edit.title}</h2>
              </div>
              <button className="icon-button" aria-label="Sluiten" onClick={() => setEdit(null)}>
                <X size={20} />
              </button>
            </div>
            <ErrorBox error={actionError} />
            <form
              className="stack"
              onSubmit={async (e) => {
                e.preventDefault();
                const f = new FormData(e.currentTarget);
                const body: Row = {
                  stage: f.get('stage'),
                  amount: f.get('amount') === '' ? null : Number(f.get('amount')),
                  expected_close_at: f.get('expected_close_at')
                    ? new Date(String(f.get('expected_close_at'))).toISOString()
                    : null,
                };
                if (f.get('closed_at'))
                  body.closed_at = new Date(String(f.get('closed_at'))).toISOString();
                if (f.get('loss_reason')) body.loss_reason = f.get('loss_reason');
                if (f.get('follow_up_at'))
                  body.follow_up_at = new Date(String(f.get('follow_up_at'))).toISOString();
                await patch(edit, body);
              }}
            >
              <label className="field">
                Fase
                <select
                  name="stage"
                  value={edit.stage}
                  disabled={!writable}
                  onChange={(e) => setEdit({ ...edit, stage: e.target.value })}
                >
                  {STAGES.map((s) => (
                    <option key={s} value={s}>
                      {label(s)}
                    </option>
                  ))}
                </select>
              </label>
              <label className="field">
                Geregistreerde waarde (€)
                <input
                  name="amount"
                  type="number"
                  min="0"
                  step="0.01"
                  defaultValue={edit.amount ?? ''}
                  disabled={!writable}
                />
              </label>
              {edit.stage === 'won' && (
                <>
                  <label className="field">
                    Afsluitdatum
                    <input
                      name="closed_at"
                      type="date"
                      required
                      defaultValue={(edit.closed_at || new Date().toISOString()).slice(0, 10)}
                      disabled={!writable}
                    />
                  </label>
                  <p className="notice">
                    Een gewonnen kans zonder waarde telt als gewonnen. Het ontbrekende bedrag blijft
                    zichtbaar als datakwaliteitsmelding.
                  </p>
                </>
              )}
              {edit.stage === 'lost' && (
                <>
                  <label className="field">
                    Verliesreden
                    <textarea
                      name="loss_reason"
                      required
                      defaultValue={edit.loss_reason || ''}
                      disabled={!writable}
                    />
                  </label>
                  <label className="field">
                    Afsluitdatum
                    <input
                      name="closed_at"
                      type="date"
                      required
                      defaultValue={(edit.closed_at || new Date().toISOString()).slice(0, 10)}
                      disabled={!writable}
                    />
                  </label>
                </>
              )}
              {edit.stage === 'waiting' && (
                <label className="field">
                  Opvolgdatum
                  <input
                    name="follow_up_at"
                    type="date"
                    required
                    defaultValue={edit.follow_up_at?.slice(0, 10) || ''}
                    disabled={!writable}
                  />
                </label>
              )}
              <label className="field">
                Verwachte afsluitdatum
                <input
                  name="expected_close_at"
                  type="date"
                  defaultValue={edit.expected_close_at?.slice(0, 10) || ''}
                  disabled={!writable}
                />
              </label>
              {writable && (
                <button className="btn btn-primary" disabled={busy}>
                  {busy ? 'Opslaan…' : 'Wijzigingen opslaan'}
                </button>
              )}
            </form>
          </section>
        </div>
      )}
    </>
  );
}

function Companies({
  api,
  query,
  tick,
  users,
  writable,
  onChanged,
  navigate,
}: {
  api: API;
  query: string;
  tick: number;
  users: User[];
  writable: boolean;
  onChanged: () => void;
  navigate: (p: string) => void;
}) {
  const { data, error, loading } = useData(api, `/api/companies?${query}`, tick);
  const [adding, setAdding] = useState(false),
    [actionError, setActionError] = useState(''),
    [busy, setBusy] = useState(false);
  return (
    <>
      <div className="section-heading">
        <div>
          <h2>
            Bedrijfsdossiers <span className="heading-count">{data?.items?.length || 0}</span>
          </h2>
          <p className="muted">Eén bedrijf kan meerdere aanvragen en verkoopkansen hebben.</p>
        </div>
        {writable && (
          <button className="btn btn-primary" onClick={() => setAdding(!adding)}>
            <Plus size={17} />
            Bedrijf toevoegen
          </button>
        )}
      </div>
      <ErrorBox error={error || actionError} />
      {adding && (
        <section className="card">
          <form
            className="form-grid"
            onSubmit={async (e) => {
              e.preventDefault();
              setBusy(true);
              setActionError('');
              const f = new FormData(e.currentTarget);
              const body = Object.fromEntries(f);
              try {
                const d = await api('/api/companies', {
                  method: 'POST',
                  body: JSON.stringify(body),
                });
                setAdding(false);
                onChanged();
                if (d.company?.id) navigate(`/companies/${d.company.id}`);
              } catch (e: any) {
                setActionError(e.message);
              } finally {
                setBusy(false);
              }
            }}
          >
            <label className="field">
              Bedrijfsnaam
              <input name="name" required />
            </label>
            <label className="field">
              Land
              <select name="country">
                <option value="BE">België</option>
                <option value="NL">Nederland</option>
                <option value="LU">Luxemburg</option>
              </select>
            </label>
            <label className="field">
              Ondernemingsnummer
              <input name="enterprise_number" />
            </label>
            <label className="field">
              Adres
              <input name="address" />
            </label>
            <label className="field">
              Postcode
              <input name="postcode" />
            </label>
            <label className="field">
              Gemeente
              <input name="city" />
            </label>
            <button className="btn btn-primary" disabled={busy}>
              Bedrijf opslaan
            </button>
          </form>
        </section>
      )}
      <section className="card">
        {loading && !data ? (
          <Loading />
        ) : !data?.items?.length ? (
          <Empty icon={Building2} title="Alle relaties op één plek">
            Bedrijven uit aanvragen en handmatig toegevoegde prospects verschijnen hier. Een
            prospect telt niet als websiteaanvraag.
          </Empty>
        ) : (
          <div className="company-grid">
            {data.items.map((c: Row) => (
              <button
                key={c.id}
                className="company-tile"
                onClick={() => navigate(`/companies/${c.id}`)}
              >
                <span className="company-avatar">{initials(c.name)}</span>
                <h3>{c.name}</h3>
                <p>
                  {[c.postcode, c.city, c.country].filter(Boolean).join(' ') || 'Locatie ontbreekt'}
                </p>
                <div>
                  <span className="badge">{c.is_prospect ? 'Prospect' : 'Bedrijf'}</span>
                  <ArrowUpRight size={17} />
                </div>
                <small>{c.enterprise_number || 'Ondernemingsnummer onbekend'}</small>
              </button>
            ))}
          </div>
        )}
      </section>
    </>
  );
}
function CompanyDetail({
  id,
  api,
  users,
  user,
  writable,
  tick,
  onChanged,
  navigate,
}: {
  id: string;
  api: API;
  users: User[];
  user: User;
  writable: boolean;
  tick: number;
  onChanged: () => void;
  navigate: (p: string) => void;
}) {
  const { data, error, loading } = useData(api, `/api/companies/${id}`, tick),
    [actionError, setActionError] = useState(''),
    [locationForm, setLocationForm] = useState(false);
  if (loading && !data) return <Loading />;
  if (!data) return <ErrorBox error={error || 'Bedrijf niet gevonden.'} />;
  const c = data.company || {};
  return (
    <>
      <button className="btn btn-text back-link" onClick={() => navigate('/companies')}>
        ← Alle bedrijven
      </button>
      <div className="detail-heading">
        <span className="company-avatar large">{initials(c.name)}</span>
        <div>
          <span className="eyebrow">BEDRIJFSDOSSIER</span>
          <h1>{c.name}</h1>
          <p>
            {c.enterprise_number || 'Ondernemingsnummer onbekend'} · {c.country || 'Land onbekend'}
          </p>
        </div>
        {['admin', 'manager'].includes(user.role) && (
          <button
            className="btn btn-secondary"
            onClick={async () => {
              const targetId = prompt(
                'ID van het gecontroleerde doelbedrijf waarmee je dit dossier wilt samenvoegen',
              );
              if (!targetId || targetId === id) return;
              try {
                const target = await api(`/api/companies/${encodeURIComponent(targetId)}`);
                if (
                  !confirm(
                    `Dossier “${c.name}” samenvoegen met “${target.company.name}”? Aanvragen en historie worden gekoppeld aan het doelbedrijf. De gegevens van het doelbedrijf blijven behouden.`,
                  )
                )
                  return;
                await api(`/api/companies/${id}/merge`, {
                  method: 'POST',
                  body: JSON.stringify({
                    target_id: targetId,
                    source_version: c.version,
                    target_version: target.company.version,
                    confirmed: true,
                  }),
                });
                onChanged();
                navigate(`/companies/${targetId}`);
              } catch (e: any) {
                setActionError(e.message);
              }
            }}
          >
            Gecontroleerd samenvoegen
          </button>
        )}
      </div>
      <ErrorBox error={error || actionError} />
      <div className="detail-grid">
        <div className="stack">
          <section className="card">
            <div className="section-heading">
              <h2>
                Aanvragen <span className="heading-count">{data.requests?.length || 0}</span>
              </h2>
            </div>
            {data.requests?.length ? (
              data.requests.map((r: Row) => (
                <RequestCard
                  key={r.id}
                  r={{ ...r, company_name: c.name }}
                  onClick={() => navigate(`/requests/${r.id}`)}
                />
              ))
            ) : (
              <Empty title="Nog geen aanvragen" icon={FileText}>
                Dit bedrijf heeft geen zichtbare websiteaanvragen. Prospects worden afzonderlijk
                bijgehouden.
              </Empty>
            )}
          </section>
          <section className="card">
            <div className="section-heading">
              <h2>Verkoopkansen</h2>
            </div>
            {data.opportunities?.map((o: Row) => (
              <div key={o.id} className="linked-opportunity">
                <div>
                  <strong>{o.title}</strong>
                  <small>{money(o.amount)}</small>
                </div>
                <Status value={o.stage} />
              </div>
            ))}
            {!data.opportunities?.length && <p className="muted">Geen zichtbare verkoopkansen.</p>}
          </section>
        </div>
        <aside className="stack">
          <section className="card">
            <div className="section-heading">
              <h2>Contactpersonen</h2>
              <Users size={19} />
            </div>
            {data.contacts?.map((p: Row) => (
              <div className="contact-person" key={p.id}>
                <strong>{p.name || 'Naam onbekend'}</strong>
                {p.email && (
                  <a href={`mailto:${p.email}`}>
                    <Mail size={15} />
                    {p.email}
                  </a>
                )}
                {p.phone && (
                  <a href={`tel:${p.phone}`}>
                    <Phone size={15} />
                    {p.phone}
                  </a>
                )}
              </div>
            ))}
            {!data.contacts?.length && <p className="muted">Nog geen contactpersoon.</p>}
          </section>
          <section className="card">
            <div className="section-heading">
              <h2>Vestigingen</h2>
              <MapPin size={19} />
            </div>
            {data.locations?.map((l: Row) => (
              <div className="location-line" key={l.id}>
                <strong>{l.address || 'Adres onbekend'}</strong>
                <span>{[l.postcode, l.city, l.country].filter(Boolean).join(' ')}</span>
                <small>
                  {l.latitude == null
                    ? 'Locatie nog niet bepaald'
                    : `${l.latitude}, ${l.longitude} · ${l.precision === 'postcode' ? 'Benaderd postcodecentrum' : 'Adreslocatie'}`}
                </small>
              </div>
            ))}
            {!data.locations?.length && <p className="muted">Locatie ontbreekt.</p>}
            {writable && (
              <button className="btn btn-secondary" onClick={() => setLocationForm(!locationForm)}>
                Locatie bevestigen
              </button>
            )}
            {locationForm && (
              <form
                className="stack compact-stack"
                onSubmit={async (e) => {
                  e.preventDefault();
                  setActionError('');
                  const f = new FormData(e.currentTarget);
                  try {
                    await api(`/api/companies/${id}/location`, {
                      method: 'POST',
                      body: JSON.stringify({
                        version: c.version,
                        latitude: Number(f.get('latitude')),
                        longitude: Number(f.get('longitude')),
                        precision: f.get('precision'),
                        country: c.country || 'BE',
                        address: f.get('address') || undefined,
                        postcode: f.get('postcode') || undefined,
                        city: f.get('city') || undefined,
                      }),
                    });
                    setLocationForm(false);
                    onChanged();
                  } catch (e: any) {
                    setActionError(e.message);
                  }
                }}
              >
                <label className="field">
                  Breedtegraad
                  <input name="latitude" type="number" step="any" min="-90" max="90" required />
                </label>
                <label className="field">
                  Lengtegraad
                  <input name="longitude" type="number" step="any" min="-180" max="180" required />
                </label>
                <label className="field">
                  Precisie
                  <select name="precision">
                    <option value="address">Bevestigd adres</option>
                    <option value="postcode">Benaderd postcodecentrum</option>
                  </select>
                </label>
                <label className="field">
                  Adres
                  <input name="address" />
                </label>
                <label className="field">
                  Postcode
                  <input name="postcode" />
                </label>
                <label className="field">
                  Gemeente
                  <input name="city" />
                </label>
                <button className="btn btn-primary">Locatie opslaan</button>
              </form>
            )}
          </section>
        </aside>
      </div>
    </>
  );
}

function Tasks({
  api,
  tick,
  writable,
  onChanged,
  navigate,
}: {
  api: API;
  tick: number;
  writable: boolean;
  onChanged: () => void;
  navigate: (p: string) => void;
}) {
  const { data, error, loading } = useData(api, '/api/tasks', tick),
    [actionError, setActionError] = useState(''),
    [showDone, setShowDone] = useState(false);
  const items: Row[] = (data?.items || []).filter((t: Row) => showDone || !t.completed);
  const groups: [string, (t: Row) => boolean][] = [
    ['Achterstallig', (t) => !t.completed && new Date(t.due_at).getTime() < Date.now()],
    ['Vandaag & binnenkort', (t) => !t.completed && new Date(t.due_at).getTime() >= Date.now()],
    ['Afgerond', (t) => Boolean(t.completed)],
  ];
  return (
    <>
      <div className="section-heading">
        <div>
          <h2>
            Mijn taken <span className="heading-count">{items.length}</span>
          </h2>
          <p className="muted">Nieuwe taken plan je vanuit een aanvraagfiche.</p>
        </div>
        <label className="checkbox-label">
          <input
            type="checkbox"
            checked={showDone}
            onChange={(e) => setShowDone(e.target.checked)}
          />
          Afgeronde taken tonen
        </label>
      </div>
      <ErrorBox error={error || actionError} />
      {loading && !data ? (
        <Loading />
      ) : !items.length ? (
        <section className="card">
          <Empty icon={CheckCircle2} title="Alles op schema">
            Er zijn momenteel geen openstaande taken. Plan vanuit een aanvraag de volgende
            betekenisvolle actie.
          </Empty>
        </section>
      ) : (
        <div className="stack">
          {groups.map(([name, predicate]) => {
            const rows = items.filter(predicate);
            return rows.length ? (
              <section className="card" key={name}>
                <div className="section-heading">
                  <h2>
                    {name}
                    <span className="heading-count">{rows.length}</span>
                  </h2>
                </div>
                {rows.map((t) => (
                  <div className={`task-row ${t.completed ? 'completed' : ''}`} key={t.id}>
                    <button
                      className="check-button"
                      aria-label={`${t.title} ${t.completed ? 'heropenen' : 'afronden'}`}
                      disabled={!writable}
                      onClick={async () => {
                        try {
                          await api(`/api/tasks/${t.id}`, {
                            method: 'PATCH',
                            body: JSON.stringify({ version: t.version, completed: !t.completed }),
                          });
                          onChanged();
                        } catch (e: any) {
                          setActionError(e.message);
                        }
                      }}
                    >
                      {t.completed && <Check size={16} />}
                    </button>
                    <div>
                      <strong>{t.title}</strong>
                      <button
                        className="text-link"
                        onClick={() => navigate(`/requests/${t.request_id}`)}
                      >
                        {t.company_name || 'Aanvraag openen'}
                      </button>
                    </div>
                    <span className="task-date">
                      <CalendarDays size={15} />
                      {date(t.due_at, true)}
                    </span>
                    <span className="muted">{t.owner_name || ''}</span>
                  </div>
                ))}
              </section>
            ) : null;
          })}
        </div>
      )}
    </>
  );
}

function Reports({ api, query, tick }: { api: API; query: string; tick: number }) {
  const { data, error, loading } = useData(api, `/api/reports?${query}`, tick);
  const filterParams = new URLSearchParams(query),
    previousParams = new URLSearchParams(query);
  const fromTime = Date.parse(filterParams.get('from') || ''),
    toTime = Date.parse(filterParams.get('to') || '');
  const hasComparison = Number.isFinite(fromTime) && Number.isFinite(toTime) && toTime >= fromTime;
  if (hasComparison) {
    previousParams.set('to', new Date(fromTime - 86400000).toISOString().slice(0, 10));
    previousParams.set(
      'from',
      new Date(fromTime - (toTime - fromTime) - 86400000).toISOString().slice(0, 10),
    );
    previousParams.set('as_of', new Date(fromTime - 1).toISOString());
  }
  const { data: previous } = useData(
    api,
    hasComparison ? `/api/reports?${previousParams.toString()}` : '/api/health',
    tick,
  );
  if (loading && !data) return <Loading />;
  const m = data?.metrics || {};
  const rate = (v: any) => (v == null ? 'Onbekend' : `${Math.round(Number(v) * 1000) / 10}%`);
  const definitions = data?.definitions || {};
  return (
    <>
      <div className="section-heading">
        <div>
          <h2>Managementrapport</h2>
          <p className="muted">
            Peildatum {date(data?.as_of || new Date().toISOString(), true)} · Cohort:{' '}
            {data?.cohort_size ?? m.requests ?? 0} aanvragen
          </p>
        </div>
        <div className="row print-hide">
          <a className="btn btn-secondary" href={`/api/reports/export.csv?${query}`}>
            <Download size={16} />
            CSV
          </a>
          <a className="btn btn-secondary" href={`/api/reports/export.xlsx?${query}`}>
            <ArrowDownToLine size={16} />
            Excel
          </a>
          <button className="btn btn-primary" onClick={() => window.print()}>
            <FileText size={16} />
            Afdrukken / PDF
          </button>
        </div>
      </div>
      <ErrorBox error={error} />
      <div className="print-only">
        <p>Actieve filters: {query || 'Geen aanvullende filters'}</p>
      </div>
      <div className="stats-grid">
        <Stat
          title="Geldige aanvragen"
          value={m.requests ?? 0}
          detail="Instroom tijdens geselecteerde periode"
          icon={FileText}
        />
        <Stat
          title="Unieke bedrijven"
          value={m.companies ?? 0}
          detail={`${m.contacts ?? 0} contactpersonen`}
          icon={Building2}
        />
        <Stat
          title="Gekwalificeerde kansen"
          value={m.opportunities ?? 0}
          detail="Afzonderlijk van formulieraanvragen"
          icon={Target}
        />
        <Stat
          title="Geregistreerde verkoopwaarde"
          value={money(m.won_value ?? 0)}
          detail="Gewonnen op afsluitdatum · geen factuuromzet"
          icon={TrendingUp}
          accent
        />
      </div>
      {hasComparison && previous?.metrics && (
        <section className="card" style={{ marginBottom: 22 }}>
          <div className="section-heading">
            <div>
              <h2>Vergelijking met de vorige periode</h2>
              <p className="muted">
                Vorige instroom: {date(previousParams.get('from'))} –{' '}
                {date(previousParams.get('to'))}. De vorige cijfers gebruiken de peildatum aan het
                einde van die periode.
              </p>
            </div>
          </div>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Maatstaf</th>
                  <th>Geselecteerde periode</th>
                  <th>Vorige periode</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Geldige aanvragen</td>
                  <td>{m.requests ?? 0}</td>
                  <td>{previous.metrics.requests}</td>
                </tr>
                <tr>
                  <td>Geregistreerde verkoopwaarde</td>
                  <td>{money(m.won_value)}</td>
                  <td>{money(previous.metrics.won_value)}</td>
                </tr>
                <tr>
                  <td>Opvolgingsgraad</td>
                  <td>{rate(m.follow_up_rate)}</td>
                  <td>{rate(previous.metrics.follow_up_rate)}</td>
                </tr>
                <tr>
                  <td>Lead-naar-verkoopconversie</td>
                  <td>{rate(m.lead_conversion)}</td>
                  <td>{rate(previous.metrics.lead_conversion)}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </section>
      )}
      <div className="report-grid">
        <section className="card">
          <div className="section-heading">
            <h2>Opvolging & conversie</h2>
          </div>
          <div className="metric-list">
            {[
              [
                'Opvolgingsgraad',
                rate(m.follow_up_rate),
                'Aanvragen met geregistreerd menselijk contact',
              ],
              [
                'Nog niet gecontacteerd',
                rate(m.uncontacted_share),
                'Alle aanvragen blijven in de noemer',
              ],
              [
                'Eerste contacttijd · mediaan',
                m.median_first_contact_hours == null
                  ? 'Onbekend'
                  : `${Math.round(m.median_first_contact_hours * 10) / 10} uur`,
                'Van ontvangst tot eerste menselijke contactactie',
              ],
              [
                'Eerste contacttijd · p90',
                m.p90_first_contact_hours == null
                  ? 'Onbekend'
                  : `${Math.round(m.p90_first_contact_hours * 10) / 10} uur`,
                'Automatische bevestigingen tellen niet',
              ],
              [
                'Lead-naar-verkoopconversie',
                rate(m.lead_conversion),
                'Elke aanvraag maximaal eenmaal',
              ],
              [
                'Bedrijfsconversie',
                rate(m.company_conversion),
                'Unieke bedrijven uit instroomcohort',
              ],
              ['Winratio', rate(m.win_ratio), 'Gewonnen / (gewonnen + verloren) op afsluitdatum'],
            ].map(([name, value, description]) => (
              <div className="metric-row" key={name}>
                <div>
                  <strong>{name}</strong>
                  <small>{description}</small>
                </div>
                <span>{value}</span>
              </div>
            ))}
          </div>
        </section>
        <section className="card">
          <div className="section-heading">
            <h2>Waarde & datakwaliteit</h2>
          </div>
          <div className="metric-list">
            {[
              [
                'Open pipelinewaarde',
                money(m.open_pipeline_value ?? 0),
                'Actuele foto · open kansen, elk eenmaal',
              ],
              [
                'Geregistreerde offertewaarde',
                money(m.quote_value ?? 0),
                'Geregistreerde bedragen in offertefase',
              ],
              ['Verloren waarde', money(m.lost_value ?? 0), 'Verloren op afsluitdatum'],
              ['Niet toegewezen aanvragen', m.unassigned ?? 0, 'Actie voor de salesmanager'],
              ['Ontbrekende locaties', m.missing_locations ?? 0, 'Geen verzonnen kaartmarkers'],
              [
                'Ontbrekende waarden',
                m.missing_values ?? 0,
                'Zichtbaar als onbekend, niet als nul',
              ],
              [
                'Achterstallige taken',
                m.overdue_tasks ?? 0,
                'Openstaande acties vóór de peildatum',
              ],
            ].map(([name, value, description]) => (
              <div className="metric-row" key={String(name)}>
                <div>
                  <strong>{name}</strong>
                  <small>{description}</small>
                </div>
                <span>{value}</span>
              </div>
            ))}
          </div>
        </section>
      </div>
      <div className="report-grid">
        <ReportBars title="Instroom per bron" rows={data?.by_source} labelKey="source" />
        <ReportBars title="Verdeling opvolgstatus" rows={data?.by_status} labelKey="status" />
      </div>
      <section className="card definitions">
        <div className="section-heading">
          <h2>Wat betekenen deze cijfers?</h2>
          <ShieldCheck size={19} />
        </div>
        <p>
          Financiële bedragen tellen elke verkoopkans eenmaal, ook wanneer meerdere aanvragen
          gekoppeld zijn. Onbekende bedragen worden niet als ingevulde nulwaarden weergegeven.
          KBO-prospects tellen niet als inkomende websiteaanvragen.
        </p>
        {Array.isArray(definitions)
          ? definitions.map((d: any, i: number) => (
              <p key={i}>{typeof d === 'string' ? d : JSON.stringify(d)}</p>
            ))
          : Object.entries(definitions).map(([key, value]) => (
              <p key={key}>
                <strong>{label(key)}:</strong> {String(value)}
              </p>
            ))}
        {data?.historical_limitations?.map((text: string, i: number) => (
          <p className="notice" key={i}>
            {text}
          </p>
        ))}
        <p className="muted">
          Campagnekosten en boekhoudgegevens zijn niet gekoppeld. CPL, ROI en gefactureerde omzet
          zijn daarom niet beschikbaar.
        </p>
      </section>
    </>
  );
}
function ReportBars({ title, rows, labelKey }: { title: string; rows: any; labelKey: string }) {
  const items: Array<Row> = Array.isArray(rows) ? rows : [];
  const max = Math.max(1, ...items.map((r) => Number(r.count || r.total || 0)));
  return (
    <section className="card">
      <div className="section-heading">
        <h2>{title}</h2>
      </div>
      {!items.length ? (
        <div className="empty compact">
          <TrendingUp size={22} />
          <p>Nog geen gegevens voor deze selectie.</p>
        </div>
      ) : (
        <div className="bar-chart">
          {items.map((r, i) => (
            <div key={r.id || i}>
              <div>
                <span>{label(r[labelKey] || r.name || r.label || 'Onbekend')}</span>
                <strong>{r.count ?? r.total ?? 0}</strong>
              </div>
              <div className="bar-track">
                <span style={{ width: `${(Number(r.count || r.total || 0) / max) * 100}%` }} />
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

function Attachments({ id, api, writable }: { id: string; api: API; writable: boolean }) {
  const [tick, setTick] = useState(0);
  const { data, error, loading } = useData(api, `/api/requests/${id}/attachments`, tick),
    [uploadError, setUploadError] = useState(''),
    [busy, setBusy] = useState(false),
    [notice, setNotice] = useState('');
  return (
    <div className="stack">
      <p className="muted" style={{ fontSize: 11 }}>
        Private dossierbijlagen · PDF, PNG of JPEG · maximaal 5 MB per bestand.
      </p>
      <ErrorBox error={error || uploadError} />
      {notice && (
        <div className="notice" role="status">
          {notice}
        </div>
      )}
      {writable && (
        <label className="field">
          Bijlage toevoegen
          <input
            type="file"
            disabled={busy}
            accept="application/pdf,image/png,image/jpeg"
            onChange={async (e) => {
              const file = e.target.files?.[0];
              if (!file) return;
              setUploadError('');
              setNotice('');
              if (file.size > 5 * 1024 * 1024) {
                setUploadError('Dit bestand is groter dan 5 MB.');
                e.target.value = '';
                return;
              }
              setBusy(true);
              try {
                const content = await new Promise<string>((resolve, reject) => {
                  const reader = new FileReader();
                  reader.onload = () => resolve(String(reader.result).split(',')[1]);
                  reader.onerror = () => reject(new Error('Het bestand kon niet gelezen worden.'));
                  reader.readAsDataURL(file);
                });
                await api(`/api/requests/${id}/attachments`, {
                  method: 'POST',
                  body: JSON.stringify({
                    name: file.name,
                    mime: file.type,
                    content_base64: content,
                  }),
                });
                setTick((t) => t + 1);
                setNotice('Bijlage veilig opgeslagen.');
              } catch (err: any) {
                setUploadError(err.message);
              } finally {
                setBusy(false);
                e.target.value = '';
              }
            }}
          />
          {busy && <small>Bestand wordt opgeslagen…</small>}
        </label>
      )}
      {loading && !data ? (
        <Loading />
      ) : !data?.items?.length ? (
        <div className="empty compact">
          <FileText size={22} />
          <p>Nog geen bijlagen in dit dossier.</p>
        </div>
      ) : (
        data.items.map((a: Row) => (
          <a className="linked-opportunity" key={a.id} href={`/api/attachments/${a.id}`}>
            <div>
              <strong>{a.name}</strong>
              <small>
                {Math.round(a.size_bytes / 1024)} KB · {a.mime}
              </small>
            </div>
            <Download size={18} />
          </a>
        ))
      )}
    </div>
  );
}

function Notifications({
  api,
  tick,
  navigate,
}: {
  api: API;
  tick: number;
  navigate: (p: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const { data, error } = useData(api, '/api/notifications', tick);
  const items: Row[] = data?.items || [];
  return (
    <div className="notifications">
      <button
        className={`icon-button ${open ? 'selected' : ''}`}
        aria-label={`Meldingen (${items.length})`}
        aria-expanded={open}
        onClick={() => setOpen(!open)}
      >
        <Bell size={17} />
        {items.length > 0 && <i />}
      </button>
      {open && (
        <div className="notification-popover">
          <div className="section-heading">
            <h3>Interne meldingen</h3>
            <button
              className="icon-button"
              aria-label="Meldingen sluiten"
              onClick={() => setOpen(false)}
            >
              <X size={15} />
            </button>
          </div>
          {error ? (
            <ErrorBox error={error} />
          ) : !items.length ? (
            <p className="muted">Geen meldingen. Nieuwe toewijzingen verschijnen hier.</p>
          ) : (
            items.slice(0, 20).map((n) => (
              <button
                key={n.id}
                onClick={() => {
                  navigate(`/requests/${n.request_id}`);
                  setOpen(false);
                }}
              >
                <span>{n.message}</span>
                <small>{date(n.created_at, true)}</small>
                <ArrowUpRight size={14} />
              </button>
            ))
          )}
        </div>
      )}
    </div>
  );
}

function MarketingFields({
  request,
  api,
  onChanged,
}: {
  request: Row;
  api: API;
  onChanged: () => void;
}) {
  const [version, setVersion] = useState(request.version),
    [error, setError] = useState(''),
    [busy, setBusy] = useState(false),
    [notice, setNotice] = useState('');
  return (
    <section className="card">
      <h2 style={{ marginBottom: 18 }}>Marketingvelden</h2>
      <form
        className="stack compact-stack"
        onSubmit={async (e) => {
          e.preventDefault();
          setBusy(true);
          setError('');
          setNotice('');
          const f = new FormData(e.currentTarget);
          try {
            const d = await api(`/api/requests/${request.id}/marketing`, {
              method: 'PATCH',
              body: JSON.stringify({
                version,
                campaign: f.get('campaign') || null,
                business_unit: f.get('business_unit'),
                brand: f.get('brand') || null,
              }),
            });
            setVersion(d.request.version);
            setNotice('Marketingvelden opgeslagen.');
            onChanged();
          } catch (e: any) {
            setError(e.message);
          } finally {
            setBusy(false);
          }
        }}
      >
        <ErrorBox error={error} />
        {notice && (
          <div className="notice" role="status">
            {notice}
          </div>
        )}
        {request.version !== version && (
          <div className="notice">
            Dit dossier is gewijzigd sinds je het formulier opende. Herlaad vóór je de
            marketingvelden opslaat.
          </div>
        )}
        <label className="field">
          Campagne
          <input name="campaign" defaultValue={request.campaign || ''} />
        </label>
        <label className="field">
          Businessunit
          <select name="business_unit" defaultValue={request.business_unit || 'Unknown'}>
            {['Wood', 'Stone', 'Glass', 'Unknown'].map((b) => (
              <option key={b} value={b}>
                {label(b)}
              </option>
            ))}
          </select>
        </label>
        <label className="field">
          Merk
          <input name="brand" defaultValue={request.brand || ''} />
        </label>
        <button className="btn btn-secondary" disabled={busy || request.version !== version}>
          Marketingvelden opslaan
        </button>
      </form>
    </section>
  );
}
