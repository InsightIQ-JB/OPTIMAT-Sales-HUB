import { useCallback, useEffect, useState } from 'react';
import { AlertCircle, Building2, Check, FileUp, Plus, Search, ShieldCheck } from 'lucide-react';
import type { User } from '../shared/domain';
type Props = {
  api: <T = any>(path: string, options?: RequestInit) => Promise<T>;
  query?: string;
  onOpenRequest?: (id: string) => void;
  onOpenCompany?: (id: string) => void;
  user: User;
};
const parseCSV = (text: string) => {
  const delimiter = text.split(/\r?\n/, 1)[0].includes(';') ? ';' : ',';
  const matrix: string[][] = [];
  let row: string[] = [],
    cell = '',
    quoted = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (c === '"') {
      if (quoted && text[i + 1] === '"') {
        cell += '"';
        i++;
      } else quoted = !quoted;
    } else if (c === delimiter && !quoted) {
      row.push(cell);
      cell = '';
    } else if ((c === '\n' || c === '\r') && !quoted) {
      if (c === '\r' && text[i + 1] === '\n') i++;
      row.push(cell);
      if (row.some((v) => v.trim())) matrix.push(row);
      row = [];
      cell = '';
    } else cell += c;
  }
  if (quoted) throw new Error('De CSV bevat een niet-afgesloten aanhalingsteken.');
  row.push(cell);
  if (row.some((v) => v.trim())) matrix.push(row);
  if (matrix.length < 2) throw new Error('Voeg een kopregel en minstens één bedrijfsrij toe.');
  const headers = matrix[0].map((h) =>
    h
      .replace(/^\uFEFF/, '')
      .trim()
      .toLowerCase(),
  );
  if (!headers.includes('name') || !headers.includes('country'))
    throw new Error('De kopregel moet minstens name en country bevatten.');
  if (matrix.length > 501) throw new Error('Importeer maximaal 500 bedrijven tegelijk.');
  return matrix.slice(1).map((values, index) => {
    if (values.length !== headers.length)
      throw new Error(`CSV-rij ${index + 2} heeft niet hetzelfde aantal kolommen als de kopregel.`);
    return Object.fromEntries(headers.map((h, i) => [h, values[i].trim()]));
  });
};
export default function Prospecting({ api, user, onOpenCompany }: Props) {
  const [status, setStatus] = useState<any>(null),
    [q, setQ] = useState(''),
    [postcode, setPostcode] = useState(''),
    [activity, setActivity] = useState(''),
    [results, setResults] = useState<any[] | null>(null),
    [error, setError] = useState(''),
    [notice, setNotice] = useState(''),
    [busy, setBusy] = useState(false),
    [tab, setTab] = useState('search');
  const [users, setUsers] = useState<any[]>([]),
    [csv, setCsv] = useState(''),
    [preview, setPreview] = useState<any>(null),
    [previewRows, setPreviewRows] = useState<any[] | null>(null),
    [previewText, setPreviewText] = useState('');
  const [manual, setManual] = useState({
    name: '',
    country: 'BE',
    enterprise_number: '',
    address: '',
    postcode: '',
    city: '',
    owner_id: '',
  });
  const canWrite = user.role !== 'management',
    canAssign = user.role === 'admin' || user.role === 'manager';
  const load = useCallback(async () => {
    try {
      setStatus(await api('/api/prospecting/status'));
      if (canAssign) {
        const r = await api<any>('/api/users');
        setUsers(r.users || []);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Prospectiestatus niet beschikbaar.');
    }
  }, [api, canAssign]);
  useEffect(() => {
    void load();
  }, [load]);
  const run = async (fn: () => Promise<void>) => {
    setError('');
    setNotice('');
    setBusy(true);
    try {
      await fn();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Deze actie kon niet worden voltooid.');
    } finally {
      setBusy(false);
    }
  };
  const search = (e: React.FormEvent) => {
    e.preventDefault();
    void run(async () => {
      const p = new URLSearchParams();
      if (q.trim()) p.set('q', q.trim());
      if (postcode) p.set('postcode', postcode);
      if (activity) p.set('activity', activity);
      const data = await api<any>(`/api/prospecting/search?${p}`);
      setResults(data.items || []);
      if (data.status && data.status !== 'ok') setNotice(String(data.message || data.status));
    });
  };
  const importOne = (candidate: any) =>
    void run(async () => {
      const data = await api<any>('/api/prospecting/import', {
        method: 'POST',
        body: JSON.stringify({ ...candidate, country: 'BE', legal_person: true }),
      });
      setNotice(
        data.existing
          ? 'Dit bedrijf heeft al een dossier.'
          : 'Prospect toegevoegd. Dit telt niet als websiteaanvraag.',
      );
      if (data.company?.id) onOpenCompany?.(data.company.id);
    });
  const create = (e: React.FormEvent) => {
    e.preventDefault();
    void run(async () => {
      const data = await api<any>('/api/companies', {
        method: 'POST',
        body: JSON.stringify(
          Object.fromEntries(Object.entries(manual).filter(([, v]) => v !== '')),
        ),
      });
      setNotice('Bedrijf aangemaakt. Dit telt niet als websiteaanvraag.');
      setManual({
        ...manual,
        name: '',
        enterprise_number: '',
        address: '',
        postcode: '',
        city: '',
      });
      if (data.company?.id) onOpenCompany?.(data.company.id);
      else if (data.id) onOpenCompany?.(data.id);
    });
  };
  const csvPreview = () =>
    void run(async () => {
      const rows = parseCSV(csv);
      const result = await api<any>('/api/prospecting/companies/import', {
        method: 'POST',
        body: JSON.stringify({ rows, commit: false }),
      });
      setPreview(result);
      setPreviewRows(rows);
      setPreviewText(csv);
    });
  const csvCommit = () =>
    void run(async () => {
      if (!previewRows || previewText !== csv)
        throw new Error('Controleer eerst de actuele CSV met de voorbeeldcontrole.');
      const result = await api<any>('/api/prospecting/companies/import', {
        method: 'POST',
        body: JSON.stringify({ rows: previewRows, commit: true }),
      });
      setPreview(result);
      setPreviewRows(null);
      setNotice('Import verwerkt. Bekijk hieronder het importverslag.');
    });
  const hasErrors =
    preview &&
    ((Array.isArray(preview.issues) && preview.issues.some((x: any) => x.severity !== 'warning')) ||
      (Array.isArray(preview.errors) && preview.errors.length > 0));
  return (
    <div className="stack prospecting-view">
      <div className="section-heading">
        <div>
          <h2>Nieuwe relaties ontdekken</h2>
          <p className="muted">
            Bedrijfsprospectie staat los van de inkomende WordPress-aanvragen.
          </p>
        </div>
        <span className="badge">KBO · België</span>
      </div>
      {error && (
        <div className="error" role="alert">
          {error}
        </div>
      )}
      {notice && (
        <div className="notice" role="status">
          <Check size={18} />
          {notice}
        </div>
      )}
      <div className="card prospect-status">
        <div className="prospect-status-icon">
          <ShieldCheck size={24} />
        </div>
        <div>
          <strong>
            {status?.configured ? 'KBO-bron geconfigureerd' : 'KBO nog niet gekoppeld'}
          </strong>
          <p className="muted">
            {status?.message ||
              'Zoeken wordt beschikbaar zodra een toegestane bron, bronrechten en serverconfiguratie zijn bevestigd. De dagelijkse leadopvolging blijft gewoon werken.'}
          </p>
          <small className="muted">
            Dekking: België · Geen KvK- of Luxemburg-koppeling · Geen automatische mailing
          </small>
        </div>
        <span className={`badge ${status?.configured ? 'badge-success' : ''}`}>
          {status?.configured ? 'Geconfigureerd' : 'Niet gekoppeld'}
        </span>
      </div>
      <div className="tabs" role="tablist" aria-label="Prospectiemethode">
        {[
          ['search', 'KBO zoeken'],
          ['manual', 'Handmatig toevoegen'],
          ['csv', 'Bedrijven importeren'],
        ].map(([key, title]) => (
          <button
            type="button"
            role="tab"
            aria-selected={tab === key}
            className={`tab ${tab === key ? 'active' : ''}`}
            key={key}
            onClick={() => setTab(key)}
          >
            {title}
          </button>
        ))}
      </div>
      {tab === 'search' && (
        <>
          <form className="card stack" onSubmit={search}>
            <div className="form-grid">
              <label className="field">
                Bedrijfsnaam of ondernemingsnummer
                <input
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder="Zoek een Belgisch bedrijf"
                  disabled={!status?.configured}
                />
              </label>
              <label className="field">
                Postcode
                <input
                  value={postcode}
                  onChange={(e) => setPostcode(e.target.value)}
                  placeholder="Optioneel"
                  disabled={!status?.configured}
                />
              </label>
              <label className="field">
                NACE-BEL-activiteit
                <input
                  value={activity}
                  onChange={(e) => setActivity(e.target.value)}
                  placeholder="Gecontroleerde code"
                  disabled={!status?.configured}
                />
              </label>
            </div>
            <div className="row">
              <button
                type="submit"
                className="btn btn-primary"
                disabled={!status?.configured || busy || (!q.trim() && !postcode && !activity)}
              >
                <Search size={16} />
                Bedrijven zoeken
              </button>
            </div>
            <p className="muted prospect-small">
              Alleen toegestane rechtspersonen. Beschikbare zoekfilters zijn afhankelijk van de
              aangesloten databron. Activiteitscodes en hun versie moeten vooraf door marketing
              worden gecontroleerd.
            </p>
          </form>
          {results && (
            <div className="card">
              <div className="section-heading">
                <h3>Zoekresultaten</h3>
                <span className="muted">{results.length} bedrijven</span>
              </div>
              {results.length === 0 ? (
                <div className="empty">
                  <Building2 size={28} />
                  <h3>Geen bedrijven gevonden</h3>
                  <p>Pas je zoekopdracht aan.</p>
                </div>
              ) : (
                <div className="prospect-results">
                  {results.map((company, index) => (
                    <article className="prospect-result" key={company.enterprise_number || index}>
                      <div>
                        <strong>{company.name}</strong>
                        <p className="muted">
                          {[company.enterprise_number, company.postcode, company.city]
                            .filter(Boolean)
                            .join(' · ')}
                        </p>
                        <small className="muted">
                          {company.source || 'KBO'}
                          {company.updated_at
                            ? ` · bijgewerkt ${new Date(company.updated_at).toLocaleDateString('nl-BE')}`
                            : ''}
                          {company.match_confidence
                            ? ` · zekerheid ${company.match_confidence}`
                            : ''}
                        </small>
                      </div>
                      {company.existing_company_id ? (
                        <button
                          className="btn btn-secondary btn-small"
                          onClick={() => onOpenCompany?.(company.existing_company_id)}
                        >
                          Bestaand dossier
                        </button>
                      ) : (
                        canWrite && (
                          <button
                            className="btn btn-primary btn-small"
                            disabled={busy || company.legal_person === false}
                            onClick={() => importOne(company)}
                          >
                            <Plus size={15} />
                            Als prospect toevoegen
                          </button>
                        )
                      )}
                    </article>
                  ))}
                </div>
              )}
            </div>
          )}
        </>
      )}
      {tab === 'manual' && (
        <form className="card stack" onSubmit={create}>
          <div>
            <h3>Een bedrijf toevoegen</h3>
            <p className="muted">
              Voor België, Nederland en Luxemburg. Je maakt hiermee een bedrijfsdossier, geen
              formulieraanvraag.
            </p>
          </div>
          <div className="form-grid">
            <label className="field">
              Bedrijfsnaam
              <input
                required
                maxLength={300}
                value={manual.name}
                onChange={(e) => setManual({ ...manual, name: e.target.value })}
                disabled={!canWrite}
              />
            </label>
            <label className="field">
              Land
              <select
                value={manual.country}
                onChange={(e) => setManual({ ...manual, country: e.target.value })}
                disabled={!canWrite}
              >
                <option value="BE">België</option>
                <option value="NL">Nederland</option>
                <option value="LU">Luxemburg</option>
              </select>
            </label>
            <label className="field">
              Ondernemingsnummer
              <input
                value={manual.enterprise_number}
                onChange={(e) => setManual({ ...manual, enterprise_number: e.target.value })}
                placeholder="Optioneel, inclusief land waar nodig"
                disabled={!canWrite}
              />
            </label>
            <label className="field">
              Straat en huisnummer
              <input
                value={manual.address}
                onChange={(e) => setManual({ ...manual, address: e.target.value })}
                disabled={!canWrite}
              />
            </label>
            <label className="field">
              Postcode
              <input
                value={manual.postcode}
                onChange={(e) => setManual({ ...manual, postcode: e.target.value })}
                disabled={!canWrite}
              />
            </label>
            <label className="field">
              Gemeente
              <input
                value={manual.city}
                onChange={(e) => setManual({ ...manual, city: e.target.value })}
                disabled={!canWrite}
              />
            </label>
            {canAssign && (
              <label className="field">
                Eigenaar
                <select
                  value={manual.owner_id}
                  onChange={(e) => setManual({ ...manual, owner_id: e.target.value })}
                >
                  <option value="">Nog niet toegewezen</option>
                  {users
                    .filter((u) => u.active && ['seller', 'manager', 'admin'].includes(u.role))
                    .map((u) => (
                      <option key={u.id} value={u.id}>
                        {u.name}
                      </option>
                    ))}
                </select>
              </label>
            )}
          </div>
          {canWrite ? (
            <div className="row">
              <button className="btn btn-primary" disabled={busy}>
                <Plus size={16} />
                Bedrijf opslaan
              </button>
            </div>
          ) : (
            <p className="notice">
              Je account heeft leesrechten. Vraag een verkoper of salesmanager om een prospect toe
              te voegen.
            </p>
          )}
        </form>
      )}
      {tab === 'csv' && (
        <div className="card stack">
          <div>
            <h3>CSV-import met voorbeeldcontrole</h3>
            <p className="muted">
              Plak maximaal 500 bedrijven. Komma's en puntkomma's worden ondersteund; tekst tussen
              aanhalingstekens blijft behouden.
            </p>
          </div>
          <div className="notice">
            <AlertCircle size={18} />
            <span>
              Gebruik de kolommen <code>name,country,enterprise_number,address,postcode,city</code>.
              Alleen <code>name</code> en <code>country</code> zijn verplicht. Bestaande dossiers
              worden gecontroleerd op een betrouwbare ondernemingssleutel.
            </span>
          </div>
          <label className="field">
            CSV-bestand
            <input
              type="file"
              accept=".csv,text/csv"
              disabled={!canWrite || busy}
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) {
                  if (f.size > 1024 * 1024) {
                    setError('Gebruik een CSV kleiner dan 1 MB.');
                    return;
                  }
                  void f
                    .text()
                    .then((text) => {
                      setCsv(text);
                      setPreview(null);
                      setPreviewRows(null);
                    })
                    .catch(() => setError('Het bestand kon niet worden gelezen.'));
                }
              }}
            />
          </label>
          <label className="field">
            Of plak CSV
            <textarea
              rows={8}
              value={csv}
              placeholder={'name,country,enterprise_number,address,postcode,city\n'}
              disabled={!canWrite}
              onChange={(e) => {
                setCsv(e.target.value);
                setPreview(null);
                setPreviewRows(null);
              }}
            />
          </label>
          <div className="row">
            <button
              className="btn btn-secondary"
              disabled={!canWrite || busy || !csv.trim()}
              onClick={csvPreview}
            >
              <Search size={16} />
              Voorbeeld controleren
            </button>
            <button
              className="btn btn-primary"
              disabled={!canWrite || busy || !previewRows || previewText !== csv || !!hasErrors}
              onClick={csvCommit}
            >
              <FileUp size={16} />
              Import bevestigen
            </button>
          </div>
          {preview && (
            <div className="prospect-import-report" aria-live="polite">
              <h4>Importverslag</h4>
              <pre>{JSON.stringify(preview, null, 2)}</pre>
            </div>
          )}
        </div>
      )}
      <style>{`.prospect-status{display:flex;gap:18px;align-items:flex-start}.prospect-status>div:nth-child(2){flex:1}.prospect-status p{font-size:13px;line-height:1.65;margin:7px 0}.prospect-status-icon{width:48px;height:48px;border-radius:12px;display:grid;place-items:center;background:#f0f5e6;color:#648434;flex:none}.prospect-small{font-size:12px;line-height:1.65}.prospect-results{display:flex;flex-direction:column;gap:12px}.prospect-result{display:flex;justify-content:space-between;align-items:center;gap:15px;border-bottom:1px solid #edf0f3;padding:15px 0}.prospect-result p{margin:6px 0;font-size:13px}.prospect-import-report pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f5f7f9;padding:15px;border-radius:8px;font-size:12px;max-height:400px;overflow:auto}.prospecting-view code{font-size:11px;overflow-wrap:anywhere}.prospecting-view textarea{font:12px/1.7 ui-monospace,monospace}.prospecting-view .notice{line-height:1.65}@media(max-width:600px){.prospect-status{flex-wrap:wrap;padding:18px}.prospect-status .badge{margin-left:66px}.prospect-result{align-items:flex-start;flex-direction:column}.prospect-status-icon{width:40px;height:40px}}`}</style>
    </div>
  );
}
