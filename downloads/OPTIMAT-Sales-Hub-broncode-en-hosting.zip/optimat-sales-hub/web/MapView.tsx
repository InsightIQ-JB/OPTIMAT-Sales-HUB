import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { AlertCircle, LocateFixed, MapPinned, RefreshCw, Search, X } from 'lucide-react';
import type { User } from '../shared/domain';

type Props = {
  api: <T = any>(path: string, options?: RequestInit) => Promise<T>;
  query?: string;
  onOpenRequest?: (id: string) => void;
  onOpenCompany?: (id: string) => void;
  user: User;
};
type MapItem = Record<string, any>;
const coordinate = (item: MapItem): [number, number] | null => {
  const a = item.latitude ?? item.lat,
    b = item.longitude ?? item.lng ?? item.lon;
  if (a === null || a === undefined || a === '' || b === null || b === undefined || b === '')
    return null;
  const lat = Number(a),
    lng = Number(b);
  return Number.isFinite(lat) &&
    Number.isFinite(lng) &&
    lat >= -90 &&
    lat <= 90 &&
    lng >= -180 &&
    lng <= 180
    ? [lat, lng]
    : null;
};
const itemKind = (i: MapItem) =>
  i.kind === 'opportunity' || i.type === 'opportunity' ? 'opportunity' : 'request';
const itemTitle = (i: MapItem) => i.company_name || i.company || i.title || 'Onbekend bedrijf';
const safeLink = (i: MapItem, request?: (id: string) => void, company?: (id: string) => void) => {
  if (i.request_id) request?.(String(i.request_id));
  else if (itemKind(i) === 'request' && i.id) request?.(String(i.id));
  else if (i.company_id) company?.(String(i.company_id));
};

export default function MapView({ api, query = '', onOpenRequest, onOpenCompany }: Props) {
  const [data, setData] = useState<any>(null),
    [error, setError] = useState(''),
    [loading, setLoading] = useState(true),
    [tilesFailed, setTilesFailed] = useState(false);
  const [requests, setRequests] = useState(true),
    [opportunities, setOpportunities] = useState(true),
    [beneluxOnly, setBeneluxOnly] = useState(false);
  const [area, setArea] = useState<L.LatLngBounds | null>(null),
    [zoom, setZoom] = useState(7);
  const host = useRef<HTMLDivElement>(null),
    map = useRef<L.Map | null>(null),
    markers = useRef<L.LayerGroup | null>(null),
    tiles = useRef<L.TileLayer | null>(null);
  const callbacks = useRef({ onOpenRequest, onOpenCompany });
  callbacks.current = { onOpenRequest, onOpenCompany };
  const reload = useCallback(async () => {
    try {
      const result = await api<any>(`/api/map${query ? `?${query.replace(/^\?/, '')}` : ''}`);
      setData(result);
      setError('');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'De kaartgegevens konden niet worden geladen.');
    } finally {
      setLoading(false);
    }
  }, [api, query]);
  useEffect(() => {
    let alive = true;
    const run = async () => {
      if (alive) await reload();
    };
    void run();
    const timer = setInterval(run, 5000);
    return () => {
      alive = false;
      clearInterval(timer);
    };
  }, [reload]);
  useEffect(() => {
    if (!host.current || map.current) return;
    const instance = L.map(host.current, {
      center: [51.15, 4.9],
      zoom: 7,
      minZoom: 3,
      maxZoom: 18,
      scrollWheelZoom: false,
    });
    map.current = instance;
    markers.current = L.layerGroup().addTo(instance);
    instance.on('zoomend', () => setZoom(instance.getZoom()));
    const resize = new ResizeObserver(() => instance.invalidateSize());
    resize.observe(host.current);
    return () => {
      resize.disconnect();
      instance.remove();
      map.current = null;
      markers.current = null;
    };
  }, []);
  const provider = data?.provider;
  const tileUrl =
    provider && typeof provider === 'object' ? provider.tile_url || provider.url : null;
  const attribution = provider && typeof provider === 'object' ? provider.attribution || '' : '';
  useEffect(() => {
    if (!map.current) return;
    if (tiles.current) {
      tiles.current.remove();
      tiles.current = null;
    }
    setTilesFailed(false);
    if (typeof tileUrl === 'string' && /^https:\/\//.test(tileUrl)) {
      const layer = L.tileLayer(tileUrl, { attribution, maxZoom: 18, crossOrigin: true });
      layer.on('tileerror', () => setTilesFailed(true));
      layer.addTo(map.current);
      tiles.current = layer;
    }
  }, [tileUrl, attribution]);
  const all: MapItem[] = Array.isArray(data?.items) ? data.items : [];
  const located = useMemo(
    () =>
      all.filter((i) => {
        if (
          (itemKind(i) === 'request' && !requests) ||
          (itemKind(i) === 'opportunity' && !opportunities)
        )
          return false;
        if (beneluxOnly && i.country && !['BE', 'NL', 'LU'].includes(i.country)) return false;
        const c = coordinate(i);
        return c && (!area || area.contains(c));
      }),
    [all, requests, opportunities, area, beneluxOnly],
  );
  const missing =
    typeof data?.missing === 'number'
      ? data.missing
      : Array.isArray(data?.missing)
        ? data.missing.length
        : all.filter((i) => !coordinate(i)).length;
  useEffect(() => {
    const layer = markers.current,
      instance = map.current;
    if (!layer || !instance) return;
    layer.clearLayers();
    const groups = new Map<string, MapItem[]>();
    for (const item of located) {
      const c = coordinate(item)!;
      const point = instance.project(c, zoom);
      const key = `${Math.floor(point.x / 38)}:${Math.floor(point.y / 38)}`;
      groups.set(key, [...(groups.get(key) || []), item]);
    }
    groups.forEach((items) => {
      const center = items.reduce<[number, number]>(
        (v, i) => {
          const c = coordinate(i)!;
          return [v[0] + c[0] / items.length, v[1] + c[1] / items.length] as [number, number];
        },
        [0, 0] as [number, number],
      );
      const approximate = items.some((i) => (i.precision || i.location_precision) === 'postcode');
      const opportunity = items.every((i) => itemKind(i) === 'opportunity');
      const icon = L.divIcon({
        className: 'optimat-map-icon',
        html: `<span class="map-pin ${approximate ? 'map-pin-approx ' : ''}${opportunity ? 'map-pin-opportunity' : ''}">${items.length > 1 ? items.length : opportunity ? '€' : '•'}</span>`,
        iconSize: [36, 36],
        iconAnchor: [18, 18],
      });
      const marker = L.marker(center, {
        icon,
        title: `${items.length} dossier(s): ${itemTitle(items[0])}`,
        keyboard: true,
      }).addTo(layer);
      const popup = document.createElement('div');
      popup.className = 'optimat-map-popup';
      const heading = document.createElement('strong');
      heading.textContent =
        items.length > 1 ? `${items.length} dossiers in dit gebied` : itemTitle(items[0]);
      popup.appendChild(heading);
      for (const item of items.slice(0, 20)) {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'map-popup-action';
        button.textContent = `${itemTitle(item)} · ${itemKind(item) === 'opportunity' ? 'Verkoopkans' : 'Aanvraag'}`;
        button.addEventListener('click', () =>
          safeLink(item, callbacks.current.onOpenRequest, callbacks.current.onOpenCompany),
        );
        popup.appendChild(button);
        const detail = document.createElement('small');
        detail.textContent = [
          item.city,
          item.postcode,
          (item.precision || item.location_precision) === 'postcode'
            ? 'Benadering: postcodecentrum'
            : 'Adreslocatie',
        ]
          .filter(Boolean)
          .join(' · ');
        popup.appendChild(detail);
      }
      if (items.length > 1) {
        const closer = document.createElement('button');
        closer.type = 'button';
        closer.textContent = 'Inzoomen op deze dossiers';
        closer.className = 'map-popup-action';
        closer.addEventListener('click', () =>
          instance.fitBounds(L.latLngBounds(items.map((i) => coordinate(i)!)), {
            maxZoom: 16,
            padding: [30, 30],
          }),
        );
        popup.appendChild(closer);
      }
      marker.bindPopup(popup, { maxWidth: 320 });
    });
  }, [located, zoom]);
  return (
    <div className="stack map-view">
      <div className="section-heading">
        <div>
          <h2>Benelux-kaart</h2>
          <p className="muted">
            Aanvragen en verkoopkansen, met dezelfde filters als je overzicht.
          </p>
        </div>
        <button
          className="btn btn-secondary"
          onClick={() => void reload()}
          aria-label="Kaart verversen"
        >
          <RefreshCw size={16} />
          <span>Verversen</span>
        </button>
      </div>
      {error && (
        <div className="error" role="alert">
          {error} De laatst geladen gegevens blijven zichtbaar.
        </div>
      )}
      {!tileUrl && (
        <div className="notice">
          <AlertCircle size={18} />
          <span>
            Kaartachtergrond nog niet gekoppeld. De lijst en beschikbare coördinaten blijven
            bruikbaar. Er worden geen locaties geschat.
          </span>
        </div>
      )}
      {tilesFailed && (
        <div className="notice" role="status">
          <AlertCircle size={18} />
          De kaartprovider is tijdelijk niet bereikbaar. Gebruik de dossiers naast de kaart.
        </div>
      )}
      <div className="card map-toolbar">
        <div className="row" style={{ flexWrap: 'wrap', gap: 18 }}>
          <label>
            <input
              type="checkbox"
              checked={requests}
              onChange={(e) => setRequests(e.target.checked)}
            />{' '}
            Aanvragen
          </label>
          <label>
            <input
              type="checkbox"
              checked={opportunities}
              onChange={(e) => setOpportunities(e.target.checked)}
            />{' '}
            Verkoopkansen
          </label>
          <label>
            <input
              type="checkbox"
              checked={beneluxOnly}
              onChange={(e) => setBeneluxOnly(e.target.checked)}
            />{' '}
            Alleen Benelux
          </label>
        </div>
        <div className="row">
          <span className="badge">{located.length} met locatie</span>
          <span className="badge">{missing} locatie ontbreekt</span>
        </div>
      </div>
      <div className="optimat-map-grid">
        <section className="card map-surface" aria-label="Kaart van België, Nederland en Luxemburg">
          <div ref={host} className="optimat-map-canvas" />
          <div className="map-controls">
            <button
              className="btn btn-secondary btn-small"
              onClick={() =>
                map.current?.fitBounds([
                  [49.4, 2.5],
                  [53.6, 7.25],
                ])
              }
            >
              <LocateFixed size={15} />
              Benelux
            </button>
            <button
              className="btn btn-secondary btn-small"
              onClick={() => setArea(map.current?.getBounds() || null)}
            >
              <Search size={15} />
              Zoeken in dit gebied
            </button>
            {area && (
              <button className="btn btn-secondary btn-small" onClick={() => setArea(null)}>
                <X size={15} />
                Gebiedsfilter wissen
              </button>
            )}
          </div>
          <div className="map-legend">
            <span>
              <i className="legend-dot" />
              Aanvraag
            </span>
            <span>
              <i className="legend-dot opportunity" />
              Verkoopkans
            </span>
            <span>
              <i className="legend-dot approximate" />
              Postcodebenadering
            </span>
          </div>
        </section>
        <aside className="card map-list" aria-label="Dossiers op de kaart">
          <div className="section-heading">
            <h3>Dossiers in beeld</h3>
            <span className="muted">{located.length}</span>
          </div>
          {loading ? (
            <p className="muted">Locaties laden…</p>
          ) : located.length === 0 ? (
            <div className="empty">
              <MapPinned size={28} />
              <h3>Nog geen locaties</h3>
              <p>
                Een geverifieerd adres of postcodecentrum verschijnt hier zodra het beschikbaar is.
              </p>
            </div>
          ) : (
            <div className="stack">
              {located.map((i, index) => (
                <button
                  key={`${itemKind(i)}-${i.id || i.request_id}-${index}`}
                  className="map-list-item"
                  onClick={() => safeLink(i, onOpenRequest, onOpenCompany)}
                >
                  <strong>{itemTitle(i)}</strong>
                  <span>
                    {[i.postcode, i.city, i.country].filter(Boolean).join(' ') ||
                      'Locatie beschikbaar'}
                  </span>
                  <small>
                    {itemKind(i) === 'opportunity' ? 'Verkoopkans' : 'Aanvraag'} ·{' '}
                    {(i.precision || i.location_precision) === 'postcode'
                      ? 'Postcodecentrum (benadering)'
                      : 'Adreslocatie'}
                  </small>
                </button>
              ))}
            </div>
          )}
          {missing > 0 && (
            <p className="muted map-missing">
              {missing} dossier(s) zonder locatie staan in het aanvragenoverzicht. Ze krijgen geen
              willekeurige marker.
            </p>
          )}
        </aside>
      </div>
      <style>{`.optimat-map-grid{display:grid;grid-template-columns:minmax(0,1fr) 320px;gap:20px}.map-toolbar{display:flex;justify-content:space-between;gap:16px;flex-wrap:wrap}.map-toolbar label{display:flex;gap:8px;align-items:center;font-size:13px}.map-surface{padding:0!important;overflow:hidden}.optimat-map-canvas{height:490px;background:#e9eeef;z-index:0}.map-controls{display:flex;gap:8px;flex-wrap:wrap;padding:12px;border-top:1px solid #edf0f3}.map-legend{display:flex;gap:16px;flex-wrap:wrap;padding:4px 14px 14px;font-size:11px;color:#626d7e}.map-legend span{display:flex;align-items:center;gap:6px}.legend-dot{width:10px;height:10px;display:inline-block;border-radius:50%;background:#131830}.legend-dot.opportunity{background:#60852f}.legend-dot.approximate{background:white;border:2px dashed #131830}.map-pin{width:34px;height:34px;display:grid;place-items:center;border-radius:50%;background:#131830;color:#fff;border:3px solid #fff;box-shadow:0 2px 9px #13183030;font:700 13px system-ui}.map-pin-opportunity{background:#60852f}.map-pin-approx{border-style:dashed}.map-list{max-height:620px;overflow:auto}.map-list-item{padding:13px;text-align:left;display:flex;flex-direction:column;gap:5px;background:#fff;border:1px solid #e8ecf1;border-radius:9px;cursor:pointer;color:#131830;min-width:0;overflow-wrap:anywhere}.map-list-item:hover{border-color:#a8bd6e;background:#fafcf7}.map-list-item span{font-size:12px;color:#637084}.map-list-item small{font-size:11px;color:#7a8597}.map-missing{border-top:1px solid #edf0f3;margin-top:20px;padding-top:15px;font-size:12px}.map-popup-action{display:block;border:0;background:#f5f7f9;color:#131830;padding:8px;margin:7px 0;cursor:pointer;text-align:left;width:100%;border-radius:4px}.optimat-map-popup small{color:#687586;display:block}.optimat-map-popup{font:12px system-ui}.map-controls .btn{font-size:11px}@media(max-width:1000px){.optimat-map-grid{grid-template-columns:1fr}.map-list{max-height:none}.optimat-map-canvas{height:370px}}@media(max-width:500px){.optimat-map-canvas{height:320px}.map-toolbar{padding:14px}.map-legend{gap:10px}}`}</style>
    </div>
  );
}
