# OPTIMAT Sales Hub

Nederlandstalige marketing- en salesapp voor OPTIMAT Group. Formulieraanvragen, bedrijven, contactpersonen, vestigingen, verkoopkansen, taken en activiteiten worden afzonderlijk opgeslagen. Een herhaalde download is een nieuwe aanvraag; een herlevering van hetzelfde event is dat niet. Een brochureaanvraag maakt geen automatische verkoopkans.

De applicatie gebruikt **Node.js 24+, TypeScript, Express, React/Vite en SQLite**. SQLite draait op één host met een persistent lokaal volume; voor meerdere applicatiereplica’s is eerst een database-/wachtrijmigratie nodig. Er is geen afhankelijkheid van Resatec-hosting, ChatGPT-aanmelding of browser-localStorage als CRM-database.

## Lokaal installeren

```bash
npm ci
npm run db:migrate
npm run sources:init
npm run build
```

Maak de eerste beheerder aan met `npm run bootstrap`. De vereiste variabelen staan in `.env.example`; stel het beheerderswachtwoord in via een beveiligde shell/secret manager. Plaats nooit echte wachtwoorden of inzendingen in de repository. Het bootstrapcommando is geen aanmeldbypass en maakt geen fictieve leads aan.

```bash
npm run dev
```

De ontwikkelopdracht start de API op poort 3000 en Vite op poort 5173; open tijdens ontwikkeling de Vite-app. Beide processen worden samen gestart en gestopt. Voor een productiebuild gebruik je `npm run build` en vervolgens `npm start`; de server levert de gebouwde frontend en API. Productie vereist HTTPS, de juiste `APP_URL`, een persistent databasevolume, backups en persoonlijke accounts. Een lege database toont lege toestanden, geen verzonnen verkoopcijfers.

## Werken in de app

Een beheerder nodigt persoonlijke accounts uit en kan hun toegang intrekken. De eerste versie ondersteunt verkopers, salesmanagers, marketing/management en beheerders. Uitnodigingslinks worden eenmalig getoond om via een beveiligd kanaal te delen; zonder gekoppelde maildienst wordt geen uitnodigingsmail geclaimd.

Salesmanagers beheren intake en toewijzing. Verkopers registreren contactacties, notities en taken op hun eigen aanvragen en houden echte verkoopkansen in een afzonderlijke pipeline bij. Management raadpleegt rapporten en exports. Rollen worden op de API gecontroleerd, inclusief kaartdata en exports.

Bronnen en formuliermapping worden in Instellingen beheerd. Een connectorbron verwijst naar de **naam** van een servergeheim. Het geheim zelf blijft buiten de databaseconfiguratie, browser en Git-repository. Nieuwe zakelijke formuliervelden blijven zichtbaar; CAPTCHA- en authenticatievelden worden niet als leadgegevens overgenomen.

## WordPress en andere externe diensten

De plugin in [`wordpress/optimat-sales-hub`](wordpress/optimat-sales-hub) levert een lokale outbox en ondertekende aflevering. Installatie en adapters staan in [de WordPress-handleiding](docs/WORDPRESS.md). De plugin is broncode voor installatie door een bevoegde WordPress-beheerder; deze repositorywijziging installeert niets op de websites. De Gravity Forms-uitbreiding voegt ondertekende formulierinventarisatie, gecontroleerde mapping, herstel uit opgeslagen bronentries en begrensde private bestandsoverdracht toe. Gebruik daarvoor [de Gravity Forms-handleiding](docs/GRAVITY-FORMS.md); andere providers hebben niet automatisch dezelfde dekking.

De openbare OPTIMAT-pagina’s waren tijdens onderzoek vanuit deze cloudomgeving geblokkeerd door het netwerkbeleid. De gebruiker heeft daarna bevestigd dat beide websites Gravity Forms gebruiken. De werkelijk geïnstalleerde versies, formulier-ID’s, veldstructuren en taalvarianten zijn nog niet via WordPress-toegang vastgesteld. Contracttests bewijzen de ontvanger, niet een live koppeling met beide websites. Alleen een echte testinzending uit een geïnstalleerde bron kan de status “live getest” rechtvaardigen.

KBO-prospectie is aanvullend. De serveradapter voor naam-/nummerzoeken staat standaard uit. Activeren vereist expliciet `KBO_ENABLED=true`, `KBO_TERMS_CONFIRMED=true` en afzonderlijke `BCE_WS_USERNAME`/`BCE_WS_PASSWORD` via de hostingomgeving. Regio-, postcode- en activiteitzoekopdrachten zijn nog niet als providerfunctionaliteit geïmplementeerd: de API weigert die onbewezen filters expliciet. Het NACE-BEL-register bewaart beheerde codes met versienummer, maar vormt geen complete of geverifieerde doelgroep. Zonder geverifieerde providerrechten, actuele hergebruikvoorwaarden en servercredentials blijft de module “nog niet gekoppeld”. Natuurlijke personen mogen niet automatisch in een KBO-prospectieselectie terechtkomen. Vrijwillige websiteaanvragen van zelfstandigen blijven wel geldig. NL/LU hebben geen toegezegde externe databron. De relevante Resatec-patronen zijn onderzocht; accounts, retailfilters en externe iframe-app zijn niet overgenomen.

Kaarttegels, geocodering en e-mail hebben elk een eigen configuratie en leverancier nodig. Kaarttegels gebruiken `MAP_TILE_URL` en `MAP_TILE_ATTRIBUTION`; de servergeocoder verwacht een goedgekeurde Photon-compatibele HTTPS-`GEOCODING_URL` en expliciet `GEOCODING_TERMS_CONFIRMED=true`. Zonder die bevestiging doet de geocoder geen externe adresaanvragen. Ontbrekende locaties krijgen geen fictieve coördinaten. De lijst blijft bruikbaar als een kaartprovider niet beschikbaar is.

## Controles

```bash
npm run typecheck
npm test
npm run build
npm run test:e2e
```

De integratietests gebruiken een tijdelijke SQLite-database en een echte lokale HTTP-server. Zij installeren niets op WordPress en gebruiken geen productiegegevens. Voor browserchecks zijn de Playwright-browserbestanden nodig (`npx playwright install chromium`). Een reeds geïnstalleerde Chromium kan met `PLAYWRIGHT_CHROMIUM_EXECUTABLE=/usr/bin/chromium npm run test:e2e` worden gebruikt. De browserrunner bouwt de app en start een afzonderlijke in-memory testserver met uitsluitend fictieve gegevens. Zie [acceptatie en dekkingsgrenzen](docs/ACCEPTANCE.md). Een onuitgevoerde browser- of livebroncheck is geen geslaagde check.

## Beheer en oplevering

- [Hosting en HTTPS inrichten](docs/HOSTING.md)
- [Beheer, backups en herstel](docs/OPERATIONS.md)
- [KPI-definities](docs/KPI-DEFINITIONS.md)
- [Gravity Forms op OPTIMAT Group en KDT aansluiten](docs/GRAVITY-FORMS.md)
- [WordPress-installatie en levering](docs/WORDPRESS.md)
- [Acceptatiescenario’s en externe blokkades](docs/ACCEPTANCE.md)

Belangrijkste nog te leveren toegang voor ingebruikname: bevoegde WordPress-/formulierproviderbeheerders op beide websites, productiehosting met HTTPS en persistent volume, een goedgekeurde kaart-/geocodingprovider en desgewenst mail- en KBO-providerrechten. De applicatie vraagt geen Resatec-credentials.
