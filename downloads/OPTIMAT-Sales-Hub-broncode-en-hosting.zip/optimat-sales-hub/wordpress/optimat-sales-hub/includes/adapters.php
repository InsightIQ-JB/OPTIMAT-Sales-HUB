<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Conditional adapters; installation does not establish the plugins are used by OPTIMAT.
 * All forms require an explicit provider:form_id rule before any business data is copied.
 */
final class Optimat_Hub_Adapters {
    public static function boot(): void {
        add_action('wpcf7_submit', static function ($form, $result): void { self::protect(static function () use ($form, $result): void { self::cf7($form, (array) $result); }); }, 20, 2);
        add_action('elementor_pro/forms/new_record', static function ($record, $handler): void { self::protect(static function () use ($record, $handler): void { self::elementor($record, $handler); }); }, 20, 2);
    }

    private static function protect(callable $callback): void {
        try { $callback(); } catch (Throwable $error) {
            update_option('optimat_hub_last_capture_error', ['at' => gmdate('c'), 'code' => 'adapter_failed'], false);
            // Never let a connector integration error alter the successful visitor submission.
        }
    }

    private static function context(): array {
        $context = [];
        // Query-string-free product page is useful provenance; never copy arbitrary request metadata.
        $referrer = wp_get_referer();
        if ($referrer) {
            $parts = wp_parse_url($referrer);
            if ($parts && isset($parts['scheme'], $parts['host']) && in_array($parts['scheme'], ['http','https'], true)) {
                $context['product_url'] = $parts['scheme'] . '://' . $parts['host'] . ($parts['path'] ?? '/');
            }
        }
        return $context;
    }

    public static function cf7($form, array $result): void {
        if (($result['status'] ?? '') !== 'mail_sent' || !class_exists('WPCF7_Submission')) { return; }
        $submission = WPCF7_Submission::get_instance();
        if (!$submission) { return; }
        $data = (array) $submission->get_posted_data();
        $fields = [];
        foreach ($form->scan_form_tags() as $tag) {
            $name = (string) $tag->name;
            if ($name === '' || !array_key_exists($name, $data)) { continue; }
            $fields[] = ['id' => $name, 'label' => $name, 'type' => (string) $tag->basetype, 'value' => $data[$name], 'options' => (array) ($tag->values ?? [])];
        }
        // CF7 itself does not guarantee stored submission IDs. The connector persists this generated ID.
        static $captured = [];
        $form_id = (string) $form->id();
        if (isset($captured[$form_id])) { return; }
        $captured[$form_id] = true;
        Optimat_Hub::capture([
            'provider' => 'cf7', 'form_id' => $form_id, 'form_name' => (string) $form->title(),
            'submission_id' => wp_generate_uuid4(), 'fields' => $fields, 'context' => self::context(),
        ]);
    }

    public static function elementor($record, $handler): void {
        $settings = (array) $record->get('form_settings');
        $form_id = (string) ($settings['id'] ?? '');
        // Widget ID is required; do not fall back to a mutable human name as identity.
        if ($form_id === '' && isset($_POST['form_id'])) { $form_id = sanitize_text_field((string) wp_unslash($_POST['form_id'])); }
        if ($form_id === '') { return; }
        $fields = [];
        foreach ((array) $record->get('fields') as $key => $field) {
            if (!is_array($field)) { continue; }
            $fields[] = [
                'id' => (string) ($field['id'] ?? $key), 'label' => (string) ($field['title'] ?? $field['id'] ?? $key),
                'type' => (string) ($field['type'] ?? 'text'),
                'value' => $field['raw_value'] ?? $field['value'] ?? null,
                'options' => (array) ($field['options'] ?? []),
            ];
        }
        static $captured = [];
        if (isset($captured[$form_id])) { return; }
        $captured[$form_id] = true;
        Optimat_Hub::capture([
            'provider' => 'elementor', 'form_id' => $form_id,
            'form_name' => (string) ($settings['form_name'] ?? $form_id),
            'submission_id' => wp_generate_uuid4(), 'fields' => $fields, 'context' => self::context(),
        ]);
    }

    public static function gravity(array $entry, array $form): void { Optimat_Hub_Gravity::capture($entry, $form); }
    public static function gravity_update(array $form, int $entry_id, array $original_entry = []): void { Optimat_Hub_Gravity::reload($entry_id, $form); }
}
