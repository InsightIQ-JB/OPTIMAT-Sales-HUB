<?php
if (!defined('ABSPATH')) { exit; }

/** Private, durable media delivery for explicitly allowlisted commercial Gravity Forms fields. */
final class Optimat_Hub_Gravity_Attachments {
    const MAX_BYTES = 5242880;
    const MAX_ATTEMPTS = 12;
    const LEASE_SECONDS = 120;
    public static function table(): string { global $wpdb; return $wpdb->prefix . 'optimat_media_outbox'; }
    public static function boot(): void {
        add_action('optimat_hub_after_gravity_capture', [self::class, 'capture'], 10, 3);
        add_action('optimat_hub_cleanup', [self::class, 'cleanup']);
        add_action('admin_menu', [self::class, 'admin_menu']);
        add_action('admin_post_optimat_hub_media_replay', [self::class, 'replay']);
    }
    public static function activate(): void {
        global $wpdb; require_once ABSPATH . 'wp-admin/includes/upgrade.php'; $table=self::table(); $charset=$wpdb->get_charset_collate();
        dbDelta("CREATE TABLE $table (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            identity_hash char(64) NOT NULL,
            event_id varchar(36) NOT NULL,
            source_id varchar(100) NOT NULL,
            form_id varchar(191) NOT NULL,
            submission_id varchar(200) NOT NULL,
            field_id varchar(100) NOT NULL,
            attachment_key varchar(200) NOT NULL,
            local_path text NOT NULL,
            original_name varchar(200) NOT NULL,
            mime varchar(100) NOT NULL,
            content_sha256 char(64) NOT NULL,
            size_bytes int unsigned NOT NULL DEFAULT 0,
            status varchar(20) NOT NULL DEFAULT 'pending',
            attempts int unsigned NOT NULL DEFAULT 0,
            available_at datetime NOT NULL,
            locked_until datetime DEFAULT NULL,
            created_at datetime NOT NULL,
            delivered_at datetime DEFAULT NULL,
            last_http_status smallint DEFAULT NULL,
            error_code varchar(64) DEFAULT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY identity_hash (identity_hash),
            UNIQUE KEY event_id (event_id),
            KEY due_events (status,available_at)
        ) ENGINE=InnoDB $charset;");
    }
    private static function enabled_rule(string $form_id): ?array {
        $rule=(array) (Optimat_Hub::config()['forms']['gravity:'.$form_id]??[]);
        return !empty($rule['enabled'])&&($rule['purpose']??'commercial')==='commercial' ? $rule : null;
    }
    private static function field_value($field,string $key,$default=null) { return is_array($field)?($field[$key]??$default):($field->$key??$default); }
    private static function uploads(): array { $uploads=wp_upload_dir(); return !empty($uploads['error'])?[]:$uploads; }
    private static function within(string $path,string $root): bool { $root=rtrim(str_replace('\\','/',$root),'/'); $path=str_replace('\\','/',$path); return $path!==$root && strpos($path,$root.'/')===0; }
    /** Resolve stored URLs only to real files under local WordPress/GF uploads. Never fetch an upload URL. */
    public static function resolve_local_url(string $url,string $form_id): ?string {
        $uploads=self::uploads(); $base=isset($uploads['basedir'])?realpath((string)$uploads['basedir']):false;
        if (!$base) { return null; }
        $roots=[];
        if (class_exists('GFFormsModel')&&method_exists('GFFormsModel','get_upload_path')&&method_exists('GFFormsModel','get_upload_url')) {
            $gf_path=realpath((string)GFFormsModel::get_upload_path((int)$form_id));
            if ($gf_path&&($gf_path===$base||self::within($gf_path,$base))) { $roots[]=['path'=>$gf_path,'url'=>(string)GFFormsModel::get_upload_url((int)$form_id)]; }
        }
        // Multisite/custom GF roots are accepted only inside this site's verified local upload directory.
        if (isset($uploads['baseurl'])) { $roots[]=['path'=>$base,'url'=>(string)$uploads['baseurl']]; }
        $parts=wp_parse_url($url); if (!is_array($parts)||!isset($parts['scheme'],$parts['host'],$parts['path'])||!in_array(strtolower($parts['scheme']),['https','http'],true)||isset($parts['user'])||isset($parts['pass'])) { return null; }
        foreach ($roots as $root) {
            $prefix=wp_parse_url($root['url']); if (!is_array($prefix)||strtolower($parts['host'])!==strtolower((string)($prefix['host']??''))||($parts['port']??null)!==($prefix['port']??null)) { continue; }
            $base_path=rtrim(rawurldecode((string)($prefix['path']??'')),'/').'/'; $path=rawurldecode($parts['path']);
            if (strpos($path,$base_path)!==0||strpos($path,"\0")!==false) { continue; }
            $relative=substr($path,strlen($base_path));
            if ($relative===''||preg_match('~(^|[/\\\\])\.\.([/\\\\]|$)~',$relative)) { continue; }
            $candidate=realpath($root['path'].DIRECTORY_SEPARATOR.$relative);
            if ($candidate&&self::within($candidate,$root['path'])&&self::within($candidate,$base)&&is_file($candidate)&&is_readable($candidate)) { return $candidate; }
        }
        return null;
    }
    private static function read_file(string $path): ?string {
        $handle=@fopen($path,'rb'); if (!$handle) { return null; }
        $bytes=stream_get_contents($handle,self::MAX_BYTES+1); fclose($handle);
        return is_string($bytes)&&strlen($bytes)>0&&strlen($bytes)<=self::MAX_BYTES?$bytes:null;
    }
    public static function detect_mime(string $bytes): ?string {
        if (substr($bytes,0,5)==='%PDF-') { return 'application/pdf'; }
        if (substr($bytes,0,8)==="\x89PNG\r\n\x1a\n") { return 'image/png'; }
        if (substr($bytes,0,3)==="\xff\xd8\xff") { return 'image/jpeg'; }
        return null;
    }
    /** Called after durable lead capture, including unchanged entries during reconciliation. No remote I/O. */
    public static function capture(array $form,array $entry,$result=null): void {
        global $wpdb;
        try {
            $form_id=(string)($form['id']??''); $entry_id=(string)($entry['id']??''); $rule=self::enabled_rule($form_id); $config=Optimat_Hub::config();
            if (!$rule||$entry_id===''||empty($config['source_id'])||isset($entry['status'])&&$entry['status']!=='active') { return; }
            $allow=array_map('strval',(array)($rule['attachments']??[])); if (!$allow) { return; }
            foreach ((array)($form['fields']??[]) as $field) {
                $field_id=(string)self::field_value($field,'id',''); $type=is_object($field)&&method_exists($field,'get_input_type')?$field->get_input_type():self::field_value($field,'type','');
                if ($type!=='fileupload'||!in_array($field_id,$allow,true)) { continue; }
                $value=$entry[$field_id]??''; if ($value===''||$value===null) { continue; }
                if (is_string($value)&&substr(ltrim($value),0,1)==='[') { $decoded=json_decode($value,true); $urls=is_array($decoded)?$decoded:[$value]; } else { $urls=is_array($value)?$value:[$value]; }
                foreach ($urls as $url) {
                    if (!is_string($url)||$url==='') { continue; }
                    $path=self::resolve_local_url($url,$form_id); $error=null; $bytes=''; $mime='';
                    if (!$path) { $error='local_file_unavailable'; }
                    elseif (($size=@filesize($path))===false||$size<1||$size>self::MAX_BYTES) { $error='file_size_not_allowed'; }
                    else { $read=self::read_file($path); if ($read===null) { $error='local_file_unavailable'; } else { $bytes=$read; $mime=self::detect_mime($bytes)??''; if (!$mime) { $error='file_type_not_allowed'; } } }
                    $checksum=$error?hash('sha256',$url):hash('sha256',$bytes); $attachment_key=$field_id.':'.$checksum;
                    $identity=hash('sha256',wp_json_encode([$config['source_id'],$form_id,$entry_id,$attachment_key]));
                    if ($wpdb->get_var($wpdb->prepare('SELECT id FROM '.self::table().' WHERE identity_hash=%s',$identity))) { continue; }
                    $name=$path?basename($path):'bijlage'; $name=sanitize_file_name($name); if ($name===''||strlen($name)>200) { $name='bijlage'; }
                    $stored=$wpdb->insert(self::table(),['identity_hash'=>$identity,'event_id'=>wp_generate_uuid4(),'source_id'=>$config['source_id'],'form_id'=>$form_id,'submission_id'=>$entry_id,'field_id'=>$field_id,'attachment_key'=>$attachment_key,'local_path'=>$path?:'','original_name'=>$name,'mime'=>$mime,'content_sha256'=>$checksum,'size_bytes'=>$error?0:strlen($bytes),'status'=>$error?'failed':'pending','attempts'=>0,'available_at'=>gmdate('Y-m-d H:i:s'),'created_at'=>gmdate('Y-m-d H:i:s'),'error_code'=>$error]);
                    if ($stored===false) { update_option('optimat_hub_media_capture_status',['at'=>gmdate('c'),'code'=>'local_storage_failed'],false); }
                    elseif ($error) { update_option('optimat_hub_media_capture_status',['at'=>gmdate('c'),'code'=>$error],false); }
                }
            }
        } catch (Throwable $error) { update_option('optimat_hub_media_capture_status',['at'=>gmdate('c'),'code'=>'media_capture_failed'],false); }
    }
    private static function private_path(string $path): bool {
        $uploads=self::uploads(); $base=isset($uploads['basedir'])?realpath((string)$uploads['basedir']):false; $actual=realpath($path);
        return $base&&$actual&&self::within($actual,$base)&&is_file($actual)&&is_readable($actual);
    }
    public static function dispatch(int $limit=10): void {
        global $wpdb; $config=Optimat_Hub::config(); $base=rtrim((string)($config['base_url']??''),'/'); $secret=Optimat_Hub::secret(); $table=self::table();
        if ($secret===''||empty($config['source_id'])||!wp_http_validate_url($base)||strtolower((string)wp_parse_url($base,PHP_URL_SCHEME))!=='https') { update_option('optimat_hub_media_worker_status',['at'=>gmdate('c'),'code'=>'not_configured'],false); return; }
        $rows=$wpdb->get_results($wpdb->prepare("SELECT id FROM $table WHERE (status='pending' AND available_at<=UTC_TIMESTAMP()) OR (status='sending' AND locked_until<UTC_TIMESTAMP()) ORDER BY id LIMIT %d",max(1,min(50,$limit))),ARRAY_A);
        foreach ($rows as $row) {
            $lease=$wpdb->query($wpdb->prepare("UPDATE $table SET status='sending',locked_until=DATE_ADD(UTC_TIMESTAMP(),INTERVAL %d SECOND),attempts=attempts+1 WHERE id=%d AND ((status='pending' AND available_at<=UTC_TIMESTAMP()) OR (status='sending' AND locked_until<UTC_TIMESTAMP()))",self::LEASE_SECONDS,$row['id']));
            if ($lease!==1) { continue; } $event=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id=%d",$row['id']),ARRAY_A); if (!$event) { continue; }
            $local_error=null;
            if ((int)$event['attempts']>self::MAX_ATTEMPTS) { $local_error='attempt_limit'; }
            elseif (!self::enabled_rule((string)$event['form_id'])||!in_array((string)$event['field_id'],array_map('strval',(array)(self::enabled_rule((string)$event['form_id'])['attachments']??[])),true)) { $local_error='form_or_field_disabled'; }
            elseif (!self::private_path((string)$event['local_path'])) { $local_error='local_file_unavailable'; }
            elseif (($size=@filesize($event['local_path']))===false||$size<1||$size>self::MAX_BYTES) { $local_error='file_size_not_allowed'; }
            $read=$local_error?'':self::read_file((string)$event['local_path']); if (!$local_error&&$read===null) { $local_error='local_file_unavailable'; } $bytes=$read??'';
            if (!$local_error&&(!hash_equals((string)$event['content_sha256'],hash('sha256',$bytes))||self::detect_mime($bytes)!==$event['mime'])) { $local_error='local_file_changed'; }
            if ($local_error) { $wpdb->update($table,['status'=>'failed','locked_until'=>null,'error_code'=>$local_error],['id'=>$event['id']]); continue; }
            $payload=wp_json_encode(['event_id'=>$event['event_id'],'provider'=>'gravity','form_id'=>$event['form_id'],'submission_id'=>$event['submission_id'],'attachment_key'=>$event['attachment_key'],'name'=>$event['original_name'],'mime'=>$event['mime'],'content_base64'=>base64_encode($bytes)],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
            $timestamp=(string)time(); $signature=hash_hmac('sha256',$timestamp.'.'.$payload,$secret);
            $response=wp_remote_post($base.'/api/connectors/'.rawurlencode($event['source_id']).'/attachments',['timeout'=>15,'redirection'=>0,'sslverify'=>true,'headers'=>['Content-Type'=>'application/json','X-Optimat-Timestamp'=>$timestamp,'X-Optimat-Signature'=>$signature],'body'=>$payload,'limit_response_size'=>4096]);
            $status=is_wp_error($response)?0:(int)wp_remote_retrieve_response_code($response); $receipt=is_wp_error($response)?null:json_decode((string)wp_remote_retrieve_body($response),true);
            $ack=$status===202&&is_array($receipt)&&($receipt['accepted']??false)===true&&($receipt['event_id']??'')===$event['event_id'];
            if ($ack) { $ignored=strpos((string)($receipt['status']??''),'ignored_')===0; $wpdb->update($table,['status'=>$ignored?'ignored':'delivered','delivered_at'=>gmdate('Y-m-d H:i:s'),'locked_until'=>null,'last_http_status'=>$status,'error_code'=>$ignored?($receipt['status']??'ignored'):null],['id'=>$event['id']]); }
            else { $permanent=in_array($status,[400,413,415],true)||is_array($receipt)&&($receipt['retryable']??null)===false; $attempts=(int)$event['attempts']; $delay=min(21600,5*(2**min($attempts,12)))+wp_rand(0,5); $wpdb->update($table,['status'=>$permanent||$attempts>=self::MAX_ATTEMPTS?'failed':'pending','available_at'=>gmdate('Y-m-d H:i:s',time()+$delay),'locked_until'=>null,'last_http_status'=>$status?:null,'error_code'=>$status===202?'invalid_receipt':($status?'http_'.$status:'transport_error')],['id'=>$event['id']]); }
        }
        update_option('optimat_hub_media_worker_status',['at'=>gmdate('c'),'code'=>'ran'],false);
    }
    public static function cleanup(): void { global $wpdb; $days=max(1,min(365,(int)(Optimat_Hub::config()['retention_days']??30))); $wpdb->query($wpdb->prepare('DELETE FROM '.self::table()." WHERE status IN ('delivered','ignored') AND delivered_at<DATE_SUB(UTC_TIMESTAMP(),INTERVAL %d DAY)",$days)); }
    public static function admin_menu(): void { add_submenu_page('options-general.php','OPTIMAT private bijlagen','OPTIMAT-bijlagen','manage_options','optimat-hub-media',[self::class,'admin_page']); }
    public static function admin_page(): void {
        if (!current_user_can('manage_options')) { return; } global $wpdb; $counts=$wpdb->get_results('SELECT status,COUNT(*) AS total FROM '.self::table().' GROUP BY status',ARRAY_A); $events=$wpdb->get_results('SELECT id,event_id,form_id,field_id,status,attempts,error_code,last_http_status FROM '.self::table().' ORDER BY id DESC LIMIT 100',ARRAY_A);
        echo '<div class="wrap"><h1>OPTIMAT private Gravity Forms-bijlagen</h1><p>Alleen expliciet vrijgegeven uploadvelden van commerciële formulieren. PDF, PNG en JPEG tot 5 MB. Geen openbare bestandslinks worden naar CRM verstuurd. Bronbestanden blijven onder de WordPress-bewaarprocedure vallen.</p>';
        foreach ($counts as $count) { echo '<p>'.esc_html($count['status']).': '.esc_html($count['total']).'</p>'; }
        $last=get_option('optimat_hub_media_capture_status'); if ($last) { echo '<p>Laatste vastlegstatus: '.esc_html((string)$last['code']).' · '.esc_html((string)$last['at']).'</p>'; }
        echo '<table class="widefat"><thead><tr><th>Event</th><th>Formulier / veld</th><th>Status</th><th>Pogingen</th><th>Diagnose</th><th>Herstel</th></tr></thead><tbody>';
        foreach ($events as $event) { echo '<tr><td>'.esc_html($event['event_id']).'</td><td>'.esc_html($event['form_id'].' / '.$event['field_id']).'</td><td>'.esc_html($event['status']).'</td><td>'.esc_html($event['attempts']).'</td><td>'.esc_html((string)$event['error_code']).'</td><td>'; if (in_array($event['status'],['failed','pending'],true)) { echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="optimat_hub_media_replay"><input type="hidden" name="id" value="'.esc_attr((string)$event['id']).'">'; wp_nonce_field('optimat_hub_media_replay_'.$event['id']); submit_button('Opnieuw aanbieden','secondary','submit',false); echo '</form>'; } echo '</td></tr>'; }
        echo '</tbody></table><p>Bij ontoegankelijke of externe uploadopslag: herstel de lokale bronbestanden of voer opnieuw reconciliatie uit. De aanvraag zelf blijft beschikbaar.</p></div>';
    }
    public static function replay(): void {
        if (!current_user_can('manage_options')) { wp_die('Geen toegang.','',['response'=>403]); } $id=absint($_POST['id']??0); check_admin_referer('optimat_hub_media_replay_'.$id); global $wpdb;
        $wpdb->update(self::table(),['status'=>'pending','attempts'=>0,'available_at'=>gmdate('Y-m-d H:i:s'),'locked_until'=>null,'error_code'=>null],['id'=>$id]); Optimat_Hub::kick(); wp_safe_redirect(admin_url('options-general.php?page=optimat-hub-media')); exit;
    }
}
