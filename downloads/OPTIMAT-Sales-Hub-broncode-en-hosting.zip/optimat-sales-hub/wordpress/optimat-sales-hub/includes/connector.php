<?php
if (!defined('ABSPATH')) { exit; }

final class Optimat_Hub {
    const VERSION = '0.2.1';
    const MAX_ATTEMPTS = 12;
    const LEASE_SECONDS = 120;

    public static function table(): string { global $wpdb; return $wpdb->prefix . 'optimat_outbox'; }
    public static function submissions_table(): string { global $wpdb; return $wpdb->prefix . 'optimat_submissions'; }
    public static function config(): array { return (array) get_option('optimat_hub_config', []); }
    public static function secret(): string {
        return defined('OPTIMAT_HUB_SECRET') ? (string) OPTIMAT_HUB_SECRET : (string) getenv('OPTIMAT_HUB_SECRET');
    }

    public static function activate(): void {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $outbox = self::table(); $submissions = self::submissions_table();
        dbDelta("CREATE TABLE $outbox (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            event_id varchar(36) NOT NULL,
            source_id varchar(100) NOT NULL,
            provider varchar(100) NOT NULL,
            form_id varchar(191) NOT NULL,
            submission_id varchar(200) NOT NULL,
            payload longtext NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'pending',
            attempts int unsigned NOT NULL DEFAULT 0,
            available_at datetime NOT NULL,
            locked_until datetime DEFAULT NULL,
            created_at datetime NOT NULL,
            delivered_at datetime DEFAULT NULL,
            last_http_status smallint DEFAULT NULL,
            error_code varchar(64) DEFAULT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY event_id (event_id),
            KEY due_events (status,available_at)
        ) ENGINE=InnoDB $charset;");
        dbDelta("CREATE TABLE $submissions (
            identity_hash char(64) NOT NULL,
            submission_id varchar(200) NOT NULL,
            source_version int unsigned NOT NULL DEFAULT 1,
            payload_hash char(64) NOT NULL,
            submitted_at varchar(32) NOT NULL,
            source_updated_at varchar(32) DEFAULT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (identity_hash)
        ) ENGINE=InnoDB $charset;");
        if (!get_option('optimat_hub_dispatch_token')) {
            add_option('optimat_hub_dispatch_token', wp_generate_password(64, false, false), '', false);
        }
        update_option('optimat_hub_version', self::VERSION, false);
        add_filter('cron_schedules', static function (array $schedules): array { $schedules['optimat_minute'] = ['interval' => 60, 'display' => 'OPTIMAT iedere minuut (fallback)']; $schedules['optimat_five_minutes'] = ['interval'=>300,'display'=>'OPTIMAT iedere 5 minuten']; return $schedules; });
        if (!wp_next_scheduled('optimat_hub_dispatch')) { wp_schedule_event(time() + 30, 'optimat_minute', 'optimat_hub_dispatch'); }
        if (!wp_next_scheduled('optimat_hub_cleanup')) { wp_schedule_event(time() + 3600, 'daily', 'optimat_hub_cleanup'); }
        if (class_exists('Optimat_Hub_Gravity')) { Optimat_Hub_Gravity::activate(); }
        if (class_exists('Optimat_Hub_Gravity_Attachments') && method_exists('Optimat_Hub_Gravity_Attachments','activate')) { Optimat_Hub_Gravity_Attachments::activate(); }
    }

    public static function deactivate(): void {
        wp_clear_scheduled_hook('optimat_hub_dispatch'); wp_clear_scheduled_hook('optimat_hub_cleanup');
        if (class_exists('Optimat_Hub_Gravity')) { Optimat_Hub_Gravity::deactivate(); }
    }

    public static function boot(): void {
        if (get_option('optimat_hub_version') !== self::VERSION) { self::activate(); }
        add_filter('cron_schedules', static function (array $schedules): array {
            $schedules['optimat_minute'] = ['interval' => 60, 'display' => 'OPTIMAT iedere minuut (fallback)']; $schedules['optimat_five_minutes'] = ['interval'=>300,'display'=>'OPTIMAT iedere 5 minuten']; return $schedules;
        });
        add_action('optimat_hub_dispatch', [self::class, 'dispatch']);
        add_action('optimat_hub_cleanup', [self::class, 'cleanup']);
        add_action('wp_ajax_optimat_hub_kick', [self::class, 'kick_endpoint']);
        add_action('wp_ajax_nopriv_optimat_hub_kick', [self::class, 'kick_endpoint']);
        add_action('admin_menu', [self::class, 'admin_menu']);
        add_action('admin_post_optimat_hub_save', [self::class, 'save_settings']);
        add_action('admin_post_optimat_hub_replay', [self::class, 'replay']);
        // Explicit generic integration point: call only after a successful validated submission.
        add_action('optimat_hub_capture', [self::class, 'capture_action'], 10, 1);
        if (defined('WP_CLI') && WP_CLI) {
            WP_CLI::add_command('optimat-hub dispatch', static function (): void {
                self::dispatch(50); WP_CLI::success('Dispatchcyclus afgerond; controleer de connectorstatus.');
            });
        }
        Optimat_Hub_Adapters::boot();
        if (class_exists('Optimat_Hub_Gravity')) { Optimat_Hub_Gravity::boot(); }
        if (class_exists('Optimat_Hub_Gravity_Attachments') && method_exists('Optimat_Hub_Gravity_Attachments','boot')) { Optimat_Hub_Gravity_Attachments::boot(); }
    }

    public static function capture_action(array $submission): void {
        try { self::capture($submission); } catch (Throwable $error) {
            update_option('optimat_hub_last_capture_error', ['at' => gmdate('c'), 'code' => 'adapter_failed'], false);
        }
    }

    /** JavaScript/Zod string limits are measured in UTF-16 code units. */
    public static function wire_length(string $value): int {
        if (!mb_check_encoding($value, 'UTF-8')) { return PHP_INT_MAX; }
        return intdiv(strlen(mb_convert_encoding($value, 'UTF-16LE', 'UTF-8')), 2);
    }

    /** No authentication/tracking fields or file bytes are copied into the sales event. */
    public static function safe_fields(array $fields): array {
        $result = [];
        foreach ($fields as $field) {
            if (!is_array($field) || !isset($field['id'])) { continue; }
            $id = (string) $field['id'];
            if (preg_match('/^(ip|ipaddress|useragent)$/i', $id)) { continue; }
            $type = strtolower((string) ($field['type'] ?? 'text'));
            $label = (string) ($field['label'] ?? $id);
            $sensitive = '/captcha|recaptcha|turnstile|password|passwd|honeypot|nonce|csrf|token|authorization|api[_-]?key|secret|session[_-]?id|cookie|gclid|fbclid|msclkid|ip_address|user_agent|^ip$/i';
            if ($id === '' || $id[0] === '_' || preg_match($sensitive, $id . ' ' . $label . ' ' . $type)) { continue; }
            if (in_array($type, ['password', 'hidden_security', 'file', 'upload', 'fileupload', 'honeypot', 'captcha'], true)) { continue; }
            $value = self::safe_value($field['value'] ?? null);
            if (self::wire_length($id) > 200 || self::wire_length($label) > 500 || self::wire_length($type) > 60) { throw new LengthException('field_metadata_limit'); }
            $item = ['id' => $id, 'label' => wp_strip_all_tags($label), 'type' => $type, 'value' => $value];
            if (isset($field['options']) && is_array($field['options'])) {
                if (count($field['options']) > 500) { throw new LengthException('field_options_limit'); }
                $item['options'] = self::safe_value($field['options']);
            }
            $result[] = $item;
        }
        if (count($result) > 300) { throw new LengthException('fields_limit'); }
        return $result;
    }

    public static function safe_context(array $context): array {
        $allowed = ['product_url','product_name','business_unit','brand','machine','model','campaign','utm_source','utm_medium','utm_campaign','utm_content','utm_term','consent','source_created_at','source_updated_at'];
        $clean = self::safe_value(array_intersect_key($context, array_flip($allowed)));
        if (isset($clean['product_url'])) {
            $parts = wp_parse_url((string) $clean['product_url']);
            if ($parts && isset($parts['scheme'], $parts['host']) && in_array($parts['scheme'], ['http','https'], true)) {
                $clean['product_url'] = $parts['scheme'] . '://' . $parts['host'] . ($parts['path'] ?? '/');
            } else { unset($clean['product_url']); }
        }
        return $clean;
    }

    public static function safe_value($value, int $depth = 0) {
        if ($depth > 10) { throw new LengthException('value_depth_limit'); }
        if (is_array($value)) {
            $clean = [];
            if (count($value) > 1000) { throw new LengthException('value_array_limit'); }
            foreach ($value as $key => $item) {
                if (is_string($key) && preg_match('/captcha|password|token|nonce|honeypot|cookie|authorization|api[_-]?key|secret|session[_-]?id|ip_address|user_agent|^ip$/i', $key)) { continue; }
                $clean[$key] = self::safe_value($item, $depth + 1);
            }
            return $clean;
        }
        if (is_bool($value) || is_int($value) || is_float($value) || $value === null) { return $value; }
        if (!is_scalar($value)) { throw new InvalidArgumentException('value_type'); }
        $text = (string) $value;
        if (self::wire_length($text) > 20000) { throw new LengthException('value_length_limit'); }
        // Values remain source values; the receiving UI escapes them on output.
        return $text;
    }

    /**
     * Durable capture; never calls the CRM synchronously (local worker kick is best-effort). Returns WP_Error if local durable storage fails.
     * Keys: provider, form_id, form_name, submission_id?, submitted_at?, fields[], context?.
     * A persisted provider submission ID is required for updates; never use email as this ID.
     */
    public static function capture(array $input) {
        global $wpdb;
        $input = apply_filters('optimat_hub_submission', $input);
        if (!is_array($input)) { return new WP_Error('optimat_invalid_submission', 'Ongeldige adaptergegevens.'); }
        $config = self::config();
        if (empty($config['source_id'])) { return new WP_Error('optimat_not_configured', 'OPTIMAT-bron nog niet ingesteld.'); }
        $provider = sanitize_key((string) ($input['provider'] ?? 'custom'));
        $form_id = sanitize_text_field((string) ($input['form_id'] ?? ''));
        if ($form_id === '') { return new WP_Error('optimat_form_required', 'Formulier-ID ontbreekt.'); }
        if ($provider === '' || self::wire_length($provider) > 80 || self::wire_length($form_id) > 191) { return self::contract_error(); }
        $forms = (array) ($config['forms'] ?? []);
        $form_key = $provider . ':' . $form_id;
        // Explicit opt-in per form. Recruitment/support/newsletter never enter commercial intake by default.
        if (!isset($forms[$form_key]) || empty($forms[$form_key]['enabled'])) { return new WP_Error('optimat_form_disabled', 'Formulier nog niet vrijgegeven.'); }
        $rule = $forms[$form_key];
        $purpose = in_array(($rule['purpose'] ?? ''), ['commercial','support','recruitment','newsletter'], true) ? $rule['purpose'] : 'unclassified';
        // Do not replicate noncommercial personal data; register their routing in the form register instead.
        if ($purpose !== 'commercial') { return new WP_Error('optimat_noncommercial_excluded', 'Niet-commerciële gegevens worden niet naar verkoop verstuurd.'); }
        $submission_id = sanitize_text_field((string) ($input['submission_id'] ?? wp_generate_uuid4()));
        $form_name = sanitize_text_field((string) ($input['form_name'] ?? $form_id));
        $language = sanitize_text_field((string) ($input['language'] ?? get_locale()));
        if ($submission_id === '' || self::wire_length($submission_id) > 200 || $form_name === '' || self::wire_length($form_name) > 200 || self::wire_length($language) > 20) { return self::contract_error(); }
        try {
            $fields = self::safe_fields((array) ($input['fields'] ?? []));
            $context = (object) self::safe_context((array) ($input['context'] ?? []));
            $intents = array_values(array_unique(array_map('sanitize_key', (array) ($input['intents'] ?? $rule['intents'] ?? []))));
            if (count($intents) > 20) { return self::contract_error(); }
            foreach ($intents as $intent) { if (self::wire_length($intent) > 80) { return self::contract_error(); } }
        } catch (Throwable $error) { return self::contract_error(); }
        $occurred_at=self::iso_time($input['occurred_at'] ?? null);
        $source_ordered=!empty($input['occurred_at']);
        // A source timestamp-only update is not a different business payload.
        $hash_context=(array) $context; unset($hash_context['source_updated_at']);
        // Never infer business unit or machine brand from the source hostname.
        $payload_hash = hash('sha256', wp_json_encode([$fields, (object) $hash_context, $intents, $purpose]));
        $identity = hash('sha256', $config['source_id'] . "\0" . $provider . "\0" . $form_id . "\0" . $submission_id);
        $outbox = self::table(); $submissions = self::submissions_table();
        if ($wpdb->query('START TRANSACTION') === false) {
            update_option('optimat_hub_last_capture_error', ['at' => gmdate('c'), 'code' => 'local_storage_failed'], false);
            return new WP_Error('optimat_local_storage_failed', 'Lokale transactie kan niet worden gestart.');
        }
        try {
            // An upsert obtains a row lock and serializes updates for this stable provider identity.
            $submitted_at = self::iso_time($input['submitted_at'] ?? null);
            $inserted = $wpdb->query($wpdb->prepare("INSERT IGNORE INTO $submissions (identity_hash,submission_id,source_version,payload_hash,submitted_at,updated_at) VALUES (%s,%s,0,'',%s,UTC_TIMESTAMP())", $identity, $submission_id, $submitted_at));
            if ($inserted === false) { throw new RuntimeException('local_storage'); }
            $previous = $wpdb->get_row($wpdb->prepare("SELECT * FROM $submissions WHERE identity_hash=%s FOR UPDATE", $identity), ARRAY_A);
            if (!$previous) { throw new RuntimeException('local_storage'); }
            if ($source_ordered && !empty($previous['source_updated_at']) && strtotime($occurred_at)<strtotime($previous['source_updated_at'])) {
                if ($wpdb->query('COMMIT')===false) { throw new RuntimeException('local_storage'); }
                return ['status'=>'ignored_stale','submission_id'=>$submission_id,'version'=>(int) $previous['source_version']];
            }
            if ($previous['payload_hash'] === $payload_hash && empty($input['force_replay'])) {
                // Remember a later no-op observation too: an older different snapshot must not win afterwards.
                if ($source_ordered && (empty($previous['source_updated_at']) || strtotime($occurred_at)>strtotime($previous['source_updated_at']))) {
                    if ($wpdb->update($submissions,['source_updated_at'=>$occurred_at,'updated_at'=>gmdate('Y-m-d H:i:s')],['identity_hash'=>$identity])===false) { throw new RuntimeException('local_storage'); }
                }
                if ($wpdb->query('COMMIT')===false) { throw new RuntimeException('local_storage'); }
                return ['status' => 'unchanged', 'submission_id' => $submission_id];
            }
            $version = ((int) $previous['source_version']) + 1;
            $event_id = wp_generate_uuid4();
            $event = [
                'event_id' => $event_id, 'submission_id' => $submission_id, 'version' => $version,
                'occurred_at' => $occurred_at, 'submitted_at' => $previous['submitted_at'],
                'provider' => $provider, 'form_id' => $form_id,
                'form_name' => $form_name,
                'language' => $language,
                'purpose' => $purpose, 'intents' => $intents, 'fields' => $fields, 'context' => $context,
            ];
            $payload = wp_json_encode($event, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if (!$payload || strlen($payload) > 900000) { throw new LengthException('payload_limit'); }
            $stored = $wpdb->insert($outbox, ['event_id' => $event_id, 'source_id' => $config['source_id'], 'provider' => $provider, 'form_id' => $form_id, 'submission_id' => $submission_id, 'payload' => $payload, 'status' => 'pending', 'available_at' => gmdate('Y-m-d H:i:s'), 'created_at' => gmdate('Y-m-d H:i:s')]);
            if ($stored === false) { throw new RuntimeException('local_storage'); }
            $updated = $wpdb->update($submissions, ['source_version' => $version, 'payload_hash' => $payload_hash, 'source_updated_at'=>$source_ordered ? $occurred_at : ($previous['source_updated_at'] ?? null), 'updated_at' => gmdate('Y-m-d H:i:s')], ['identity_hash' => $identity]);
            if ($updated === false) { throw new RuntimeException('local_storage'); }
            if ($wpdb->query('COMMIT') === false) { throw new RuntimeException('local_storage'); }
            self::kick();
            return ['status' => 'queued', 'event_id' => $event_id, 'submission_id' => $submission_id, 'version' => $version];
        } catch (Throwable $error) {
            $wpdb->query('ROLLBACK');
            if ($error instanceof LengthException) { return self::contract_error(); }
            update_option('optimat_hub_last_capture_error', ['at' => gmdate('c'), 'code' => 'local_storage_failed'], false);
            // Deliberately do not log the exception, payload, visitor identity, or form fields.
            return new WP_Error('optimat_local_storage_failed', 'Lokale bewaring is mislukt; beheerder moet broninzending herstellen.');
        }
    }

    /** Inventory uses the same durable queue and delivery authentication as entry events. */
    public static function queue_inventory(array $inventory) {
        global $wpdb;
        $config=self::config();
        if (empty($config['source_id'])) { return new WP_Error('optimat_not_configured'); }
        $payload=wp_json_encode($inventory,JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!$payload || strlen($payload)>1900000) { return self::contract_error(); }
        $event_id=(string) ($inventory['event_id'] ?? wp_generate_uuid4());
        $stored=$wpdb->insert(self::table(),['event_id'=>$event_id,'source_id'=>$config['source_id'],'provider'=>'gravity_inventory','form_id'=>'_inventory','submission_id'=>$event_id,'payload'=>$payload,'status'=>'pending','available_at'=>gmdate('Y-m-d H:i:s'),'created_at'=>gmdate('Y-m-d H:i:s')]);
        if ($stored===false) { update_option('optimat_hub_last_capture_error',['at'=>gmdate('c'),'code'=>'local_storage_failed'],false); return new WP_Error('optimat_local_storage_failed'); }
        self::kick(); return ['status'=>'queued','event_id'=>$event_id];
    }

    public static function contract_error() {
        update_option('optimat_hub_last_capture_error', ['at' => gmdate('c'), 'code' => 'contract_limit'], false);
        return new WP_Error('optimat_contract_limit', 'Brongegevens overschrijden het ontvangstcontract. Controleer de broninzending en de adapter; waarden zijn niet stilzwijgend afgekapt.');
    }

    public static function iso_time($value): string {
        if (!$value) { return gmdate('c'); }
        try { return (new DateTimeImmutable((string) $value))->setTimezone(new DateTimeZone('UTC'))->format('c'); }
        catch (Throwable $error) { return gmdate('c'); }
    }

    /** Best-effort asynchronous kick; durable queue + a real server cron remains required. */
    public static function kick(): void {
        $token = (string) get_option('optimat_hub_dispatch_token', '');
        if ($token === '') { return; }
        wp_remote_post(admin_url('admin-ajax.php'), [
            'timeout' => 0.05, 'blocking' => false, 'sslverify' => true,
            'body' => ['action' => 'optimat_hub_kick', 'token' => $token], 'redirection' => 0,
        ]);
    }

    public static function kick_endpoint(): void {
        $expected = (string) get_option('optimat_hub_dispatch_token', '');
        $actual = isset($_POST['token']) ? (string) wp_unslash($_POST['token']) : '';
        if ($expected === '' || !hash_equals($expected, $actual)) { status_header(403); exit; }
        self::dispatch(10); status_header(204); exit;
    }

    public static function dispatch(int $limit = 20): void {
        global $wpdb;
        $config = self::config(); $secret = self::secret();
        $base = rtrim((string) ($config['base_url'] ?? ''), '/');
        if ($secret === '' || empty($config['source_id']) || !wp_http_validate_url($base) || strtolower((string) wp_parse_url($base, PHP_URL_SCHEME)) !== 'https') {
            update_option('optimat_hub_worker_status', ['at' => gmdate('c'), 'code' => 'not_configured'], false); return;
        }
        $table = self::table();
        $rows = $wpdb->get_results($wpdb->prepare("SELECT id FROM $table WHERE (status='pending' AND available_at<=UTC_TIMESTAMP()) OR (status='sending' AND locked_until<UTC_TIMESTAMP()) ORDER BY id LIMIT %d", max(1, min(50, $limit))), ARRAY_A);
        foreach ($rows as $row) {
            $lease = $wpdb->query($wpdb->prepare("UPDATE $table SET status='sending',locked_until=DATE_ADD(UTC_TIMESTAMP(),INTERVAL %d SECOND),attempts=attempts+1 WHERE id=%d AND ((status='pending' AND available_at<=UTC_TIMESTAMP()) OR (status='sending' AND locked_until<UTC_TIMESTAMP()))", self::LEASE_SECONDS, $row['id']));
            if ($lease !== 1) { continue; }
            $event = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id=%d", $row['id']), ARRAY_A);
            if (!$event) { continue; }
            // Use a fresh delivery timestamp on every retry; the event timestamps and event_id stay stable.
            $timestamp = (string) time();
            $signature = hash_hmac('sha256', $timestamp . '.' . $event['payload'], $secret);
            $path=$event['provider']==='gravity_inventory' ? '/api/connectors/' . rawurlencode($event['source_id']) . '/sync' : '/api/webhooks/' . rawurlencode($event['source_id']);
            $response = wp_remote_post($base . $path, [
                'timeout' => 12, 'redirection' => 0, 'sslverify' => true,
                'headers' => ['Content-Type' => 'application/json', 'X-Optimat-Timestamp' => $timestamp, 'X-Optimat-Signature' => $signature],
                'body' => $event['payload'], 'limit_response_size' => 4096,
            ]);
            $status = is_wp_error($response) ? 0 : (int) wp_remote_retrieve_response_code($response);
            $receipt = is_wp_error($response) ? null : json_decode((string) wp_remote_retrieve_body($response), true);
            $acknowledged = $status === 202 && is_array($receipt) && ($receipt['accepted'] ?? false) === true && ($receipt['event_id'] ?? '') === $event['event_id'];
            if ($acknowledged) {
                $wpdb->update($table, ['status' => 'delivered', 'delivered_at' => gmdate('Y-m-d H:i:s'), 'locked_until' => null, 'last_http_status' => $status, 'error_code' => null], ['id' => $event['id']]);
                update_option('optimat_hub_last_success', gmdate('c'), false);
            } else {
                $attempts = (int) $event['attempts'];
                $delay = min(21600, 5 * (2 ** min($attempts, 12))) + wp_rand(0, 5);
                $wpdb->update($table, [
                    'status' => $attempts >= self::MAX_ATTEMPTS ? 'failed' : 'pending',
                    'available_at' => gmdate('Y-m-d H:i:s', time() + $delay), 'locked_until' => null,
                    'last_http_status' => $status ?: null,
                    'error_code' => $status === 202 ? 'invalid_receipt' : ($status ? 'http_' . $status : 'transport_error'),
                ], ['id' => $event['id']]);
            }
        }
        update_option('optimat_hub_worker_status', ['at' => gmdate('c'), 'code' => 'ran'], false);
        if (class_exists('Optimat_Hub_Gravity_Attachments') && method_exists('Optimat_Hub_Gravity_Attachments','dispatch')) { Optimat_Hub_Gravity_Attachments::dispatch(10); }
    }

    public static function cleanup(): void {
        global $wpdb;
        $days = max(1, min(365, (int) (self::config()['retention_days'] ?? 30)));
        // Pending and failed events are never automatically deleted. Purge delivered payloads only.
        $wpdb->query($wpdb->prepare('DELETE FROM ' . self::table() . " WHERE status='delivered' AND delivered_at<DATE_SUB(UTC_TIMESTAMP(),INTERVAL %d DAY)", $days));
    }

    public static function admin_menu(): void { add_options_page('OPTIMAT Sales Hub', 'OPTIMAT Sales Hub', 'manage_options', 'optimat-hub', [self::class, 'admin_page']); }
    public static function admin_page(): void {
        if (!current_user_can('manage_options')) { return; }
        global $wpdb;
        $config = self::config(); $table = self::table();
        $counts = $wpdb->get_results("SELECT status,COUNT(*) AS total FROM $table GROUP BY status", ARRAY_A);
        $events = $wpdb->get_results("SELECT id,event_id,provider,form_id,status,attempts,created_at,last_http_status,error_code FROM $table ORDER BY id DESC LIMIT 100", ARRAY_A);
        $error = get_option('optimat_hub_last_capture_error'); $worker = get_option('optimat_hub_worker_status');
        echo '<div class="wrap"><h1>OPTIMAT Sales Hub Connector</h1><p>Gravity Forms is als bronprovider bevestigd; inventariseer op deze installatie alle formulieren en taalvarianten. Geen live koppeling bewezen door alleen de plug-in te installeren.</p>';
        echo '<p>Gedeeld geheim: ' . (self::secret() !== '' ? 'ingesteld (waarde verborgen)' : '<strong>ontbreekt</strong>') . '. Laatste ontvangstbevestiging: ' . esc_html((string) get_option('optimat_hub_last_success', 'nog geen')) . '</p>';
        if ($worker) { echo '<p>Worker: ' . esc_html((string) $worker['code']) . ' · ' . esc_html((string) $worker['at']) . '</p>'; }
        if ($error) { echo '<div class="notice notice-error"><p>Bewaar-/adapterfout (' . esc_html((string) $error['code']) . ') op ' . esc_html((string) $error['at']) . '. Controleer de broninzending, contractlimieten en database en herstel vanuit de formulierprovider. De bezoekersflow is niet onderbroken.</p></div>'; }
        if (class_exists('Optimat_Hub_Gravity')) { Optimat_Hub_Gravity::admin_panel(); }
        foreach ($counts as $count) { echo '<p>' . esc_html($count['status']) . ': ' . esc_html($count['total']) . '</p>'; }
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="optimat_hub_save">';
        wp_nonce_field('optimat_hub_save');
        echo '<table class="form-table"><tr><th>Sales Hub HTTPS-basis-URL</th><td><input class="regular-text" type="url" name="base_url" required value="' . esc_attr($config['base_url'] ?? '') . '"></td></tr><tr><th>Bron-ID uit Sales Hub</th><td><input class="regular-text" name="source_id" required value="' . esc_attr($config['source_id'] ?? '') . '"></td></tr><tr><th>Geleverde events bewaren (dagen)</th><td><input type="number" min="1" max="365" name="retention_days" value="' . esc_attr((string) ($config['retention_days'] ?? 30)) . '"></td></tr><tr><th>Vrijgegeven formulieren (JSON)</th><td><textarea name="forms" rows="12" cols="90">' . esc_textarea(wp_json_encode($config['forms'] ?? new stdClass(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) . '</textarea><p>Voorbeeld: {"elementor:abc123":{"enabled":true,"purpose":"commercial","intents":["brochure"]}}. Kies formulier-ID’s uitsluitend na verificatie. Recruitment/support/nieuwsbrief worden niet naar verkoop gekopieerd.</p></td></tr></table>';
        submit_button('Configuratie bewaren'); echo '</form>';
        echo '<p>Een echte servercron iedere 5 seconden is nodig voor de beoogde normale doorlooptijd ≤15 seconden. WP-Cron is slechts een verkeersafhankelijke fallback. Zie installatiehandleiding.</p><h2>Outbox (geen persoonsgegevens)</h2><table class="widefat striped"><thead><tr><th>Event</th><th>Provider / formulier</th><th>Status</th><th>Pogingen</th><th>HTTP / foutcode</th><th>Actie</th></tr></thead><tbody>';
        foreach ($events as $event) {
            echo '<tr><td>' . esc_html($event['event_id']) . '</td><td>' . esc_html($event['provider'] . ' / ' . $event['form_id']) . '</td><td>' . esc_html($event['status']) . '</td><td>' . esc_html($event['attempts']) . '</td><td>' . esc_html((string) ($event['last_http_status'] ?? '') . ' ' . (string) ($event['error_code'] ?? '')) . '</td><td>';
            if (in_array($event['status'], ['failed', 'pending'], true)) {
                echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="optimat_hub_replay"><input type="hidden" name="event_id" value="' . esc_attr($event['event_id']) . '">';
                wp_nonce_field('optimat_hub_replay_' . $event['event_id']); submit_button('Opnieuw aanbieden', 'secondary', 'submit', false); echo '</form>';
            }
            echo '</td></tr>';
        }
        echo '</tbody></table></div>';
    }

    public static function save_settings(): void {
        if (!current_user_can('manage_options')) { wp_die('Geen toegang.', '', ['response' => 403]); }
        check_admin_referer('optimat_hub_save');
        $base = esc_url_raw(trim((string) wp_unslash($_POST['base_url'] ?? '')));
        if (!wp_http_validate_url($base) || strtolower((string) wp_parse_url($base, PHP_URL_SCHEME)) !== 'https' || wp_parse_url($base, PHP_URL_QUERY) || wp_parse_url($base, PHP_URL_FRAGMENT)) { wp_die('Gebruik een geldige HTTPS-basis-URL zonder query of fragment.'); }
        $source = sanitize_text_field((string) wp_unslash($_POST['source_id'] ?? ''));
        if (!preg_match('/^[A-Za-z0-9_-]{1,100}$/', $source)) { wp_die('Ongeldig bron-ID.'); }
        $forms = json_decode((string) wp_unslash($_POST['forms'] ?? '{}'), true);
        if (!is_array($forms) || count($forms) > 500) { wp_die('Ongeldig formulierregister-JSON.'); }
        $safe_forms = [];
        foreach ($forms as $key => $rule) {
            if (!is_string($key) || !preg_match('/^[a-z0-9_-]+:.{1,191}$/', $key) || !is_array($rule)) { wp_die('Ongeldige formulierregel.'); }
            $purpose = (string) ($rule['purpose'] ?? 'commercial');
            if (!in_array($purpose, ['unclassified','commercial','support','recruitment','newsletter'], true)) { wp_die('Ongeldig formulierdoel.'); }
            try { $safe_forms[$key] = self::sanitize_form_rule($rule); } catch (Throwable $error) { wp_die('Ongeldige formulierregel of contractgrens overschreden.'); }
        }
        update_option('optimat_hub_config', ['base_url' => rtrim($base, '/'), 'source_id' => $source, 'forms' => $safe_forms, 'retention_days' => max(1, min(365, (int) ($_POST['retention_days'] ?? 30)))], false);
        if (class_exists('Optimat_Hub_Gravity')) { Optimat_Hub_Gravity::configuration_changed(); }
        self::kick(); wp_safe_redirect(admin_url('options-general.php?page=optimat-hub')); exit;
    }

    public static function sanitize_form_rule(array $rule): array {
        $purpose=(string) ($rule['purpose'] ?? 'unclassified');
        if (!in_array($purpose,['unclassified','commercial','support','recruitment','newsletter'],true)) { throw new InvalidArgumentException('invalid_purpose'); }
        $intents=array_values(array_filter(array_unique(array_map('sanitize_key',(array) ($rule['intents'] ?? [])))));
        if (count($intents)>20) { throw new LengthException('intents_limit'); }
        foreach ($intents as $intent) { if (self::wire_length($intent)>80) { throw new LengthException('intent_limit'); } }
        $rules=[];
        foreach ((array) ($rule['intent_rules'] ?? []) as $item) {
            if (!is_array($item) || empty($item['field_id']) || !array_key_exists('equals',$item) || !is_scalar($item['equals']) || !is_array($item['add'] ?? null)) { throw new InvalidArgumentException('invalid_intent_rule'); }
            $add=array_values(array_unique(array_map('sanitize_key',$item['add'])));
            if (count($add)>20 || self::wire_length((string) $item['equals'])>20000) { throw new LengthException('intent_limit'); }
            foreach ($add as $intent) { if (self::wire_length($intent)>80) { throw new LengthException('intent_limit'); } }
            $rules[]=['field_id'=>sanitize_text_field((string) $item['field_id']),'equals'=>(string) $item['equals'],'add'=>$add];
        }
        if (count($rules)>50) { throw new LengthException('intent_rules_limit'); }
        $language=sanitize_text_field((string) ($rule['language'] ?? get_locale()));
        if (self::wire_length($language)>20) { throw new LengthException('language_limit'); }
        $attachments=array_values(array_filter(array_unique(array_map(static fn($id)=>preg_match('/^[0-9]+$/',(string) $id) ? (string) $id : '',(array) ($rule['attachments'] ?? [])))));
        return ['enabled'=>!empty($rule['enabled']) && $purpose==='commercial','purpose'=>$purpose,'intents'=>$intents,'intent_rules'=>$rules,'language'=>$language,'attachments'=>$attachments];
    }

    public static function replay(): void {
        if (!current_user_can('manage_options')) { wp_die('Geen toegang.', '', ['response' => 403]); }
        $event_id = sanitize_text_field((string) wp_unslash($_POST['event_id'] ?? ''));
        check_admin_referer('optimat_hub_replay_' . $event_id);
        global $wpdb;
        $wpdb->query($wpdb->prepare('UPDATE ' . self::table() . " SET status='pending',attempts=0,available_at=UTC_TIMESTAMP(),locked_until=NULL WHERE event_id=%s AND status IN ('failed','pending')", $event_id));
        self::kick(); wp_safe_redirect(admin_url('options-general.php?page=optimat-hub')); exit;
    }
}
