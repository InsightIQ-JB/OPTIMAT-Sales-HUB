<?php
if (!defined('ABSPATH')) { exit; }

/** Saved-entry integration: no changes to Gravity Forms validation, notifications or confirmations. */
final class Optimat_Hub_Gravity {
    const STATE = 'optimat_hub_gravity_reconcile';
    const LOCK = 'optimat_hub_gravity_reconcile_lock';
    const OVERLAP_SECONDS = 7200;
    const PAGE_SIZE = 50;
    const FULL_RESCAN_INTERVAL = 86400;

    public static function boot(): void {
        add_action('gform_after_submission', static function ($entry, $form): void { self::guard(static fn() => self::capture((array) $entry, (array) $form)); }, 20, 2);
        add_action('gform_after_update_entry', static function ($form, $entry_id, $original = []): void { self::guard(static fn() => self::reload((int) $entry_id, (array) $form)); }, 20, 3);
        // Official GFAPI update action; returning the entry is harmless for actions and safe for filter variants.
        add_action('gform_post_update_entry', static function ($entry, $original = []) {
            self::guard(static fn() => self::reload((int) ($entry['id'] ?? 0)));
            return $entry;
        }, 20, 2);
        // Compatibility filter used by some integration/version paths: never replace its return value.
        add_filter('gform_entry_post_update', static function ($entry, $original = []) {
            self::guard(static fn() => self::reload((int) ($entry['id'] ?? 0)));
            return $entry;
        }, 20, 2);
        add_action('optimat_hub_gravity_reconcile', static function (): void { self::guard(static fn() => self::reconcile(false, 2)); });
        add_action('gform_after_save_form', static function (): void { self::guard(static fn() => self::sync()); }, 20, 2);
        add_action('optimat_hub_gravity_inventory', static function (): void { self::guard(static fn() => self::sync()); });
        add_action('admin_post_optimat_hub_gravity_form', [self::class, 'save_form']);
        add_action('admin_post_optimat_hub_gravity_run', [self::class, 'admin_run']);
        if (defined('WP_CLI') && WP_CLI) {
            WP_CLI::add_command('optimat-hub gravity inventory', static function (): void {
                $inventory = self::inventory();
                if (is_wp_error($inventory)) { WP_CLI::error('Gravity Forms-inventaris niet beschikbaar.'); }
                WP_CLI::line(wp_json_encode($inventory, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            });
            WP_CLI::add_command('optimat-hub gravity sync', static function (): void {
                $result = self::sync();
                if (is_wp_error($result)) { WP_CLI::error('Inventaris kon niet duurzaam worden klaargezet; controleer de connectorstatus.'); }
                Optimat_Hub::dispatch(50); WP_CLI::success('Inventaris duurzaam klaargezet; controleer ontvangstbewijs in connectorstatus.');
            });
            WP_CLI::add_command('optimat-hub gravity reconcile', static function ($args, $assoc): void {
                $result = self::reconcile(isset($assoc['full']), max(1, min(20, (int) ($assoc['pages'] ?? 5))), isset($assoc['replay']));
                if (is_wp_error($result)) { WP_CLI::error('Reconciliatie gepauzeerd; controleer de connectorstatus.'); }
                WP_CLI::line(wp_json_encode($result));
            });
            WP_CLI::add_command('optimat-hub gravity test', static function (): void {
                $result = self::synthetic_test();
                if (!$result['passed']) { WP_CLI::error('Synthetische normalisatiecontrole mislukt.'); }
                WP_CLI::success('Synthetische compound-/intentiecontrole geslaagd; geen echte inzending verzonden en geen live koppeling bewezen.');
            });
        }
    }

    public static function activate(): void {
        if (!wp_next_scheduled('optimat_hub_gravity_reconcile')) { wp_schedule_event(time() + 60, 'optimat_minute', 'optimat_hub_gravity_reconcile'); }
        if (!wp_next_scheduled('optimat_hub_gravity_inventory')) { wp_schedule_event(time() + 90, 'optimat_five_minutes', 'optimat_hub_gravity_inventory'); }
    }
    public static function deactivate(): void { wp_clear_scheduled_hook('optimat_hub_gravity_reconcile'); wp_clear_scheduled_hook('optimat_hub_gravity_inventory'); }

    private static function guard(callable $callback): void {
        try { $callback(); } catch (Throwable $error) {
            update_option('optimat_hub_last_capture_error', ['at'=>gmdate('c'),'code'=>'gravity_adapter_failed'], false);
        }
    }
    private static function prop($field, string $key, $default = null) { return is_object($field) ? ($field->$key ?? $default) : ($field[$key] ?? $default); }
    private static function descriptor($field): ?array {
        $id = (string) self::prop($field, 'id', '');
        $type = (string) self::prop($field, 'type', 'text');
        if (in_array(strtolower($type), ['html','section','page','file','fileupload','signature','password','captcha','honeypot','creditcard','stripe_creditcard'], true)) { return null; }
        $label = (string) self::prop($field, 'label', $id);
        // Reuse the same security/privacy filter as actual events, without copying any values.
        if (count(Optimat_Hub::safe_fields([['id'=>$id,'label'=>$label,'type'=>$type,'value'=>null]])) !== 1) { return null; }
        $options = [];
        foreach ((array) self::prop($field, 'choices', []) as $choice) {
            $options[] = ['label'=>(string) ($choice['text'] ?? ''),'value'=>$choice['value'] ?? ''];
        }
        if (count($options) > 500) { throw new LengthException('gravity_options_limit'); }
        $inputs = [];
        foreach ((array) self::prop($field, 'inputs', []) as $input) {
            if (empty($input['id'])) { continue; }
            $inputs[] = ['id'=>(string) $input['id'],'label'=>(string) ($input['label'] ?? $input['id']),'type'=>$type,'hidden'=>!empty($input['isHidden'])];
        }
        return ['id'=>$id,'label'=>$label,'type'=>$type,'hidden'=>$type==='hidden' || !empty(self::prop($field, 'isHidden', false)),'options'=>$options,'inputs'=>$inputs];
    }
    public static function form_fields(array $form): array {
        $fields = [];
        foreach ((array) ($form['fields'] ?? []) as $field) {
            $descriptor = self::descriptor($field);
            if (!$descriptor) { continue; }
            $fields[] = $descriptor;
            foreach ($descriptor['inputs'] as $input) {
                // A top-level subinput descriptor makes exact name/address/email mapping possible.
                $fields[] = ['id'=>$input['id'],'label'=>$descriptor['label'].' · '.$input['label'],'type'=>$input['type'],'hidden'=>$input['hidden'],'parent_id'=>$descriptor['id'],'options'=>[],'inputs'=>[]];
            }
        }
        if (count($fields) > 500) { throw new LengthException('gravity_inventory_fields_limit'); }
        return $fields;
    }
    public static function normalize(array $entry, array $form, ?array $rule = null): array {
        $rule = $rule ?? (Optimat_Hub::config()['forms']['gravity:'.(string) $form['id']] ?? []);
        $fields = [];
        foreach (self::form_fields($form) as $descriptor) {
            $value = $entry[$descriptor['id']] ?? null;
            if ($descriptor['inputs']) {
                $value = [];
                foreach ($descriptor['inputs'] as $input) { $value[$input['id']] = ['label'=>$input['label'],'value'=>$entry[$input['id']] ?? null]; }
            }
            $fields[] = ['id'=>$descriptor['id'],'label'=>$descriptor['label'],'type'=>$descriptor['type'],'options'=>$descriptor['options'],'value'=>$value];
        }
        $context = [];
        if (!empty($entry['date_created'])) { $context['source_created_at']=(string) $entry['date_created']; }
        if (!empty($entry['date_updated'])) { $context['source_updated_at']=(string) $entry['date_updated']; }
        if (!empty($entry['source_url'])) { $context['product_url'] = (string) $entry['source_url']; }
        $intents = (array) ($rule['intents'] ?? []);
        foreach ((array) ($rule['intent_rules'] ?? []) as $intent_rule) {
            $field_id = (string) ($intent_rule['field_id'] ?? '');
            if ($field_id === '' || !array_key_exists($field_id, $entry)) { continue; }
            $expected = (string) ($intent_rule['equals'] ?? '');
            $value = $entry[$field_id];
            $actual = is_array($value) ? array_map('strval', $value) : [(string) $value];
            // Match original configured values exactly; never infer intent from labels or free text.
            if (in_array($expected, $actual, true)) { $intents = array_merge($intents, (array) ($intent_rule['add'] ?? [])); }
        }
        $normalized=[
            'provider'=>'gravity','form_id'=>(string) $form['id'],'form_name'=>(string) ($form['title'] ?? $form['id']),
            'submission_id'=>(string) $entry['id'],'submitted_at'=>isset($entry['date_created']) ? $entry['date_created'].' UTC' : null,
            'fields'=>$fields,'intents'=>array_values(array_unique(array_map('sanitize_key', $intents))),
            'language'=>(string) ($rule['language'] ?? get_locale()),'context'=>$context,
        ];
        $source_time=!empty($entry['date_updated']) && $entry['date_updated']!=='0000-00-00 00:00:00' ? $entry['date_updated'] : ($entry['date_created'] ?? null);
        if (!empty($source_time) && $source_time!=='0000-00-00 00:00:00') { $normalized['occurred_at']=Optimat_Hub::iso_time($source_time.' UTC'); }
        return $normalized;
    }
    public static function capture(array $entry, array $form, bool $replay = false) {
        if (($entry['status'] ?? 'active') !== 'active') { return ['status'=>'excluded_source_status']; }
        $normalized=self::normalize($entry,$form);
        if ($replay) { $normalized['force_replay']=true; }
        $result = Optimat_Hub::capture($normalized);
        if (!is_wp_error($result) && in_array(($result['status'] ?? ''), ['queued','unchanged'], true)) {
            do_action('optimat_hub_after_gravity_capture', $form, $entry, $result);
        }
        return $result;
    }
    public static function reload(int $entry_id, ?array $form = null) {
        if (!class_exists('GFAPI') || !$entry_id) { return new WP_Error('gravity_unavailable'); }
        $entry = GFAPI::get_entry($entry_id);
        if (is_wp_error($entry) || !is_array($entry)) { return new WP_Error('gravity_entry_unavailable'); }
        $form = $form ?? GFAPI::get_form((int) $entry['form_id']);
        if (!is_array($form)) { return new WP_Error('gravity_form_unavailable'); }
        return self::capture($entry, $form);
    }
    public static function inventory() {
        if (!class_exists('GFAPI')) { return new WP_Error('gravity_unavailable', 'Gravity Forms is niet actief.'); }
        try {
            $forms = GFAPI::get_forms(null, false, 'id', 'ASC');
            if (is_wp_error($forms) || !is_array($forms) || count($forms) > 500) { return Optimat_Hub::contract_error(); }
            $items = []; $config = Optimat_Hub::config();
            foreach ($forms as $form) {
                $rule = $config['forms']['gravity:'.(string) $form['id']] ?? [];
                if (Optimat_Hub::wire_length((string) $form['id'])>191 || Optimat_Hub::wire_length((string) ($form['title'] ?? $form['id']))>200) { throw new LengthException('gravity_form_metadata_limit'); }
                $items[] = ['form_id'=>(string) $form['id'],'name'=>(string) ($form['title'] ?? $form['id']),'active'=>!empty($form['is_active']),
                    'enabled'=>!empty($rule['enabled']),'purpose'=>(string) ($rule['purpose'] ?? 'unclassified'),'base_intents'=>(array) ($rule['intents'] ?? []),
                    'intent_rules'=>(array) ($rule['intent_rules'] ?? []),'fields'=>self::form_fields($form)];
            }
            $state = (array) get_option(self::STATE, []);
            return ['kind'=>'gravity_inventory','event_id'=>wp_generate_uuid4(),'connector_version'=>Optimat_Hub::VERSION,
                'site_url'=>home_url('/'),'generated_at'=>gmdate('c'),'complete'=>true,'forms'=>$items,
                'reconciliation'=>['supported'=>true,'status'=>$state['status'] ?? 'not_started','last_completed_at'=>$state['last_completed_at'] ?? null,'last_attempt_at'=>$state['last_attempt_at'] ?? null]];
        } catch (Throwable $error) { return Optimat_Hub::contract_error(); }
    }
    public static function sync() {
        $inventory = self::inventory();
        if (is_wp_error($inventory)) { return $inventory; }
        $result = Optimat_Hub::queue_inventory($inventory);
        if (!is_wp_error($result)) { update_option('optimat_hub_gravity_last_inventory_queued', gmdate('c'), false); }
        return $result;
    }

    /** Bounded, resumable, id-keyset scan. Checkpoint advances only after durable local capture. */
    public static function reconcile(bool $full = false, int $max_pages = 2, bool $replay = false) {
        if (!class_exists('GFAPI')) { return new WP_Error('gravity_unavailable'); }
        $token = wp_generate_uuid4(); $lock = get_option(self::LOCK);
        if (is_array($lock) && (int) ($lock['until'] ?? 0) < time()) { delete_option(self::LOCK); }
        if (!add_option(self::LOCK, ['token'=>$token,'until'=>time()+120], '', false)) { return ['status'=>'busy']; }
        try {
            $state = (array) get_option(self::STATE, []);
            $full_due=empty($state['last_full_completed_at']) || strtotime((string) $state['last_full_completed_at'])<time()-self::FULL_RESCAN_INTERVAL;
            if (($state['mode'] ?? '')==='incremental' && $full_due) { $full=true; }
            if (($state['status'] ?? '') !== 'running' || ($full && ($state['mode'] ?? '') !== 'full') || ($replay && empty($state['replay']))) {
                $ids = [];
                foreach ((array) (Optimat_Hub::config()['forms'] ?? []) as $key=>$rule) {
                    if (str_starts_with($key, 'gravity:') && !empty($rule['enabled']) && ($rule['purpose'] ?? '') === 'commercial') { $ids[] = (int) substr($key, 8); }
                }
                sort($ids, SORT_NUMERIC);
                $last_completed = $state['last_completed_at'] ?? null;
                $last_full = $state['last_full_completed_at'] ?? null;
                $must_full=$full || !$last_completed || !$last_full || strtotime((string) $last_full)<time()-self::FULL_RESCAN_INTERVAL;
                $mode = $must_full ? 'full' : 'incremental';
                $state = ['status'=>'running','mode'=>$mode,'replay'=>$replay,'run_id'=>wp_generate_uuid4(),'until'=>gmdate('Y-m-d H:i:s'),
                    'since'=>$mode==='incremental' ? gmdate('Y-m-d H:i:s', strtotime((string) $last_completed)-self::OVERLAP_SECONDS) : null,
                    'forms'=>$ids,'form_index'=>0,'last_id'=>0,'processed'=>0,'changed'=>0,'last_completed_at'=>$last_completed,'last_full_completed_at'=>$last_full,'last_attempt_at'=>gmdate('c')];
                update_option(self::STATE, $state, false);
            }
            for ($page=0; $page<max(1,min(20,$max_pages)); $page++) {
                if ($state['form_index'] >= count($state['forms'])) {
                    $state['status']='completed'; $state['last_completed_at']=Optimat_Hub::iso_time($state['until'].' UTC');
                    if ($state['mode']==='full') { $state['last_full_completed_at']=$state['last_completed_at']; }
                    update_option(self::STATE,$state,false); self::sync(); return $state;
                }
                $form_id = (int) $state['forms'][$state['form_index']]; $form = GFAPI::get_form($form_id);
                if (!is_array($form)) { return self::reconcile_error($state,'form_unavailable'); }
                $criteria=['status'=>'active','field_filters'=>['mode'=>'all',['key'=>'id','operator'=>'>','value'=>(string) $state['last_id']]]];
                if ($state['mode']==='incremental') {
                    $criteria['field_filters'][]=['key'=>'date_updated','operator'=>'>=','value'=>$state['since']];
                    $criteria['field_filters'][]=['key'=>'date_updated','operator'=>'<=','value'=>$state['until']];
                } else { $criteria['end_date']=$state['until']; }
                $total=0;
                $entries=GFAPI::get_entries($form_id,$criteria,['key'=>'id','direction'=>'ASC','is_numeric'=>true],['offset'=>0,'page_size'=>self::PAGE_SIZE],$total);
                if (is_wp_error($entries) || !is_array($entries)) { return self::reconcile_error($state,'entries_unavailable'); }
                foreach ($entries as $entry) {
                    if ((int) ($entry['id'] ?? 0) <= (int) $state['last_id']) { return self::reconcile_error($state,'unstable_entry_order'); }
                    $result=self::capture((array) $entry,$form,!empty($state['replay']));
                    if (is_wp_error($result)) {
                        // A policy change is an explicit exclusion; storage/contract failure pauses this record.
                        if (!in_array($result->get_error_code(), ['optimat_form_disabled','optimat_noncommercial_excluded'], true)) { return self::reconcile_error($state,'capture_failed'); }
                    }
                    $state['last_id']=(int) $entry['id']; $state['processed']++;
                    if (is_array($result) && ($result['status'] ?? '')==='queued') { $state['changed']++; }
                    $state['last_attempt_at']=gmdate('c'); unset($state['error_code']);
                    // If killed after capture but before this checkpoint, replay is safely idempotent.
                    update_option(self::STATE,$state,false);
                }
                if (count($entries)<self::PAGE_SIZE) { $state['form_index']++; $state['last_id']=0; update_option(self::STATE,$state,false); }
                // Keep a bounded worker invocation; the next timer/CLI call resumes the saved cursor.
            }
            return $state;
        } catch (Throwable $error) {
            $state=(array) get_option(self::STATE,[]); return self::reconcile_error($state,'reconcile_failed');
        } finally {
            $current=get_option(self::LOCK);
            if (is_array($current) && ($current['token'] ?? '')===$token) { delete_option(self::LOCK); }
        }
    }
    private static function reconcile_error(array $state, string $code) {
        if (($state['mode'] ?? '')==='incremental' && in_array($code,['entries_unavailable','unstable_entry_order'],true)) {
            // Do not rely on an unsupported provider date filter: safely restart a complete id-keyset scan.
            $state['mode']='full'; $state['since']=null; $state['form_index']=0; $state['last_id']=0;
            $state['processed']=0; $state['changed']=0; $code='incremental_filter_failed_full_fallback';
        }
        $state['status']='running'; $state['error_code']=$code; $state['last_attempt_at']=gmdate('c'); update_option(self::STATE,$state,false);
        return new WP_Error('optimat_reconcile_failed','Reconciliatie gepauzeerd; foutcode '.$code.'. Cursor blijft op laatst duurzaam bewaarde entry.');
    }

    public static function synthetic_test(): array {
        $form=['id'=>987654,'title'=>'SYNTHETISCHE CONTRACTTEST','fields'=>[(object)['id'=>1,'label'=>'Adres','type'=>'address','inputs'=>[['id'=>'1.1','label'=>'Straat']]],(object)['id'=>2,'label'=>'Prijsindicatie','type'=>'checkbox','inputs'=>[['id'=>'2.1','label'=>'Offerte']]]]];
        $entry=['id'=>987654,'date_created'=>'2020-01-01 12:00:00','1.1'=>'Synthetische teststraat','2.1'=>'Ja'];
        $normalized=self::normalize($entry,$form,['intents'=>['brochure'],'intent_rules'=>[['field_id'=>'2.1','equals'=>'Ja','add'=>['quote']]]]);
        return ['passed'=>count($normalized['fields'])===4 && $normalized['fields'][1]['id']==='1.1' && $normalized['intents']===['brochure','quote'],'live_tested'=>false];
    }

    public static function admin_panel(): void {
        if (!class_exists('GFAPI')) { echo '<h2>Gravity Forms</h2><p>Gravity Forms niet actief; broninventaris nog niet beschikbaar.</p>'; return; }
        $inventory=self::inventory();
        if (is_wp_error($inventory)) { echo '<p>Gravity Forms-inventaris niet beschikbaar. Controleer de contract-/bronstatus.</p>'; return; }
        $state=(array) get_option(self::STATE,[]);
        echo '<h2>Gravity Forms: '.esc_html((string) count($inventory['forms'])).' formulieren gevonden</h2><p>Site: '.esc_html($inventory['site_url']).' · Reconciliatie: '.esc_html($state['status'] ?? 'nog niet gestart').' · Laatste voltooiing: '.esc_html($state['last_completed_at'] ?? 'nog geen').'</p><p>Nieuwe formulieren blijven uitgeschakeld totdat doel en intenties uitdrukkelijk zijn ingesteld. Veldmapping gebeurt met deze exacte veld-ID’s in Sales Hub. Synchronisatie van de inventaris bewijst geen live inzending.</p>';
        if (!empty($state['error_code'])) { echo '<div class="notice notice-error"><p>Reconciliatie gepauzeerd: '.esc_html($state['error_code']).'. Cursor is behouden; herstel het probleem en hervat.</p></div>'; }
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="optimat_hub_gravity_run">'; wp_nonce_field('optimat_hub_gravity_run');
        echo '<button class="button" name="operation" value="sync">Inventaris synchroniseren</button> <button class="button" name="operation" value="reconcile">Reconciliatie hervatten</button> <button class="button" name="operation" value="full">Volledige hercontrole starten/hervatten</button></form>';
        foreach ($inventory['forms'] as $form) {
            $rule=Optimat_Hub::config()['forms']['gravity:'.$form['form_id']] ?? [];
            echo '<details style="margin:16px 0;background:#fff;padding:16px;border:1px solid #ccd0d4"><summary><strong>'.esc_html($form['name']).'</strong> · #'.esc_html($form['form_id']).' · '.($form['active'] ? 'actief':'inactief').' · '.(!empty($rule['enabled']) ? 'vrijgegeven':'uitgeschakeld').'</summary>';
            echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="optimat_hub_gravity_form"><input type="hidden" name="form_id" value="'.esc_attr($form['form_id']).'">'; wp_nonce_field('optimat_hub_gravity_form_'.$form['form_id']);
            echo '<p><label><input type="checkbox" name="enabled" value="1" '.checked(!empty($rule['enabled']),true,false).'> Commerciële ontvangst vrijgeven na controle</label></p><p><label>Doel <select name="purpose">';
            foreach (['unclassified'=>'Nog te classificeren','commercial'=>'Commercieel','support'=>'Support','recruitment'=>'Sollicitaties','newsletter'=>'Nieuwsbrief'] as $key=>$label) { echo '<option value="'.esc_attr($key).'" '.selected($rule['purpose'] ?? 'unclassified',$key,false).'>'.esc_html($label).'</option>'; }
            echo '</select></label> <label>Taal <input name="language" value="'.esc_attr($rule['language'] ?? '').'" placeholder="nl_BE"></label></p><p><label>Basisintenties (komma’s, bijvoorbeeld brochure,quote) <input class="regular-text" name="intents" value="'.esc_attr(implode(',',(array) ($rule['intents'] ?? []))).'"></label></p><p><label>Extra intentieregels (JSON) <textarea name="intent_rules" rows="4" cols="90">'.esc_textarea(wp_json_encode($rule['intent_rules'] ?? [], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)).'</textarea></label><br>Voorbeeld na veldcontrole: [{"field_id":"7.1","equals":"Ja","add":["quote"]}]. Basisintenties blijven behouden.</p>';
            echo '<p><label>Bijlagevelden (komma’s; alleen gecontroleerde fileupload-ID’s) <input name="attachments" value="'.esc_attr(implode(',',(array) ($rule['attachments'] ?? []))).'"></label>. Leeg = geen bestandsoverdracht. Alleen private toegestane bestanden, zie handleiding.</p>';
            submit_button('Formulierinstellingen bewaren','secondary'); echo '</form><table class="widefat striped"><thead><tr><th>Veld-ID</th><th>Label</th><th>Type</th><th>Opties (originele waarden)</th></tr></thead><tbody>';
            foreach ($form['fields'] as $field) { echo '<tr><td>'.esc_html($field['id']).'</td><td>'.esc_html($field['label']).'</td><td>'.esc_html($field['type'].(!empty($field['hidden']) ? ' (verborgen zakelijk)':'')).'</td><td>'.esc_html(wp_json_encode($field['options'],JSON_UNESCAPED_UNICODE)).'</td></tr>'; }
            echo '</tbody></table></details>';
        }
    }
    public static function save_form(): void {
        if (!current_user_can('manage_options')) { wp_die('Geen toegang.','',['response'=>403]); }
        $form_id=(string) absint($_POST['form_id'] ?? 0); check_admin_referer('optimat_hub_gravity_form_'.$form_id);
        if (!class_exists('GFAPI') || !is_array(GFAPI::get_form((int) $form_id))) { wp_die('Onbekend Gravity Forms-formulier.'); }
        $purpose=sanitize_key((string) wp_unslash($_POST['purpose'] ?? 'unclassified'));
        if (!in_array($purpose,['unclassified','commercial','support','recruitment','newsletter'],true)) { wp_die('Ongeldig doel.'); }
        $intents=array_values(array_filter(array_unique(array_map('sanitize_key',explode(',',(string) wp_unslash($_POST['intents'] ?? ''))))));
        $rules=json_decode((string) wp_unslash($_POST['intent_rules'] ?? '[]'),true);
        if (!is_array($rules) || count($rules)>50 || count($intents)>20) { wp_die('Ongeldige intentieregels.'); }
        $form_fields=self::form_fields(GFAPI::get_form((int) $form_id)); $ids=array_column($form_fields,'id'); $safe_rules=[];
        foreach ($rules as $rule) {
            if (!is_array($rule) || !in_array((string) ($rule['field_id'] ?? ''),$ids,true) || !array_key_exists('equals',$rule) || !is_scalar($rule['equals']) || !is_array($rule['add'] ?? null)) { wp_die('Controleer veld-ID, equals en add in de intentieregels.'); }
            $add=array_values(array_unique(array_map('sanitize_key',$rule['add'])));
            if (count($add)>20 || Optimat_Hub::wire_length((string) $rule['equals'])>20000) { wp_die('Intentieregel te groot.'); }
            foreach ($add as $intent) { if (Optimat_Hub::wire_length($intent)>80) { wp_die('Intentie te lang.'); } }
            $safe_rules[]=['field_id'=>(string) $rule['field_id'],'equals'=>(string) $rule['equals'],'add'=>$add];
        }
        foreach ($intents as $intent) { if (Optimat_Hub::wire_length($intent)>80) { wp_die('Intentie te lang.'); } }
        $language=sanitize_text_field((string) wp_unslash($_POST['language'] ?? ''));
        if (Optimat_Hub::wire_length($language)>20) { wp_die('Taalcode te lang.'); }
        $attachments=array_values(array_filter(array_map('trim',explode(',',(string) wp_unslash($_POST['attachments'] ?? '')))));
        $allowed_files=[]; foreach ((array) (GFAPI::get_form((int) $form_id)['fields'] ?? []) as $file_field) { if (self::prop($file_field,'type')==='fileupload') { $allowed_files[]=(string) self::prop($file_field,'id'); } }
        foreach ($attachments as $file_id) { if (!in_array($file_id,$allowed_files,true)) { wp_die('Bijlageveld moet een bestaand fileupload-veld zijn.'); } }
        $config=Optimat_Hub::config(); $config['forms']['gravity:'.$form_id]=['attachments'=>$attachments,'enabled'=>!empty($_POST['enabled']) && $purpose==='commercial','purpose'=>$purpose,'language'=>$language ?: get_locale(),'intents'=>$intents,'intent_rules'=>$safe_rules];
        update_option('optimat_hub_config',$config,false);
        // A newly enabled form must be scanned from entry zero, not inherit an old incremental watermark.
        $previous=(array) get_option(self::STATE,[]); $previous['status']='reset_required'; unset($previous['last_completed_at']); update_option(self::STATE,$previous,false);
        self::sync(); wp_safe_redirect(admin_url('options-general.php?page=optimat-hub')); exit;
    }
    public static function configuration_changed(): void {
        $previous=(array) get_option(self::STATE,[]); $previous['status']='reset_required'; unset($previous['last_completed_at']);
        update_option(self::STATE,$previous,false); self::sync();
    }

    public static function admin_run(): void {
        if (!current_user_can('manage_options')) { wp_die('Geen toegang.','',['response'=>403]); }
        check_admin_referer('optimat_hub_gravity_run'); $operation=sanitize_key((string) wp_unslash($_POST['operation'] ?? ''));
        if ($operation==='sync') { self::sync(); } elseif ($operation==='reconcile' || $operation==='full') { self::reconcile($operation==='full',2); }
        wp_safe_redirect(admin_url('options-general.php?page=optimat-hub')); exit;
    }
}
