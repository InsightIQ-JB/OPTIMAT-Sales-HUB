<?php
/** Contract tests only: local filesystem + WordPress/DB/HTTP fakes, no live Gravity Forms service. */
define('ABSPATH','/not-a-live-wordpress/'); define('ARRAY_A','ARRAY_A');
$GLOBALS['media_options']=[]; $GLOBALS['media_deliveries']=[];
function add_action($hook,$callback,$priority=10,$args=1): void { $GLOBALS['media_hooks'][$hook]=[$callback,$priority,$args]; }
function get_option($key,$default=false) { return $GLOBALS['media_options'][$key]??$default; }
function update_option($key,$value,$autoload=null): void { $GLOBALS['media_options'][$key]=$value; }
function wp_upload_dir(): array { return ['basedir'=>$GLOBALS['media_root'],'baseurl'=>'https://wordpress.example/wp-content/uploads','error'=>false]; }
function wp_parse_url($url,$component=-1) { return parse_url($url,$component); }
function wp_http_validate_url($url): bool { return filter_var($url,FILTER_VALIDATE_URL)!==false; }
function wp_json_encode($value,$flags=0) { return json_encode($value,$flags); }
function wp_generate_uuid4(): string { $hex=bin2hex(random_bytes(16)); return substr($hex,0,8).'-'.substr($hex,8,4).'-4'.substr($hex,13,3).'-a'.substr($hex,17,3).'-'.substr($hex,20,12); }
function sanitize_file_name($value): string { return preg_replace('/[^A-Za-z0-9_.-]/','_',basename($value)); }
function wp_rand($min,$max): int { return $min; }
class WP_Error { public function __construct(public string $code) {} }
function is_wp_error($value): bool { return $value instanceof WP_Error; }
function wp_remote_retrieve_response_code($value): int { return (int)$value['response']['code']; }
function wp_remote_retrieve_body($value): string { return (string)($value['body']??''); }
function wp_remote_post($url,$args) {
    $GLOBALS['media_deliveries'][]=['url'=>$url,'args'=>$args]; $mode=$GLOBALS['media_http_mode']??'ok';
    if ($mode==='unreachable') { return new WP_Error('network_error'); }
    $event=json_decode($args['body'],true);
    if ($mode==='not_ready') { return ['response'=>['code'=>409],'body'=>json_encode(['error'=>'pending','retryable'=>true])]; }
    if ($mode==='conflict') { return ['response'=>['code'=>409],'body'=>json_encode(['error'=>'conflict','retryable'=>false])]; }
    return ['response'=>['code'=>202],'body'=>json_encode(['accepted'=>true,'event_id'=>$mode==='wrong_receipt'?'wrong-id':$event['event_id'],'status'=>$mode==='erased'?'ignored_erased':'received'])];
}
final class Optimat_Hub {
    public static function config(): array { return $GLOBALS['media_config']; }
    public static function secret(): string { return 'synthetic-media-contract-key'; }
    public static function kick(): void { $GLOBALS['media_kicks']=($GLOBALS['media_kicks']??0)+1; }
}
final class GFFormsModel {
    public static function get_upload_path($form_id): string { return $GLOBALS['media_root'].'/gravity_forms/'.$form_id; }
    public static function get_upload_url($form_id): string { return 'https://wordpress.example/wp-content/uploads/gravity_forms/'.$form_id; }
}
final class MediaWpdb {
    public string $prefix='wp_'; public array $rows=[]; public bool $failInsert=false; private array $prepared=[];
    public function prepare(string $sql,...$args): string { $key='__media_sql_'.count($this->prepared);$this->prepared[$key]=[$sql,$args];return $key; }
    private function resolve(string $sql): array { return $this->prepared[$sql]??[$sql,[]]; }
    public function get_var(string $sql) { [$query,$args]=$this->resolve($sql);foreach($this->rows as $row){if($row['identity_hash']===$args[0])return $row['id'];}return null; }
    public function insert(string $table,array $data) { if($this->failInsert)return false;$id=count($this->rows)+1;$this->rows[$id]=$data+['id'=>$id,'locked_until'=>null];return 1; }
    public function query(string $sql) { [$query,$args]=$this->resolve($sql);if(strpos($query,"SET status='sending'")!==false){$id=$args[1];if(!isset($this->rows[$id])||!in_array($this->rows[$id]['status'],['pending','sending'],true))return 0;$this->rows[$id]['status']='sending';$this->rows[$id]['attempts']++;return 1;}throw new RuntimeException('Unexpected SQL in fake'); }
    public function get_results(string $sql,$format): array { [$query,$args]=$this->resolve($sql);$eligible=array_filter($this->rows,static fn($row)=>$row['status']==='pending'&&$row['available_at']<=gmdate('Y-m-d H:i:s')||$row['status']==='sending'&&($row['locked_until']??'')<gmdate('Y-m-d H:i:s'));return array_slice(array_values(array_map(static fn($row)=>['id'=>$row['id']],$eligible)),0,(int)($args[0]??10)); }
    public function get_row(string $sql,$format): ?array { [$query,$args]=$this->resolve($sql);return $this->rows[$args[0]]??null; }
    public function update(string $table,array $data,array $where) { $id=$where['id'];$this->rows[$id]=array_merge($this->rows[$id],$data);return 1; }
}
require_once dirname(__DIR__).'/includes/gravity-attachments.php';
$checks=0;function media_check($condition,string $message): void { global $checks;if(!$condition)throw new RuntimeException('FAIL: '.$message);$checks++;echo 'PASS: '.$message."\n"; }
$root=sys_get_temp_dir().'/optimat-media-'.bin2hex(random_bytes(6));mkdir($root.'/gravity_forms/17',0700,true);$GLOBALS['media_root']=$root;$GLOBALS['wpdb']=new MediaWpdb();
$GLOBALS['media_config']=['source_id'=>'source-contract','base_url'=>'https://sales.example','forms'=>['gravity:17'=>['enabled'=>true,'purpose'=>'commercial','attachments'=>['4']],'gravity:18'=>['enabled'=>true,'purpose'=>'recruitment','attachments'=>['4']]]];
$pdf=$root.'/gravity_forms/17/offerte.pdf';$png=$root.'/gravity_forms/17/tekening.png';file_put_contents($pdf,"%PDF-1.4\nsynthetic contract file");file_put_contents($png,"\x89PNG\r\n\x1a\nsynthetic image");$outside=$root.'-outside.pdf';file_put_contents($outside,'%PDF-1.4 outside root');
$base='https://wordpress.example/wp-content/uploads/gravity_forms/17/';
Optimat_Hub_Gravity_Attachments::boot();media_check(($GLOBALS['media_hooks']['optimat_hub_after_gravity_capture'][2]??0)===3,'hooks run after durable saved-entry capture and historical reconciliation');
media_check(Optimat_Hub_Gravity_Attachments::resolve_local_url($base.'offerte.pdf','17')===realpath($pdf),'GF upload URL resolves to a real local upload file');
media_check(Optimat_Hub_Gravity_Attachments::resolve_local_url('https://external.example/offerte.pdf','17')===null,'external upload URLs are never fetched');
media_check(Optimat_Hub_Gravity_Attachments::resolve_local_url($base.'%2e%2e/%2e%2e/private.pdf','17')===null,'encoded directory traversal is rejected');
symlink($outside,$root.'/gravity_forms/17/escape.pdf');media_check(Optimat_Hub_Gravity_Attachments::resolve_local_url($base.'escape.pdf','17')===null,'symlink escaping uploads is rejected');
$form=['id'=>17,'fields'=>[(object)['id'=>4,'type'=>'fileupload'],(object)['id'=>8,'type'=>'fileupload']]];$entry=['id'=>'9001','status'=>'active','4'=>json_encode([$base.'offerte.pdf',$base.'tekening.png','https://external.example/private.pdf']),'8'=>$base.'offerte.pdf'];
Optimat_Hub_Gravity_Attachments::capture($form,$entry,['status'=>'queued']);media_check(count($GLOBALS['wpdb']->rows)===3,'only allowlisted field queues its two local files and durable external-file diagnosis');media_check(count($GLOBALS['media_deliveries'])===0,'visitor capture performs no remote HTTP request');media_check($GLOBALS['wpdb']->rows[3]['status']==='failed'&&$GLOBALS['wpdb']->rows[3]['error_code']==='local_file_unavailable','inaccessible source file has an explicit diagnosis without blocking the lead');
Optimat_Hub_Gravity_Attachments::capture($form,$entry,['status'=>'unchanged']);media_check(count($GLOBALS['wpdb']->rows)===3,'reconcile of unchanged files does not create extra media events');
$recruit=$form;$recruit['id']=18;Optimat_Hub_Gravity_Attachments::capture($recruit,$entry);$trash=$entry;$trash['status']='trash';Optimat_Hub_Gravity_Attachments::capture($form,$trash);media_check(count($GLOBALS['wpdb']->rows)===3,'noncommercial forms and deleted/spam entries are excluded');
$GLOBALS['media_http_mode']='unreachable';Optimat_Hub_Gravity_Attachments::dispatch(1);media_check($GLOBALS['wpdb']->rows[1]['status']==='pending'&&$GLOBALS['wpdb']->rows[1]['attempts']===1,'transport failure preserves a durable media retry');media_check($GLOBALS['wpdb']->rows[1]['available_at']>gmdate('Y-m-d H:i:s'),'transport retry backs off');
$GLOBALS['media_http_mode']='not_ready';$GLOBALS['wpdb']->rows[1]['available_at']=gmdate('Y-m-d H:i:s');Optimat_Hub_Gravity_Attachments::dispatch(1);media_check($GLOBALS['wpdb']->rows[1]['status']==='pending','media arriving before CRM processing retries after409');
$GLOBALS['media_http_mode']='wrong_receipt';$GLOBALS['wpdb']->rows[1]['available_at']=gmdate('Y-m-d H:i:s');Optimat_Hub_Gravity_Attachments::dispatch(1);media_check($GLOBALS['wpdb']->rows[1]['status']==='pending'&&$GLOBALS['wpdb']->rows[1]['error_code']==='invalid_receipt','receipt must echo the stable media event ID');
$GLOBALS['media_http_mode']='ok';$GLOBALS['wpdb']->rows[1]['available_at']=gmdate('Y-m-d H:i:s');Optimat_Hub_Gravity_Attachments::dispatch(1);media_check($GLOBALS['wpdb']->rows[1]['status']==='delivered','authenticated durable acknowledgement completes media delivery');
$delivery=end($GLOBALS['media_deliveries']);$wire=json_decode($delivery['args']['body'],true);media_check($wire['provider']==='gravity'&&base64_decode($wire['content_base64'],true)===file_get_contents($pdf),'wire contains original allowed bytes and GF source identity');media_check(!array_key_exists('local_path',$wire)&&strpos($delivery['args']['body'],'https://wordpress.example')===false,'wire does not expose local paths or public upload URLs');$headers=$delivery['args']['headers'];media_check(hash_equals(hash_hmac('sha256',$headers['X-Optimat-Timestamp'].'.'.$delivery['args']['body'],Optimat_Hub::secret()),$headers['X-Optimat-Signature']),'each retry signs the fresh timestamp and exact JSON bytes');media_check($delivery['args']['sslverify']===true&&$delivery['args']['redirection']===0,'TLS verification stays enabled and redirects cannot leak signed payloads');
file_put_contents($png,"\x89PNG\r\n\x1a\nchanged file");$calls=count($GLOBALS['media_deliveries']);Optimat_Hub_Gravity_Attachments::dispatch(1);media_check($GLOBALS['wpdb']->rows[2]['status']==='failed'&&$GLOBALS['wpdb']->rows[2]['error_code']==='local_file_changed'&&count($GLOBALS['media_deliveries'])===$calls,'changed file contents fail explicitly before remote transport');
$svg=$root.'/gravity_forms/17/unsafe.svg';file_put_contents($svg,'<svg><script>alert(1)</script></svg>');$oversize=$root.'/gravity_forms/17/large.pdf';file_put_contents($oversize,'%PDF-'.str_repeat('x',5242880));$invalid=$entry;$invalid['id']='9002';$invalid['4']=json_encode([$base.'unsafe.svg',$base.'large.pdf']);Optimat_Hub_Gravity_Attachments::capture($form,$invalid);media_check($GLOBALS['wpdb']->rows[4]['error_code']==='file_type_not_allowed'&&$GLOBALS['wpdb']->rows[5]['error_code']==='file_size_not_allowed','unsupported active formats and oversized files produce durable bounded failures');
$GLOBALS['wpdb']->rows[1]['status']='pending';$GLOBALS['wpdb']->rows[1]['attempts']=11;$GLOBALS['wpdb']->rows[1]['available_at']=gmdate('Y-m-d H:i:s');$GLOBALS['media_http_mode']='unreachable';Optimat_Hub_Gravity_Attachments::dispatch(1);media_check($GLOBALS['wpdb']->rows[1]['status']==='failed'&&$GLOBALS['wpdb']->rows[1]['attempts']===12,'twelfth transport failure enters the recoverable failed queue');
$GLOBALS['wpdb']->rows[1]['status']='pending';$GLOBALS['wpdb']->rows[1]['attempts']=0;$GLOBALS['wpdb']->rows[1]['available_at']=gmdate('Y-m-d H:i:s');$GLOBALS['media_http_mode']='erased';Optimat_Hub_Gravity_Attachments::dispatch(1);media_check($GLOBALS['wpdb']->rows[1]['status']==='ignored','privacy tombstone acknowledgement stops retries without recreating a dossier');
unlink($root.'/gravity_forms/17/escape.pdf');foreach([$pdf,$png,$svg,$oversize,$outside] as $file)unlink($file);rmdir($root.'/gravity_forms/17');rmdir($root.'/gravity_forms');rmdir($root);echo "MEDIA CONTRACT CHECKS: $checks\n";
