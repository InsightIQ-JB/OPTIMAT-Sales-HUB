<?php
/** Isolated PHP contract tests with WordPress/database/HTTP fakes; not a live provider test. */
define('ABSPATH', '/not-a-live-wordpress/');
define('ARRAY_A', 'ARRAY_A');
class WP_Error { public function __construct(public string $code, public string $message = '') {} public function get_error_code(): string { return $this->code; } }
function is_wp_error($value): bool { return $value instanceof WP_Error; }
function get_option($key, $default = false) { return $GLOBALS['options'][$key] ?? $default; }
function update_option($key, $value, $autoload = null): void { $GLOBALS['options'][$key] = $value; }
function apply_filters($name, $value, ...$args) { foreach (($GLOBALS['filters'][$name] ?? []) as $callback) { $value=$callback($value,...$args); } return $value; }
function sanitize_key($value): string { return preg_replace('/[^a-z0-9_-]/', '', strtolower($value)); }
function sanitize_text_field($value): string { return strip_tags((string) $value); }
function wp_strip_all_tags($value): string { return strip_tags((string) $value); }
function wp_json_encode($value, $flags = 0) { return json_encode($value, $flags); }
function wp_generate_uuid4(): string { $hex = bin2hex(random_bytes(16)); return substr($hex,0,8).'-'.substr($hex,8,4).'-4'.substr($hex,13,3).'-a'.substr($hex,17,3).'-'.substr($hex,20,12); }
function get_locale(): string { return 'nl_BE'; }
function admin_url($path): string { return 'https://wordpress.example/' . $path; }
function wp_http_validate_url($url): bool { return filter_var($url, FILTER_VALIDATE_URL) !== false; }
function wp_parse_url($url, $component = -1) { return parse_url($url, $component); }
function wp_rand($min, $max): int { return $min; }
function wp_remote_retrieve_response_code($response): int { return $response['response']['code']; }
function wp_remote_retrieve_body($response): string { return $response['body'] ?? ''; }
function wp_remote_post($url, $args) {
    if (str_contains($url, 'admin-ajax.php')) { return ['response'=>['code'=>200], 'body'=>'']; }
    $GLOBALS['deliveries'][] = ['url'=>$url, 'args'=>$args];
    if (($GLOBALS['http_mode'] ?? '') === 'unreachable') { return new WP_Error('network_failed'); }
    if (($GLOBALS['http_mode'] ?? '') === 'html') { return ['response'=>['code'=>200], 'body'=>'<html>not a receipt</html>']; }
    $event = json_decode($args['body'], true);
    return ['response'=>['code'=>202], 'body'=>json_encode(['accepted'=>true,'event_id'=>($GLOBALS['http_mode'] ?? '') === 'wrong_id' ? 'different-id' : $event['event_id']])];
}

final class FakeWpdb {
    public string $prefix = 'wp_';
    public array $outbox = [];
    public array $submissions = [];
    public bool $failInsert = false;
    private array $prepared = [];
    private ?array $snapshot = null;
    public function prepare(string $sql, ...$args): string { $key = '__prepared_' . count($this->prepared); $this->prepared[$key] = [$sql,$args]; return $key; }
    private function resolve(string $sql): array { return $this->prepared[$sql] ?? [$sql,[]]; }
    public function query(string $sql) {
        [$query,$args] = $this->resolve($sql);
        if ($query === 'START TRANSACTION') { $this->snapshot = [$this->outbox,$this->submissions]; return 0; }
        if ($query === 'COMMIT') { $this->snapshot = null; return 0; }
        if ($query === 'ROLLBACK') { if ($this->snapshot !== null) { [$this->outbox,$this->submissions] = $this->snapshot; } $this->snapshot = null; return 0; }
        if (str_starts_with($query, 'INSERT IGNORE INTO wp_optimat_submissions')) {
            if (isset($this->submissions[$args[0]])) { return 0; }
            $this->submissions[$args[0]] = ['identity_hash'=>$args[0],'submission_id'=>$args[1],'source_version'=>0,'payload_hash'=>'','submitted_at'=>$args[2]]; return 1;
        }
        if (str_starts_with($query, 'UPDATE wp_optimat_outbox SET status=\'sending\'')) {
            $id = $args[1];
            if (!isset($this->outbox[$id]) || !in_array($this->outbox[$id]['status'], ['pending','sending'], true)) { return 0; }
            $this->outbox[$id]['status'] = 'sending'; $this->outbox[$id]['attempts']++;
            return 1;
        }
        throw new RuntimeException('Unexpected query in test fake: ' . $query);
    }
    public function get_row(string $sql, $format): ?array {
        [$query,$args] = $this->resolve($sql);
        if (str_contains($query, 'wp_optimat_submissions')) { return $this->submissions[$args[0]] ?? null; }
        if (str_contains($query, 'wp_optimat_outbox')) { return $this->outbox[$args[0]] ?? null; }
        throw new RuntimeException('Unexpected get_row');
    }
    public function get_results(string $sql, $format): array {
        [$query,$args] = $this->resolve($sql);
        return array_slice(array_values(array_map(static fn($row)=>['id'=>$row['id']], array_filter($this->outbox, static fn($row)=>$row['status']==='pending' && $row['available_at'] <= gmdate('Y-m-d H:i:s')))), 0, (int) ($args[0] ?? 20));
    }
    public function insert(string $table, array $data) {
        if ($this->failInsert) { return false; }
        $id = count($this->outbox) + 1; $this->outbox[$id] = $data + ['id'=>$id,'attempts'=>0]; return 1;
    }
    public function update(string $table, array $data, array $where) {
        if ($table === 'wp_optimat_submissions') { $key=$where['identity_hash']; $this->submissions[$key] = array_merge($this->submissions[$key],$data); return 1; }
        $key = $where['id']; $this->outbox[$key] = array_merge($this->outbox[$key],$data); return 1;
    }
}
require_once dirname(__DIR__) . '/includes/connector.php';
$checks = 0;
function check($condition, string $message): void { global $checks; if (!$condition) { throw new RuntimeException('FAIL: '.$message); } $checks++; echo 'PASS: '.$message."\n"; }

putenv('OPTIMAT_HUB_SECRET=synthetic-contract-test-key-not-production');
$GLOBALS['wpdb'] = new FakeWpdb();
$GLOBALS['options'] = ['optimat_hub_config'=>[
    'source_id'=>'source-test','base_url'=>'https://sales.example','forms'=>[
        'gravity:17'=>['enabled'=>true,'purpose'=>'commercial','intents'=>['brochure','quote']],
        'gravity:18'=>['enabled'=>true,'purpose'=>'recruitment','intents'=>[]],
    ],
], 'optimat_hub_dispatch_token'=>'synthetic-test-kick'];
$fields = [
 ['id'=>'company','label'=>'Bedrijf','type'=>'text','value'=>'Testbedrijf'],
 ['id'=>'interests','label'=>'Interesses','type'=>'checkbox','value'=>['CNC','Zagen'],'options'=>['CNC','Zagen']],
 ['id'=>'address','label'=>'Adres','type'=>'address','value'=>['street'=>['label'=>'Straat','value'=>'Teststraat']]],
 ['id'=>'password','label'=>'Wachtwoord','type'=>'text','value'=>'must not copy'],
 ['id'=>'g-recaptcha-response','type'=>'hidden','value'=>'must not copy'],
 ['id'=>'_wpnonce','type'=>'hidden','value'=>'must not copy'],
 ['id'=>'resume','type'=>'fileupload','value'=>'/private/tmp/file.pdf'],
];
$safe = Optimat_Hub::safe_fields($fields);
check(count($safe) === 3, 'security fields and file paths excluded');
check($safe[1]['value'] === ['CNC','Zagen'] && $safe[2]['value']['street']['value'] === 'Teststraat', 'compound and multichoice business values preserved');
check($safe[1]['options'] === ['CNC','Zagen'], 'original business options preserved');
$context = Optimat_Hub::safe_context(['product_url'=>'https://source.example/product/?token=secret','ip_address'=>'1.2.3.4','utm_source'=>'event']);
check($context === ['product_url'=>'https://source.example/product/','utm_source'=>'event'], 'context restricted and product query stripped');
$input = ['provider'=>'gravity','form_id'=>'17','form_name'=>'Brochure','submission_id'=>'entry-1','submitted_at'=>'2025-10-27T08:00:00Z','fields'=>$fields];
$first = Optimat_Hub::capture($input);
check($first['status'] === 'queued' && $first['version'] === 1, 'successful capture durably queued');
$again = Optimat_Hub::capture($input);
check($again['status'] === 'unchanged' && count($GLOBALS['wpdb']->outbox) === 1, 'same provider submission and business payload produces no extra event');
$updated = $input; $updated['fields'][0]['value'] = 'Testbedrijf gewijzigd';
$second = Optimat_Hub::capture($updated);
check($second['status'] === 'queued' && $second['version'] === 2 && $second['submission_id'] === 'entry-1', 'changed business payload increments source version with stable identity');
$event1 = json_decode($GLOBALS['wpdb']->outbox[1]['payload'], true);
$event2 = json_decode($GLOBALS['wpdb']->outbox[2]['payload'], true);
check($event1['event_id'] !== $event2['event_id'] && $event1['submitted_at'] === $event2['submitted_at'], 'new event ID and original submitted date preserved on update');
check($event1['intents'] === ['brochure','quote'], 'combined brochure and quote intent preserved');
$new = $input; $new['submission_id'] = 'entry-2'; Optimat_Hub::capture($new);
check(count($GLOBALS['wpdb']->outbox) === 3, 'another submission stays a distinct event');
$excluded = $input; $excluded['form_id']='18';
check(is_wp_error(Optimat_Hub::capture($excluded)) && count($GLOBALS['wpdb']->outbox)===3, 'recruitment form excluded from commercial outbox');
$disabled = $input; $disabled['form_id']='999';
check(is_wp_error(Optimat_Hub::capture($disabled)), 'unknown forms require explicit opt-in');
$GLOBALS['wpdb']->failInsert=true; $failed=$input; $failed['submission_id']='entry-failed';
$result=Optimat_Hub::capture($failed); $GLOBALS['wpdb']->failInsert=false;
check(is_wp_error($result) && count($GLOBALS['wpdb']->outbox)===3 && count($GLOBALS['wpdb']->submissions)===2, 'failed local store rolls back identity and event atomically');
check(isset($GLOBALS['options']['optimat_hub_last_capture_error']['code']), 'local failure has a non-PII administrator status');
$GLOBALS['http_mode']='unreachable'; Optimat_Hub::dispatch(1);
check($GLOBALS['wpdb']->outbox[1]['status']==='pending' && $GLOBALS['wpdb']->outbox[1]['attempts']===1, 'temporary transport failure retains event for retry');
check($GLOBALS['wpdb']->outbox[1]['available_at']>gmdate('Y-m-d H:i:s'), 'retry has increasing delay');
$GLOBALS['http_mode']='html'; $GLOBALS['wpdb']->outbox[1]['available_at']=gmdate('Y-m-d H:i:s'); Optimat_Hub::dispatch(1);
check($GLOBALS['wpdb']->outbox[1]['status']==='pending', 'HTTP200 HTML is not accepted as durable receipt');
$GLOBALS['http_mode']='wrong_id'; $GLOBALS['wpdb']->outbox[1]['available_at']=gmdate('Y-m-d H:i:s'); Optimat_Hub::dispatch(1);
check($GLOBALS['wpdb']->outbox[1]['status']==='pending' && $GLOBALS['wpdb']->outbox[1]['error_code']==='invalid_receipt', 'HTTP202 wrong receipt ID is not marked delivered');
$GLOBALS['http_mode']='ok'; $GLOBALS['wpdb']->outbox[1]['available_at']=gmdate('Y-m-d H:i:s'); Optimat_Hub::dispatch(1);
check($GLOBALS['wpdb']->outbox[1]['status']==='delivered', 'valid durable receipt marks delivery');
$delivery = end($GLOBALS['deliveries']);
$headers=$delivery['args']['headers'];
check(hash_equals(hash_hmac('sha256',$headers['X-Optimat-Timestamp'].'.'.$delivery['args']['body'],Optimat_Hub::secret()),$headers['X-Optimat-Signature']), 'wire signature covers fresh delivery timestamp and exact raw JSON');
check($delivery['args']['sslverify']===true && $delivery['args']['redirection']===0, 'TLS verification on and credential-bearing redirects disabled');
$GLOBALS['http_mode']='unreachable'; $GLOBALS['wpdb']->outbox[2]['attempts']=11; $GLOBALS['wpdb']->outbox[2]['available_at']=gmdate('Y-m-d H:i:s'); Optimat_Hub::dispatch(1);
check($GLOBALS['wpdb']->outbox[2]['status']==='failed' && $GLOBALS['wpdb']->outbox[2]['attempts']===12, 'twelfth failed attempt enters durable failed queue');
check(count($GLOBALS['deliveries']) >= 3, 'retry paths executed through HTTP fake');
// Wire boundary fixtures: no silent truncation and no event that is guaranteed to fail schema validation.
$GLOBALS['wpdb'] = new FakeWpdb();
$boundaryProvider = str_repeat('p',80); $boundaryForm = str_repeat('f',191);
$GLOBALS['options']['optimat_hub_config']['forms'][$boundaryProvider . ':' . $boundaryForm] = ['enabled'=>true,'purpose'=>'commercial','intents'=>[]];
$boundaryFields = [];
for ($i=0; $i<300; $i++) { $boundaryFields[]=['id'=>str_pad((string) $i,200,'x'),'label'=>str_repeat('l',500),'type'=>str_repeat('t',60),'value'=>'<original business value>','options'=>array_fill(0,100,'option')]; }
$boundaryFields[0]['options']=array_fill(0,500,'option');
$boundary=['provider'=>$boundaryProvider,'form_id'=>$boundaryForm,'form_name'=>str_repeat('n',200),'submission_id'=>str_repeat('s',200),'language'=>str_repeat('a',20),'intents'=>array_map(static fn($i)=>str_pad((string)$i,80,'i'), range(1,20)),'fields'=>$boundaryFields];
$result=Optimat_Hub::capture($boundary);
check(!is_wp_error($result) && $result['status']==='queued', 'maximum wire metadata, fields, options, intents and 200-character submission ID accepted');
$wire=json_decode($GLOBALS['wpdb']->outbox[1]['payload'],true);
check(count($wire['fields'])===300 && strlen($wire['fields'][0]['id'])===200 && strlen($wire['fields'][0]['label'])===500 && count($wire['fields'][0]['options'])===500, 'accepted boundary fields are preserved without truncation');
check($wire['fields'][0]['value']==='<original business value>', 'original business string is not stripped as HTML');
foreach (['form_name'=>str_repeat('n',201),'submission_id'=>str_repeat('s',201),'language'=>str_repeat('a',21)] as $key=>$value) {
    $oversize=$boundary; $oversize[$key]=$value;
    check(is_wp_error(Optimat_Hub::capture($oversize)), 'oversized '.$key.' rejected with visible contract error');
}
$oversize=$boundary; $oversize['fields'][]=$boundaryFields[0];
check(is_wp_error(Optimat_Hub::capture($oversize)), '301 business fields rejected instead of silently sliced');
$oversize=$boundary; $oversize['fields'][0]['options'][]='501st';
check(is_wp_error(Optimat_Hub::capture($oversize)), '501 options rejected instead of silently sliced');
$oversize=$boundary; $oversize['fields'][0]['label']=str_repeat('😀',251);
check(is_wp_error(Optimat_Hub::capture($oversize)), 'UTF-16 wire length enforced for emoji labels');
$oversize=$boundary; $oversize['intents'][]='extra-intent';
check(is_wp_error(Optimat_Hub::capture($oversize)), '21 intents rejected instead of silently sliced');
check(count($GLOBALS['wpdb']->outbox)===1 && $GLOBALS['options']['optimat_hub_last_capture_error']['code']==='contract_limit', 'oversized data produces no malformed events and a non-PII visible status');
echo "Completed $checks isolated connector checks. No live WordPress/provider integration exercised.\n";
