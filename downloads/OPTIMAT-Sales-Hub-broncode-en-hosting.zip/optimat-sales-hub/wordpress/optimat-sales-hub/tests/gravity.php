<?php
/** Includes generic connector checks, then exercises actual GF adapter methods against a mocked GFAPI. */
require __DIR__.'/contract.php';
function add_action($name,$callback,$priority=10,$accepted_args=1): void { $GLOBALS['actions'][$name][]=$callback; }
function add_filter($name,$callback,$priority=10,$accepted_args=1): void { $GLOBALS['filters'][$name][]=$callback; }
function do_action($name,...$args): void { foreach (($GLOBALS['actions'][$name] ?? []) as $callback) { $callback(...$args); } }
function add_option($name,$value,$deprecated='',$autoload=false): bool { if (array_key_exists($name,$GLOBALS['options'])) { return false; } $GLOBALS['options'][$name]=$value; return true; }
function delete_option($name): void { unset($GLOBALS['options'][$name]); }
function home_url($path=''): string { return 'https://wordpress.example'.($path ?: ''); }
class GFAPI {
    public static array $forms=[];
    public static array $entries=[];
    public static array $searches=[];
    public static function get_forms($active=null,$trash=false,$sort='id',$direction='ASC'): array { return array_values(self::$forms); }
    public static function get_form($id) { return self::$forms[$id] ?? false; }
    public static function get_entry($id) { return self::$entries[$id] ?? new WP_Error('not_found'); }
    public static function get_entries($form_id,$criteria,$sorting,$paging,&$total=0) {
        self::$searches[]=[$form_id,$criteria,$sorting,$paging];
        if (!empty($GLOBALS['gf_search_fail'])) { return new WP_Error('search_failed'); }
        $rows=array_filter(self::$entries,static function ($entry) use ($form_id,$criteria): bool {
            if ((int)$entry['form_id'] !== (int)$form_id || ($entry['status'] ?? 'active')!==($criteria['status'] ?? 'active')) { return false; }
            if (isset($criteria['end_date']) && $entry['date_created']>$criteria['end_date']) { return false; }
            foreach ($criteria['field_filters'] ?? [] as $filter) {
                if (!is_array($filter)) { continue; }
                $actual=$entry[$filter['key']] ?? '';
                if ($filter['operator']==='>' && $actual<=$filter['value']) { return false; }
                if ($filter['operator']==='>=' && $actual<$filter['value']) { return false; }
                if ($filter['operator']==='<=' && $actual>$filter['value']) { return false; }
            }
            return true;
        });
        usort($rows,static fn($a,$b)=>(int)$a['id']<=>(int)$b['id']); $total=count($rows);
        return array_slice($rows,$paging['offset'],$paging['page_size']);
    }
}
require dirname(__DIR__).'/includes/gravity.php';
$GLOBALS['wpdb']=new FakeWpdb();
$GLOBALS['options']['optimat_hub_config']=['source_id'=>'gf-test','base_url'=>'https://sales.example','forms'=>[
 'gravity:17'=>['enabled'=>true,'purpose'=>'commercial','language'=>'nl_BE','intents'=>['brochure'],'intent_rules'=>[['field_id'=>'7.1','equals'=>'Ja, offerte','add'=>['quote']]],'attachments'=>['9']],
 'gravity:18'=>['enabled'=>false,'purpose'=>'recruitment','intents'=>[]],
]];
unset($GLOBALS['options'][Optimat_Hub_Gravity::STATE],$GLOBALS['options'][Optimat_Hub_Gravity::LOCK]);
$form=['id'=>17,'title'=>'Brochure + offerte','is_active'=>true,'fields'=>[
 (object)['id'=>1,'label'=>'Bedrijf','type'=>'text'],
 (object)['id'=>2,'label'=>'Naam','type'=>'name','inputs'=>[['id'=>'2.3','label'=>'Voornaam'],['id'=>'2.6','label'=>'Achternaam']]],
 (object)['id'=>3,'label'=>'Adres','type'=>'address','inputs'=>[['id'=>'3.1','label'=>'Straat'],['id'=>'3.3','label'=>'Plaats']]],
 (object)['id'=>7,'label'=>'Interesse','type'=>'checkbox','inputs'=>[['id'=>'7.1','label'=>'Offerte'],['id'=>'7.2','label'=>'Demo']],'choices'=>[['text'=>'Ook een offerte','value'=>'Ja, offerte'],['text'=>'Een demo','value'=>'Demo']]],
 (object)['id'=>8,'label'=>'Machine','type'=>'hidden'],
 (object)['id'=>9,'label'=>'Bijlage','type'=>'fileupload'],
 (object)['id'=>10,'label'=>'CAPTCHA token','type'=>'hidden'],
 (object)['id'=>11,'label'=>'Betaalkaart','type'=>'creditcard'],
]];
GFAPI::$forms=[17=>$form,18=>['id'=>18,'title'=>'Sollicitatie','is_active'=>true,'fields'=>[]],19=>['id'=>19,'title'=>'Nieuw ongeclassificeerd formulier','is_active'=>false,'fields'=>[]]];
$entry=['id'=>1,'form_id'=>17,'status'=>'active','date_created'=>'2020-01-01 09:00:00','date_updated'=>gmdate('Y-m-d H:i:s'),'source_url'=>'https://wordpress.example/machine/?token=discard','1'=>'Testfirma','2.3'=>'Jan','2.6'=>'Test','3.1'=>'Teststraat','3.3'=>'Gent','7.1'=>'Ja, offerte','7.2'=>'Demo','8'=>'CNC','9'=>'https://wordpress.example/private/customer.pdf','10'=>'discard','11'=>'discard'];
GFAPI::$entries=[1=>$entry];
$normalized=Optimat_Hub_Gravity::normalize($entry,$form);
$by_id=array_column($normalized['fields'],null,'id');
check($by_id['2.3']['value']==='Jan' && $by_id['3.3']['value']==='Gent', 'GF name and address subinput IDs are separately mappable');
check($by_id['2']['value']['2.6']['value']==='Test', 'GF compound parent retains original labeled values');
check($by_id['7']['value']['7.1']['value']==='Ja, offerte' && count($by_id['7']['options'])===2, 'GF multiple-checkbox parent preserves selected values and original options');
check($normalized['intents']===['brochure','quote'], 'GF exact configured quote choice supplements existing brochure intent');
check(isset($by_id['8']) && !isset($by_id['9'],$by_id['10'],$by_id['11']), 'GF business hidden fields retained and file/security/card fields excluded');
$unselected=$entry; $unselected['7.1']='Nee';
check(Optimat_Hub_Gravity::normalize($unselected,$form)['intents']===['brochure'], 'GF quote is not inferred when configured value is absent');
$inventory=Optimat_Hub_Gravity::inventory();
check($inventory['complete']===true && count($inventory['forms'])===3 && $inventory['site_url']==='https://wordpress.example/', 'GFAPI inventory includes active and inactive forms for this exact website');
check($inventory['forms'][2]['purpose']==='unclassified' && !$inventory['forms'][2]['enabled'], 'new GF forms are unclassified and opt-in disabled');
$descriptors=array_column($inventory['forms'][0]['fields'],null,'id');
check($descriptors['8']['hidden']===true && isset($descriptors['2.3']) && !array_key_exists('value',$descriptors['2.3']), 'GF inventory contains hidden flags and subinput schemas without entry values');
check(!str_contains(wp_json_encode($inventory),'Testfirma') && !str_contains(wp_json_encode($inventory),'customer.pdf'), 'GF inventory contains no entry PII or upload URL');
$result=Optimat_Hub_Gravity::sync();
check($result['status']==='queued' && $GLOBALS['wpdb']->outbox[1]['provider']==='gravity_inventory', 'GF inventory sync is durable in the shared outbox');
$GLOBALS['http_mode']='ok'; Optimat_Hub::dispatch(1); $last=end($GLOBALS['deliveries']);
check($last['url']==='https://sales.example/api/connectors/gf-test/sync' && $GLOBALS['wpdb']->outbox[1]['status']==='delivered', 'GF inventory uses signed connector endpoint and strict receipt');
$GLOBALS['wpdb']=new FakeWpdb();
Optimat_Hub_Gravity::boot();
do_action('gform_after_submission',$entry,$form);
check(count($GLOBALS['wpdb']->outbox)===1, 'actual registered GF after-submission hook queues a saved entry');
$changed=$entry; $changed['1']='Gewijzigd'; GFAPI::$entries[1]=$changed;
do_action('gform_post_update_entry',$changed,$entry);
check(isset($GLOBALS['actions']['gform_post_update_entry']) && count($GLOBALS['wpdb']->outbox)===2, 'official registered GFAPI post-update action captures changed saved entry');
$returned=apply_filters('gform_entry_post_update',$changed,$entry);
check($returned===$changed && count($GLOBALS['wpdb']->outbox)===2, 'compatibility GF entry-update filter preserves return and deduplicates saved snapshot');
do_action('gform_after_update_entry',$form,1,$entry);
check(count($GLOBALS['wpdb']->outbox)===2, 'admin update hook and GFAPI hook deduplicate unchanged content');
$sourceevent=json_decode($GLOBALS['wpdb']->outbox[2]['payload'],true);
check($sourceevent['submission_id']==='1' && $sourceevent['version']===2 && str_starts_with($sourceevent['submitted_at'],'2020-01-01'), 'GF source ID/version and original source date survive updates');
$spam=$changed; $spam['status']='spam'; $spamresult=Optimat_Hub_Gravity::capture($spam,$form);
check($spamresult['status']==='excluded_source_status' && count($GLOBALS['wpdb']->outbox)===2, 'GF spam/trash entries never enter commercial capture');
$preserved=Optimat_Hub::sanitize_form_rule(['enabled'=>true,'purpose'=>'commercial','intents'=>['brochure'],'intent_rules'=>[['field_id'=>'7.1','equals'=>'Ja, offerte','add'=>['quote']]],'attachments'=>['9'],'language'=>'nl_BE']);
check($preserved['intent_rules'][0]['equals']==='Ja, offerte' && $preserved['attachments']===['9'], 'advanced settings preserve exact intent rules and attachment allowlist');
check(Optimat_Hub_Gravity::synthetic_test()['passed'] && !Optimat_Hub_Gravity::synthetic_test()['live_tested'], 'GF CLI synthetic check exercises compound fields and reports no live test');

// Bounded full rescan, killed-worker replay, resume, and failed-capture checkpoint invariants.
$GLOBALS['wpdb']=new FakeWpdb(); GFAPI::$entries=[];
for ($i=1;$i<=120;$i++) { $row=$entry; $row['id']=$i; $row['1']='Fictief '.$i; GFAPI::$entries[$i]=$row; }
$state=Optimat_Hub_Gravity::reconcile(true,1);
check($state['status']==='running' && $state['last_id']===50 && count($GLOBALS['wpdb']->outbox)===50, 'full GF reconcile reads bounded keyset page and checkpoints fifty durable entries');
$state['last_id']=49; update_option(Optimat_Hub_Gravity::STATE,$state); // Simulate crash after entry50 commit before checkpoint.
$state=Optimat_Hub_Gravity::reconcile(false,1);
check($state['last_id']===99 && count($GLOBALS['wpdb']->outbox)===99, 'resume after commit/checkpoint crash replays safely without duplicate or skipped record');
$GLOBALS['wpdb']->failInsert=true;
$failed=Optimat_Hub_Gravity::reconcile(false,1); $GLOBALS['wpdb']->failInsert=false;
$paused=get_option(Optimat_Hub_Gravity::STATE);
check(is_wp_error($failed) && $paused['last_id']===99 && $paused['error_code']==='capture_failed', 'local storage failure pauses cursor before failed entry');
$state=Optimat_Hub_Gravity::reconcile(false,2);
check($state['status']==='completed' && $state['processed']===121 && count(array_filter($GLOBALS['wpdb']->outbox,static fn($r)=>$r['provider']==='gravity'))===120, 'repair resumes all 120 source entries with no loss and no duplicate');
$watermark=$state['last_completed_at'];
$state=Optimat_Hub_Gravity::reconcile(false,1);
$search=end(GFAPI::$searches); $filters=$search[1]['field_filters'];
check($state['mode']==='incremental' && $filters[2]['key']==='date_updated' && $filters[1]['value']<=gmdate('Y-m-d H:i:s',strtotime($watermark)-7200), 'incremental GF scan uses changed-date window with two-hour overlap');
$GLOBALS['options'][Optimat_Hub_Gravity::STATE]['status']='completed';
$before=count(array_filter($GLOBALS['wpdb']->outbox,static fn($r)=>$r['provider']==='gravity'));
$state=Optimat_Hub_Gravity::reconcile(true,1,true);
check($state['replay']===true && count(array_filter($GLOBALS['wpdb']->outbox,static fn($r)=>$r['provider']==='gravity'))===$before+50, 'explicit full replay emits new source versions for formerly acknowledged entries');
$latest=json_decode(end($GLOBALS['wpdb']->outbox)['payload'],true);
check($latest['version']===2, 'forced recovery uses higher source version instead of conflicting original event ID');
$lock=['token'=>'other-worker','until'=>time()+100]; update_option(Optimat_Hub_Gravity::LOCK,$lock);
check(Optimat_Hub_Gravity::reconcile(false,1)['status']==='busy', 'parallel GF reconciliation respects durable worker lock');
delete_option(Optimat_Hub_Gravity::LOCK);
$old=(array) get_option(Optimat_Hub_Gravity::STATE); $old['status']='completed'; $old['last_full_completed_at']='2020-01-01T00:00:00Z'; update_option(Optimat_Hub_Gravity::STATE,$old);
$state=Optimat_Hub_Gravity::reconcile(false,1);
check($state['mode']==='full' && $state['last_id']===50, 'automatic daily full scan recovers updates even if provider changed-date filtering is unsupported');
$countryform=$form; $countryform['fields'][]=(object)['id'=>15,'label'=>'Land','type'=>'select','choices'=>array_map(static fn($i)=>['text'=>'Land '.$i,'value'=>'C'.$i],range(1,250))];
$countryfields=Optimat_Hub_Gravity::form_fields($countryform);
check(count(end($countryfields)['options'])===250, 'legitimate GF country dropdown with 250 choices fits the500-option contract');
$state=(array) get_option(Optimat_Hub_Gravity::STATE); $state['mode']='incremental'; $state['status']='running'; $state['last_full_completed_at']=gmdate('c'); $state['form_index']=0; $state['last_id']=0; $state['since']='2020-01-01 00:00:00'; update_option(Optimat_Hub_Gravity::STATE,$state);
$GLOBALS['gf_search_fail']=true; $failed=Optimat_Hub_Gravity::reconcile(false,1); $GLOBALS['gf_search_fail']=false;
$fallback=get_option(Optimat_Hub_Gravity::STATE);
check(is_wp_error($failed) && $fallback['mode']==='full' && $fallback['last_id']===0 && $fallback['error_code']==='incremental_filter_failed_full_fallback', 'unsupported incremental provider filter restarts a safe full scan instead of permanently blocking recovery');
$GLOBALS['wpdb']=new FakeWpdb();
$fixture_entry=$entry; unset($fixture_entry['source_url'],$fixture_entry['date_updated']);
$fixture_entry['1']='SYNTHETISCHE PHP-WIRE TESTFIRMA';
$fixture_result=Optimat_Hub_Gravity::capture($fixture_entry,$form);
$fixture_raw=$GLOBALS['wpdb']->outbox[1]['payload'];
check($fixture_result['status']==='queued' && str_contains($fixture_raw,'"context":{'), 'actual PHP GF wire JSON uses object context for historical entry without source URL');
$empty_input=Optimat_Hub_Gravity::normalize($fixture_entry,$form); $empty_input['submission_id']='empty-context-fixture'; $empty_input['context']=[];
Optimat_Hub::capture($empty_input); $empty_raw=$GLOBALS['wpdb']->outbox[2]['payload'];
check(str_contains($empty_raw,'"context":{}'), 'actual PHP outbox encodes empty allowed context as{} rather than incompatible[]');
$GLOBALS['wpdb']=new FakeWpdb();
$newer=$entry; $newer['date_updated']='2026-10-27 10:00:00'; $newer['1']='NIEUWSTE SNAPSHOT';
$accepted=Optimat_Hub_Gravity::capture($newer,$form);
$older=$entry; $older['date_updated']='2026-10-27 09:00:00'; $older['1']='VEROUDERDE SNAPSHOT';
$ignored=Optimat_Hub_Gravity::capture($older,$form);
check($accepted['status']==='queued' && $ignored['status']==='ignored_stale' && count($GLOBALS['wpdb']->outbox)===1, 'older delayed GF snapshot cannot enqueue a higher local version over newer source data');
$noop=$newer; $noop['date_updated']='2026-10-27 12:00:00';
$unchanged=Optimat_Hub_Gravity::capture($noop,$form);
check($unchanged['status']==='unchanged' && count($GLOBALS['wpdb']->outbox)===1, 'newer source timestamp without business change updates watermark without another event');
$between=$newer; $between['date_updated']='2026-10-27 11:00:00'; $between['1']='OLDER THAN NO-OP';
$ignored=Optimat_Hub_Gravity::capture($between,$form);
check($ignored['status']==='ignored_stale' && count($GLOBALS['wpdb']->outbox)===1, 'no-op timestamp observation prevents later older different payload from overwriting current source state');
$timestamp_event=json_decode($GLOBALS['wpdb']->outbox[1]['payload'],true);
check(strtotime($timestamp_event['occurred_at'])===strtotime('2026-10-27 10:00:00 UTC'), 'GF occurred_at is original source updated time in UTC rather than dispatch time');
if (getenv('OPTIMAT_WRITE_WIRE_FIXTURE')==='1') {
    $fixture_dir=dirname(__DIR__,3).'/tests/fixtures';
    if (!is_dir($fixture_dir)) { mkdir($fixture_dir,0755,true); }
    file_put_contents($fixture_dir.'/gravity-wire.json',$fixture_raw);
    file_put_contents($fixture_dir.'/gravity-empty-context-wire.json',$empty_raw);
}
echo "Completed $checks isolated connector and Gravity Forms checks. No live WordPress/GF provider integration exercised.\n";
