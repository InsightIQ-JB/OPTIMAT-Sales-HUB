<?php
/**
 * Plugin Name: OPTIMAT Sales Hub Connector
 * Description: Durable one-way form delivery to OPTIMAT Sales Hub. Provider adapters require per-form verification.
 * Version: 0.2.1
 * Requires PHP: 8.1
 * Requires at least: 6.3
 * License: GPL-2.0-or-later
 */
if (!defined('ABSPATH')) { exit; }
require_once __DIR__ . '/includes/connector.php';
require_once __DIR__ . '/includes/adapters.php';
require_once __DIR__ . '/includes/gravity.php';
if (is_file(__DIR__ . '/includes/gravity-attachments.php')) { require_once __DIR__ . '/includes/gravity-attachments.php'; }
register_activation_hook(__FILE__, ['Optimat_Hub', 'activate']);
register_deactivation_hook(__FILE__, ['Optimat_Hub', 'deactivate']);
add_action('plugins_loaded', ['Optimat_Hub', 'boot']);
