CREATE TABLE IF NOT EXISTS geocode_jobs (
  id TEXT PRIMARY KEY,
  location_id TEXT NOT NULL UNIQUE REFERENCES locations(id) ON DELETE CASCADE,
  address_fingerprint TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','processing','retry','completed','failed','skipped')),
  attempts INTEGER NOT NULL DEFAULT 0,
  next_attempt_at TEXT,
  error_code TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS geocode_jobs_queue ON geocode_jobs(status,next_attempt_at);
