CREATE TABLE IF NOT EXISTS attachments (
  id TEXT PRIMARY KEY,
  request_id TEXT NOT NULL REFERENCES requests(id) ON DELETE CASCADE,
  storage_key TEXT NOT NULL UNIQUE,
  original_name TEXT NOT NULL,
  mime TEXT NOT NULL CHECK(mime IN ('application/pdf','image/png','image/jpeg')),
  size_bytes INTEGER NOT NULL CHECK(size_bytes > 0 AND size_bytes <= 5242880),
  sha256 TEXT NOT NULL,
  uploaded_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS attachments_request ON attachments(request_id);
CREATE TABLE IF NOT EXISTS attachment_deletion_queue (
  storage_key TEXT PRIMARY KEY,
  queued_at TEXT NOT NULL
);
