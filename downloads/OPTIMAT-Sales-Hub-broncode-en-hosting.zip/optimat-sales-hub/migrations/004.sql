CREATE TABLE IF NOT EXISTS erased_submissions(key_hash TEXT PRIMARY KEY,erased_at TEXT NOT NULL);
