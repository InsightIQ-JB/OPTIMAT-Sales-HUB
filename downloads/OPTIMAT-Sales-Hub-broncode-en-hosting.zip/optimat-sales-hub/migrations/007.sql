-- System source uploads have no personal application account. Keep existing attachment rows intact.
CREATE TABLE attachments_with_source (
  id TEXT PRIMARY KEY,
  request_id TEXT NOT NULL REFERENCES requests(id) ON DELETE CASCADE,
  storage_key TEXT NOT NULL UNIQUE,
  original_name TEXT NOT NULL,
  mime TEXT NOT NULL CHECK(mime IN ('application/pdf','image/png','image/jpeg')),
  size_bytes INTEGER NOT NULL CHECK(size_bytes > 0 AND size_bytes <= 5242880),
  sha256 TEXT NOT NULL,
  uploaded_by TEXT REFERENCES users(id),
  created_at TEXT NOT NULL
);
INSERT INTO attachments_with_source SELECT * FROM attachments;
DROP TABLE attachments;
ALTER TABLE attachments_with_source RENAME TO attachments;
CREATE INDEX attachments_request ON attachments(request_id);
CREATE TABLE source_attachment_receipts (
  id TEXT PRIMARY KEY,
  source_id TEXT NOT NULL REFERENCES sources(id),
  provider TEXT NOT NULL,
  form_id TEXT NOT NULL,
  submission_id TEXT NOT NULL,
  attachment_key TEXT NOT NULL,
  content_hash TEXT NOT NULL,
  request_id TEXT NOT NULL REFERENCES requests(id) ON DELETE CASCADE,
  attachment_id TEXT NOT NULL REFERENCES attachments(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL,
  UNIQUE(source_id,provider,form_id,submission_id,attachment_key)
);
