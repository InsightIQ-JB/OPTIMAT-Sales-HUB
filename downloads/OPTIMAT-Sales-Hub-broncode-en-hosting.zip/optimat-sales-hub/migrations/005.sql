CREATE TABLE IF NOT EXISTS request_history(id TEXT PRIMARY KEY,request_id TEXT NOT NULL REFERENCES requests(id) ON DELETE CASCADE,snapshot_json TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS request_history_lookup ON request_history(request_id,created_at DESC);
-- Existing state is first known at migration time; do not invent earlier ownership or status.
INSERT INTO request_history(id,request_id,snapshot_json,created_at)
SELECT lower(hex(randomblob(16))),r.id,json_object('id',r.id,'company_id',r.company_id,'contact_id',r.contact_id,'source_id',r.source_id,'owner_id',r.owner_id,'owner_name',u.name,'status',r.status,'priority',r.priority,'business_unit',r.business_unit,'brand',r.brand,'machine',r.machine,'model',r.model,'intents_json',r.intents_json,'campaign',r.campaign,'purpose',r.purpose,'is_test',r.is_test,'is_spam',r.is_spam,'submitted_at',r.submitted_at,'received_at',r.received_at,'country',c.country,'source_name',s.name,'source_url',s.site_url,'latitude',l.latitude,'longitude',l.longitude,'precision',l.precision,'history_origin','backfill'),strftime('%Y-%m-%dT%H:%M:%fZ','now')
FROM requests r LEFT JOIN companies c ON c.id=r.company_id LEFT JOIN locations l ON l.id=r.location_id LEFT JOIN users u ON u.id=r.owner_id LEFT JOIN sources s ON s.id=r.source_id
WHERE NOT EXISTS(SELECT 1 FROM request_history h WHERE h.request_id=r.id);
