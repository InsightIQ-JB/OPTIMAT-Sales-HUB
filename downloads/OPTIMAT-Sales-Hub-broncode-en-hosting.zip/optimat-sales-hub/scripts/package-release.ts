import { execFileSync } from 'node:child_process';
import { lstatSync, readFileSync, mkdirSync, writeFileSync } from 'node:fs';
import { resolve, join } from 'node:path';
import JSZip from 'jszip';
const root = resolve('.');
const files = new Set(
  execFileSync('git', ['ls-files', '--cached', '--others', '--exclude-standard', '-z'], {
    cwd: root,
  })
    .toString()
    .split('\0')
    .filter(Boolean),
);
const zip = new JSZip();
for (const relative of files) {
  const path = join(root, relative);
  if (lstatSync(path).isFile()) zip.file('optimat-sales-hub/' + relative, readFileSync(path));
}
mkdirSync('.data', { recursive: true, mode: 0o700 });
writeFileSync(
  '.data/optimat-sales-hub-source.zip',
  await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' }),
  { mode: 0o600 },
);
console.log(
  `Broncodepakket gemaakt (${files.size} bestanden), zonder Git-metadata, afhankelijkheden, klantdatabase of genegeerde secrets.`,
);
