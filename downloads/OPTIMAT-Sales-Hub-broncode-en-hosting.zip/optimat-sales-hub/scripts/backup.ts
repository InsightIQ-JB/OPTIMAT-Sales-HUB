import { backup } from 'node:sqlite';
import { mkdirSync, chmodSync } from 'node:fs';
import { resolve } from 'node:path';
import { db } from '../server/db.js';
const dir = process.env.BACKUP_DIR || '.data/backups';
mkdirSync(dir, { recursive: true, mode: 0o700 });
const destination = resolve(
  dir,
  `optimat-${new Date().toISOString().replace(/[:.]/g, '-')}.sqlite`,
);
await backup(db, destination);
chmodSync(destination, 0o600);
console.log(
  'Consistente SQLite-back-up gemaakt. Bewaar privé, versleutel buiten de app en volg docs/OPERATIONS.md.',
);
db.close();
