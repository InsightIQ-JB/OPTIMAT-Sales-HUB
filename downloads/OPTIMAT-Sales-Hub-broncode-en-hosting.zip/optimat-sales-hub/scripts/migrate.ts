import { initDb, db } from '../server/db.js';
initDb();
console.log('Databasemigraties toegepast.');
db.close();
