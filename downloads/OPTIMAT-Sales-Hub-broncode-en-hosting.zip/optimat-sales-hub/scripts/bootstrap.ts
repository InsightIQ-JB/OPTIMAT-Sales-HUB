import { db, id, now } from '../server/db.js';
import { hashPassword } from '../server/auth.js';
import { z } from 'zod';
const input = z
  .object({
    email: z.string().email(),
    password: z.string().min(12).max(256),
    name: z.string().min(1),
  })
  .parse({
    email: process.env.ADMIN_EMAIL,
    password: process.env.ADMIN_PASSWORD,
    name: process.env.ADMIN_NAME || 'Beheerder',
  });
if (db.prepare("SELECT id FROM users WHERE role='admin' AND active=1").get())
  throw new Error('Er bestaat al een beheerder. Gebruik de beveiligde uitnodigingsfunctie.');
db.prepare(
  'INSERT INTO users (id,email,name,password_hash,role,active,created_at) VALUES (?,?,?,?,?,1,?)',
).run(id(), input.email.toLowerCase(), input.name, hashPassword(input.password), 'admin', now());
console.log('Beheerdersaccount aangemaakt. Het wachtwoord is niet opgeslagen in logs.');
db.close();
