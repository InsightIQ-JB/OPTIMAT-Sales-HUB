import { spawn } from 'node:child_process';
const env = { ...process.env, APP_URL: process.env.DEV_APP_URL || 'http://localhost:5173' };
const api = spawn(process.execPath, ['--watch', '--import', 'tsx', 'server/index.ts'], {
  stdio: 'inherit',
  env,
});
const web = spawn(process.execPath, ['node_modules/vite/bin/vite.js', '--host', '0.0.0.0'], {
  stdio: 'inherit',
  env,
});
let stopping = false;
function stop(code = 0) {
  if (stopping) return;
  stopping = true;
  api.kill('SIGTERM');
  web.kill('SIGTERM');
  process.exitCode = code;
}
for (const child of [api, web]) {
  child.on('error', () => stop(1));
  child.on('exit', (code) => stop(code || 0));
}
process.on('SIGINT', () => stop());
process.on('SIGTERM', () => stop());
