import { db, id, now, transaction } from '../server/db.js';
const defaults = [
  {
    name: 'OPTIMAT Group (Gravity Forms)',
    site_url: 'https://www.optimat-group.com/',
    secret_env: 'OPTIMAT_WP_MAIN_SECRET',
  },
  {
    name: 'KDT (Gravity Forms)',
    site_url: 'https://kdt.optimat-group.com/',
    secret_env: 'OPTIMAT_WP_KDT_SECRET',
  },
];
const identity = (value: string) => new URL(value).hostname.replace(/^www\./, '').toLowerCase();
transaction(() => {
  const known = db.prepare('SELECT site_url FROM sources').all() as { site_url: string }[];
  for (const source of defaults) {
    if (known.some((row) => identity(row.site_url) === identity(source.site_url))) continue;
    db.prepare(
      'INSERT INTO sources(id,name,site_url,secret_env,created_at) VALUES (?,?,?,?,?)',
    ).run(id(), source.name, source.site_url, source.secret_env, now());
  }
});
console.log(
  'Bronregistratie gecontroleerd: beide WordPress-sites aanwezig; bestaande instellingen behouden. Dit maakt geen accounts, leads of live koppeling aan.',
);
db.close();
