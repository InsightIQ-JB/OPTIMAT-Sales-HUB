export const ROLES = ['seller', 'manager', 'management', 'admin'] as const;
export type Role = (typeof ROLES)[number];
export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  team_id: string | null;
  marketing_permission: number;
  active: number;
}
export const REQUEST_STATUSES = ['new', 'to_contact', 'contacted', 'waiting', 'closed'] as const;
export const STAGES = [
  'qualified',
  'demo',
  'quote',
  'negotiation',
  'waiting',
  'won',
  'lost',
] as const;
export const LABELS: Record<string, string> = {
  new: 'Nieuw',
  to_contact: 'Te contacteren',
  contacted: 'Gecontacteerd',
  waiting: 'In wacht',
  closed: 'Afgerond',
  qualified: 'Gekwalificeerd',
  demo: 'Demo / afspraak',
  quote: 'Offerte',
  negotiation: 'Onderhandeling',
  won: 'Verkocht',
  lost: 'Verloren',
  seller: 'Verkoper',
  manager: 'Salesmanager',
  management: 'Marketing / management',
  admin: 'Beheerder',
  Wood: 'Wood',
  Stone: 'Stone',
  Glass: 'Glass',
  Unknown: 'Onbekend',
};
export interface BusinessField {
  id: string;
  label: string;
  type: string;
  value: unknown;
  options?: unknown[];
}
export interface IntakeEvent {
  event_id: string;
  submission_id: string;
  version: number;
  occurred_at: string;
  submitted_at: string;
  provider: string;
  form_id: string;
  form_name: string;
  language?: string;
  purpose: 'commercial' | 'support' | 'recruitment' | 'newsletter';
  intents: string[];
  fields: BusinessField[];
  context?: Record<string, unknown>;
}
