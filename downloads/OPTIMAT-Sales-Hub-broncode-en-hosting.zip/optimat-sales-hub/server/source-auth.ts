import type { Request } from 'express';
import { createHmac, timingSafeEqual } from 'node:crypto';
import { db } from './db.js';
import { HttpError } from './errors.js';
export interface SourceRecord {
  id: string;
  name: string;
  site_url: string;
  secret_env: string;
  previous_secret_env: string | null;
  enabled: number;
  [key: string]: unknown;
}
/** Authentication is identical for all connector channels; bodies have separate strict schemas. */
export function verifySourceRequest(req: Request): SourceRecord {
  const source = db
    .prepare('SELECT * FROM sources WHERE id=? AND enabled=1')
    .get(String(req.params.sourceId)) as SourceRecord | undefined;
  if (!source) throw new HttpError(404, 'Bron niet beschikbaar.');
  const timestamp = req.headers['x-optimat-timestamp'],
    signature = req.headers['x-optimat-signature'];
  if (
    typeof timestamp !== 'string' ||
    !/^\d{10}$/.test(timestamp) ||
    Math.abs(Date.now() / 1000 - Number(timestamp)) > 300 ||
    typeof signature !== 'string' ||
    !/^[a-f0-9]{64}$/i.test(signature)
  )
    throw new HttpError(401, 'Ongeldige ondertekening of tijdstempel.');
  const raw = (req as Request & { rawBody?: Buffer }).rawBody;
  if (!raw) throw new HttpError(400, 'Ondertekende JSON-body vereist.');
  const secrets = [source.secret_env, source.previous_secret_env]
    .filter(Boolean)
    .map((name) => process.env[name!])
    .filter(Boolean) as string[];
  if (!secrets.length) throw new HttpError(503, 'Brongeheim nog niet ingesteld.');
  const valid = secrets.some((secret) =>
    timingSafeEqual(
      Buffer.from(signature, 'hex'),
      createHmac('sha256', secret)
        .update(timestamp + '.')
        .update(raw)
        .digest(),
    ),
  );
  if (!valid) throw new HttpError(401, 'Ongeldige ondertekening.');
  return source;
}
