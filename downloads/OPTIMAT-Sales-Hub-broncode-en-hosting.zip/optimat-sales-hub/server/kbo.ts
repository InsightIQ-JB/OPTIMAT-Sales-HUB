import { createHash, randomBytes, randomUUID } from 'node:crypto';
import { XMLParser, XMLValidator } from 'fast-xml-parser';
import { HttpError } from './errors.ts';

/** Official SOAP endpoint. Never accept an arbitrary user-controlled endpoint. */
export const KBO_ENDPOINT = 'https://kbopub.economie.fgov.be/kbopubws180000/services/wsKBOPub';
const SOURCE = 'KBO Public Search webservice' as const;
type Environment = Record<string, string | undefined>;
type XmlNode = Record<string, unknown>;
export interface KboCompany {
  enterprise_number: string;
  name: string;
  country: 'BE';
  legal_person: true;
  active: boolean;
  address: string;
  postcode: string;
  city: string;
  email: string;
  phone: string;
  website: string;
  activities: { code: string; version: string }[];
  data_source: typeof SOURCE;
  source_updated_at: string | null;
  match_confidence: 'enterprise_number';
}
export function kboStatus(env: Environment = process.env) {
  const enabled = env.KBO_ENABLED === 'true',
    terms = env.KBO_TERMS_CONFIRMED === 'true';
  const credentials = Boolean(env.BCE_WS_USERNAME?.trim() && env.BCE_WS_PASSWORD?.trim());
  const configured = enabled && terms && credentials;
  return {
    configured,
    status: !enabled
      ? 'not_configured'
      : !terms
        ? 'terms_unconfirmed'
        : !credentials
          ? 'credentials_missing'
          : 'configured_not_live_tested',
    coverage: 'BE',
    reason: !enabled
      ? 'KBO is nog niet gekoppeld. Activeer alleen na bevestiging van de officiële toegang en hergebruikvoorwaarden.'
      : !terms
        ? 'De actuele hergebruikvoorwaarden, toegangsrechten en quota moeten eerst bevestigd worden.'
        : !credentials
          ? 'KBO-servercredentials ontbreken.'
          : 'De adapter is geconfigureerd; een echte KBO-zoekopdracht is nog niet als live integratie geverifieerd.',
    provider: SOURCE,
    terms_verified: terms,
    search_available: configured,
    manual_import_available: true,
    capabilities: { number: true, name: true, postcode: false, activity: false },
    live_verified: false,
    unsupported: [
      'Nederlandse KvK',
      'Luxemburgse registers',
      'Regio-/activiteitzoekopdrachten: aanvullende contractverificatie vereist',
    ],
    no_unsolicited_mailing: true,
  };
}
function escapeXml(value: string) {
  return value.replace(
    /[<>&"']/g,
    (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' })[c]!,
  );
}
function object(value: unknown): XmlNode {
  return value && typeof value === 'object' && !Array.isArray(value) ? (value as XmlNode) : {};
}
function text(value: unknown): string {
  if (value === null || value === undefined) return '';
  if (typeof value === 'string' || typeof value === 'number') return String(value).trim();
  const node = object(value);
  return node['#text'] !== undefined ? text(node['#text']) : text(node.Code);
}
function children(value: unknown, key: string): unknown[] {
  const node = object(value),
    v = node[key];
  return v === undefined ? [] : Array.isArray(v) ? v : [v];
}
function descendants(value: unknown, key: string): unknown[] {
  if (Array.isArray(value)) return value.flatMap((v) => descendants(v, key));
  const node = object(value);
  return Object.entries(node).flatMap(([k, v]) =>
    k === key ? (Array.isArray(v) ? v : [v]) : descendants(v, key),
  );
}
function localDescription(value: unknown, key: string, language: string): string {
  const values = children(value, key);
  const entry = values.find((v) => text(object(v).Language) === language) || values[0];
  return text(object(entry).Value) || text(entry);
}
function normalizeNumber(raw: string): string {
  let number = raw
    .trim()
    .replace(/^BE\s*/i, '')
    .replace(/[.\s/-]/g, '');
  if (/^\d{9}$/.test(number)) number = '0' + number;
  if (
    !/^[01]\d{9}$/.test(number) ||
    97 - (Number(number.slice(0, 8)) % 97) !== Number(number.slice(8))
  )
    throw new HttpError(422, 'Ongeldig Belgisch ondernemingsnummer.');
  return number;
}
function parseXml(xml: string): unknown {
  if (/<!DOCTYPE|<!ENTITY/i.test(xml) || XMLValidator.validate(xml) !== true)
    throw new HttpError(502, 'KBO gaf een ongeldige XML-respons.');
  return new XMLParser({
    removeNSPrefix: true,
    ignoreAttributes: true,
    parseTagValue: false,
    trimValues: true,
    processEntities: true,
  }).parse(xml);
}
function parseCompany(
  raw: unknown,
  language: string,
  snapshotDate: string | null,
): KboCompany | null {
  const e = object(raw),
    type = text(e.TypeOfEnterprise) || text(e.Type);
  if (type !== 'ELP') return null; // Never return natural-person enterprises for prospecting.
  let number: string;
  try {
    number = normalizeNumber(text(e.Number) || text(e.EnterpriseNumber));
  } catch {
    return null;
  }
  const name =
    localDescription(e, 'PrimaryDenomination', language) ||
    localDescription(
      children(e, 'Denomination').find(
        (d) => text(object(d).Code) === '001' && !text(object(d).StrikingOff),
      ),
      'Description',
      language,
    );
  if (!name) return null;
  const addresses = children(e, 'Address').filter((a) => !text(object(a).StrikingOff));
  const a = object(
    addresses.find((a) => text(object(object(a).TypeOfAddress).Code) === 'REGO') || addresses[0],
  );
  const country = text(object(a.Country).Code);
  if (country && country !== '150' && country !== 'BE') return null;
  const street = [
    localDescription(a.Street, 'Description', language),
    text(a.HouseNumber),
    text(a.Box),
  ]
    .filter(Boolean)
    .join(' ');
  const postcode = text(a.Zipcode),
    city = localDescription(a.Municipality, 'Description', language);
  const status = text(descendants(e.JuridicalSituation ?? e, 'Status')[0]);
  const contacts = children(e, 'ContactInformation').filter((c) => !text(object(c).StrikingOff));
  const contact = (code: string) =>
    text(object(contacts.find((c) => text(object(c).ContactType) === code)).Value);
  const activities = children(e, 'Activity')
    .filter((a) => !text(object(a).StrikingOff))
    .map((a) => ({ code: text(object(a).Code), version: text(object(a).Version) }))
    .filter((a) => a.code && a.version);
  return {
    enterprise_number: number,
    name,
    country: 'BE',
    legal_person: true,
    active: status === 'AC',
    address: street,
    postcode,
    city,
    email: contact('004'),
    phone: contact('001'),
    website: contact('003'),
    activities,
    data_source: SOURCE,
    source_updated_at: snapshotDate,
    match_confidence: 'enterprise_number',
  };
}
async function soapCall(
  operation: string,
  body: string,
  language: 'nl' | 'fr',
  env: Environment,
  send: typeof fetch,
): Promise<unknown> {
  const username = env.BCE_WS_USERNAME!.trim(),
    password = env.BCE_WS_PASSWORD!;
  const nonce = randomBytes(24),
    created = new Date().toISOString(),
    digest = createHash('sha1').update(nonce).update(created).update(password).digest('base64');
  const id = randomUUID(),
    expires = new Date(Date.now() + 300000).toISOString();
  const xml = `<?xml version="1.0" encoding="UTF-8"?><soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:mes="http://economie.fgov.be/kbopub/webservices/v1/messages" xmlns:dat="http://economie.fgov.be/kbopub/webservices/v1/datamodel" xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd" xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd"><soap:Header><wsse:Security soap:mustUnderstand="1"><wsu:Timestamp wsu:Id="Timestamp-${id}"><wsu:Created>${created}</wsu:Created><wsu:Expires>${expires}</wsu:Expires></wsu:Timestamp><wsse:UsernameToken wsu:Id="UsernameToken-${id}"><wsse:Username>${escapeXml(username)}</wsse:Username><wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest">${digest}</wsse:Password><wsse:Nonce EncodingType="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary">${nonce.toString('base64')}</wsse:Nonce><wsu:Created>${created}</wsu:Created></wsse:UsernameToken></wsse:Security><mes:RequestContext><mes:Id>${id}</mes:Id><mes:Language>${language}</mes:Language></mes:RequestContext></soap:Header><soap:Body>${body}</soap:Body></soap:Envelope>`;
  let response: Response;
  try {
    response = await send(KBO_ENDPOINT, {
      method: 'POST',
      headers: {
        'content-type': 'text/xml; charset=utf-8',
        SOAPAction: `"http://fgov.economie.be/kbopub/${operation}"`,
      },
      body: xml,
      signal: AbortSignal.timeout(12000),
      redirect: 'error',
    });
  } catch {
    throw new HttpError(502, 'KBO is tijdelijk niet bereikbaar. Probeer later opnieuw.');
  }
  // Limit parser work and do not place SOAP bodies or credentials in application logs.
  const raw = await response.text();
  if (raw.length > 2000000)
    throw new HttpError(502, 'KBO-respons overschrijdt de toegestane grootte.');
  const parsed = parseXml(raw),
    fault = descendants(parsed, 'Fault')[0];
  if (!response.ok || fault) {
    const message = text(object(fault).faultstring) || text(descendants(fault, 'Text')[0]);
    if (
      /SecurityError|FailedAuthentication|InvalidSecurity|authenticated/i.test(message) ||
      response.status === 401 ||
      response.status === 403
    )
      throw new HttpError(
        502,
        'KBO heeft de toegangsgegevens geweigerd. Controleer de bronconfiguratie.',
      );
    if (/quota|balance/i.test(message) || response.status === 429)
      throw new HttpError(503, 'Het KBO-quotum is bereikt. Probeer later opnieuw.');
    if (/terms of service|kbo-open-data\/login/i.test(message))
      throw new HttpError(503, 'KBO vereist bevestiging van de actuele gebruiksvoorwaarden.');
    throw new HttpError(502, 'KBO kon de zoekopdracht niet verwerken.');
  }
  const status = text(object(descendants(parsed, 'ReplyStatus')[0]).Code);
  if (status && !['00001', '00003', '00008', '10001', '10003'].includes(status)) {
    if (['00010', '00014', '00016'].includes(status)) return { empty: true };
    throw new HttpError(502, 'KBO gaf geen bruikbaar zoekresultaat.');
  }
  return parsed;
}
export async function searchKbo(
  input: { q: string; language?: 'nl' | 'fr'; postcode?: string; activity?: string },
  options: { env?: Environment; fetch?: typeof fetch } = {},
) {
  const env = options.env ?? process.env,
    status = kboStatus(env);
  if (!status.configured) throw new HttpError(503, status.reason);
  if (input.postcode?.trim() || input.activity?.trim())
    throw new HttpError(
      422,
      'Regio- en activiteitfilters zijn nog niet geverifieerd voor deze bron. Zoek op naam of ondernemingsnummer.',
    );
  const q = input.q.trim(),
    language = input.language === 'fr' ? 'fr' : 'nl';
  if (q.length < 2 || q.length > 100)
    throw new HttpError(
      422,
      'Vul een bedrijfsnaam van 2 tot 100 tekens of een geldig ondernemingsnummer in.',
    );
  const isNumber = /^(?:BE\s*)?[\d.\s/-]+$/i.test(q);
  let operation: string, body: string;
  if (isNumber) {
    const number = normalizeNumber(q);
    operation = 'ReadEnterprise';
    body = `<mes:ReadEnterpriseRequest><dat:EnterpriseNumber>${number}</dat:EnterpriseNumber></mes:ReadEnterpriseRequest>`;
  } else {
    operation = 'ReadEnterpriseByPhoneme';
    body = `<mes:ReadEnterpriseByPhonemeRequest>${q
      .split(/\s+/)
      .slice(0, 10)
      .map((word) => `<mes:Phoneme>${escapeXml(word)}</mes:Phoneme>`)
      .join(
        '',
      )}<mes:TypeOfEnterprise>ELP</mes:TypeOfEnterprise><mes:ActiveFilter>true</mes:ActiveFilter></mes:ReadEnterpriseByPhonemeRequest>`;
  }
  const parsed = await soapCall(operation, body, language, env, options.fetch ?? fetch);
  const date = text(descendants(parsed, 'SnapshotDate')[0]),
    snapshotDate = /^\d{4}-\d{2}-\d{2}(?:T.*)?$/.test(date) ? date : null;
  const companies = descendants(parsed, 'Enterprise')
    .map((e) => parseCompany(e, language, snapshotDate))
    .filter((c): c is KboCompany => Boolean(c));
  const items = [...new Map(companies.map((c) => [c.enterprise_number, c])).values()];
  return {
    items,
    snapshotDate,
    truncated: text(object(descendants(parsed, 'ReplyStatus')[0]).Code) === '00008',
    source: SOURCE,
    live_verified: false,
  };
}
