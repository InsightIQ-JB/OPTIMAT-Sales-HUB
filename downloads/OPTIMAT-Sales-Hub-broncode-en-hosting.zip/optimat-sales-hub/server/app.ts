import express from 'express';
import { existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { ZodError } from 'zod';
import { db, audit, id, now } from './db.js';
import {
  authRouter,
  adminRouter,
  requireAuth,
  csrfProtection,
  publicUser,
  requireRoles,
} from './auth.js';
import { webhookHandler, integrationsRouter } from './intake.js';
import { crmRouter } from './crm.js';
import { reportsRouter } from './reporting.js';
import { prospectingRouter } from './prospecting.js';
import { privacyRouter } from './privacy.js';
import { HttpError, wrap } from './errors.js';
import { z } from 'zod';
import { sourceAttachmentHandler } from './source-attachments.js';
import { inventoryHandler, connectorAdminRouter } from './connectors.js';
export function createApp(_options: { worker?: boolean } = {}) {
  const app = express();
  app.disable('x-powered-by');
  if (process.env.TRUST_PROXY === '1') app.set('trust proxy', 1);
  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'same-origin');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader(
      'Content-Security-Policy',
      "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; connect-src 'self'; font-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'; object-src 'none'",
    );
    next();
  });
  app.get('/api/health', (_req, res) => {
    db.prepare('SELECT 1').get();
    res.json({ status: 'ok' });
  });
  app.post(
    '/api/webhooks/:sourceId',
    express.json({
      limit: '1mb',
      verify(req, _res, buf) {
        (req as any).rawBody = Buffer.from(buf);
      },
    }),
    webhookHandler,
  );
  app.post(
    '/api/connectors/:sourceId/sync',
    express.json({
      limit: '2mb',
      verify(req, _res, buf) {
        (req as any).rawBody = Buffer.from(buf);
      },
    }),
    inventoryHandler,
  );
  app.post(
    '/api/connectors/:sourceId/attachments',
    express.json({
      limit: '7mb',
      verify(req, _res, buf) {
        (req as any).rawBody = Buffer.from(buf);
      },
    }),
    sourceAttachmentHandler,
  );
  app.use(express.json({ limit: '7mb' }));
  app.use('/api', (_req, res, next) => {
    res.setHeader('Cache-Control', 'no-store');
    next();
  });
  app.use('/api/auth', authRouter);
  app.use('/api', requireAuth, csrfProtection);
  app.get('/api/users', (req, res) => {
    const users = db.prepare('SELECT * FROM users WHERE active=1 ORDER BY name').all() as any[];
    res.json({
      users: users
        .filter((u) =>
          req.user.role === 'seller'
            ? u.id === req.user.id
            : req.user.role !== 'admin' && req.user.team_id
              ? u.team_id === req.user.team_id
              : true,
        )
        .map(publicUser),
    });
  });
  app.get('/api/catalog', (_req, res) =>
    res.json({
      items: db.prepare('SELECT * FROM catalog WHERE active=1 ORDER BY category,brand,model').all(),
    }),
  );
  app.post(
    '/api/catalog',
    requireRoles('admin'),
    wrap((req, res) => {
      const item = z
        .object({
          category: z.string().min(1).max(100),
          brand: z.string().max(100).optional(),
          model: z.string().max(150).optional(),
        })
        .parse(req.body);
      const itemId = id();
      db.prepare('INSERT INTO catalog(id,category,brand,model) VALUES (?,?,?,?)').run(
        itemId,
        item.category,
        item.brand || null,
        item.model || null,
      );
      audit(req.user.id, 'catalog', itemId, 'created');
      res.status(201).json({ id: itemId, ...item });
    }),
  );
  app.get('/api/views', (req, res) =>
    res.json({
      items: (
        db
          .prepare('SELECT * FROM saved_views WHERE user_id=? ORDER BY name')
          .all(req.user.id) as any[]
      ).map((v) => ({ ...v, filters: JSON.parse(v.filters_json) })),
    }),
  );
  app.post(
    '/api/views',
    wrap((req, res) => {
      const v = z
        .object({ name: z.string().min(1).max(100), filters: z.record(z.string().max(300)) })
        .parse(req.body);
      const vid = id();
      db.prepare('INSERT INTO saved_views VALUES (?,?,?,?)').run(
        vid,
        req.user.id,
        v.name,
        JSON.stringify(v.filters),
      );
      res.status(201).json({ id: vid, ...v });
    }),
  );
  app.delete('/api/views/:id', (req, res) => {
    db.prepare('DELETE FROM saved_views WHERE id=? AND user_id=?').run(
      String(req.params.id),
      req.user.id,
    );
    res.json({ ok: true });
  });
  app.use('/api/admin', adminRouter);
  app.use('/api/integrations', connectorAdminRouter, integrationsRouter);
  app.use('/api/reports', reportsRouter);
  app.use('/api/prospecting', prospectingRouter);
  app.use('/api', privacyRouter);
  app.use('/api', crmRouter);
  app.use('/api', (_req, _res, next) => next(new HttpError(404, 'API-route niet gevonden.')));
  const dist = resolve('dist');
  if (existsSync(dist)) {
    app.use(express.static(dist, { index: false }));
    app.get('/{*path}', (_req, res) => res.sendFile(resolve(dist, 'index.html')));
  }
  app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    if (err instanceof ZodError) {
      res.status(400).json({
        error: 'Controleer de ingevoerde gegevens.',
        issues: err.issues.map((i) => ({ path: i.path.join('.'), message: i.message })),
      });
      return;
    }
    if (err instanceof HttpError) {
      res.status(err.status).json({ error: err.message });
      return;
    }
    if (err?.type === 'entity.too.large') {
      res.status(413).json({ error: 'Het bestand of verzoek is te groot.' });
      return;
    }
    if (err instanceof SyntaxError && 'body' in err) {
      res.status(400).json({ error: 'Ongeldige JSON.' });
      return;
    }
    if (err?.code?.startsWith('ERR_SQLITE') && /UNIQUE/.test(err.message)) {
      res.status(409).json({ error: 'Dit record bestaat al.' });
      return;
    }
    console.error('API_ERROR', { name: err?.name, code: err?.code || 'INTERNAL' });
    res.status(500).json({
      error: 'De actie is niet gelukt. Probeer opnieuw of neem contact op met de beheerder.',
    });
  });
  return app;
}
