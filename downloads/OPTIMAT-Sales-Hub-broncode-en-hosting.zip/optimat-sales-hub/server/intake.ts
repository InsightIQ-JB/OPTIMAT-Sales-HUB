import { Router, type RequestHandler } from 'express';
import { createHash } from 'node:crypto';
import { sourceMetadata, formMetadata } from './connectors.js';
import { verifySourceRequest } from './source-auth.js';
import { z } from 'zod';
import { db, id, now, json, transaction, audit } from './db.js';
import { HttpError, wrap } from './errors.js';
import { requireRoles } from './auth.js';
import { snapshotRequest } from './history.js';
import { isErased } from './tombstones.js';
import type { BusinessField, IntakeEvent } from '../shared/domain.js';
const date = z.string().datetime({ offset: true });
export const eventSchema = z.object({
  event_id: z.string().min(1).max(200),
  submission_id: z.string().min(1).max(200),
  version: z.number().int().min(1),
  occurred_at: date,
  submitted_at: date,
  provider: z.string().min(1).max(80),
  form_id: z.string().min(1).max(191),
  form_name: z.string().min(1).max(200),
  language: z.string().max(20).optional(),
  purpose: z.enum(['commercial', 'support', 'recruitment', 'newsletter']),
  intents: z.array(z.string().max(80)).max(20),
  fields: z
    .array(
      z
        .object({
          id: z.string().min(1).max(200),
          label: z.string().max(500),
          type: z.string().max(60),
          value: z.unknown(),
          options: z.array(z.unknown()).max(500).optional(),
        })
        .transform((f) => ({ ...f, value: f.value ?? null })),
    )
    .max(300),
  context: z
    .preprocess(
      (value) => (Array.isArray(value) && value.length === 0 ? {} : value),
      z.record(z.unknown()),
    )
    .optional(),
});
const blocked =
  /(captcha|password|passwd|secret|token|honeypot|authorization|cookie|nonce|csrf|api.?key|session.?id|gclid|fbclid|msclkid|ip_address|user_agent|^ip$)/i;
function cleanValue(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(cleanValue);
  if (value && typeof value === 'object')
    return Object.fromEntries(
      Object.entries(value)
        .filter(([k]) => !blocked.test(k))
        .map(([k, v]) => [k, cleanValue(v)]),
    );
  return value;
}
export function cleanFields(fields: BusinessField[]) {
  return fields
    .filter((f) => ![f.id, f.type, f.label].some((value) => blocked.test(value)))
    .map((f) => ({
      ...f,
      value: cleanValue(f.value),
      ...(f.options ? { options: cleanValue(f.options) as unknown[] } : {}),
    }));
}
const targets = [
  'company_name',
  'name',
  'email',
  'phone',
  'enterprise_number',
  'country',
  'address',
  'postcode',
  'city',
  'region',
  'business_unit',
  'brand',
  'machine',
  'model',
  'message',
  'language',
  'campaign',
  'job_title',
];
export const mappingSchema = z.record(z.enum(targets as [string, ...string[]]));
function canonicalValue(value: unknown): string {
  if (value === null || value === undefined) return '';
  if (Array.isArray(value)) return value.map(canonicalValue).filter(Boolean).join(', ');
  if (typeof value === 'object') {
    const object = value as Record<string, unknown>;
    if (Object.hasOwn(object, 'value')) return canonicalValue(object.value);
    return Object.values(object).map(canonicalValue).filter(Boolean).join(' ');
  }
  return String(value);
}
export function mapFields(fields: BusinessField[], mapping: Record<string, string>) {
  const mapped: Record<string, unknown> = {},
    extra: BusinessField[] = [];
  const clean = cleanFields(fields),
    topIds = new Set(clean.map((field) => field.id));
  const add = (fieldId: string, value: unknown) => {
    const target = mapping[fieldId];
    if (!target) return;
    const normalized = canonicalValue(value);
    if (
      mapped[target] !== undefined &&
      ['name', 'address', 'machine', 'model', 'message'].includes(target)
    ) {
      const previous = String(mapped[target]);
      if (previous !== normalized && normalized)
        mapped[target] = previous + (target === 'message' ? '\n' : ' ') + normalized;
    } else mapped[target] = normalized;
  };
  for (const field of clean) {
    if (mapping[field.id]) add(field.id, field.value);
    else extra.push(field);
    // Backwards compatible compound mapping; newer GF adapters also emit flattened inputs.
    if (field.value && typeof field.value === 'object' && !Array.isArray(field.value))
      for (const [key, value] of Object.entries(field.value))
        if (!topIds.has(key) && mapping[key]) add(key, value);
  }
  return { mapped, extra };
}
export function normalizeCountry(value: unknown) {
  const raw = String(value || '')
    .trim()
    .toUpperCase();
  const countries: Record<string, string> = {
    BE: 'BE',
    BELGIË: 'BE',
    BELGIE: 'BE',
    BELGIQUE: 'BE',
    BELGIUM: 'BE',
    NL: 'NL',
    NEDERLAND: 'NL',
    NETHERLANDS: 'NL',
    'PAYS-BAS': 'NL',
    LU: 'LU',
    LUXEMBOURG: 'LU',
    LUXEMBURG: 'LU',
  };
  return countries[raw] || raw;
}
export function validEnterprise(value: unknown, country: string) {
  const number = String(value || '').replace(/\D/g, '');
  if (country !== 'BE' || number.length !== 10) return null;
  return 97 - (Number(number.slice(0, 8)) % 97) === Number(number.slice(8)) ? number : null;
}
function stringVal(v: unknown) {
  if (v === null || v === undefined) return '';
  return (typeof v === 'object' ? JSON.stringify(v) : String(v)).slice(0, 10000);
}
function canonicalDate(value: string) {
  return new Date(value).toISOString();
}
function sanitizeEvent(input: IntakeEvent): IntakeEvent {
  return {
    ...input,
    fields: cleanFields(input.fields),
    context: cleanValue(input.context || {}) as Record<string, unknown>,
  };
}
function eventDigest(event: IntakeEvent) {
  return createHash('sha256').update(json(event)).digest('hex');
}
export function receiveEvent(sourceId: string, input: IntakeEvent) {
  const event = sanitizeEvent(eventSchema.parse(input));
  if (isErased(sourceId, event.provider, event.form_id, event.submission_id))
    return { id: null, duplicate: true, status: 'ignored_erased' };
  const existing = db
    .prepare('SELECT * FROM events WHERE source_id=? AND event_id=?')
    .get(sourceId, event.event_id) as any;
  const digest = eventDigest(event);
  if (existing) {
    if (existing.payload_hash !== digest)
      throw new HttpError(409, 'Event-ID is al gebruikt voor andere inhoud.');
    return { id: existing.id, duplicate: true, status: existing.status };
  }
  const eventId = id();
  db.prepare(
    'INSERT INTO events (id,source_id,event_id,submission_id,provider,form_id,source_version,occurred_at,received_at,payload_json,payload_hash,status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
  ).run(
    eventId,
    sourceId,
    event.event_id,
    event.submission_id,
    event.provider,
    event.form_id,
    event.version,
    canonicalDate(event.occurred_at),
    now(),
    json(event),
    digest,
    'pending',
  );
  db.prepare('UPDATE sources SET last_received_at=? WHERE id=?').run(now(), sourceId);
  return { id: eventId, duplicate: false, status: 'pending' };
}
export const webhookHandler: RequestHandler = wrap((req, res) => {
  const source = verifySourceRequest(req);
  const input = eventSchema.parse(req.body);
  const result = transaction(() => receiveEvent(source.id, input));
  res.status(202).json({ accepted: true, event_id: input.event_id, ...result });
});
function enrichMissing(request: any, mapped: Record<string, unknown>) {
  const c = db.prepare('SELECT * FROM companies WHERE id=?').get(request.company_id) as any;
  const country = c.country || normalizeCountry(mapped.country);
  const enterprise = validEnterprise(mapped.enterprise_number, country);
  const conflict = enterprise
    ? db
        .prepare('SELECT id FROM companies WHERE country=? AND enterprise_number=? AND id<>?')
        .get(country, enterprise, c.id)
    : null;
  db.prepare(
    "UPDATE companies SET name=CASE WHEN name='Bedrijf onbekend' AND ?<>'' THEN ? ELSE name END,country=CASE WHEN country='' THEN ? ELSE country END,enterprise_number=COALESCE(enterprise_number,?),updated_at=?,version=version+1 WHERE id=?",
  ).run(
    stringVal(mapped.company_name),
    stringVal(mapped.company_name),
    country,
    conflict ? null : enterprise,
    now(),
    c.id,
  );
  let contactId = request.contact_id;
  if (contactId) {
    db.prepare(
      "UPDATE contacts SET name=coalesce(nullif(name,''),?),email=coalesce(nullif(email,''),?),phone=coalesce(nullif(phone,''),?),job_title=coalesce(nullif(job_title,''),?),language=coalesce(nullif(language,''),?) WHERE id=?",
    ).run(
      stringVal(mapped.name) || null,
      stringVal(mapped.email).toLowerCase() || null,
      stringVal(mapped.phone) || null,
      stringVal(mapped.job_title) || null,
      stringVal(mapped.language) || null,
      contactId,
    );
  } else if (mapped.name || mapped.email || mapped.phone) {
    const existing = mapped.email
      ? (db
          .prepare('SELECT id FROM contacts WHERE company_id=? AND email=?')
          .get(c.id, stringVal(mapped.email).toLowerCase()) as any)
      : null;
    contactId = existing?.id || id();
    if (!existing)
      db.prepare(
        'INSERT INTO contacts(id,company_id,name,email,phone,job_title,language,created_at) VALUES (?,?,?,?,?,?,?,?)',
      ).run(
        contactId,
        c.id,
        stringVal(mapped.name) || null,
        stringVal(mapped.email).toLowerCase() || null,
        stringVal(mapped.phone) || null,
        stringVal(mapped.job_title) || null,
        stringVal(mapped.language) || null,
        now(),
      );
    db.prepare('UPDATE requests SET contact_id=? WHERE id=?').run(contactId, request.id);
  }
  if (request.location_id) {
    db.prepare(
      "UPDATE locations SET address=coalesce(nullif(address,''),?),postcode=coalesce(nullif(postcode,''),?),city=coalesce(nullif(city,''),?),country=CASE WHEN country='' THEN ? ELSE country END,version=version+1 WHERE id=? AND manually_confirmed=0",
    ).run(
      stringVal(mapped.address) || null,
      stringVal(mapped.postcode) || null,
      stringVal(mapped.city) || null,
      country,
      request.location_id,
    );
  } else if (mapped.address || mapped.postcode || mapped.city) {
    const locationId = id();
    db.prepare(
      'INSERT INTO locations(id,company_id,country,address,postcode,city) VALUES (?,?,?,?,?,?)',
    ).run(
      locationId,
      c.id,
      country,
      stringVal(mapped.address) || null,
      stringVal(mapped.postcode) || null,
      stringVal(mapped.city) || null,
    );
    db.prepare('UPDATE requests SET location_id=? WHERE id=?').run(locationId, request.id);
  }
}
function processEvent(row: any) {
  const e = JSON.parse(row.payload_json) as IntakeEvent;
  let form = db
    .prepare('SELECT * FROM forms WHERE source_id=? AND provider=? AND form_id=?')
    .get(row.source_id, e.provider, e.form_id) as any;
  if (!form) {
    const formId = id();
    db.prepare(
      'INSERT INTO forms(id,source_id,provider,form_id,name,purpose,mapping_json,version,coverage,updated_at) VALUES (?,?,?,?,?,?,?,1,?,?)',
    ).run(
      formId,
      row.source_id,
      e.provider,
      e.form_id,
      e.form_name,
      e.purpose,
      '{}',
      'contract_only',
      now(),
    );
    form = db.prepare('SELECT * FROM forms WHERE id=?').get(formId);
    db.prepare('INSERT INTO mapping_history VALUES (?,?,?,?,?,?)').run(
      id(),
      formId,
      1,
      '{}',
      null,
      now(),
    );
  }
  if (
    e.purpose === 'commercial' &&
    (form.purpose === 'unclassified' ||
      (form.purpose === 'commercial' && Object.keys(JSON.parse(form.mapping_json)).length === 0))
  ) {
    db.prepare(
      "UPDATE events SET status='awaiting_mapping',error_code='FORM_MAPPING_REQUIRED' WHERE id=?",
    ).run(row.id);
    return;
  }
  if (form.purpose !== 'commercial' || e.purpose !== 'commercial') {
    db.prepare('UPDATE events SET status=?,processed_at=?,error_code=NULL WHERE id=?').run(
      'excluded',
      now(),
      row.id,
    );
    db.prepare('UPDATE events SET payload_json=? WHERE id=?').run(
      json({ ...e, fields: [], context: {} }),
      row.id,
    );
    return;
  }
  const { mapped } = mapFields(e.fields, JSON.parse(form.mapping_json));
  const old = db
    .prepare(
      'SELECT * FROM requests WHERE source_id=? AND provider=? AND form_id=? AND submission_id=?',
    )
    .get(row.source_id, e.provider, form.id, e.submission_id) as any;
  if (
    old &&
    (e.version <= old.source_version || canonicalDate(e.occurred_at) < old.source_occurred_at)
  ) {
    db.prepare('UPDATE events SET status=?,processed_at=? WHERE id=?').run(
      'ignored_stale',
      now(),
      row.id,
    );
    return;
  }
  const context = e.context || {};
  const unit = ['Wood', 'Stone', 'Glass'].includes(stringVal(mapped.business_unit))
    ? stringVal(mapped.business_unit)
    : 'Unknown';
  if (old) {
    enrichMissing(old, mapped);
    db.prepare(
      'UPDATE requests SET source_version=?,source_occurred_at=?,business_unit=?,brand=?,machine=?,model=?,message=?,language=?,intents_json=?,campaign=?,context_json=?,fields_json=?,mapped_json=?,mapping_version=?,updated_at=?,version=version+1 WHERE id=?',
    ).run(
      e.version,
      canonicalDate(e.occurred_at),
      unit,
      stringVal(mapped.brand) || old.brand,
      stringVal(mapped.machine) || old.machine,
      stringVal(mapped.model) || old.model,
      stringVal(mapped.message) || old.message,
      stringVal(mapped.language) || e.language || old.language,
      json(e.intents),
      stringVal(mapped.campaign) || old.campaign,
      json(context),
      json(e.fields),
      json(mapped),
      form.version,
      now(),
      old.id,
    );
    db.prepare(
      'INSERT INTO activities(id,request_id,company_id,kind,body,created_at) VALUES (?,?,?,?,?,?)',
    ).run(
      id(),
      old.id,
      old.company_id,
      'source_update',
      `Bron bijgewerkt naar versie ${e.version}.`,
      now(),
    );
    snapshotRequest(old.id);
  } else {
    const country = normalizeCountry(mapped.country);
    const enterprise = validEnterprise(mapped.enterprise_number, country);
    let company = enterprise
      ? (db
          .prepare('SELECT * FROM companies WHERE country=? AND enterprise_number=?')
          .get(country, enterprise) as any)
      : null;
    if (!company) {
      const companyId = id();
      db.prepare(
        'INSERT INTO companies(id,name,country,enterprise_number,owner_id,data_source,match_confidence,created_at,updated_at) VALUES (?,?,?,?,NULL,?,?,?,?)',
      ).run(
        companyId,
        stringVal(mapped.company_name) || 'Bedrijf onbekend',
        country,
        enterprise,
        'wordpress',
        enterprise ? 'validated_enterprise_number' : 'unreviewed',
        now(),
        now(),
      );
      company = db.prepare('SELECT * FROM companies WHERE id=?').get(companyId);
    }
    let contactId: string | null = null;
    const email = stringVal(mapped.email).toLowerCase();
    if (email || mapped.name || mapped.phone) {
      const existing = email
        ? (db
            .prepare('SELECT id FROM contacts WHERE company_id=? AND email=?')
            .get(company.id, email) as any)
        : null;
      contactId = existing?.id || id();
      if (!existing)
        db.prepare(
          'INSERT INTO contacts(id,company_id,name,email,phone,job_title,language,created_at) VALUES (?,?,?,?,?,?,?,?)',
        ).run(
          contactId,
          company.id,
          stringVal(mapped.name) || null,
          email || null,
          stringVal(mapped.phone) || null,
          stringVal(mapped.job_title) || null,
          stringVal(mapped.language) || e.language || null,
          now(),
        );
    }
    let locationId: string | null = null;
    if (mapped.address || mapped.postcode || mapped.city) {
      const address = stringVal(mapped.address);
      const postcode = stringVal(mapped.postcode);
      const city = stringVal(mapped.city);
      const existing = db
        .prepare(
          "SELECT id FROM locations WHERE company_id=? AND country=? AND coalesce(address,'')=? AND coalesce(postcode,'')=? AND coalesce(city,'')=?",
        )
        .get(company.id, country, address, postcode, city) as any;
      locationId = existing?.id || id();
      if (!existing)
        db.prepare(
          'INSERT INTO locations(id,company_id,country,address,postcode,city,region) VALUES (?,?,?,?,?,?,?)',
        ).run(
          locationId,
          company.id,
          country,
          address,
          postcode,
          city,
          stringVal(mapped.region) || null,
        );
    }
    const requestId = id();
    db.prepare(
      'INSERT INTO requests (id,source_id,form_id,provider,submission_id,source_version,source_occurred_at,company_id,contact_id,location_id,business_unit,brand,machine,model,message,language,intents_json,campaign,context_json,fields_json,mapped_json,mapping_version,purpose,is_test,submitted_at,received_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
    ).run(
      requestId,
      row.source_id,
      form.id,
      e.provider,
      e.submission_id,
      e.version,
      canonicalDate(e.occurred_at),
      company.id,
      contactId,
      locationId,
      unit,
      stringVal(mapped.brand) || null,
      stringVal(mapped.machine) || null,
      stringVal(mapped.model) || null,
      stringVal(mapped.message) || null,
      stringVal(mapped.language) || e.language || null,
      json(e.intents),
      stringVal(mapped.campaign) || null,
      json(context),
      json(e.fields),
      json(mapped),
      form.version,
      'commercial',
      context.is_test === true ? 1 : 0,
      canonicalDate(e.submitted_at),
      row.received_at,
      now(),
    );
    db.prepare(
      'INSERT INTO activities(id,request_id,company_id,kind,body,created_at) VALUES (?,?,?,?,?,?)',
    ).run(
      id(),
      requestId,
      company.id,
      'submission',
      'Aanvraag ontvangen vanuit WordPress.',
      row.received_at,
    );
    audit(null, 'request', requestId, 'received', {
      event_id: row.id,
      mapping_version: form.version,
    });
    snapshotRequest(requestId, row.received_at);
  }
  db.prepare('UPDATE events SET status=?,processed_at=?,error_code=NULL WHERE id=?').run(
    'processed',
    now(),
    row.id,
  );
}
export async function processPending(limit = 50) {
  const rows = db
    .prepare(
      "SELECT * FROM events WHERE status IN ('pending','retry') AND (next_attempt_at IS NULL OR next_attempt_at<=?) ORDER BY received_at LIMIT ?",
    )
    .all(now(), limit) as any[];
  let processed = 0;
  for (const row of rows) {
    try {
      transaction(() => processEvent(row));
      processed++;
    } catch {
      const attempts = row.attempts + 1;
      db.prepare(
        'UPDATE events SET status=?,attempts=?,next_attempt_at=?,error_code=? WHERE id=?',
      ).run(
        attempts >= 8 ? 'failed' : 'retry',
        attempts,
        new Date(Date.now() + Math.min(3600000, 1000 * 2 ** attempts)).toISOString(),
        'PROCESSING_FAILED',
        row.id,
      );
    }
  }
  return { processed, total: rows.length };
}
export const integrationsRouter = Router();
integrationsRouter.use(requireRoles('admin'));
integrationsRouter.get('/', (_req, res) => {
  const sources = (db.prepare('SELECT * FROM sources ORDER BY name').all() as any[]).map((s) => ({
    ...s,
    secret_configured: !!process.env[s.secret_env],
    previous_secret_configured: !!(s.previous_secret_env && process.env[s.previous_secret_env]),
    status: s.last_live_test_at
      ? 'live_tested'
      : s.last_received_at
        ? 'contract_only'
        : 'not_configured',
  }));
  res.json({
    sources: sources.map((source) => ({ ...source, ...sourceMetadata(source.id) })),
    forms: (db.prepare('SELECT * FROM forms ORDER BY name').all() as any[]).map((f) => ({
      ...f,
      mapping: JSON.parse(f.mapping_json),
      ...formMetadata(f.id),
    })),
    events: db
      .prepare(
        'SELECT id,source_id,event_id,provider,form_id,source_version,status,attempts,received_at,processed_at,error_code FROM events ORDER BY received_at DESC LIMIT 100',
      )
      .all(),
    inventory_complete:
      sources.length > 0 && sources.every((source) => sourceMetadata(source.id).inventory_complete),
    inventory_scope: 'gravity_forms_catalog',
    inventory_note:
      'Alleen geconfigureerde formulieren zichtbaar. Volledige WordPress-inventaris en echte testinzending per bron zijn nog vereist.',
  });
});
const secretName = z
  .string()
  .regex(/^[A-Za-z_][A-Za-z0-9_]*$/)
  .max(120);
integrationsRouter.post(
  '/sources',
  wrap((req, res) => {
    const s = z
      .object({
        name: z.string().min(1).max(150),
        site_url: z.string().url(),
        secret_env: secretName,
        previous_secret_env: secretName.optional(),
      })
      .parse(req.body);
    if (new URL(s.site_url).protocol !== 'https:')
      throw new HttpError(400, 'Bronwebsite moet HTTPS gebruiken.');
    const sourceId = id();
    db.prepare(
      'INSERT INTO sources (id,name,site_url,secret_env,previous_secret_env,created_at) VALUES (?,?,?,?,?,?)',
    ).run(sourceId, s.name, s.site_url, s.secret_env, s.previous_secret_env || null, now());
    audit(req.user.id, 'source', sourceId, 'created');
    res.status(201).json({ id: sourceId, ...s, secret_configured: !!process.env[s.secret_env] });
  }),
);
integrationsRouter.patch(
  '/sources/:id',
  wrap((req, res) => {
    const s = z
      .object({
        secret_env: secretName,
        previous_secret_env: secretName.nullable().optional(),
        enabled: z.boolean().optional(),
      })
      .parse(req.body);
    if (!db.prepare('SELECT id FROM sources WHERE id=?').get(String(req.params.id)))
      throw new HttpError(404, 'Bron niet gevonden.');
    db.prepare(
      'UPDATE sources SET secret_env=?,previous_secret_env=?,enabled=coalesce(?,enabled) WHERE id=?',
    ).run(
      s.secret_env,
      s.previous_secret_env || null,
      s.enabled === undefined ? null : s.enabled ? 1 : 0,
      String(req.params.id),
    );
    audit(req.user.id, 'source', String(req.params.id), 'rotation_updated');
    res.json({ ok: true });
  }),
);
integrationsRouter.post(
  '/forms',
  wrap((req, res) => {
    const f = z
      .object({
        source_id: z.string(),
        provider: z.string().min(1).max(80),
        form_id: z.string().min(1).max(191),
        name: z.string().min(1).max(200),
        purpose: z.enum(['unclassified', 'commercial', 'support', 'recruitment', 'newsletter']),
        mapping: mappingSchema,
        version: z.number().int().positive(),
      })
      .parse(req.body);
    if (!db.prepare('SELECT id FROM sources WHERE id=?').get(f.source_id))
      throw new HttpError(400, 'Onbekende bron.');
    const result = transaction(() => {
      const old = db
        .prepare('SELECT * FROM forms WHERE source_id=? AND provider=? AND form_id=?')
        .get(f.source_id, f.provider, f.form_id) as any;
      if (old && f.version !== old.version)
        throw new HttpError(409, 'Mapping is intussen gewijzigd. Herlaad de configuratie.');
      const formId = old?.id || id();
      const version = old ? old.version + 1 : 1;
      if (old)
        db.prepare(
          'UPDATE forms SET name=?,purpose=?,mapping_json=?,version=?,updated_at=? WHERE id=?',
        ).run(f.name, f.purpose, json(f.mapping), version, now(), formId);
      else
        db.prepare(
          'INSERT INTO forms (id,source_id,provider,form_id,name,purpose,mapping_json,version,updated_at) VALUES (?,?,?,?,?,?,?,?,?)',
        ).run(
          formId,
          f.source_id,
          f.provider,
          f.form_id,
          f.name,
          f.purpose,
          json(f.mapping),
          version,
          now(),
        );
      db.prepare('INSERT INTO mapping_history VALUES (?,?,?,?,?,?)').run(
        id(),
        formId,
        version,
        json(f.mapping),
        req.user.id,
        now(),
      );
      audit(req.user.id, 'form', formId, 'mapping_updated', { version });
      db.prepare(
        "UPDATE events SET status='pending',error_code=NULL,next_attempt_at=NULL WHERE source_id=? AND provider=? AND form_id=? AND status='awaiting_mapping'",
      ).run(f.source_id, f.provider, f.form_id);
      return { id: formId, version };
    });
    res.json(result);
  }),
);
integrationsRouter.get('/form-history/:id', (req, res) =>
  res.json({
    items: db
      .prepare('SELECT * FROM mapping_history WHERE form_id=? ORDER BY version DESC')
      .all(String(req.params.id)),
  }),
);
integrationsRouter.post(
  '/preview',
  wrap((req, res) => {
    const input = z
      .object({ fields: eventSchema.shape.fields, mapping: mappingSchema })
      .parse(req.body);
    res.json(mapFields(input.fields, input.mapping));
  }),
);
integrationsRouter.post(
  '/events/:id/retry',
  wrap((req, res) => {
    const event = db.prepare('SELECT * FROM events WHERE id=?').get(String(req.params.id)) as any;
    if (!event) throw new HttpError(404, 'Event niet gevonden.');
    if (!['failed', 'retry'].includes(event.status))
      throw new HttpError(400, 'Alleen mislukte events kunnen opnieuw worden aangeboden.');
    db.prepare(
      "UPDATE events SET status='pending',attempts=0,next_attempt_at=NULL,error_code=NULL WHERE id=?",
    ).run(event.id);
    audit(req.user.id, 'event', event.id, 'retry');
    res.json({ ok: true });
  }),
);
const importSchema = z.object({
  source_id: z.string(),
  events: z.array(eventSchema).min(1).max(500),
});
for (const action of ['preview', 'commit'])
  integrationsRouter.post(
    '/import/' + action,
    wrap((req, res) => {
      const input = importSchema.parse(req.body);
      if (!db.prepare('SELECT id FROM sources WHERE id=?').get(input.source_id))
        throw new HttpError(400, 'Onbekende bron.');
      const seen = new Map<string, string>();
      const results = input.events.map((e, index) => {
        const digest = eventDigest(sanitizeEvent(e));
        const existing = db
          .prepare('SELECT id,payload_hash FROM events WHERE source_id=? AND event_id=?')
          .get(input.source_id, e.event_id) as any;
        const previous = seen.get(e.event_id);
        seen.set(e.event_id, digest);
        const erased = isErased(input.source_id, e.provider, e.form_id, e.submission_id);
        return {
          index,
          event_id: e.event_id,
          duplicate: !!existing || !!previous,
          ignored_erased: erased,
          conflict:
            !erased &&
            ((!!existing && existing.payload_hash !== digest) ||
              (!!previous && previous !== digest)),
          submitted_at: e.submitted_at,
        };
      });
      if (results.some((r) => r.conflict))
        throw new HttpError(409, 'Import bevat conflicterende event-ID’s.');
      if (action === 'commit')
        transaction(() => {
          for (const event of input.events) receiveEvent(input.source_id, event);
          audit(req.user.id, 'import', input.source_id, 'committed', {
            count: input.events.length,
          });
        });
      res.json({
        mode: action,
        total: results.length,
        duplicates: results.filter((r) => r.duplicate).length,
        new: results.filter((r) => !r.duplicate && !r.ignored_erased).length,
        ignored_erased: results.filter((r) => r.ignored_erased).length,
        results,
      });
    }),
  );
/** One worker per application process; synchronous transactions make receipts and processing atomic. */
export function startWorker(intervalMs = 1000) {
  let working = false;
  const timer = setInterval(async () => {
    if (working) return;
    working = true;
    try {
      await processPending();
    } catch {
      console.error('WORKER_ERROR');
    } finally {
      working = false;
    }
  }, intervalMs);
  return () => clearInterval(timer);
}
