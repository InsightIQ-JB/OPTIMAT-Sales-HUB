import { Router } from 'express';
import { createHash } from 'node:crypto';
import { mkdirSync, writeFileSync, readFileSync, unlinkSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { z } from 'zod';
import { db, id, now, audit, transaction } from './db.js';
import { assertWrite, requireRoles, visibleRequest } from './auth.js';
import { eraseSubmission } from './tombstones.js';
import { HttpError, wrap } from './errors.js';

const MAX_BYTES = 5 * 1024 * 1024;
const attachmentRoot = () => resolve(process.env.ATTACHMENT_DIR || '.data/attachments');
const fileSchema = z.object({
  name: z.string().min(1).max(200),
  mime: z.enum(['application/pdf', 'image/png', 'image/jpeg']),
  content_base64: z
    .string()
    .min(4)
    .max(Math.ceil(MAX_BYTES / 3) * 4),
});
function filePath(key: string) {
  if (!/^[0-9a-f-]{36}$/.test(key)) throw new HttpError(500, 'Bijlage niet beschikbaar.');
  return join(attachmentRoot(), key);
}
function filename(value: string, mime: string) {
  const name =
    value
      .replace(/[\x00-\x1f\x7f<>:"/\\|?*]/g, '_')
      .trim()
      .slice(0, 140) || 'bijlage';
  const ext = mime === 'application/pdf' ? '.pdf' : mime === 'image/png' ? '.png' : '.jpg';
  return name.replace(/\.[^.]+$/, '') + ext;
}
function validMagic(bytes: Buffer, mime: string) {
  return mime === 'application/pdf'
    ? bytes.subarray(0, 5).equals(Buffer.from('%PDF-'))
    : mime === 'image/png'
      ? bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))
      : bytes.length >= 3 && bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255;
}
function publicAttachment(row: any) {
  return {
    id: row.id,
    request_id: row.request_id,
    name: row.original_name,
    mime: row.mime,
    size_bytes: row.size_bytes,
    sha256: row.sha256,
    uploaded_by: row.uploaded_by,
    created_at: row.created_at,
  };
}
/** Retry private-file cleanup without retaining a person's name or request payload. */
export function cleanupDeletedAttachments() {
  const rows = db.prepare('SELECT storage_key FROM attachment_deletion_queue').all() as {
    storage_key: string;
  }[];
  let removed = 0;
  for (const row of rows) {
    try {
      try {
        unlinkSync(filePath(row.storage_key));
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error;
      }
      db.prepare('DELETE FROM attachment_deletion_queue WHERE storage_key=?').run(row.storage_key);
      removed++;
    } catch {
      /* No raw path or request data in general logs. Keep opaque cleanup job for retry. */
    }
  }
  return {
    removed,
    pending: Number(
      (db.prepare('SELECT count(*) AS count FROM attachment_deletion_queue').get() as any).count,
    ),
  };
}

export const privacyRouter = Router();
privacyRouter.get(
  '/requests/:id/attachments',
  wrap((req, res) => {
    const request = visibleRequest(req.user, String(req.params.id));
    res.json({
      items: (
        db
          .prepare('SELECT * FROM attachments WHERE request_id=? ORDER BY created_at')
          .all(request.id) as any[]
      ).map(publicAttachment),
    });
  }),
);
privacyRouter.post(
  '/requests/:id/attachments',
  wrap((req, res) => {
    assertWrite(req.user);
    const request = visibleRequest(req.user, String(req.params.id));
    const input = fileSchema.parse(req.body);
    if (
      !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(input.content_base64)
    )
      throw new HttpError(400, 'Ongeldige bestandsinhoud.');
    const content = Buffer.from(input.content_base64, 'base64');
    if (!content.length || content.length > MAX_BYTES)
      throw new HttpError(400, 'Een bijlage mag maximaal 5 MB groot zijn.');
    if (!validMagic(content, input.mime))
      throw new HttpError(
        400,
        'Bestandsinhoud en bestandstype komen niet overeen. Alleen PDF, PNG en JPEG zijn toegestaan.',
      );
    const attachmentId = id(),
      key = id();
    mkdirSync(attachmentRoot(), { recursive: true, mode: 0o700 });
    const path = filePath(key);
    writeFileSync(path, content, { flag: 'wx', mode: 0o600 });
    try {
      transaction(() => {
        db.prepare(
          'INSERT INTO attachments(id,request_id,storage_key,original_name,mime,size_bytes,sha256,uploaded_by,created_at) VALUES (?,?,?,?,?,?,?,?,?)',
        ).run(
          attachmentId,
          request.id,
          key,
          filename(input.name, input.mime),
          input.mime,
          content.length,
          createHash('sha256').update(content).digest('hex'),
          req.user.id,
          now(),
        );
        audit(req.user.id, 'attachment', attachmentId, 'uploaded', {
          request_id: request.id,
          size_bytes: content.length,
        });
      });
    } catch (error) {
      try {
        unlinkSync(path);
      } catch {
        /* File remains private and can be removed during maintenance. */
      }
      throw error;
    }
    res.status(201).json({
      attachment: publicAttachment(
        db.prepare('SELECT * FROM attachments WHERE id=?').get(attachmentId),
      ),
    });
  }),
);
privacyRouter.get(
  '/attachments/:id',
  wrap((req, res) => {
    const attachment = db
      .prepare('SELECT * FROM attachments WHERE id=?')
      .get(String(req.params.id)) as any;
    if (!attachment) throw new HttpError(404, 'Bijlage niet gevonden.');
    visibleRequest(req.user, attachment.request_id);
    let bytes: Buffer;
    try {
      bytes = readFileSync(filePath(attachment.storage_key));
    } catch {
      throw new HttpError(404, 'Bijlage niet beschikbaar.');
    }
    if (createHash('sha256').update(bytes).digest('hex') !== attachment.sha256)
      throw new HttpError(409, 'De integriteitscontrole van de bijlage is mislukt.');
    res.setHeader('Cache-Control', 'private, no-store');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Content-Security-Policy', "default-src 'none'; sandbox");
    res.type(attachment.mime);
    res.attachment(attachment.original_name);
    res.send(bytes);
  }),
);

privacyRouter.get(
  '/admin/privacy/requests/:id/export',
  requireRoles('admin'),
  wrap((req, res) => {
    const request = visibleRequest(req.user, String(req.params.id));
    const company = db.prepare('SELECT * FROM companies WHERE id=?').get(request.company_id);
    const contact = request.contact_id
      ? db.prepare('SELECT * FROM contacts WHERE id=?').get(request.contact_id)
      : null;
    const location = request.location_id
      ? db.prepare('SELECT * FROM locations WHERE id=?').get(request.location_id)
      : null;
    const activities = db
      .prepare('SELECT * FROM activities WHERE request_id=? ORDER BY created_at')
      .all(request.id);
    const tasks = db
      .prepare('SELECT * FROM tasks WHERE request_id=? ORDER BY created_at')
      .all(request.id);
    const assignments = db
      .prepare('SELECT * FROM assignments WHERE request_id=? ORDER BY created_at')
      .all(request.id);
    const opportunities = db
      .prepare(
        'SELECT o.* FROM opportunities o JOIN opportunity_requests link ON link.opportunity_id=o.id WHERE link.request_id=?',
      )
      .all(request.id);
    const attachments = (
      db.prepare('SELECT * FROM attachments WHERE request_id=?').all(request.id) as any[]
    ).map(publicAttachment);
    res.setHeader('Cache-Control', 'private, no-store');
    res.attachment(`aanvraag-${request.id}.json`);
    res.json({
      exported_at: now(),
      scope:
        'Geselecteerde commerciële aanvraag, bijbehorende gegevens en gekoppelde verkoopkansen; bestanden zijn afzonderlijk beveiligd beschikbaar.',
      request,
      company,
      contact,
      location,
      activities,
      tasks,
      assignments,
      opportunities,
      attachments,
    });
  }),
);
privacyRouter.get(
  '/admin/privacy/retention',
  requireRoles('admin'),
  wrap((_req, res) => {
    const saved = db
      .prepare("SELECT value_json FROM settings WHERE key='retention_days'")
      .get() as any;
    const retentionDays = saved ? JSON.parse(saved.value_json) : 730;
    const cutoff = new Date(Date.now() - Number(retentionDays) * 86400000).toISOString();
    const candidates = db
      .prepare(
        "SELECT r.id,r.submitted_at,r.updated_at,r.status,r.version FROM requests r WHERE r.purpose='commercial' AND r.updated_at<? ORDER BY r.updated_at LIMIT 500",
      )
      .all(cutoff);
    const cleanup = cleanupDeletedAttachments();
    res.json({
      retention_days: retentionDays,
      cutoff,
      enforcement: 'manual_review',
      items: candidates,
      cleanup_pending: cleanup.pending,
      notice:
        'Controleer doelbinding en bewaarplicht vóór gerichte verwijdering. Back-ups en brongegevens in WordPress hebben een eigen bewaartermijn; verwijdering hier wist die kopieën niet automatisch.',
    });
  }),
);
privacyRouter.delete(
  '/admin/privacy/requests/:id',
  requireRoles('admin'),
  wrap((req, res) => {
    const input = z
      .object({ version: z.number().int().positive(), reason: z.string().min(5).max(500) })
      .parse(req.body);
    const request = visibleRequest(req.user, String(req.params.id));
    if (request.version !== input.version)
      throw new HttpError(409, 'De aanvraag is intussen gewijzigd. Herlaad voor verwijdering.');
    transaction(() => {
      const fresh = db.prepare('SELECT version FROM requests WHERE id=?').get(request.id) as any;
      if (!fresh || fresh.version !== input.version)
        throw new HttpError(409, 'De aanvraag is intussen gewijzigd. Herlaad voor verwijdering.');
      const attachments = db
        .prepare('SELECT id,storage_key FROM attachments WHERE request_id=?')
        .all(request.id) as any[];
      const relatedIds = [
        request.id,
        ...(db.prepare('SELECT id FROM tasks WHERE request_id=?').all(request.id) as any[]).map(
          (row) => row.id,
        ),
        ...(
          db.prepare('SELECT id FROM activities WHERE request_id=?').all(request.id) as any[]
        ).map((row) => row.id),
        ...attachments.map((row) => row.id),
      ];
      for (const attachment of attachments)
        db.prepare('INSERT OR IGNORE INTO attachment_deletion_queue VALUES (?,?)').run(
          attachment.storage_key,
          now(),
        );
      const form = request.form_id
        ? (db.prepare('SELECT form_id FROM forms WHERE id=?').get(request.form_id) as any)
        : null;
      if (request.source_id && form)
        eraseSubmission(request.source_id, request.provider, form.form_id, request.submission_id);
      if (request.source_id && form)
        db.prepare(
          'DELETE FROM events WHERE source_id=? AND provider=? AND form_id=? AND submission_id=?',
        ).run(request.source_id, request.provider, form.form_id, request.submission_id);
      // Delete request-level history that can contain personal text, preserving unrelated dossiers.
      for (const relatedId of relatedIds)
        db.prepare('DELETE FROM audit_log WHERE entity_id=?').run(relatedId);
      db.prepare('DELETE FROM requests WHERE id=?').run(request.id);
      if (
        request.contact_id &&
        !db.prepare('SELECT id FROM requests WHERE contact_id=? LIMIT 1').get(request.contact_id)
      )
        db.prepare('DELETE FROM contacts WHERE id=?').run(request.contact_id);
      if (
        request.location_id &&
        !db.prepare('SELECT id FROM requests WHERE location_id=? LIMIT 1').get(request.location_id)
      )
        db.prepare('DELETE FROM locations WHERE id=?').run(request.location_id);
      const hasRequests = db
        .prepare('SELECT id FROM requests WHERE company_id=? LIMIT 1')
        .get(request.company_id);
      const hasOpportunities = db
        .prepare('SELECT id FROM opportunities WHERE company_id=? LIMIT 1')
        .get(request.company_id);
      const hasTasks = db
        .prepare('SELECT id FROM tasks WHERE company_id=? LIMIT 1')
        .get(request.company_id);
      const hasActivities = db
        .prepare('SELECT id FROM activities WHERE company_id=? LIMIT 1')
        .get(request.company_id);
      if (!hasRequests && !hasOpportunities && !hasTasks && !hasActivities) {
        db.prepare('DELETE FROM contacts WHERE company_id=?').run(request.company_id);
        db.prepare('DELETE FROM locations WHERE company_id=?').run(request.company_id);
        db.prepare('DELETE FROM audit_log WHERE entity_id=?').run(request.company_id);
        db.prepare('DELETE FROM companies WHERE id=?').run(request.company_id);
      }
      // Opaque audit identifier; do not retain submitted names, free-text reason or payload.
      audit(req.user.id, 'privacy_deletion', id(), 'request_deleted', {
        request_reference_sha256: createHash('sha256').update(request.id).digest('hex'),
        reason_recorded: true,
      });
    });
    const cleanup = cleanupDeletedAttachments();
    res.json({
      deleted: true,
      cleanup_pending: cleanup.pending,
      source_and_backups:
        'Niet automatisch verwijderd; pas de bron- en back-upbewaarprocedure toe.',
    });
  }),
);
