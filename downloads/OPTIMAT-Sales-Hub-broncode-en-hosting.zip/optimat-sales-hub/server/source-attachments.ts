import { createHash } from 'node:crypto';
import { mkdirSync, writeFileSync, unlinkSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { z } from 'zod';
import { db, id, now, audit, transaction } from './db.js';
import { HttpError, wrap } from './errors.js';
import { verifySourceRequest } from './source-auth.js';
import { isErased } from './tombstones.js';

const MAX_BYTES = 5 * 1024 * 1024;
const schema = z.object({
  event_id: z.string().min(1).max(200),
  provider: z.literal('gravity'),
  form_id: z.string().min(1).max(191),
  submission_id: z.string().min(1).max(200),
  attachment_key: z.string().min(1).max(200),
  name: z.string().min(1).max(200),
  mime: z.enum(['application/pdf', 'image/png', 'image/jpeg']),
  content_base64: z
    .string()
    .min(4)
    .max(Math.ceil(MAX_BYTES / 3) * 4),
});
function safeName(value: string, mime: string) {
  const name =
    value
      .replace(/[\x00-\x1f\x7f<>:"/\\|?*]/g, '_')
      .trim()
      .slice(0, 140) || 'bijlage';
  return (
    name.replace(/\.[^.]+$/, '') +
    (mime === 'application/pdf' ? '.pdf' : mime === 'image/png' ? '.png' : '.jpg')
  );
}
function validMagic(bytes: Buffer, mime: string) {
  return mime === 'application/pdf'
    ? bytes.subarray(0, 5).equals(Buffer.from('%PDF-'))
    : mime === 'image/png'
      ? bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))
      : bytes.length >= 3 && bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255;
}
/** Signed source channel: no browser session and no public file paths or URLs. */
export const sourceAttachmentHandler = wrap((req, res) => {
  const source = verifySourceRequest(req);
  const input = schema.parse(req.body);
  const acknowledge = (extra: Record<string, unknown> = {}) =>
    res.status(202).json({ accepted: true, event_id: input.event_id, ...extra });
  if (isErased(source.id, input.provider, input.form_id, input.submission_id))
    return void acknowledge({ status: 'ignored_erased' });
  const form = db
    .prepare('SELECT id,purpose FROM forms WHERE source_id=? AND provider=? AND form_id=?')
    .get(source.id, input.provider, input.form_id) as any;
  if (form && ['support', 'recruitment', 'newsletter'].includes(form.purpose))
    return void acknowledge({ status: 'ignored_noncommercial' });
  if (form && form.purpose !== 'commercial')
    return void res.status(409).json({
      error: 'Het formulier moet eerst commercieel worden ingedeeld.',
      code: 'FORM_MAPPING_REQUIRED',
      retryable: true,
    });
  const excluded = db
    .prepare(
      "SELECT id FROM events WHERE source_id=? AND provider=? AND form_id=? AND submission_id=? AND status='excluded' LIMIT 1",
    )
    .get(source.id, input.provider, input.form_id, input.submission_id);
  const request = form
    ? (db
        .prepare(
          'SELECT id,purpose FROM requests WHERE source_id=? AND provider=? AND form_id=? AND submission_id=?',
        )
        .get(source.id, input.provider, form.id, input.submission_id) as any)
    : null;
  if (!request && excluded) return void acknowledge({ status: 'ignored_noncommercial' });
  if (!request)
    return void res.status(409).json({
      error: 'De aanvraag is nog niet verwerkt. De bron mag de bijlage opnieuw aanbieden.',
      code: 'REQUEST_NOT_READY',
      retryable: true,
    });
  if (request.purpose !== 'commercial')
    return void acknowledge({ status: 'ignored_noncommercial' });
  if (
    !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(input.content_base64)
  )
    throw new HttpError(400, 'Ongeldige bestandsinhoud.');
  const content = Buffer.from(input.content_base64, 'base64');
  if (!content.length || content.length > MAX_BYTES)
    throw new HttpError(400, 'Een bijlage mag maximaal 5 MB groot zijn.');
  if (!validMagic(content, input.mime))
    throw new HttpError(
      400,
      'Bestandsinhoud en bestandstype komen niet overeen. Alleen PDF, PNG en JPEG zijn toegestaan.',
    );
  const digest = createHash('sha256').update(content).digest('hex');
  const receipt = db
    .prepare(
      'SELECT * FROM source_attachment_receipts WHERE source_id=? AND provider=? AND form_id=? AND submission_id=? AND attachment_key=?',
    )
    .get(
      source.id,
      input.provider,
      input.form_id,
      input.submission_id,
      input.attachment_key,
    ) as any;
  if (receipt) {
    if (receipt.content_hash !== digest)
      return void res.status(409).json({
        error: 'De bijlagesleutel is al gebruikt voor andere inhoud.',
        code: 'ATTACHMENT_KEY_CONFLICT',
        retryable: false,
      });
    return void acknowledge({ status: 'duplicate', attachment_id: receipt.attachment_id });
  }
  const attachmentId = id(),
    key = id(),
    root = resolve(process.env.ATTACHMENT_DIR || '.data/attachments');
  mkdirSync(root, { recursive: true, mode: 0o700 });
  const path = join(root, key);
  writeFileSync(path, content, { flag: 'wx', mode: 0o600 });
  try {
    transaction(() => {
      db.prepare(
        'INSERT INTO attachments(id,request_id,storage_key,original_name,mime,size_bytes,sha256,uploaded_by,created_at) VALUES (?,?,?,?,?,?,?,NULL,?)',
      ).run(
        attachmentId,
        request.id,
        key,
        safeName(input.name, input.mime),
        input.mime,
        content.length,
        digest,
        now(),
      );
      db.prepare(
        'INSERT INTO source_attachment_receipts(id,source_id,provider,form_id,submission_id,attachment_key,content_hash,request_id,attachment_id,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
      ).run(
        id(),
        source.id,
        input.provider,
        input.form_id,
        input.submission_id,
        input.attachment_key,
        digest,
        request.id,
        attachmentId,
        now(),
      );
      audit(null, 'attachment', attachmentId, 'received_from_source', {
        source_id: source.id,
        request_id: request.id,
        size_bytes: content.length,
      });
    });
  } catch (error) {
    try {
      unlinkSync(path);
    } catch {
      try {
        db.prepare('INSERT OR IGNORE INTO attachment_deletion_queue VALUES (?,?)').run(key, now());
      } catch {
        /* Preserve private orphan without logging file details if storage itself is unavailable. */
      }
    }
    throw error;
  }
  acknowledge({ status: 'received', attachment_id: attachmentId });
});
