import { Router } from 'express';
import ExcelJS from 'exceljs';
import { db, now } from './db.ts';
import { requireAuth } from './auth.ts';
import { wrap, HttpError } from './errors.ts';
import { periodBoundary } from './time.ts';
import { historicalRequests, matchesRequestFilters } from './history.ts';
import { listRequests, listOpportunities, safeJson } from './crm.ts';
import type { User } from '../shared/domain.ts';
export const reportsRouter = Router();
reportsRouter.use(requireAuth);
export const KPI_DEFINITIONS = {
  requests:
    'Unieke geldige commerciële inzendingen uit het instroomcohort; herleveringen, spam en testdata uitgesloten.',
  companies: 'Unieke bedrijven gekoppeld aan dit instroomcohort; losse prospects tellen niet mee.',
  opportunities: 'Unieke gekwalificeerde verkoopkansen gekoppeld aan het instroomcohort.',
  follow_up_rate:
    'Aandeel aanvragen uit het instroomcohort met minstens één geregistreerde menselijke contactactie op de peildatum. Ongecontacteerde aanvragen blijven in de noemer.',
  median_first_contact_hours:
    'Mediaan uren van ontvangst tot de eerste geregistreerde bel-, mail- of gespreksactie; automatische ontvangstmail en notities tellen niet.',
  p90_first_contact_hours: '90e percentiel met lineaire interpolatie van dezelfde contacttijden.',
  lead_conversion:
    'Aandeel commerciële aanvragen uit het instroomcohort gekoppeld aan minstens één gewonnen verkoopkans; elke aanvraag telt maximaal één keer.',
  company_conversion:
    'Aandeel bedrijven uit het instroomcohort met minstens één gewonnen verkoopkans gekoppeld aan dat cohort.',
  win_ratio:
    'Gewonnen / (gewonnen + verloren) kansen op afsluitdatum binnen de periode. Open kansen uitgesloten.',
  open_pipeline_value:
    'Actuele pipelinefoto op peildatum: som van geregistreerde bedragen van open kansen; ontbrekende waarden zijn onbekend.',
  won_value:
    'Som geregistreerde waarde van gewonnen kansen met afsluitdatum in de periode; geen gefactureerde omzet.',
  quote_value: 'Pipelinefoto: geregistreerde bedragen van kansen in offertefase op de peildatum.',
  lost_value: 'Geregistreerde bedragen van verloren kansen met afsluitdatum in de periode.',
  ownership:
    'Rechten volgen de huidige portefeuille. Bij ownership=at_close wordt de geselecteerde verkoper op afsluitmoment gefilterd voor afsluitcijfers; cohort en pipeline blijven huidige portefeuille.',
};
type Row = Record<string, any>;
function quantile(values: number[], p: number) {
  if (!values.length) return null;
  const v = [...values].sort((a, b) => a - b);
  const i = (v.length - 1) * p;
  return v[Math.floor(i)] + (v[Math.ceil(i)] - v[Math.floor(i)]) * (i % 1);
}
const sum = (items: Row[]) => items.reduce((s, o) => s + (o.amount ?? 0), 0);
function group(items: Row[], key: string) {
  const counts = new Map<string, number>();
  for (const i of items) {
    const value = String(i[key] ?? 'Onbekend');
    counts.set(value, (counts.get(value) ?? 0) + 1);
  }
  return [...counts].map(([name, count]) => ({ name, count }));
}
function snapshots(opportunities: Row[], asOf: string) {
  return opportunities
    .filter((o) => o.created_at <= asOf)
    .map((o) => {
      const h = db
        .prepare(
          'SELECT snapshot_json FROM opportunity_history WHERE opportunity_id=? AND created_at<=? ORDER BY created_at DESC,rowid DESC LIMIT 1',
        )
        .get(o.id, asOf) as Row | undefined;
      return h ? { ...o, ...safeJson(h.snapshot_json, {}) } : o;
    });
}
function calculateReportData(user: User, q: Record<string, any> = {}) {
  const asOf = typeof q.as_of === 'string' ? new Date(q.as_of) : new Date();
  if (Number.isNaN(asOf.getTime())) throw new HttpError(400, 'Ongeldige peildatum.');
  const as_of = asOf.toISOString();
  if (asOf.getTime() > Date.now() + 60000)
    throw new HttpError(400, 'Peildatum ligt in de toekomst.');
  const historical = historicalRequests(user, as_of);
  const cohort = historical.items.filter(
    (r) => r.submitted_at <= as_of && matchesRequestFilters(r, q),
  );
  const requestIds = new Set(cohort.map((r) => r.id));
  const companyIds = new Set(cohort.map((r) => r.company_id));
  const contacts = new Set(cohort.filter((r) => r.contact_id).map((r) => r.contact_id));
  const currentLinks = db
    .prepare('SELECT opportunity_id,request_id FROM opportunity_requests')
    .all() as Row[];
  const allOpportunities = snapshots(listOpportunities(user, {}, true), as_of);
  const linked: Row[] = allOpportunities.flatMap((o) =>
    (Array.isArray(o.linked_request_ids)
      ? o.linked_request_ids
      : currentLinks.filter((link) => link.opportunity_id === o.id).map((link) => link.request_id)
    ).map((request_id: string) => ({ opportunity_id: o.id, request_id })),
  );
  const requestDimensions = { ...q };
  delete requestDimensions.from;
  delete requestDimensions.to;
  delete requestDimensions.status;
  delete requestDimensions.as_of;
  delete requestDimensions.owner;
  delete requestDimensions.stage;
  const eligibleRequests = new Set(
    historical.items.filter((r) => matchesRequestFilters(r, requestDimensions)).map((r) => r.id),
  );
  const eligibleOpportunityIds = new Set(
    linked.filter((l) => eligibleRequests.has(l.request_id)).map((l) => l.opportunity_id),
  );
  const opportunities = allOpportunities.filter(
    (o) =>
      eligibleOpportunityIds.has(o.id) &&
      (!q.stage || o.stage === q.stage) &&
      (q.ownership === 'at_close' || !q.owner || o.owner_id === q.owner),
  );
  const cohortOpportunityIds = new Set(
    linked.filter((l) => requestIds.has(l.request_id)).map((l) => l.opportunity_id),
  );
  const cohortOpportunities = opportunities.filter((o) => cohortOpportunityIds.has(o.id));
  const open = opportunities.filter((o) => !['won', 'lost'].includes(o.stage));
  const from = q.from ? periodBoundary(String(q.from)) : null;
  const to = q.to ? periodBoundary(String(q.to), true) : null;
  const closed = opportunities.filter(
    (o) =>
      ['won', 'lost'].includes(o.stage) &&
      o.closed_at &&
      o.closed_at <= as_of &&
      (!from || o.closed_at >= from) &&
      (!to || o.closed_at <= to) &&
      (q.ownership !== 'at_close' || !q.owner || o.owner_at_close === q.owner),
  );
  const won = closed.filter((o) => o.stage === 'won');
  const lost = closed.filter((o) => o.stage === 'lost');
  const cohortWon = new Set(
    cohortOpportunities
      .filter((o) => o.stage === 'won' && o.closed_at && o.closed_at <= as_of)
      .map((o) => o.id),
  );
  const convertedRequests = new Set(
    linked
      .filter((l) => requestIds.has(l.request_id) && cohortWon.has(l.opportunity_id))
      .map((l) => l.request_id),
  );
  const convertedCompanies = new Set(
    cohort.filter((r) => convertedRequests.has(r.id)).map((r) => r.company_id),
  );
  const firstContacts = new Map<string, string>();
  for (const r of cohort) {
    const a = db
      .prepare(
        "SELECT MIN(created_at) at FROM activities WHERE request_id=? AND kind IN ('call','email','meeting') AND created_at<=?",
      )
      .get(r.id, as_of) as Row;
    if (a.at) firstContacts.set(r.id, a.at);
  }
  const contactHours = cohort
    .filter((r) => firstContacts.has(r.id))
    .map((r) =>
      Math.max(0, (Date.parse(firstContacts.get(r.id)!) - Date.parse(r.received_at)) / 3600000),
    );
  const overdue = (
    db.prepare('SELECT * FROM tasks WHERE due_at<? AND created_at<=?').all(as_of, as_of) as Row[]
  ).filter((t) => {
    const state = db
      .prepare(
        "SELECT details_json FROM audit_log WHERE action='task_updated' AND json_extract(details_json,'$.task_id')=? AND created_at<=? ORDER BY created_at DESC,rowid DESC LIMIT 1",
      )
      .get(t.id, as_of) as Row | undefined;
    return state
      ? !safeJson(state.details_json, {}).completed
      : !(t.updated_at <= as_of ? t.completed : 0);
  });
  const metrics = {
    requests: cohort.length,
    companies: companyIds.size,
    contacts: contacts.size,
    opportunities: cohortOpportunities.length,
    unassigned: cohort.filter((r) => !r.owner_id).length,
    open_pipeline_value: sum(open),
    won_value: sum(won),
    lost_value: sum(lost),
    quote_value: sum(open.filter((o) => o.stage === 'quote')),
    follow_up_rate: cohort.length ? firstContacts.size / cohort.length : null,
    median_first_contact_hours: quantile(contactHours, 0.5),
    p90_first_contact_hours: quantile(contactHours, 0.9),
    uncontacted_share: cohort.length ? 1 - firstContacts.size / cohort.length : null,
    lead_conversion: cohort.length ? convertedRequests.size / cohort.length : null,
    company_conversion: companyIds.size ? convertedCompanies.size / companyIds.size : null,
    win_ratio: won.length + lost.length ? won.length / (won.length + lost.length) : null,
    missing_values: opportunities.filter((o) => o.amount === null).length,
    missing_locations: cohort.filter((r) => r.latitude === null || r.longitude === null).length,
    overdue_tasks: overdue.filter((t) => requestIds.has(t.request_id)).length,
    won_count: won.length,
    lost_count: lost.length,
    open_count: open.length,
    contacted: firstContacts.size,
    converted_requests: convertedRequests.size,
    won_without_value: won.filter((o) => o.amount === null).length,
    average_sales_cycle_days: closed.length
      ? closed.reduce(
          (s, o) =>
            s + Math.max(0, (Date.parse(o.closed_at) - Date.parse(o.created_at)) / 86400000),
          0,
        ) / closed.length
      : null,
  };
  const report = {
    metrics,
    by_source: group(cohort, 'source_name'),
    by_status: group(cohort, 'status'),
    by_owner: group(cohort, 'owner_name'),
    definitions: KPI_DEFINITIONS,
    as_of,
    cohort_size: cohort.length,
    filters: q,
    time_zone: 'Europe/Brussels',
    time_scopes: { cohort: 'submitted_at', closed: 'closed_at', pipeline: 'as_of' },
    history_unknown_requests: historical.unknown,
    historical_limitations: [
      'Historische peildata gebruiken bewaarde aanvraag- en verkoopkansdimensies; vóór de eerste bekende momentopname is de status onbekend. Vrije tekstzoekopdrachten gebruiken actuele toegankelijke dossiertekst; berichten en persoonsgegevens worden niet in rapportagemomentopnamen gekopieerd.',
    ],
    generated_at: now(),
  };
  return { report, cohort, opportunities };
}
export function calculateReport(user: User, q: Record<string, any> = {}) {
  return calculateReportData(user, q).report;
}
reportsRouter.get(
  '/',
  wrap(async (req, res) => {
    res.json(calculateReport(req.user!, req.query));
  }),
);
export function spreadsheetSafe(value: unknown) {
  const str = String(value ?? '');
  return /^[\s\u0000-\u001f]*[=+\-@]/.test(str) ? "'" + str : str;
}
const exportColumns = [
  ['id', 'Aanvraag-ID'],
  ['company_name', 'Bedrijf'],
  ['contact_name', 'Contactpersoon'],
  ['email', 'E-mail'],
  ['phone', 'Telefoon'],
  ['country', 'Land'],
  ['source_name', 'Bron'],
  ['submitted_at', 'Ingezonden (UTC)'],
  ['business_unit', 'Businessunit'],
  ['brand', 'Merk'],
  ['machine', 'Machine'],
  ['status', 'Opvolgstatus'],
  ['owner_name', 'Verkoper'],
  ['message', 'Bericht'],
] as const;
reportsRouter.get(
  '/export.csv',
  wrap(async (req, res) => {
    const { cohort: items } = calculateReportData(req.user!, req.query);
    const csvCell = (value: unknown) => '"' + spreadsheetSafe(value).replaceAll('"', '""') + '"';
    const lines = [
      exportColumns.map(([, label]) => csvCell(label)).join(';'),
      ...items.map((item) => exportColumns.map(([key]) => csvCell(item[key])).join(';')),
    ];
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="optimat-aanvragen.csv"');
    res.send('\uFEFF' + lines.join('\r\n'));
  }),
);
reportsRouter.get(
  '/export.xlsx',
  wrap(async (req, res) => {
    const {
      cohort: items,
      report,
      opportunities: historicalOpportunities,
    } = calculateReportData(req.user!, req.query);
    const workbook = new ExcelJS.Workbook();
    workbook.creator = 'OPTIMAT Sales Hub';
    workbook.created = new Date();
    const sheet = workbook.addWorksheet('Aanvragen');
    sheet.columns = exportColumns.map(([key, header]) => ({ key, header, width: 24 }));
    for (const item of items)
      sheet.addRow(
        Object.fromEntries(exportColumns.map(([key]) => [key, spreadsheetSafe(item[key])])),
      );
    sheet.getRow(1).font = { bold: true };
    const kpis = workbook.addWorksheet('KPI en definities');
    kpis.columns = [
      { header: 'Maatstaf', key: 'key', width: 34 },
      { header: 'Waarde', key: 'value', width: 26 },
      { header: 'Definitie', key: 'definition', width: 110 },
    ];
    for (const [key, value] of Object.entries(report.metrics))
      kpis.addRow({
        key,
        value: value ?? 'Onbekend',
        definition: KPI_DEFINITIONS[key as keyof typeof KPI_DEFINITIONS] ?? '',
      });
    kpis.addRow({ key: 'Peildatum UTC', value: report.as_of });
    kpis.addRow({ key: 'Actieve filters', value: JSON.stringify(req.query) });
    const opportunities = workbook.addWorksheet('Verkoopkansen');
    opportunities.columns = [
      { header: 'ID', key: 'id', width: 40 },
      { header: 'Bedrijf', key: 'company_name', width: 30 },
      { header: 'Titel', key: 'title', width: 30 },
      { header: 'Fase', key: 'stage', width: 20 },
      { header: 'Bedrag EUR', key: 'amount', width: 20 },
      { header: 'Afsluitdatum', key: 'closed_at', width: 30 },
    ];
    for (const o of historicalOpportunities)
      opportunities.addRow({
        ...o,
        title: spreadsheetSafe(o.title),
        company_name: spreadsheetSafe(o.company_name),
      });
    res.setHeader(
      'Content-Type',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    );
    res.setHeader('Content-Disposition', 'attachment; filename="optimat-rapport.xlsx"');
    res.send(Buffer.from(await workbook.xlsx.writeBuffer()));
  }),
);
