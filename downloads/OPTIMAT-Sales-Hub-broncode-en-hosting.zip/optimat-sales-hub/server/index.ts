import { createApp } from './app.js';
import { startWorker } from './intake.js';
import { processGeocoding } from './geocoding.js';
import { cleanupDeletedAttachments } from './privacy.js';
if (
  process.env.NODE_ENV === 'production' &&
  (!process.env.APP_URL || new URL(process.env.APP_URL).protocol !== 'https:')
)
  throw new Error('Productie vereist APP_URL met HTTPS.');
const port = Number(process.env.PORT || 3000);
const app = createApp();
const server = app.listen(port, process.env.HOST || '0.0.0.0', () =>
  console.log(`OPTIMAT Sales Hub luistert op poort ${port}`),
);
const stopWorker = startWorker();
const geoWorker = setInterval(() => {
  void processGeocoding().catch(() => console.error('GEOCODING_WORKER_ERROR'));
  cleanupDeletedAttachments();
}, 1000);
const shutdown = () => {
  stopWorker();
  clearInterval(geoWorker);
  server.close(() => process.exit(0));
};
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
