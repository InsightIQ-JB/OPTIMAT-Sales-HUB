import { HttpError } from './errors.js';
/** Date-only filters describe a civil day in Brussels, including 23/25-hour DST days. */
export function periodBoundary(input: string, end = false): string {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input)) {
    const dt = new Date(input);
    if (Number.isNaN(+dt)) throw new HttpError(400, 'Ongeldige datum.');
    return dt.toISOString();
  }
  const base = Date.parse(input + 'T00:00:00Z');
  if (!Number.isFinite(base) || new Date(base).toISOString().slice(0, 10) !== input)
    throw new HttpError(400, 'Ongeldige datum.');
  const midnight = base + (end ? 86400000 : 0);
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Europe/Brussels',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(new Date(midnight));
  const value = (type: string) => Number(parts.find((p) => p.type === type)!.value);
  const asUtc = Date.UTC(
    value('year'),
    value('month') - 1,
    value('day'),
    value('hour'),
    value('minute'),
    value('second'),
  );
  const offset = asUtc - midnight;
  return new Date(midnight - offset - (end ? 1 : 0)).toISOString();
}
