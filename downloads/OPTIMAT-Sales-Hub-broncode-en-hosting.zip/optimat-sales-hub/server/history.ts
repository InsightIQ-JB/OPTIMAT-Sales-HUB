import { db, id, now } from './db.ts';
import { periodBoundary } from './time.ts';
import { scope } from './auth.ts';
import type { User } from '../shared/domain.ts';
type Row = Record<string, any>;
/** Store reporting dimensions only. Messages, raw fields, contacts and company names remain in their original records. */
export function snapshotRequest(requestId: string, at = now()) {
  const r = db
    .prepare(
      `SELECT r.id,r.company_id,r.contact_id,r.source_id,r.owner_id,u.name owner_name,r.status,r.priority,r.business_unit,r.brand,r.machine,r.model,r.intents_json,r.campaign,r.purpose,r.is_test,r.is_spam,r.submitted_at,r.received_at,c.country,s.name source_name,s.site_url source_url,l.latitude,l.longitude,l.precision FROM requests r LEFT JOIN companies c ON c.id=r.company_id LEFT JOIN locations l ON l.id=r.location_id LEFT JOIN users u ON u.id=r.owner_id LEFT JOIN sources s ON s.id=r.source_id WHERE r.id=?`,
    )
    .get(requestId);
  if (r)
    db.prepare(
      'INSERT INTO request_history(id,request_id,snapshot_json,created_at) VALUES(?,?,?,?)',
    ).run(id(), requestId, JSON.stringify(r), at);
}
export function snapshotCompanyRequests(companyId: string, at = now()) {
  for (const r of db.prepare('SELECT id FROM requests WHERE company_id=?').all(companyId) as Row[])
    snapshotRequest(r.id, at);
}
export function matchesRequestFilters(r: Row, q: Record<string, any> = {}) {
  if (r.purpose !== 'commercial' || r.is_test || r.is_spam) return false;
  const exact: Record<string, string> = {
    owner: 'owner_id',
    status: 'status',
    business_unit: 'business_unit',
    brand: 'brand',
    campaign: 'campaign',
    country: 'country',
  };
  for (const [key, column] of Object.entries(exact))
    if (typeof q[key] === 'string' && q[key]) {
      if (key === 'owner' && q.owner === 'unassigned') {
        if (r.owner_id !== null) return false;
      } else if (r[column] !== q[key]) return false;
    }
  if (typeof q.source === 'string' && q.source) {
    const term = q.source.toLowerCase();
    if (
      r.source_id !== q.source &&
      !String(r.source_url ?? '')
        .toLowerCase()
        .includes(term) &&
      !String(r.source_name ?? '')
        .toLowerCase()
        .includes(term)
    )
      return false;
  }
  if (typeof q.intent === 'string' && q.intent) {
    let intents: string[] = [];
    try {
      intents = JSON.parse(r.intents_json);
    } catch {}
    if (!intents.includes(q.intent)) return false;
  }
  if (typeof q.search === 'string' && q.search) {
    const term = q.search.toLowerCase();
    if (
      !['company_name', 'contact_name', 'email', 'message', 'machine', 'model', 'brand'].some(
        (key) =>
          String(r[key] ?? '')
            .toLowerCase()
            .includes(term),
      )
    )
      return false;
  }
  if (typeof q.from === 'string' && q.from && r.submitted_at < periodBoundary(q.from)) return false;
  if (typeof q.to === 'string' && q.to && r.submitted_at > periodBoundary(q.to, true)) return false;
  return true;
}
/** Access remains based on the current portfolio; historical ownership never grants access to an old dossier. */
export function historicalRequests(user: User, asOf: string) {
  const access = scope(user);
  const current = db
    .prepare(
      `SELECT r.*,c.name company_name,ct.name contact_name,ct.email,c.country,s.name source_name,s.site_url source_url,u.name owner_name,l.latitude,l.longitude,l.precision FROM requests r LEFT JOIN companies c ON c.id=r.company_id LEFT JOIN contacts ct ON ct.id=r.contact_id LEFT JOIN sources s ON s.id=r.source_id LEFT JOIN users u ON u.id=r.owner_id LEFT JOIN locations l ON l.id=r.location_id WHERE ${access.sql}`,
    )
    .all(...access.params) as Row[];
  const items: Row[] = [];
  let unknown = 0;
  for (const r of current) {
    if (r.received_at > asOf) continue;
    const h = db
      .prepare(
        'SELECT snapshot_json FROM request_history WHERE request_id=? AND created_at<=? ORDER BY created_at DESC,rowid DESC LIMIT 1',
      )
      .get(r.id, asOf) as Row | undefined;
    if (h) {
      items.push({ ...r, ...JSON.parse(h.snapshot_json) });
    } else if (r.updated_at <= asOf) {
      items.push(r);
    } else unknown++;
  }
  return { items, unknown };
}
