import { createHmac, randomBytes } from 'node:crypto';
import { db, now } from './db.js';
function key() {
  let row = db
    .prepare("SELECT value_json FROM settings WHERE key='privacy_tombstone_key'")
    .get() as any;
  if (!row) {
    const value = randomBytes(32).toString('hex');
    db.prepare('INSERT OR IGNORE INTO settings VALUES (?,?)').run(
      'privacy_tombstone_key',
      JSON.stringify(value),
    );
    row = db.prepare("SELECT value_json FROM settings WHERE key='privacy_tombstone_key'").get();
  }
  return JSON.parse(row.value_json) as string;
}
function digest(sourceId: string, provider: string, formId: string, submissionId: string) {
  return createHmac('sha256', key())
    .update(JSON.stringify([sourceId, provider, formId, submissionId]))
    .digest('hex');
}
export function isErased(sourceId: string, provider: string, formId: string, submissionId: string) {
  return !!db
    .prepare('SELECT key_hash FROM erased_submissions WHERE key_hash=?')
    .get(digest(sourceId, provider, formId, submissionId));
}
export function eraseSubmission(
  sourceId: string,
  provider: string,
  formId: string,
  submissionId: string,
) {
  db.prepare('INSERT OR IGNORE INTO erased_submissions VALUES (?,?)').run(
    digest(sourceId, provider, formId, submissionId),
    now(),
  );
}
