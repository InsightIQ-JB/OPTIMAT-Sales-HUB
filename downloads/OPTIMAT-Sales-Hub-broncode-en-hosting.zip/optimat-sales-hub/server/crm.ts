import { Router, type Request } from 'express';
import { z } from 'zod';
import { db, transaction, id, now, audit } from './db.ts';
import { requireAuth, requireRoles, assertWrite, visibleRequest, scope } from './auth.ts';
import { HttpError, wrap } from './errors.ts';
import { periodBoundary } from './time.ts';
import { geocodingStatus } from './geocoding.ts';
import { snapshotRequest, snapshotCompanyRequests } from './history.ts';
import { REQUEST_STATUSES, STAGES, LABELS, type User } from '../shared/domain.ts';

export const crmRouter = Router();
crmRouter.use(requireAuth);
type Row = Record<string, any>;
const row = (sql: string, ...params: any[]): Row | undefined =>
  db.prepare(sql).get(...params) as Row | undefined;
const rows = (sql: string, ...params: any[]): Row[] => db.prepare(sql).all(...params) as Row[];
export const safeJson = (value: any, fallback: any = []) => {
  try {
    return JSON.parse(value ?? 'null') ?? fallback;
  } catch {
    return fallback;
  }
};
const date = z
  .string()
  .datetime({ offset: true })
  .transform((v) => new Date(v).toISOString());
const optionalDate = date.nullable().optional();
const nonempty = z.string().trim().min(1).max(200);
function version(row: Row, expected: number) {
  if (row.version !== expected)
    throw new HttpError(
      409,
      'Dit dossier is intussen gewijzigd. Vernieuw het scherm en probeer opnieuw.',
    );
}
function isTeamScoped(user: User) {
  return ['manager', 'management'].includes(user.role) && !!user.team_id;
}
export function portfolioScope(user: User, alias = 'o'): { sql: string; params: any[] } {
  if (user.role === 'seller') return { sql: `${alias}.owner_id=?`, params: [user.id] };
  if (isTeamScoped(user))
    return {
      sql: `(${alias}.owner_id IS NULL OR EXISTS(SELECT 1 FROM users portfolio_user WHERE portfolio_user.id=${alias}.owner_id AND portfolio_user.team_id=?))`,
      params: [user.team_id],
    };
  return { sql: '1=1', params: [] };
}
function ownerAllowed(value: string | null | undefined, user?: User) {
  if (!value) return;
  const allowed = row(
    `SELECT id FROM users WHERE id=? AND active=1 AND role IN ('seller','manager','admin')${user && isTeamScoped(user) ? ' AND team_id=?' : ''}`,
    value,
    ...(user && isTeamScoped(user) ? [user.team_id] : []),
  );
  if (!allowed) throw new HttpError(400, 'Kies een actieve verkoper binnen je toegestane team.');
}
function companyScope(user: User, alias = 'c'): { sql: string; params: any[] } {
  if (user.role === 'admin' || (user.role !== 'seller' && !isTeamScoped(user)))
    return { sql: '1=1', params: [] };
  const rs = scope(user, 'company_request'),
    os = portfolioScope(user, 'company_opportunity');
  const owned = portfolioScope(user, alias);
  return {
    sql: `((${alias}.owner_id IS NOT NULL AND ${owned.sql}) OR EXISTS(SELECT 1 FROM requests company_request WHERE company_request.company_id=${alias}.id AND ${rs.sql}) OR EXISTS(SELECT 1 FROM opportunities company_opportunity WHERE company_opportunity.company_id=${alias}.id AND ${os.sql})${isTeamScoped(user) ? ` OR (${alias}.owner_id IS NULL AND NOT EXISTS(SELECT 1 FROM requests company_request_any WHERE company_request_any.company_id=${alias}.id) AND NOT EXISTS(SELECT 1 FROM opportunities company_opportunity_any WHERE company_opportunity_any.company_id=${alias}.id))` : ''})`,
    params: [...owned.params, ...rs.params, ...os.params],
  };
}
function wholeCompany(user: User, c: Row) {
  if (user.role !== 'seller' && !isTeamScoped(user)) return true;
  if (!c.owner_id) return false;
  const owned = portfolioScope(user, 'c');
  return !!row(`SELECT c.id FROM companies c WHERE c.id=? AND ${owned.sql}`, c.id, ...owned.params);
}
export function visibleCompany(user: User, companyId: string) {
  const s = companyScope(user);
  const c = row(`SELECT c.* FROM companies c WHERE c.id=? AND ${s.sql}`, companyId, ...s.params);
  if (!c) throw new HttpError(404, 'Bedrijf niet gevonden.');
  return c;
}
export function visibleOpportunity(user: User, opportunityId: string) {
  const s = portfolioScope(user);
  const o = row(
    `SELECT o.* FROM opportunities o WHERE o.id=? AND ${s.sql}`,
    opportunityId,
    ...s.params,
  );
  if (!o) throw new HttpError(404, 'Verkoopkans niet gevonden.');
  return o;
}
export function requestFilter(user: User, q: Record<string, any>, alias = 'r') {
  const s = scope(user, alias);
  const clauses = [
    s.sql,
    `${alias}.purpose='commercial'`,
    `${alias}.is_test=0`,
    `${alias}.is_spam=0`,
  ];
  const params: any[] = [...s.params];
  const exact: Record<string, string> = {
    owner: 'owner_id',
    status: 'status',
    business_unit: 'business_unit',
    brand: 'brand',
    campaign: 'campaign',
  };
  for (const [key, column] of Object.entries(exact)) {
    if (typeof q[key] === 'string' && q[key]) {
      if (q[key] === 'unassigned' && key === 'owner') clauses.push(`${alias}.owner_id IS NULL`);
      else {
        clauses.push(`${alias}.${column}=?`);
        params.push(q[key]);
      }
    }
  }
  if (typeof q.source === 'string' && q.source) {
    const value = '%' + q.source.replace(/[\\%_]/g, '\\$&') + '%';
    clauses.push(
      `(${alias}.source_id=? OR EXISTS(SELECT 1 FROM sources fs WHERE fs.id=${alias}.source_id AND (fs.site_url LIKE ? ESCAPE '\\' OR fs.name LIKE ? ESCAPE '\\')))`,
    );
    params.push(q.source, value, value);
  }
  if (typeof q.country === 'string' && q.country) {
    clauses.push(
      `EXISTS(SELECT 1 FROM companies fc WHERE fc.id=${alias}.company_id AND fc.country=?)`,
    );
    params.push(q.country);
  }
  if (typeof q.intent === 'string' && q.intent) {
    clauses.push(`EXISTS(SELECT 1 FROM json_each(${alias}.intents_json) WHERE value=?)`);
    params.push(q.intent);
  }
  if (typeof q.search === 'string' && q.search) {
    clauses.push(
      `(${alias}.message LIKE ? ESCAPE '\\' OR ${alias}.machine LIKE ? ESCAPE '\\' OR ${alias}.model LIKE ? ESCAPE '\\' OR ${alias}.brand LIKE ? ESCAPE '\\' OR EXISTS(SELECT 1 FROM companies sc WHERE sc.id=${alias}.company_id AND sc.name LIKE ? ESCAPE '\\') OR EXISTS(SELECT 1 FROM contacts ct WHERE ct.id=${alias}.contact_id AND (ct.name LIKE ? ESCAPE '\\' OR ct.email LIKE ? ESCAPE '\\')))`,
    );
    const v = '%' + q.search.replace(/[\\%_]/g, '\\$&') + '%';
    params.push(v, v, v, v, v, v, v);
  }
  if (typeof q.from === 'string' && q.from) {
    if (Number.isNaN(Date.parse(q.from))) throw new HttpError(400, 'Ongeldige begindatum.');
    clauses.push(`${alias}.submitted_at>=?`);
    params.push(periodBoundary(q.from));
  }
  if (typeof q.to === 'string' && q.to) {
    if (Number.isNaN(Date.parse(q.to))) throw new HttpError(400, 'Ongeldige einddatum.');
    clauses.push(`${alias}.submitted_at<=?`);
    params.push(periodBoundary(q.to, true));
  }
  return {
    sql: clauses
      .filter(Boolean)
      .map((c) => '(' + c + ')')
      .join(' AND '),
    params,
  };
}
export function listRequests(user: User, q: Record<string, any> = {}): Row[] {
  const f = requestFilter(user, q);
  return rows(
    `SELECT r.*,c.name company_name,c.country,c.enterprise_number,ct.name contact_name,ct.email,ct.phone,l.latitude,l.longitude,l.precision,l.city,l.postcode,l.address,u.name owner_name,s.name source_name,s.site_url source_url FROM requests r LEFT JOIN companies c ON c.id=r.company_id LEFT JOIN contacts ct ON ct.id=r.contact_id LEFT JOIN locations l ON l.id=r.location_id LEFT JOIN users u ON u.id=r.owner_id LEFT JOIN sources s ON s.id=r.source_id WHERE ${f.sql} ORDER BY r.submitted_at DESC`,
    ...f.params,
  ).map((r) => ({ ...r, intents: safeJson(r.intents_json), fields: safeJson(r.fields_json) }));
}
export function listOpportunities(
  user: User,
  q: Record<string, any> = {},
  includeExcluded = false,
) {
  const clauses = [
    `EXISTS(SELECT 1 FROM opportunity_requests valid_link JOIN requests valid_r ON valid_r.id=valid_link.request_id WHERE valid_link.opportunity_id=o.id AND valid_r.purpose='commercial' AND (valid_r.is_test=0 OR ${includeExcluded ? 1 : 0}=1) AND (valid_r.is_spam=0 OR ${includeExcluded ? 1 : 0}=1))`,
  ];
  const access = portfolioScope(user);
  clauses.push(access.sql);
  const params: any[] = [...access.params];
  if (q.owner) {
    clauses.push('o.owner_id=?');
    params.push(q.owner);
  }
  if (q.stage) {
    clauses.push('o.stage=?');
    params.push(q.stage);
  }
  if (q.search) {
    clauses.push('(o.title LIKE ? OR c.name LIKE ?)');
    params.push('%' + q.search + '%', '%' + q.search + '%');
  }
  const requestKeys = [
    'source',
    'business_unit',
    'country',
    'brand',
    'intent',
    'campaign',
    'status',
    'from',
    'to',
  ];
  const filtered = Object.fromEntries(requestKeys.filter((k) => q[k]).map((k) => [k, q[k]]));
  if (Object.keys(filtered).length) {
    const f = requestFilter(user, filtered);
    clauses.push(
      `EXISTS(SELECT 1 FROM opportunity_requests oor JOIN requests r ON r.id=oor.request_id WHERE oor.opportunity_id=o.id AND ${f.sql})`,
    );
    params.push(...f.params);
  }
  return rows(
    `SELECT o.*,c.name company_name,u.name owner_name FROM opportunities o LEFT JOIN companies c ON c.id=o.company_id LEFT JOIN users u ON u.id=o.owner_id WHERE ${clauses.join(' AND ')} ORDER BY o.updated_at DESC`,
    ...params,
  );
}
export function createCompany(user: User, input: any, ownTransaction = true) {
  assertWrite(user);
  const data = z
    .object({
      name: nonempty,
      country: z.enum(['BE', 'NL', 'LU']).default('BE'),
      enterprise_number: z.string().trim().max(30).nullable().optional(),
      address: z.string().max(300).optional(),
      postcode: z.string().max(20).optional(),
      city: z.string().max(100).optional(),
      owner_id: z.string().nullable().optional(),
    })
    .parse(input);
  const owner = user.role === 'seller' ? user.id : (data.owner_id ?? null);
  ownerAllowed(owner, user);
  let normalized = data.enterprise_number?.replace(/[^a-zA-Z0-9]/g, '').toUpperCase() || null;
  if (data.country === 'BE' && normalized) normalized = normalized.replace(/^BE/, '');
  if (normalized) {
    const existing = row(
      'SELECT id FROM companies WHERE enterprise_number=? AND country=?',
      normalized,
      data.country,
    );
    if (existing)
      throw new HttpError(409, 'Er bestaat al een dossier voor dit ondernemingsnummer.');
    if (data.country === 'BE') {
      const digits = normalized.replace(/^BE/, '');
      if (
        !/^\d{10}$/.test(digits) ||
        97 - (Number(digits.slice(0, 8)) % 97) !== Number(digits.slice(8))
      )
        throw new HttpError(400, 'Ongeldig Belgisch ondernemingsnummer.');
    }
  }
  const cid = id();
  const insert = () => {
    db.prepare(
      'INSERT INTO companies(id,name,country,enterprise_number,owner_id,created_at,updated_at) VALUES(?,?,?,?,?,?,?)',
    ).run(cid, data.name, data.country, normalized, owner, now(), now());
    if (data.address || data.city || data.postcode)
      db.prepare(
        'INSERT INTO locations(id,company_id,address,postcode,city,country) VALUES(?,?,?,?,?,?)',
      ).run(
        id(),
        cid,
        data.address ?? null,
        data.postcode ?? null,
        data.city ?? null,
        data.country,
      );
    audit(user.id, 'company', cid, 'created', { source: 'manual' });
    return row('SELECT * FROM companies WHERE id=?', cid)!;
  };
  return ownTransaction ? transaction(insert) : insert();
}
crmRouter.get(
  '/requests',
  wrap(async (req, res) => {
    const items = listRequests(req.user!, req.query);
    res.json({ items, total: items.length });
  }),
);
crmRouter.get(
  '/requests/:id',
  wrap(async (req, res) => {
    const r = visibleRequest(req.user!, String(req.params.id));
    const opportunityAccess = portfolioScope(req.user!);
    const opportunities = rows(
      `SELECT o.* FROM opportunities o JOIN opportunity_requests x ON x.opportunity_id=o.id WHERE x.request_id=? AND ${opportunityAccess.sql}`,
      r.id,
      ...opportunityAccess.params,
    );
    const source = r.source_id
      ? row('SELECT name,site_url FROM sources WHERE id=?', r.source_id)
      : null;
    const form = r.form_id ? row('SELECT name FROM forms WHERE id=?', r.form_id) : null;
    res.json({
      request: {
        ...r,
        source_name: source?.name ?? null,
        source_url: source?.site_url ?? null,
        form_name: form?.name ?? null,
        intents: safeJson(r.intents_json),
      },
      company: r.company_id ? row('SELECT * FROM companies WHERE id=?', r.company_id) : null,
      contact: r.contact_id ? row('SELECT * FROM contacts WHERE id=?', r.contact_id) : null,
      location: r.location_id ? row('SELECT * FROM locations WHERE id=?', r.location_id) : null,
      fields: safeJson(r.fields_json),
      opportunities,
      activities: rows(
        'SELECT a.*,u.name actor_name FROM activities a LEFT JOIN users u ON u.id=a.actor_id WHERE a.request_id=? ORDER BY a.created_at DESC',
        r.id,
      ),
      tasks: rows('SELECT * FROM tasks WHERE request_id=? ORDER BY due_at', r.id),
    });
  }),
);
crmRouter.patch(
  '/requests/:id',
  wrap(async (req, res) => {
    assertWrite(req.user!);
    const r = visibleRequest(req.user!, String(req.params.id));
    const data = z
      .object({
        version: z.number().int(),
        status: z.enum(REQUEST_STATUSES).optional(),
        owner_id: z.string().nullable().optional(),
        priority: z.enum(['low', 'normal', 'high']).optional(),
        close_reason: z.string().max(500).nullable().optional(),
        follow_up_at: optionalDate,
        is_spam: z.boolean().optional(),
        is_test: z.boolean().optional(),
      })
      .strict()
      .parse(req.body);
    version(r, data.version);
    if (
      (data.is_spam !== undefined || data.is_test !== undefined) &&
      !['admin', 'manager'].includes(req.user!.role)
    )
      throw new HttpError(403, 'Alleen manager of beheerder mag gegevens classificeren.');
    if (
      ['admin', 'manager'].includes(req.user!.role) &&
      data.close_reason?.trim().toLowerCase() === 'spam'
    )
      data.is_spam = true;
    if (data.owner_id !== undefined) {
      if (req.user!.role === 'seller')
        throw new HttpError(403, 'Alleen de salesmanager mag toewijzen.');
      ownerAllowed(data.owner_id, req.user!);
    }
    const merged = { ...r, ...data };
    if (merged.status === 'closed' && !merged.close_reason)
      throw new HttpError(400, 'Geef een afrondreden.');
    if (merged.status === 'waiting' && !merged.follow_up_at)
      throw new HttpError(400, 'Kies een opvolgdatum.');
    transaction(() => {
      const values = Object.entries(data).filter(([k]) => k !== 'version');
      if (values.length) {
        const result = db
          .prepare(
            `UPDATE requests SET ${values.map(([k]) => `${k}=?`).join(',')},version=version+1,updated_at=? WHERE id=? AND version=?`,
          )
          .run(
            ...values.map(([, v]) => (typeof v === 'boolean' ? Number(v) : (v as any))),
            now(),
            r.id,
            r.version,
          );
        if (!result.changes) throw new HttpError(409, 'Dossier gewijzigd.');
        snapshotRequest(r.id);
        audit(req.user!.id, 'request', r.id, 'updated', {
          before: { status: r.status, owner_id: r.owner_id, priority: r.priority },
          changes: data,
        });
        if (data.status && data.status !== r.status)
          db.prepare(
            'INSERT INTO activities(id,request_id,actor_id,kind,body,created_at) VALUES(?,?,?,?,?,?)',
          ).run(
            id(),
            r.id,
            req.user!.id,
            'status',
            `Opvolgstatus gewijzigd naar ${LABELS[data.status] ?? data.status}.`,
            now(),
          );
        if (data.owner_id !== undefined && data.owner_id !== r.owner_id)
          db.prepare(
            'INSERT INTO activities(id,request_id,actor_id,kind,body,created_at) VALUES(?,?,?,?,?,?)',
          ).run(
            id(),
            r.id,
            req.user!.id,
            'assignment',
            data.owner_id
              ? 'Aanvraag toegewezen aan ' +
                  row('SELECT name FROM users WHERE id=?', data.owner_id)?.name +
                  '.'
              : 'Toewijzing verwijderd.',
            now(),
          );
        if (data.owner_id !== undefined) {
          db.prepare(
            'UPDATE tasks SET owner_id=?,version=version+1,updated_at=? WHERE request_id=? AND completed=0',
          ).run(data.owner_id, now(), r.id);
          db.prepare(
            'INSERT INTO assignments(id,request_id,previous_owner_id,owner_id,actor_id,created_at) VALUES(?,?,?,?,?,?)',
          ).run(id(), r.id, r.owner_id, data.owner_id, req.user!.id, now());
          if (data.owner_id)
            db.prepare(
              'INSERT INTO notifications(id,user_id,request_id,message,created_at) VALUES(?,?,?,?,?)',
            ).run(id(), data.owner_id, r.id, 'Een aanvraag is aan jou toegewezen.', now());
        }
      }
    });
    res.json({ request: row('SELECT * FROM requests WHERE id=?', r.id) });
  }),
);
crmRouter.post(
  '/requests/:id/activities',
  wrap(async (req, res) => {
    assertWrite(req.user!);
    const r = visibleRequest(req.user!, String(req.params.id));
    const data = z
      .object({
        kind: z.enum(['note', 'call', 'email', 'meeting']),
        body: z.string().trim().min(1).max(10000),
      })
      .parse(req.body);
    const aid = id();
    transaction(() => {
      db.prepare(
        'INSERT INTO activities(id,request_id,actor_id,kind,body,created_at) VALUES(?,?,?,?,?,?)',
      ).run(aid, r.id, req.user!.id, data.kind, data.body, now());
      if (data.kind !== 'note')
        db.prepare('UPDATE requests SET updated_at=?,version=version+1 WHERE id=?').run(
          now(),
          r.id,
        );
      audit(req.user!.id, 'request', r.id, 'activity_added', { kind: data.kind, activity_id: aid });
    });
    res.status(201).json({ activity: row('SELECT * FROM activities WHERE id=?', aid) });
  }),
);
crmRouter.post(
  '/requests/:id/tasks',
  wrap(async (req, res) => {
    assertWrite(req.user!);
    const r = visibleRequest(req.user!, String(req.params.id));
    const data = z.object({ title: nonempty, due_at: date }).parse(req.body);
    const tid = id();
    transaction(() => {
      db.prepare(
        'INSERT INTO tasks(id,request_id,owner_id,title,due_at,created_at,updated_at) VALUES(?,?,?,?,?,?,?)',
      ).run(tid, r.id, r.owner_id ?? req.user!.id, data.title, data.due_at, now(), now());
      db.prepare(
        'INSERT INTO activities(id,request_id,actor_id,kind,body,created_at) VALUES(?,?,?,?,?,?)',
      ).run(id(), r.id, req.user!.id, 'task', 'Opvolgtaak gepland.', now());
      audit(req.user!.id, 'request', r.id, 'task_created', { task_id: tid });
    });
    res.status(201).json({ task: row('SELECT * FROM tasks WHERE id=?', tid) });
  }),
);
crmRouter.get(
  '/tasks',
  wrap(async (req, res) => {
    const access = scope(req.user!);
    res.json({
      items: rows(
        `SELECT t.*,c.name company_name,r.status request_status FROM tasks t JOIN requests r ON r.id=t.request_id LEFT JOIN companies c ON c.id=r.company_id WHERE ${access.sql}${req.user!.role === 'seller' ? ' AND t.owner_id=?' : ''} ORDER BY t.completed,t.due_at`,
        ...access.params,
        ...(req.user!.role === 'seller' ? [req.user!.id] : []),
      ),
    });
  }),
);
crmRouter.patch(
  '/tasks/:id',
  wrap(async (req, res) => {
    assertWrite(req.user!);
    const t = row('SELECT * FROM tasks WHERE id=?', String(req.params.id));
    if (!t) throw new HttpError(404, 'Taak niet gevonden.');
    visibleRequest(req.user!, t.request_id);
    if (req.user!.role === 'seller' && t.owner_id !== req.user!.id)
      throw new HttpError(404, 'Taak niet gevonden.');
    const data = z.object({ version: z.number().int(), completed: z.boolean() }).parse(req.body);
    version(t, data.version);
    const result = db
      .prepare(
        'UPDATE tasks SET completed=?,version=version+1,updated_at=? WHERE id=? AND version=?',
      )
      .run(data.completed ? 1 : 0, now(), t.id, data.version);
    if (!result.changes) throw new HttpError(409, 'Taak is intussen gewijzigd.');
    audit(req.user!.id, 'request', t.request_id, 'task_updated', {
      task_id: t.id,
      completed: data.completed,
    });
    res.json({ task: row('SELECT * FROM tasks WHERE id=?', t.id) });
  }),
);
crmRouter.get(
  '/opportunities',
  wrap(async (req, res) => {
    res.json({ items: listOpportunities(req.user!, req.query) });
  }),
);
crmRouter.post(
  '/requests/:id/opportunities',
  wrap(async (req, res) => {
    assertWrite(req.user!);
    const r = visibleRequest(req.user!, String(req.params.id));
    const data = z
      .object({
        title: nonempty,
        amount: z.number().nonnegative().nullable().optional(),
        stage: z.enum(STAGES).default('qualified'),
        expected_close_at: optionalDate,
      })
      .parse(req.body);
    if (['won', 'lost', 'waiting'].includes(data.stage))
      throw new HttpError(
        400,
        'Maak eerst een open verkoopkans aan en vul daarna de afsluitgegevens in.',
      );
    const oid = id();
    transaction(() => {
      db.prepare(
        'INSERT INTO opportunities(id,company_id,owner_id,title,stage,amount,expected_close_at,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)',
      ).run(
        oid,
        r.company_id,
        r.owner_id,
        data.title,
        data.stage,
        data.amount ?? null,
        data.expected_close_at ?? null,
        now(),
        now(),
      );
      db.prepare('INSERT INTO opportunity_requests(opportunity_id,request_id) VALUES(?,?)').run(
        oid,
        r.id,
      );
      db.prepare(
        'INSERT INTO opportunity_history(id,opportunity_id,actor_id,created_at,snapshot_json) VALUES(?,?,?,?,?)',
      ).run(
        id(),
        oid,
        req.user!.id,
        now(),
        JSON.stringify({
          ...row('SELECT * FROM opportunities WHERE id=?', oid),
          linked_request_ids: [r.id],
        }),
      );
      audit(req.user!.id, 'opportunity', oid, 'created', { request_id: r.id });
    });
    res.status(201).json({ opportunity: row('SELECT * FROM opportunities WHERE id=?', oid) });
  }),
);
crmRouter.post(
  '/opportunities/:id/requests',
  wrap(async (req, res) => {
    assertWrite(req.user!);
    const o = visibleOpportunity(req.user!, String(req.params.id));
    const data = z.object({ request_id: z.string() }).parse(req.body);
    const r = visibleRequest(req.user!, data.request_id);
    if (r.company_id !== o.company_id)
      throw new HttpError(400, 'Koppel alleen aanvragen van hetzelfde bedrijf.');
    transaction(() => {
      const result = db
        .prepare(
          'INSERT OR IGNORE INTO opportunity_requests(opportunity_id,request_id) VALUES(?,?)',
        )
        .run(o.id, r.id);
      if (result.changes) {
        db.prepare(
          'INSERT INTO opportunity_history(id,opportunity_id,actor_id,created_at,snapshot_json) VALUES(?,?,?,?,?)',
        ).run(
          id(),
          o.id,
          req.user!.id,
          now(),
          JSON.stringify({
            ...o,
            linked_request_ids: rows(
              'SELECT request_id FROM opportunity_requests WHERE opportunity_id=?',
              o.id,
            ).map((link) => link.request_id),
          }),
        );
        audit(req.user!.id, 'opportunity', o.id, 'request_linked', { request_id: r.id });
      }
    });
    res.json({ ok: true });
  }),
);
crmRouter.patch(
  '/opportunities/:id',
  wrap(async (req, res) => {
    assertWrite(req.user!);
    const o = visibleOpportunity(req.user!, String(req.params.id));
    const data = z
      .object({
        version: z.number().int(),
        stage: z.enum(STAGES).optional(),
        amount: z.number().nonnegative().nullable().optional(),
        expected_close_at: optionalDate,
        closed_at: optionalDate,
        follow_up_at: optionalDate,
        loss_reason: z.string().max(500).nullable().optional(),
        owner_id: z.string().nullable().optional(),
      })
      .strict()
      .parse(req.body);
    version(o, data.version);
    if (data.owner_id !== undefined) {
      if (req.user!.role === 'seller')
        throw new HttpError(403, 'Alleen een manager mag herverdelen.');
      ownerAllowed(data.owner_id, req.user!);
    }
    const merged = { ...o, ...data };
    const stage = data.stage === undefined ? o.stage : data.stage;
    if (stage === 'lost' && !merged.loss_reason) throw new HttpError(400, 'Geef een verliesreden.');
    if (stage === 'waiting' && !merged.follow_up_at)
      throw new HttpError(400, 'Kies een opvolgdatum.');
    if (['won', 'lost'].includes(stage) && !merged.closed_at)
      throw new HttpError(400, 'Kies een afsluitdatum.');
    const changes: Record<string, any> = Object.fromEntries(
      Object.entries(data).filter(([k]) => k !== 'version'),
    );
    if (data.stage && !['won', 'lost'].includes(data.stage)) {
      changes.closed_at = null;
      changes.owner_at_close = null;
    }
    if (['won', 'lost'].includes(stage) && o.stage !== stage)
      changes.owner_at_close = data.owner_id ?? o.owner_id;
    transaction(() => {
      const values = Object.entries(changes);
      if (values.length) {
        const result = db
          .prepare(
            `UPDATE opportunities SET ${values.map(([k]) => `${k}=?`).join(',')},version=version+1,updated_at=? WHERE id=? AND version=?`,
          )
          .run(...values.map(([, v]) => v), now(), o.id, data.version);
        if (!result.changes) throw new HttpError(409, 'Verkoopkans gewijzigd.');
        db.prepare(
          'INSERT INTO opportunity_history(id,opportunity_id,actor_id,created_at,snapshot_json) VALUES(?,?,?,?,?)',
        ).run(
          id(),
          o.id,
          req.user!.id,
          now(),
          JSON.stringify({
            ...o,
            ...changes,
            linked_request_ids: rows(
              'SELECT request_id FROM opportunity_requests WHERE opportunity_id=?',
              o.id,
            ).map((link) => link.request_id),
          }),
        );
        audit(req.user!.id, 'opportunity', o.id, 'updated', {
          before: { stage: o.stage, amount: o.amount, owner_id: o.owner_id },
          changes,
        });
        if (data.stage && data.stage !== o.stage)
          for (const link of rows(
            'SELECT request_id FROM opportunity_requests WHERE opportunity_id=?',
            o.id,
          ))
            db.prepare(
              'INSERT INTO activities(id,request_id,opportunity_id,actor_id,kind,body,created_at) VALUES(?,?,?,?,?,?,?)',
            ).run(
              id(),
              link.request_id,
              o.id,
              req.user!.id,
              'pipeline',
              `Verkoopfase gewijzigd naar ${LABELS[data.stage] ?? data.stage}.`,
              now(),
            );
      }
    });
    res.json({ opportunity: row('SELECT * FROM opportunities WHERE id=?', o.id) });
  }),
);
crmRouter.get(
  '/companies',
  wrap(async (req, res) => {
    const access = companyScope(req.user!);
    const params: any[] = [...access.params];
    let where = access.sql;
    if (req.query.search) {
      where += ' AND c.name LIKE ?';
      params.push('%' + String(req.query.search) + '%');
    }
    res.json({
      items: rows(
        `SELECT c.*,u.name owner_name FROM companies c LEFT JOIN users u ON u.id=c.owner_id WHERE ${where} ORDER BY c.name`,
        ...params,
      ),
    });
  }),
);
crmRouter.post(
  '/companies',
  wrap(async (req, res) => {
    res.status(201).json({ company: createCompany(req.user!, req.body) });
  }),
);
crmRouter.get(
  '/companies/:id',
  wrap(async (req, res) => {
    const c = visibleCompany(req.user!, String(req.params.id));
    const requests = listRequests(req.user!, {}).filter((r) => r.company_id === c.id);
    const opportunities = listOpportunities(req.user!, {}).filter((o) => o.company_id === c.id);
    const contactIds = new Set(requests.map((r) => r.contact_id));
    const locationIds = new Set(requests.map((r) => r.location_id));
    res.json({
      company: c,
      contacts: rows('SELECT * FROM contacts WHERE company_id=?', c.id).filter(
        (ct) => wholeCompany(req.user!, c) || contactIds.has(ct.id),
      ),
      locations: rows('SELECT * FROM locations WHERE company_id=?', c.id).filter(
        (l) => wholeCompany(req.user!, c) || locationIds.has(l.id),
      ),
      requests,
      opportunities,
    });
  }),
);
crmRouter.post(
  '/companies/:id/location',
  wrap(async (req, res) => {
    assertWrite(req.user!);
    const c = visibleCompany(req.user!, String(req.params.id));
    const data = z
      .object({
        version: z.number().int(),
        latitude: z.number().min(-90).max(90),
        longitude: z.number().min(-180).max(180),
        precision: z.enum(['address', 'postcode']),
        country: z.string().length(2),
        address: z.string().max(300).optional(),
        postcode: z.string().max(20).optional(),
        city: z.string().max(100).optional(),
      })
      .parse(req.body);
    version(c, data.version);
    transaction(() => {
      const locationAccess = scope(req.user!, 'lr');
      let l = !wholeCompany(req.user!, c)
        ? row(
            `SELECT l.* FROM locations l JOIN requests lr ON lr.location_id=l.id WHERE l.company_id=? AND ${locationAccess.sql} ORDER BY l.id LIMIT 1`,
            c.id,
            ...locationAccess.params,
          )
        : row('SELECT * FROM locations WHERE company_id=? ORDER BY id LIMIT 1', c.id);
      if (!l) {
        const lid = id();
        db.prepare('INSERT INTO locations(id,company_id,country) VALUES(?,?,?)').run(
          lid,
          c.id,
          data.country,
        );
        l = { id: lid };
      }
      db.prepare(
        'UPDATE locations SET latitude=?,longitude=?,precision=?,country=?,address=COALESCE(?,address),postcode=COALESCE(?,postcode),city=COALESCE(?,city),geocode_source=?,geocoded_at=?,manually_confirmed=1,version=version+1 WHERE id=?',
      ).run(
        data.latitude,
        data.longitude,
        data.precision,
        data.country,
        data.address ?? null,
        data.postcode ?? null,
        data.city ?? null,
        'manual',
        now(),
        l.id,
      );
      const changed = db
        .prepare('UPDATE companies SET version=version+1,updated_at=? WHERE id=? AND version=?')
        .run(now(), c.id, data.version);
      if (!changed.changes) throw new HttpError(409, 'Bedrijf is intussen gewijzigd.');
      if (!wholeCompany(req.user!, c)) {
        const ra = scope(req.user!);
        db.prepare(
          `UPDATE requests AS r SET location_id=COALESCE(location_id,?) WHERE company_id=? AND ${ra.sql}`,
        ).run(l.id, c.id, ...ra.params);
      } else
        db.prepare(
          'UPDATE requests SET location_id=COALESCE(location_id,?) WHERE company_id=?',
        ).run(l.id, c.id);
      snapshotCompanyRequests(c.id);
      audit(req.user!.id, 'company', c.id, 'location_confirmed', { precision: data.precision });
    });
    res.json({ ok: true });
  }),
);
crmRouter.get(
  '/map',
  wrap(async (req, res) => {
    const geo = geocodingStatus();
    const requests = listRequests(req.user!, req.query);
    const located = requests.filter((r) => r.latitude !== null && r.longitude !== null);
    const opps = listOpportunities(req.user!, req.query);
    const items = located.map((r) => ({
      id: r.id,
      kind: 'request',
      company_id: r.company_id,
      company_name: r.company_name,
      status: r.status,
      owner_id: r.owner_id,
      latitude: r.latitude,
      longitude: r.longitude,
      precision: r.precision,
      city: r.city,
      country: r.country,
    }));
    for (const o of opps.filter((o) => !['won', 'lost'].includes(o.stage))) {
      const linkedIds = new Set(
        rows('SELECT request_id FROM opportunity_requests WHERE opportunity_id=?', o.id).map(
          (link) => link.request_id,
        ),
      );
      const linkedLocations = located.filter((r) => linkedIds.has(r.id));
      const unique = new Map(linkedLocations.map((r) => [`${r.latitude},${r.longitude}`, r]));
      for (const r of unique.values())
        items.push({
          id: o.id,
          kind: 'opportunity',
          company_id: o.company_id,
          company_name: o.company_name,
          status: o.stage,
          owner_id: o.owner_id,
          latitude: r.latitude,
          longitude: r.longitude,
          precision: r.precision,
          city: r.city,
          country: r.country,
        });
    }
    res.json({
      items,
      missing: requests
        .filter((r) => r.latitude === null || r.longitude === null)
        .map((r) => ({ id: r.id, company_name: r.company_name, country: r.country })),
      provider: {
        configured: !!process.env.MAP_TILE_URL,
        status: process.env.MAP_TILE_URL ? 'configured' : 'not_configured',
        tile_url: process.env.MAP_TILE_URL ?? null,
        attribution: process.env.MAP_TILE_ATTRIBUTION ?? '',
        geocoding: geo.status,
        geocoding_provider: geo.provider,
        ...(req.user!.role === 'admin' ? { geocoding_queue: geo.queue } : {}),
      },
    });
  }),
);
crmRouter.get(
  '/notifications',
  wrap(async (req, res) => {
    res.json({
      items: rows(
        'SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 100',
        req.user!.id,
      ),
    });
  }),
);
crmRouter.patch(
  '/requests/:id/marketing',
  wrap(async (req, res) => {
    if (
      req.user!.role !== 'admin' &&
      !(req.user!.role === 'management' && req.user!.marketing_permission)
    )
      throw new HttpError(403, 'Marketingrechten vereist.');
    const r = visibleRequest(req.user!, String(req.params.id));
    const data = z
      .object({
        version: z.number().int(),
        campaign: z.string().max(200).nullable().optional(),
        business_unit: z.enum(['Wood', 'Stone', 'Glass', 'Unknown']).optional(),
        brand: z.string().max(200).nullable().optional(),
      })
      .strict()
      .parse(req.body);
    version(r, data.version);
    const changes = Object.entries(data).filter(([k]) => k !== 'version');
    if (changes.length) {
      db.prepare(
        `UPDATE requests SET ${changes.map(([k]) => `${k}=?`).join(',')},version=version+1,updated_at=? WHERE id=? AND version=?`,
      ).run(...changes.map(([, v]) => v as any), now(), r.id, data.version);
      snapshotRequest(r.id);
      audit(req.user!.id, 'request', r.id, 'marketing_updated', data);
    }
    res.json({ request: row('SELECT * FROM requests WHERE id=?', r.id) });
  }),
);
crmRouter.post(
  '/companies/:id/merge',
  requireRoles('admin', 'manager'),
  wrap(async (req, res) => {
    const source = visibleCompany(req.user!, String(req.params.id));
    const data = z
      .object({
        target_id: z.string(),
        source_version: z.number().int(),
        target_version: z.number().int(),
        confirmed: z.literal(true),
      })
      .parse(req.body);
    const target = visibleCompany(req.user!, data.target_id);
    if (source.id === target.id) throw new HttpError(400, 'Kies twee verschillende bedrijven.');
    version(source, data.source_version);
    version(target, data.target_version);
    if (isTeamScoped(req.user!)) {
      const rs = scope(req.user!),
        os = portfolioScope(req.user!);
      for (const company of [source, target])
        if (
          row(
            `SELECT r.id FROM requests r WHERE r.company_id=? AND NOT(${rs.sql}) LIMIT 1`,
            company.id,
            ...rs.params,
          ) ||
          row(
            `SELECT o.id FROM opportunities o WHERE o.company_id=? AND NOT(${os.sql}) LIMIT 1`,
            company.id,
            ...os.params,
          )
        )
          throw new HttpError(
            403,
            'Dit bedrijf bevat dossiers buiten je team; een beheerder moet de samenvoeging uitvoeren.',
          );
    }
    if (source.country !== target.country)
      throw new HttpError(400, 'Bedrijven uit verschillende landen vereisen handmatige controle.');
    transaction(() => {
      for (const contact of rows('SELECT * FROM contacts WHERE company_id=?', source.id)) {
        const existing = contact.email
          ? row('SELECT * FROM contacts WHERE company_id=? AND email=?', target.id, contact.email)
          : null;
        if (existing) {
          db.prepare('UPDATE requests SET contact_id=? WHERE contact_id=?').run(
            existing.id,
            contact.id,
          );
          audit(req.user!.id, 'contact', existing.id, 'merged', { source_contact_id: contact.id });
          db.prepare('DELETE FROM contacts WHERE id=?').run(contact.id);
        } else db.prepare('UPDATE contacts SET company_id=? WHERE id=?').run(target.id, contact.id);
      }
      for (const table of ['locations', 'requests', 'opportunities', 'activities', 'tasks'])
        db.prepare(`UPDATE ${table} SET company_id=? WHERE company_id=?`).run(target.id, source.id);
      db.prepare('UPDATE companies SET version=version+1,updated_at=? WHERE id=?').run(
        now(),
        target.id,
      );
      snapshotCompanyRequests(target.id);
      audit(req.user!.id, 'company', target.id, 'merged', {
        source_id: source.id,
        target_id: target.id,
      });
      db.prepare('DELETE FROM companies WHERE id=?').run(source.id);
    });
    res.json({ company: row('SELECT * FROM companies WHERE id=?', target.id) });
  }),
);
