import { createHash } from 'node:crypto';
import { db, id, now, transaction } from './db.js';
import { snapshotRequest } from './history.js';

type Location = Record<string, any>;
type Job = Record<string, any>;
const COUNTRIES: Record<string, string> = { BE: 'Belgium', NL: 'Netherlands', LU: 'Luxembourg' };
const MAX_ATTEMPTS = 5;
const LEASE_MS = 30_000;
let running = false;
let lastRequestAt = 0;

function configuration() {
  const termsConfirmed = process.env.GEOCODING_TERMS_CONFIRMED === 'true';
  if (!process.env.GEOCODING_URL)
    return {
      configured: false,
      status: 'not_configured',
      provider: null,
      terms_confirmed: termsConfirmed,
      url: null,
    };
  let url: URL;
  try {
    url = new URL(process.env.GEOCODING_URL);
  } catch {
    return {
      configured: false,
      status: 'invalid_url',
      provider: null,
      terms_confirmed: termsConfirmed,
      url: null,
    };
  }
  if (url.protocol !== 'https:' || url.username || url.password || url.hash)
    return {
      configured: false,
      status: 'invalid_url',
      provider: null,
      terms_confirmed: termsConfirmed,
      url: null,
    };
  return {
    configured: termsConfirmed,
    status: termsConfirmed ? 'configured_not_live_verified' : 'terms_not_confirmed',
    provider: url.hostname,
    terms_confirmed: termsConfirmed,
    url,
  };
}
export function geocodingStatus() {
  const { url: _url, ...status } = configuration();
  const rows = db
    .prepare('SELECT status,count(*) AS count FROM geocode_jobs GROUP BY status')
    .all() as { status: string; count: number }[];
  return {
    ...status,
    protocol: 'photon-compatible-geojson',
    queue: Object.fromEntries(rows.map((row) => [row.status, row.count])),
    coverage: ['BE', 'NL', 'LU'],
    notice:
      'Externe geocodering vereist bevestigde providervoorwaarden; geverifieerde en handmatig bevestigde locaties worden behouden.',
  };
}
const fingerprint = (location: Location) =>
  createHash('sha256')
    .update(
      JSON.stringify([
        location.country,
        location.address,
        location.postcode,
        location.city,
        location.region,
      ]),
    )
    .digest('hex');
function hasCoordinates(location: Location) {
  return (
    typeof location.latitude === 'number' &&
    typeof location.longitude === 'number' &&
    Number.isFinite(location.latitude) &&
    Number.isFinite(location.longitude) &&
    location.latitude >= -90 &&
    location.latitude <= 90 &&
    location.longitude >= -180 &&
    location.longitude <= 180
  );
}
function eligible(location: Location) {
  return (
    !location.manually_confirmed &&
    !hasCoordinates(location) &&
    Object.hasOwn(COUNTRIES, String(location.country).toUpperCase()) &&
    !!(
      String(location.address || '').trim() ||
      String(location.postcode || '').trim() ||
      String(location.city || '').trim()
    )
  );
}
function queueLocations() {
  const locations = db
    .prepare(
      "SELECT * FROM locations WHERE manually_confirmed=0 AND (latitude IS NULL OR longitude IS NULL OR latitude NOT BETWEEN -90 AND 90 OR longitude NOT BETWEEN -180 AND 180) AND upper(country) IN ('BE','NL','LU')",
    )
    .all() as Location[];
  transaction(() => {
    for (const location of locations) {
      if (!eligible(location)) continue;
      const hash = fingerprint(location);
      const existing = db
        .prepare('SELECT * FROM geocode_jobs WHERE location_id=?')
        .get(location.id) as Job | undefined;
      if (!existing)
        db.prepare(
          'INSERT INTO geocode_jobs(id,location_id,address_fingerprint,status,created_at,updated_at) VALUES (?,?,?,?,?,?)',
        ).run(id(), location.id, hash, 'pending', now(), now());
      else if (existing.address_fingerprint !== hash)
        db.prepare(
          "UPDATE geocode_jobs SET address_fingerprint=?,status='pending',attempts=0,next_attempt_at=NULL,error_code=NULL,updated_at=? WHERE id=?",
        ).run(hash, now(), existing.id);
    }
  });
}
function providerResult(
  value: unknown,
  requestedCountry: string,
): { latitude: number; longitude: number; precision: 'address' | 'postcode' } {
  const result = value as any;
  const feature =
    result?.type === 'FeatureCollection' && Array.isArray(result.features)
      ? result.features[0]
      : null;
  if (!feature) throw new GeocodingFailure('NO_MATCH', false);
  const coords = feature?.geometry?.type === 'Point' ? feature.geometry.coordinates : null;
  if (
    !Array.isArray(coords) ||
    coords.length < 2 ||
    typeof coords[0] !== 'number' ||
    typeof coords[1] !== 'number' ||
    !Number.isFinite(coords[0]) ||
    !Number.isFinite(coords[1]) ||
    coords[0] < -180 ||
    coords[0] > 180 ||
    coords[1] < -90 ||
    coords[1] > 90
  )
    throw new GeocodingFailure('INVALID_COORDINATES', false);
  const properties = feature.properties || {};
  const country = String(properties.countrycode || properties.country_code || '').toUpperCase();
  if (country !== requestedCountry) throw new GeocodingFailure('COUNTRY_MISMATCH', false);
  const type = String(properties.type || properties.osm_value || '').toLowerCase();
  // Photon house/building results represent an address. Other matches remain approximate.
  const precise = !!properties.housenumber || ['house', 'building'].includes(type);
  if (!precise && !properties.postcode) throw new GeocodingFailure('INSUFFICIENT_PRECISION', false);
  return { latitude: coords[1], longitude: coords[0], precision: precise ? 'address' : 'postcode' };
}
class GeocodingFailure extends Error {
  constructor(
    public code: string,
    public retryable: boolean,
  ) {
    super(code);
  }
}
function finish(jobId: string, status: string, errorCode: string | null = null) {
  db.prepare(
    'UPDATE geocode_jobs SET status=?,next_attempt_at=NULL,error_code=?,updated_at=? WHERE id=?',
  ).run(status, errorCode, now(), jobId);
}

/** Durable queue separate from intake; fetch can be injected for contract tests. */
export async function processGeocoding(limit = 1, fetcher: typeof fetch = globalThis.fetch) {
  if (running) return { processed: 0, status: 'busy' };
  running = true;
  let processed = 0;
  try {
    queueLocations();
    const config = configuration();
    if (!config.configured || !config.url) return { processed: 0, status: config.status };
    const minInterval = Math.max(1000, Number(process.env.GEOCODING_MIN_INTERVAL_MS) || 1000);
    for (let n = 0; n < Math.max(0, Math.min(10, limit)); n++) {
      if (Date.now() - lastRequestAt < minInterval) break;
      // Expired processing leases recover after a process crash without losing the address job.
      const job = db
        .prepare(
          "SELECT * FROM geocode_jobs WHERE status IN ('pending','retry','processing') AND (next_attempt_at IS NULL OR next_attempt_at<=?) ORDER BY created_at LIMIT 1",
        )
        .get(now()) as Job | undefined;
      if (!job) break;
      const location = db.prepare('SELECT * FROM locations WHERE id=?').get(job.location_id) as
        | Location
        | undefined;
      if (!location || !eligible(location)) {
        finish(job.id, 'skipped');
        continue;
      }
      if (fingerprint(location) !== job.address_fingerprint) {
        finish(job.id, 'skipped', 'ADDRESS_CHANGED');
        continue;
      }
      if (job.attempts >= MAX_ATTEMPTS) {
        finish(job.id, 'failed', 'ATTEMPT_LIMIT_REACHED');
        continue;
      }
      const attempts = job.attempts + 1;
      db.prepare(
        "UPDATE geocode_jobs SET status='processing',attempts=?,next_attempt_at=?,updated_at=? WHERE id=?",
      ).run(attempts, new Date(Date.now() + LEASE_MS).toISOString(), now(), job.id);
      const url = new URL(config.url);
      const country = String(location.country).toUpperCase();
      url.searchParams.set(
        'q',
        [location.address, location.postcode, location.city, location.region, COUNTRIES[country]]
          .filter(Boolean)
          .join(', '),
      );
      url.searchParams.set('limit', '1');
      lastRequestAt = Date.now();
      try {
        const response = await fetcher(url, {
          method: 'GET',
          headers: {
            Accept: 'application/json',
            'User-Agent': 'OPTIMAT-Sales-Hub/0.1 server-geocoder',
          },
          signal: AbortSignal.timeout(8000),
          redirect: 'error',
        });
        if (!response.ok)
          throw new GeocodingFailure(
            response.status === 429
              ? 'PROVIDER_RATE_LIMIT'
              : response.status === 401 || response.status === 403
                ? 'PROVIDER_ACCESS_DENIED'
                : 'PROVIDER_HTTP_ERROR',
            response.status === 429 || response.status >= 500,
          );
        const text = await response.text();
        if (text.length > 1024 * 1024) throw new GeocodingFailure('RESPONSE_TOO_LARGE', false);
        let parsed: unknown;
        try {
          parsed = JSON.parse(text);
        } catch {
          throw new GeocodingFailure('INVALID_PROVIDER_RESPONSE', true);
        }
        const point = providerResult(parsed, country);
        transaction(() => {
          const current = db.prepare('SELECT * FROM locations WHERE id=?').get(location.id) as
            | Location
            | undefined;
          if (
            !current ||
            !eligible(current) ||
            current.version !== location.version ||
            fingerprint(current) !== job.address_fingerprint
          ) {
            finish(job.id, 'skipped', 'LOCATION_CHANGED');
            return;
          }
          db.prepare(
            'UPDATE locations SET latitude=?,longitude=?,precision=?,geocode_source=?,geocoded_at=?,version=version+1 WHERE id=?',
          ).run(
            point.latitude,
            point.longitude,
            point.precision,
            config.provider,
            now(),
            location.id,
          );
          for (const request of db
            .prepare('SELECT id FROM requests WHERE location_id=?')
            .all(location.id) as { id: string }[])
            snapshotRequest(request.id);
          finish(job.id, 'completed');
        });
      } catch (error) {
        const failure =
          error instanceof GeocodingFailure
            ? error
            : new GeocodingFailure('PROVIDER_UNAVAILABLE', true);
        const retry = failure.retryable && attempts < MAX_ATTEMPTS;
        db.prepare(
          'UPDATE geocode_jobs SET status=?,next_attempt_at=?,error_code=?,updated_at=? WHERE id=?',
        ).run(
          retry ? 'retry' : 'failed',
          retry
            ? new Date(Date.now() + Math.min(3600000, 30000 * 2 ** (attempts - 1))).toISOString()
            : null,
          failure.code,
          now(),
          job.id,
        );
      }
      processed++;
    }
    return { processed, status: 'ok' };
  } finally {
    running = false;
  }
}
