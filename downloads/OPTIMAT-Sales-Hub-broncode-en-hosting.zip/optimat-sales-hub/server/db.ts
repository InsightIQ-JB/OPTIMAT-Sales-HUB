import { DatabaseSync } from 'node:sqlite';
import { mkdirSync, readFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { randomUUID } from 'node:crypto';
export const dbPath = process.env.DB_PATH || resolve('.data/optimat.sqlite');
if (dbPath !== ':memory:') mkdirSync(dirname(dbPath), { recursive: true, mode: 0o700 });
export const db = new DatabaseSync(dbPath);
db.exec('PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;');
export const now = () => new Date().toISOString();
export const id = () => randomUUID();
export const json = (value: unknown) => JSON.stringify(value);
export function initDb() {
  db.exec(readFileSync(new URL('../migrations/001.sql', import.meta.url), 'utf8'));
  db.prepare('INSERT OR IGNORE INTO schema_migrations VALUES (?,?)').run('001', now());
  for (const version of ['002', '003', '004', '005', '006', '007'])
    if (!db.prepare('SELECT version FROM schema_migrations WHERE version=?').get(version))
      transaction(() => {
        db.exec(readFileSync(new URL(`../migrations/${version}.sql`, import.meta.url), 'utf8'));
        db.prepare('INSERT INTO schema_migrations VALUES (?,?)').run(version, now());
      });
}
export function transaction<T>(fn: () => T): T {
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (e) {
    db.exec('ROLLBACK');
    throw e;
  }
}
export function audit(
  actorId: string | null,
  entityType: string,
  entityId: string,
  action: string,
  details: unknown = {},
) {
  db.prepare('INSERT INTO audit_log VALUES (?,?,?,?,?,?,?)').run(
    id(),
    actorId,
    entityType,
    entityId,
    action,
    json(details),
    now(),
  );
}
initDb();
