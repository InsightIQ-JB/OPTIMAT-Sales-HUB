import { Router, type RequestHandler } from 'express';
import { randomBytes, scryptSync, timingSafeEqual, createHash } from 'node:crypto';
import { z } from 'zod';
import { db, id, now, audit, transaction } from './db.js';
import { geocodingStatus } from './geocoding.js';
import { HttpError, wrap } from './errors.js';
import { ROLES, type User, type Role } from '../shared/domain.js';
declare global {
  namespace Express {
    interface Request {
      user: User;
      csrf: string;
      sessionHash: string;
    }
  }
}
export const hash = (s: string) => createHash('sha256').update(s).digest('hex');
export function hashPassword(password: string) {
  const salt = randomBytes(16).toString('hex');
  return `${salt}:${scryptSync(password, salt, 64).toString('hex')}`;
}
function verifyPassword(password: string, stored: string) {
  const [salt, expected] = stored.split(':');
  if (!salt || !expected) return false;
  const computed = scryptSync(password, salt, 64);
  const bytes = Buffer.from(expected, 'hex');
  return bytes.length === computed.length && timingSafeEqual(bytes, computed);
}
export function publicUser(row: any): User {
  return {
    id: row.id,
    name: row.name,
    email: row.email,
    role: row.role,
    team_id: row.team_id,
    marketing_permission: row.marketing_permission,
    active: row.active,
  };
}
function sessionToken(req: any) {
  const cookie = req.headers.cookie || '';
  return cookie
    .split(';')
    .map((s: string) => s.trim())
    .find((s: string) => s.startsWith('optimat_session='))
    ?.slice(16);
}
export const requireAuth: RequestHandler = (req, _res, next) => {
  const token = sessionToken(req);
  if (!token) return next(new HttpError(401, 'Meld je aan om verder te gaan.'));
  const row = db
    .prepare(
      'SELECT u.*,s.csrf,s.id_hash FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.id_hash=? AND s.expires_at>? AND u.active=1',
    )
    .get(hash(token), now()) as any;
  if (!row) return next(new HttpError(401, 'Je sessie is verlopen. Meld je opnieuw aan.'));
  req.user = publicUser(row);
  req.csrf = row.csrf;
  req.sessionHash = row.id_hash;
  next();
};
export const requireRoles =
  (...roles: Role[]): RequestHandler =>
  (req, _res, next) =>
    roles.includes(req.user.role)
      ? next()
      : next(new HttpError(403, 'Je hebt geen toegang tot deze actie.'));
export const canWrite = (user: User) => ['admin', 'manager', 'seller'].includes(user.role);
export function assertWrite(user: User) {
  if (!canWrite(user)) throw new HttpError(403, 'Deze rol heeft alleen leestoegang.');
}
export function scope(user: User, alias = 'r'): { sql: string; params: string[] } {
  const base = `${alias}.purpose='commercial'`;
  if (user.role === 'seller') return { sql: base + ` AND ${alias}.owner_id=?`, params: [user.id] };
  if (user.role !== 'admin' && user.team_id)
    return {
      sql:
        base +
        ` AND (${alias}.owner_id IS NULL OR EXISTS(SELECT 1 FROM users scoped_owner WHERE scoped_owner.id=${alias}.owner_id AND scoped_owner.team_id=?))`,
      params: [user.team_id],
    };
  return { sql: base, params: [] };
}
export function visibleRequest(user: User, requestId: string) {
  const s = scope(user);
  const row = db
    .prepare(`SELECT r.* FROM requests r WHERE r.id=? AND ${s.sql}`)
    .get(requestId, ...s.params) as any;
  if (!row) throw new HttpError(404, 'Aanvraag niet gevonden.');
  return row;
}
export const checkOrigin: RequestHandler = (req, _res, next) => {
  const origin = req.headers.origin;
  const expected = process.env.APP_URL || `http://${req.headers.host}`;
  if (origin && origin !== new URL(expected).origin)
    return next(new HttpError(403, 'Deze herkomst is niet toegestaan.'));
  next();
};
export const csrfProtection: RequestHandler = (req, _res, next) => {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  if (req.headers['x-csrf-token'] !== req.csrf)
    return next(new HttpError(403, 'Ongeldig beveiligingstoken. Herlaad de pagina.'));
  checkOrigin(req, _res, next);
};
function limitLoginIp(ip: string) {
  const t = Date.now(),
    key = hash('login-ip:' + ip);
  db.prepare('DELETE FROM auth_attempts WHERE window_at<?').run(t - 900000);
  const record = db.prepare('SELECT * FROM auth_attempts WHERE key=?').get(key) as any;
  if (record?.attempts >= 50)
    throw new HttpError(429, 'Te veel pogingen. Probeer over 15 minuten opnieuw.');
  if (!record) db.prepare('INSERT INTO auth_attempts VALUES (?,?,?)').run(key, 0, t);
  db.prepare('UPDATE auth_attempts SET attempts=attempts+1 WHERE key=?').run(key);
}
function setSession(res: any, user: User) {
  const token = randomBytes(32).toString('base64url');
  const csrf = randomBytes(32).toString('base64url');
  db.prepare('INSERT INTO sessions VALUES (?,?,?,?,?)').run(
    hash(token),
    user.id,
    csrf,
    new Date(Date.now() + 12 * 3600000).toISOString(),
    now(),
  );
  res.cookie('optimat_session', token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: 12 * 3600000,
    path: '/',
  });
  return csrf;
}
export const authRouter = Router();
authRouter.post(
  '/login',
  checkOrigin,
  wrap((req, res) => {
    const input = z
      .object({ email: z.string().email().max(254), password: z.string().min(1).max(256) })
      .parse(req.body);
    limitLoginIp(req.ip || 'unknown');
    const key = hash(`${req.ip}:${input.email.toLowerCase()}`);
    const t = Date.now();
    let attempt = db.prepare('SELECT * FROM auth_attempts WHERE key=?').get(key) as any;
    if (attempt && t - attempt.window_at < 900000 && attempt.attempts >= 10)
      throw new HttpError(429, 'Te veel pogingen. Probeer over 15 minuten opnieuw.');
    if (!attempt || t - attempt.window_at >= 900000) {
      db.prepare('INSERT OR REPLACE INTO auth_attempts VALUES (?,?,?)').run(key, 0, t);
    }
    db.prepare('UPDATE auth_attempts SET attempts=attempts+1 WHERE key=?').run(key);
    const user = db
      .prepare('SELECT * FROM users WHERE email=? AND active=1')
      .get(input.email.toLowerCase()) as any;
    const fallback = '00000000000000000000000000000000:' + '0'.repeat(128);
    const valid = verifyPassword(input.password, user?.password_hash || fallback);
    if (!user || !valid) throw new HttpError(401, 'E-mailadres of wachtwoord is onjuist.');
    db.prepare('DELETE FROM auth_attempts WHERE key=?').run(key);
    const safe = publicUser(user);
    const csrf = setSession(res, safe);
    audit(user.id, 'user', user.id, 'login');
    res.json({ user: safe, csrf });
  }),
);
authRouter.get('/me', requireAuth, (req, res) => res.json({ user: req.user, csrf: req.csrf }));
authRouter.post('/logout', requireAuth, csrfProtection, (req, res) => {
  db.prepare('DELETE FROM sessions WHERE id_hash=?').run(req.sessionHash);
  res.clearCookie('optimat_session', { path: '/' });
  res.json({ ok: true });
});
authRouter.post(
  '/accept-invite',
  checkOrigin,
  wrap((req, res) => {
    const input = z
      .object({
        token: z.string().min(32).max(256),
        password: z.string().min(12).max(256),
        name: z.string().min(1).max(150).optional(),
      })
      .parse(req.body);
    const invitation = db
      .prepare('SELECT * FROM invitations WHERE token_hash=? AND used_at IS NULL AND expires_at>?')
      .get(hash(input.token), now()) as any;
    if (!invitation) throw new HttpError(400, 'Uitnodiging ongeldig of verlopen.');
    transaction(() => {
      const existing = db.prepare('SELECT * FROM users WHERE email=?').get(invitation.email) as any;
      if (existing) throw new HttpError(409, 'Er bestaat al een account met dit e-mailadres.');
      const userId = id();
      db.prepare(
        'INSERT INTO users(id,email,name,password_hash,role,team_id,marketing_permission,active,created_at) VALUES (?,?,?,?,?,?,?,1,?)',
      ).run(
        userId,
        invitation.email,
        input.name || invitation.name,
        hashPassword(input.password),
        invitation.role,
        invitation.team_id,
        invitation.marketing_permission,
        now(),
      );
      db.prepare('UPDATE invitations SET used_at=? WHERE id=?').run(now(), invitation.id);
      audit(userId, 'user', userId, 'accepted_invitation');
      const user = publicUser(db.prepare('SELECT * FROM users WHERE id=?').get(userId));
      res.json({ user, csrf: setSession(res, user) });
    });
  }),
);
export const adminRouter = Router();
adminRouter.use(requireRoles('admin'));
adminRouter.get('/users', (_req, res) =>
  res.json({
    users: (db.prepare('SELECT * FROM users ORDER BY name').all() as any[]).map(publicUser),
  }),
);
adminRouter.post(
  '/invitations',
  wrap((req, res) => {
    const input = z
      .object({
        email: z.string().email().max(254),
        name: z.string().min(1).max(150),
        role: z.enum(ROLES),
        team_id: z.string().max(100).nullable().optional(),
        marketing_permission: z.boolean().optional(),
      })
      .parse(req.body);
    const email = input.email.toLowerCase();
    if (db.prepare('SELECT id FROM users WHERE email=?').get(email))
      throw new HttpError(409, 'Dit account bestaat al.');
    const token = randomBytes(32).toString('base64url');
    db.prepare('INSERT INTO invitations VALUES (?,?,?,?,?,?,?,?,?,?)').run(
      id(),
      hash(token),
      email,
      input.name,
      input.role,
      input.team_id || null,
      input.marketing_permission ? 1 : 0,
      new Date(Date.now() + 48 * 3600000).toISOString(),
      null,
      req.user.id,
    );
    audit(req.user.id, 'invitation', email, 'created');
    res.status(201).json({
      token,
      url: `/invite?token=${token}`,
      expires_in_hours: 48,
      delivery: 'Kopieer de eenmalige link en deel die via een beveiligd kanaal.',
    });
  }),
);
adminRouter.patch(
  '/users/:id',
  wrap((req, res) => {
    const input = z
      .object({
        active: z.boolean().optional(),
        role: z.enum(ROLES).optional(),
        marketing_permission: z.boolean().optional(),
        team_id: z.string().max(100).nullable().optional(),
      })
      .parse(req.body);
    const target = db.prepare('SELECT * FROM users WHERE id=?').get(String(req.params.id)) as any;
    if (!target) throw new HttpError(404, 'Gebruiker niet gevonden.');
    if (
      target.id === req.user.id &&
      (input.active === false || (input.role && input.role !== 'admin'))
    )
      throw new HttpError(400, 'Je kunt je eigen beheerrechten niet intrekken.');
    transaction(() => {
      db.prepare(
        'UPDATE users SET active=?,role=?,marketing_permission=?,team_id=? WHERE id=?',
      ).run(
        input.active === undefined ? target.active : input.active ? 1 : 0,
        input.role || target.role,
        input.marketing_permission === undefined
          ? target.marketing_permission
          : input.marketing_permission
            ? 1
            : 0,
        input.team_id === undefined ? target.team_id : input.team_id,
        target.id,
      );
      db.prepare('DELETE FROM sessions WHERE user_id=?').run(target.id);
      audit(req.user.id, 'user', target.id, 'access_updated', input);
    });
    res.json({ user: publicUser(db.prepare('SELECT * FROM users WHERE id=?').get(target.id)) });
  }),
);
adminRouter.get('/settings', (_req, res) =>
  res.json({
    retention_days: JSON.parse(
      (db.prepare("SELECT value_json FROM settings WHERE key='retention_days'").get() as any)
        ?.value_json || '730',
    ),
    enforcement: 'manual_review',
    email_status: process.env.SMTP_HOST ? 'configured_not_verified' : 'not_configured',
    geocoding_status: geocodingStatus().status,
  }),
);
adminRouter.patch(
  '/settings',
  wrap((req, res) => {
    const v = z.object({ retention_days: z.number().int().min(30).max(3650) }).parse(req.body);
    db.prepare('INSERT OR REPLACE INTO settings VALUES (?,?)').run(
      'retention_days',
      JSON.stringify(v.retention_days),
    );
    audit(req.user.id, 'settings', 'retention', 'updated', v);
    res.json(v);
  }),
);
