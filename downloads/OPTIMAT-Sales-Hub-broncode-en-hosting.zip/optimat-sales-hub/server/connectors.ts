import { Router, type RequestHandler } from 'express';
import { z } from 'zod';
import { createHash } from 'node:crypto';
import { readdirSync, readFileSync } from 'node:fs';
import { resolve, join } from 'node:path';
import JSZip from 'jszip';
import { db, id, now, transaction, audit } from './db.js';
import { verifySourceRequest } from './source-auth.js';
import { HttpError, wrap } from './errors.js';
import { requireRoles } from './auth.js';
const date = z.string().datetime({ offset: true });
const purpose = z.enum(['unclassified', 'commercial', 'support', 'recruitment', 'newsletter']);
const inputSchema = z.object({
  id: z.union([z.string(), z.number()]).transform(String),
  label: z.string().max(500).optional(),
});
const fieldSchema = z.object({
  id: z.union([z.string().max(200), z.number()]).transform(String),
  label: z.string().max(500),
  type: z.string().max(60),
  options: z
    .array(
      z.union([
        z.string(),
        z.number(),
        z.boolean(),
        z.null(),
        z.object({
          label: z.string().optional(),
          text: z.string().optional(),
          value: z.union([z.string(), z.number(), z.boolean(), z.null()]).optional(),
        }),
      ]),
    )
    .max(500)
    .optional(),
  inputs: z.array(inputSchema).max(100).optional(),
  hidden: z.boolean().optional(),
});
export const inventorySchema = z.object({
  kind: z.literal('gravity_inventory'),
  event_id: z.string().min(1).max(200),
  connector_version: z.string().min(1).max(50),
  site_url: z.string().url(),
  generated_at: date,
  complete: z.boolean(),
  forms: z
    .array(
      z.object({
        form_id: z.union([z.string().max(191), z.number()]).transform(String),
        name: z.string().min(1).max(200),
        active: z.boolean(),
        purpose: purpose.optional(),
        enabled: z.boolean().optional(),
        base_intents: z.array(z.string().max(80)).max(20).optional(),
        intent_rules: z
          .array(
            z.object({
              field_id: z.string().max(200),
              equals: z.union([z.string(), z.number(), z.boolean()]),
              add: z.array(z.string().max(80)).max(20),
            }),
          )
          .max(100)
          .optional(),
        fields: z.array(fieldSchema).max(500),
      }),
    )
    .max(500),
  reconciliation: z
    .object({
      supported: z.boolean(),
      status: z.string().max(80),
      last_completed_at: date.nullable().optional(),
      last_attempt_at: date.nullable().optional(),
    })
    .optional(),
});
const forbidden =
  /(captcha|password|passwd|secret|token|honeypot|authorization|cookie|nonce|csrf|api.?key|session.?id|gclid|fbclid|msclkid|ip_address|user_agent|^ip$)/i;
function safeFields(fields: z.infer<typeof fieldSchema>[]) {
  return fields
    .filter((f) => ![f.id, f.type, f.label].some((v) => forbidden.test(v)))
    .map((f) => ({
      ...f,
      inputs: f.inputs?.filter((i) => !forbidden.test(i.id) && !forbidden.test(i.label || '')),
    }));
}
function canonicalSite(value: string) {
  const u = new URL(value);
  if (u.protocol !== 'https:' || u.username || u.password || u.search || u.hash)
    throw new HttpError(400, 'Een HTTPS-WordPress-site zonder queryparameters is vereist.');
  return (
    u.hostname.replace(/^www\./, '') + (u.port ? ':' + u.port : '') + u.pathname.replace(/\/+$/, '')
  );
}
export const inventoryHandler: RequestHandler = wrap((req, res) => {
  const source = verifySourceRequest(req);
  const payload = inventorySchema.parse(req.body);
  if (canonicalSite(payload.site_url) !== canonicalSite(source.site_url))
    throw new HttpError(
      409,
      'De WordPress-site hoort niet bij dit bron-ID. Controleer de instellingen op beide sites.',
    );
  if (Date.parse(payload.generated_at) > Date.now() + 300000)
    throw new HttpError(400, 'Inventaristijd ligt in de toekomst.');
  const digest = createHash('sha256').update(JSON.stringify(payload)).digest('hex');
  const result = transaction(() => {
    const old = db
      .prepare('SELECT * FROM connector_syncs WHERE source_id=? AND event_id=?')
      .get(source.id, payload.event_id) as any;
    if (old) {
      if (old.payload_hash !== digest)
        throw new HttpError(409, 'Inventaris-ID is al voor andere inhoud gebruikt.');
      return { duplicate: true, status: 'received' };
    }
    const state = db
      .prepare('SELECT * FROM source_connector_state WHERE source_id=?')
      .get(source.id) as any;
    const generatedAt = new Date(payload.generated_at).toISOString();
    db.prepare('INSERT INTO connector_syncs VALUES (?,?,?,?,?)').run(
      source.id,
      payload.event_id,
      digest,
      generatedAt,
      now(),
    );
    if (state && state.inventory_generated_at > generatedAt)
      return { duplicate: false, status: 'ignored_stale' };
    for (const form of payload.forms) {
      let row = db
        .prepare('SELECT * FROM forms WHERE source_id=? AND provider=? AND form_id=?')
        .get(source.id, 'gravity', form.form_id) as any;
      if (!row) {
        const formId = id();
        db.prepare(
          'INSERT INTO forms(id,source_id,provider,form_id,name,purpose,mapping_json,version,coverage,updated_at) VALUES (?,?,?,?,?,?,?,1,?,?)',
        ).run(
          formId,
          source.id,
          'gravity',
          form.form_id,
          form.name,
          'unclassified',
          '{}',
          'discovered',
          now(),
        );
        db.prepare('INSERT INTO mapping_history VALUES (?,?,?,?,?,?)').run(
          id(),
          formId,
          1,
          '{}',
          null,
          now(),
        );
        row = { id: formId };
      }
      // Discovery never alters an administrator's routing, mapping or revision.
      db.prepare(
        'INSERT INTO form_inventory VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(form_id) DO UPDATE SET fields_schema_json=excluded.fields_schema_json,active=excluded.active,enabled_at_source=excluded.enabled_at_source,source_purpose=excluded.source_purpose,base_intents_json=excluded.base_intents_json,intent_rules_json=excluded.intent_rules_json,last_seen_at=excluded.last_seen_at',
      ).run(
        row.id,
        JSON.stringify(safeFields(form.fields)),
        form.active ? 1 : 0,
        form.enabled ? 1 : 0,
        form.purpose || 'unclassified',
        JSON.stringify(form.base_intents || []),
        JSON.stringify(form.intent_rules || []),
        generatedAt,
      );
    }
    if (payload.complete) {
      const ids = payload.forms.map((f) => f.form_id);
      const known = db
        .prepare('SELECT f.id,f.form_id FROM forms f WHERE f.source_id=? AND f.provider=?')
        .all(source.id, 'gravity') as any[];
      for (const form of known)
        if (!ids.includes(form.form_id))
          db.prepare('UPDATE form_inventory SET active=0 WHERE form_id=?').run(form.id);
    }
    db.prepare(
      'INSERT INTO source_connector_state VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(source_id) DO UPDATE SET connector_version=excluded.connector_version,site_url=excluded.site_url,last_heartbeat_at=excluded.last_heartbeat_at,inventory_received_at=excluded.inventory_received_at,inventory_generated_at=excluded.inventory_generated_at,inventory_complete=excluded.inventory_complete,reconciliation_json=excluded.reconciliation_json',
    ).run(
      source.id,
      payload.connector_version,
      payload.site_url,
      now(),
      now(),
      generatedAt,
      payload.complete ? 1 : 0,
      JSON.stringify(payload.reconciliation || { supported: false, status: 'not_reported' }),
    );
    db.prepare('UPDATE sources SET reconciliation_status=? WHERE id=?').run(
      payload.reconciliation?.supported ? payload.reconciliation.status : 'not_supported',
      source.id,
    );
    audit(null, 'source', source.id, 'gravity_inventory_received', {
      forms: payload.forms.length,
      complete: payload.complete,
    });
    return { duplicate: false, status: 'received' };
  });
  res.status(202).json({ accepted: true, event_id: payload.event_id, ...result });
});
export function sourceMetadata(sourceId: string) {
  const state = db
    .prepare('SELECT * FROM source_connector_state WHERE source_id=?')
    .get(sourceId) as any;
  if (!state)
    return {
      connector_status: 'not_connected',
      last_heartbeat_at: null,
      inventory_complete: false,
      inventory_received_at: null,
      reconciliation: { supported: false, status: 'not_configured' },
    };
  return {
    connector_status:
      Date.now() - Date.parse(state.last_heartbeat_at) < 900000
        ? 'connected_contract_only'
        : 'heartbeat_delayed',
    connector_version: state.connector_version,
    last_heartbeat_at: state.last_heartbeat_at,
    inventory_complete: !!state.inventory_complete,
    inventory_received_at: state.inventory_received_at,
    reconciliation: JSON.parse(state.reconciliation_json),
  };
}
export function mappingSuggestions(fields: { id: string; label: string; type: string }[]) {
  const result: Record<string, string> = {};
  for (const f of fields) {
    const label = f.label.trim().toLowerCase();
    let target: string | undefined;
    if (f.type === 'email' || /^(e-?mail|e-mailadres|email address)$/.test(label)) target = 'email';
    else if (f.type === 'phone' || /^(telefoon|telefoonnummer|phone|téléphone|gsm)$/.test(label))
      target = 'phone';
    else if (/^(bedrijf|bedrijfsnaam|company|company name|société|entreprise)$/.test(label))
      target = 'company_name';
    else if (/^(btw|btw-nummer|ondernemingsnummer|vat|vat number)$/.test(label))
      target = 'enterprise_number';
    else if (/^(land|country|pays)$/.test(label)) target = 'country';
    else if (/^(postcode|postal code|zip|zip code|code postal)$/.test(label)) target = 'postcode';
    else if (/^(gemeente|stad|city|ville)$/.test(label)) target = 'city';
    else if (/^(straat|straat en huisnummer|adres|street address|address|adresse)$/.test(label))
      target = 'address';
    else if (/^(naam|voornaam|achternaam|first name|last name|name|prénom|nom)$/.test(label))
      target = 'name';
    else if (/^(bericht|message|opmerking|opmerkingen|uw bericht)$/.test(label)) target = 'message';
    if (target) result[f.id] = target;
  }
  return result;
}
export function formMetadata(formId: string) {
  const row = db.prepare('SELECT * FROM form_inventory WHERE form_id=?').get(formId) as any;
  if (!row) return { field_schema: [], mapping_suggestions: {} };
  const fields = JSON.parse(row.fields_schema_json);
  return {
    field_schema: fields,
    mapping_suggestions: mappingSuggestions(fields),
    active: !!row.active,
    enabled_at_source: !!row.enabled_at_source,
    source_purpose: row.source_purpose,
    base_intents: JSON.parse(row.base_intents_json),
    intent_rules: JSON.parse(row.intent_rules_json),
    last_seen_at: row.last_seen_at,
  };
}
export const connectorAdminRouter = Router();
connectorAdminRouter.use(requireRoles('admin'));
connectorAdminRouter.get(
  '/wordpress.zip',
  wrap(async (_req, res) => {
    const zip = new JSZip();
    const root = resolve('wordpress/optimat-sales-hub');
    function add(dir: string, prefix: string) {
      for (const entry of readdirSync(dir, { withFileTypes: true })) {
        if (entry.name === 'tests') continue;
        const path = join(dir, entry.name);
        if (entry.isDirectory()) add(path, prefix + entry.name + '/');
        else if (entry.isFile() && entry.name.endsWith('.php'))
          zip.file(prefix + entry.name, readFileSync(path));
      }
    }
    add(root, 'optimat-sales-hub/');
    res.type('application/zip');
    res.attachment('optimat-sales-hub-wordpress.zip');
    res.send(await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' }));
  }),
);
