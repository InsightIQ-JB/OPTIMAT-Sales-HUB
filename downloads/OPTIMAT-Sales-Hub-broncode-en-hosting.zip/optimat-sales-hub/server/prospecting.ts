import { Router } from 'express';
import { z } from 'zod';
import { db, audit, now, id, transaction } from './db.ts';
import { requireAuth, requireRoles, assertWrite } from './auth.ts';
import { wrap, HttpError } from './errors.ts';
import { createCompany } from './crm.ts';
import { kboStatus, searchKbo } from './kbo.ts';
export const prospectingRouter = Router();
prospectingRouter.use(requireAuth);
prospectingRouter.get(
  '/status',
  wrap(async (_req, res) => {
    res.json({ ...kboStatus(), manual_import_available: true, no_unsolicited_mailing: true });
  }),
);
prospectingRouter.get(
  '/search',
  wrap(async (req, res) => {
    const input = z
      .object({
        q: z.string().trim().min(1).max(200),
        language: z.enum(['nl', 'fr']).optional(),
        postcode: z.string().max(20).optional(),
        activity: z.string().max(30).optional(),
      })
      .parse(req.query);
    const result = await searchKbo(input);
    res.json({ ...result, status: kboStatus().status });
  }),
);
prospectingRouter.post(
  '/import',
  wrap(async (req, res) => {
    assertWrite(req.user!);
    const input = z
      .object({
        name: z.string().trim().min(1).max(200),
        enterprise_number: z.string().min(1),
        country: z.literal('BE'),
        legal_person: z.literal(true),
        address: z.string().max(300).optional(),
        postcode: z.string().max(20).optional(),
        city: z.string().max(100).optional(),
        owner_id: z.string().nullable().optional(),
        data_source: z.string().max(300).optional(),
        source_updated_at: z.string().datetime({ offset: true }).nullable().optional(),
      })
      .parse(req.body);
    const company = createCompany(req.user!, input);
    db.prepare(
      'UPDATE companies SET is_prospect=1,data_source=?,source_updated_at=?,match_confidence=? WHERE id=?',
    ).run(
      input.data_source ?? 'manual',
      input.source_updated_at ?? null,
      'enterprise_number',
      company.id,
    );
    audit(req.user!.id, 'company', company.id, 'prospect_added', {
      source: input.data_source ?? 'manual',
      legal_person: true,
    });
    res
      .status(201)
      .json({ company: db.prepare('SELECT * FROM companies WHERE id=?').get(company.id) });
  }),
);
prospectingRouter.post(
  '/companies/import',
  wrap(async (req, res) => {
    assertWrite(req.user!);
    const input = z
      .object({
        rows: z
          .array(
            z.object({
              name: z.string().trim().min(1).max(200),
              country: z.enum(['BE', 'NL', 'LU']),
              enterprise_number: z.string().max(30).optional(),
              address: z.string().max(300).optional(),
              postcode: z.string().max(20).optional(),
              city: z.string().max(100).optional(),
              owner_id: z.string().nullable().optional(),
              legal_person: z.boolean().optional(),
            }),
          )
          .min(1)
          .max(500),
        commit: z.boolean().default(false),
      })
      .parse(req.body);
    const issues: { row: number; error: string }[] = [];
    const keys = new Set<string>();
    const preview = input.rows.map((r, index) => {
      let number = r.enterprise_number?.replace(/[^a-zA-Z0-9]/g, '').toUpperCase() ?? null;
      if (r.country === 'BE' && number) number = number.replace(/^BE/, '');
      const key = number ? r.country + ':' + number : null;
      if (r.country === 'BE' && r.legal_person !== true)
        issues.push({
          row: index + 1,
          error: 'Bevestig dat het prospectiebedrijf een rechtspersoon is.',
        });
      if (r.country === 'BE' && number) {
        const digits = number.replace(/^BE/, '');
        if (
          !/^\d{10}$/.test(digits) ||
          97 - (Number(digits.slice(0, 8)) % 97) !== Number(digits.slice(8))
        )
          issues.push({ row: index + 1, error: 'Ongeldig Belgisch ondernemingsnummer.' });
      }
      if (
        key &&
        (keys.has(key) ||
          db
            .prepare('SELECT id FROM companies WHERE country=? AND enterprise_number=?')
            .get(r.country, number))
      )
        issues.push({ row: index + 1, error: 'Ondernemingsnummer bestaat al in import of CRM.' });
      if (key) keys.add(key);
      return { ...r, enterprise_number: number, row: index + 1 };
    });
    if (input.commit && issues.length)
      throw new HttpError(
        400,
        'Import geblokkeerd. Los eerst alle fouten uit de voorbeeldcontrole op.',
      );
    const created: string[] = [];
    if (input.commit) {
      transaction(() => {
        for (const r of preview) {
          const company = createCompany(req.user!, r, false);
          db.prepare(
            'UPDATE companies SET is_prospect=1,data_source=?,match_confidence=? WHERE id=?',
          ).run('manual_csv', r.enterprise_number ? 'enterprise_number' : 'unverified', company.id);
          created.push(company.id);
        }
        audit(req.user!.id, 'import', id(), 'companies_imported', { count: created.length });
      });
    }
    res.json({ rows: preview, issues, created, count: created.length, committed: input.commit });
  }),
);
prospectingRouter.get(
  '/activities',
  wrap(async (_req, res) => {
    res.json({
      items: db.prepare('SELECT * FROM nace_activities WHERE active=1 ORDER BY code').all(),
    });
  }),
);
prospectingRouter.post(
  '/activities',
  requireRoles('admin', 'management'),
  wrap(async (req, res) => {
    if (req.user!.role === 'management' && !req.user!.marketing_permission)
      throw new HttpError(403, 'Marketingrechten vereist.');
    const data = z
      .object({
        code: z.string().trim().min(1).max(30),
        version: z.string().trim().min(1).max(30),
        label: z.string().trim().min(1).max(200),
      })
      .parse(req.body);
    const activityId = id();
    db.prepare('INSERT INTO nace_activities(id,code,version,label) VALUES(?,?,?,?)').run(
      activityId,
      data.code,
      data.version,
      data.label,
    );
    audit(req.user!.id, 'nace_activity', activityId, 'created', {});
    res.status(201).json({ id: activityId, ...data });
  }),
);
