import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createHmac, randomUUID } from 'node:crypto';
import type { Server } from 'node:http';
import type { Role } from '../shared/domain.ts';

export async function makeHarness() {
  const folder = mkdtempSync(join(tmpdir(), 'optimat-contract-'));
  process.env.DB_PATH = join(folder, 'contract.sqlite');
  process.env.NODE_ENV = 'test';
  process.env.TEST_WP_SECRET = 'synthetic-contract-key-not-a-live-credential';
  const { db, now } = await import('../server/db.ts');
  const { hashPassword } = await import('../server/auth.ts');
  const { createApp } = await import('../server/app.ts');
  const app = await createApp({ worker: false });
  const server: Server = await new Promise((resolve) => {
    const srv = app.listen(0, '127.0.0.1', () => resolve(srv));
  });
  const address = server.address();
  if (!address || typeof address === 'string') throw new Error('No HTTP test address');
  const base = `http://127.0.0.1:${address.port}`;
  process.env.APP_ORIGIN = base;
  process.env.APP_URL = base;
  process.env.PUBLIC_URL = base;
  const password = 'Test-only-strong-password-2026!';
  async function seedUser(role: Role, name: string = role) {
    const userId = randomUUID(),
      email = `${name}-${userId}@example.invalid`;
    db.prepare(
      'INSERT INTO users(id,email,name,password_hash,role,active,created_at) VALUES(?,?,?,?,?,1,?)',
    ).run(userId, email, name, await hashPassword(password), role, now());
    return { id: userId, email, password, role };
  }
  async function raw(path: string, options: RequestInit = {}) {
    return fetch(base + path, {
      ...options,
      headers: { Origin: base, ...options.headers },
      redirect: 'manual',
    });
  }
  async function login(user: { email: string; password: string }) {
    const response = await raw('/api/auth/login', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(user),
    });
    if (!response.ok) throw new Error(`Login ${response.status}: ${await response.text()}`);
    const payload = (await response.json()) as { csrf: string; user: Record<string, unknown> };
    const cookie = response.headers
      .getSetCookie()
      .map((value) => value.split(';')[0])
      .join('; ');
    const request = (
      path: string,
      method = 'GET',
      body?: unknown,
      extra: Record<string, string> = {},
    ) =>
      raw(path, {
        method,
        headers: {
          cookie,
          'x-csrf-token': payload.csrf,
          'content-type': 'application/json',
          ...extra,
        },
        body: body === undefined ? undefined : JSON.stringify(body),
      });
    return { request, cookie, csrf: payload.csrf, user: payload.user };
  }
  function seedSource() {
    const sourceId = randomUUID(),
      formId = randomUUID();
    db.prepare('INSERT INTO sources(id,name,site_url,secret_env,created_at) VALUES(?,?,?,?,?)').run(
      sourceId,
      'Contractbron',
      `https://${sourceId}.example.invalid`,
      'TEST_WP_SECRET',
      now(),
    );
    const mapping = {
      company: 'company_name',
      vat: 'enterprise_number',
      country: 'country',
      email: 'email',
      person: 'name',
      phone: 'phone',
      message: 'message',
      machine: 'machine',
      model: 'model',
      postcode: 'postcode',
      city: 'city',
      address: 'address',
      business_unit: 'business_unit',
      brand: 'brand',
    };
    db.prepare(
      'INSERT INTO forms(id,source_id,provider,form_id,name,purpose,mapping_json,version,coverage,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)',
    ).run(
      formId,
      sourceId,
      'contract',
      '42',
      'Contract brochure/offerte',
      'commercial',
      JSON.stringify(mapping),
      1,
      'contract_tested',
      now(),
    );
    return { sourceId, formId };
  }
  function signed(
    path: string,
    payload: unknown,
    options: { timestamp?: string; secret?: string } = {},
  ) {
    const body = JSON.stringify(payload),
      timestamp = options.timestamp || String(Math.floor(Date.now() / 1000));
    const signature = createHmac('sha256', options.secret || process.env.TEST_WP_SECRET!)
      .update(`${timestamp}.${body}`)
      .digest('hex');
    return raw(path, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-optimat-timestamp': timestamp,
        'x-optimat-signature': signature,
      },
      body,
    });
  }
  async function close() {
    await new Promise<void>((resolve, reject) =>
      server.close((error) => (error ? reject(error) : resolve())),
    );
    db.close();
    rmSync(folder, { recursive: true, force: true });
  }
  return { db, now, base, raw, seedUser, login, seedSource, signed, close };
}
