import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import JSZip from 'jszip';
import { makeHarness } from './helpers.ts';

let h: Awaited<ReturnType<typeof makeHarness>>;
let admin: Awaited<ReturnType<Awaited<ReturnType<typeof makeHarness>>['login']>>;
before(async () => {
  h = await makeHarness();
  admin = await h.login(await h.seedUser('admin', 'Gravity-beheerder'));
  process.env.TEST_GF_MAIN_SECRET = 'synthetic-only-main-gravity-source-key';
  process.env.TEST_GF_KDT_SECRET = 'synthetic-only-kdt-gravity-source-key';
});
after(async () => {
  await h?.close();
});

async function source(secretEnv = 'TEST_GF_MAIN_SECRET') {
  const site_url = `https://${randomUUID()}.example.invalid`;
  const response = await admin.request('/api/integrations/sources', 'POST', {
    name: 'Synthetische Gravity-bron',
    site_url,
    secret_env: secretEnv,
  });
  assert.equal(response.status, 201, await response.clone().text());
  const payload = (await response.json()) as { id: string };
  return { id: payload.id, site_url };
}
function inventory(site_url: string, overrides: Record<string, unknown> = {}) {
  return {
    kind: 'gravity_inventory',
    event_id: randomUUID(),
    connector_version: '0.2.0-contract',
    site_url,
    generated_at: new Date().toISOString(),
    complete: true,
    forms: [
      {
        form_id: '17',
        name: 'Synthetisch brochure en offerte',
        active: true,
        purpose: 'unclassified',
        enabled: false,
        base_intents: [],
        fields: [
          { id: '1', label: 'Bedrijfsnaam', type: 'text' },
          { id: '2', label: 'Zakelijk e-mailadres', type: 'email' },
          {
            id: '3',
            label: 'Contactpersoon',
            type: 'name',
            inputs: [
              { id: '3.3', label: 'Voornaam' },
              { id: '3.6', label: 'Achternaam' },
            ],
          },
          {
            id: '4',
            label: 'Machine-interesses',
            type: 'multiselect',
            options: ['CNC', 'Kantenaanlijmen'],
          },
          { id: '5', label: 'Productmodel', type: 'hidden', hidden: true },
          { id: '6', label: 'CAPTCHA', type: 'captcha' },
          { id: '7', label: 'Wachtwoord', type: 'password' },
        ],
      },
    ],
    reconciliation: { supported: true, status: 'not_started' },
    ...overrides,
  };
}
async function integrations() {
  const response = await admin.request('/api/integrations');
  assert.equal(response.status, 200);
  return (await response.json()) as any;
}

test('gescheiden Gravity-bronnen accepteren alleen eigen HMAC en de geconfigureerde website', async () => {
  const main = await source(),
    kdt = await source('TEST_GF_KDT_SECRET');
  const meta = inventory(main.site_url);
  const wrongKey = await h.signed(`/api/connectors/${main.id}/sync`, meta, {
    secret: process.env.TEST_GF_KDT_SECRET,
  });
  assert.equal(wrongKey.status, 401);
  const wrongSite = await h.signed(`/api/connectors/${main.id}/sync`, inventory(kdt.site_url), {
    secret: process.env.TEST_GF_MAIN_SECRET,
  });
  assert.equal(wrongSite.status, 409);
  const validMain = await h.signed(`/api/connectors/${main.id}/sync`, meta, {
    secret: process.env.TEST_GF_MAIN_SECRET,
  });
  assert.equal(validMain.status, 202, await validMain.clone().text());
  const ack = (await validMain.json()) as any;
  assert.equal(ack.accepted, true);
  assert.equal(ack.event_id, meta.event_id);
  const validKdt = await h.signed(`/api/connectors/${kdt.id}/sync`, inventory(kdt.site_url), {
    secret: process.env.TEST_GF_KDT_SECRET,
  });
  assert.equal(validKdt.status, 202, await validKdt.clone().text());
  const data = await integrations();
  const configured = data.sources.find((item: any) => item.id === main.id);
  assert.ok(configured.last_heartbeat_at);
  assert.equal(Boolean(configured.inventory_complete), true);
  assert.equal(
    data.forms.filter((item: any) => [main.id, kdt.id].includes(item.source_id)).length,
    2,
  );
  assert.equal(
    Number((h.db.prepare('SELECT count(*) n FROM requests').get() as any).n),
    0,
    'Een metadata-inventaris maakt geen lead',
  );
  assert.equal(
    configured.status === 'live_tested',
    false,
    'Een heartbeat is geen echte formulierinzending',
  );
});

test('metadata blijft waardevrij, gevoelige velden worden gefilterd en alleen beheerders zien schema en diagnostiek', async () => {
  const src = await source();
  const payload = inventory(src.site_url);
  (payload.forms[0].fields[0] as any).value = 'private-entry-value-not-metadata';
  (payload.forms[0].fields[0] as any).defaultValue = 'private-entry-default-not-metadata';
  (payload.forms[0].fields[2].inputs![0] as any).value = 'private-compound-entry-not-metadata';
  assert.equal(
    (
      await h.signed(`/api/connectors/${src.id}/sync`, payload, {
        secret: process.env.TEST_GF_MAIN_SECRET,
      })
    ).status,
    202,
  );
  const data = await integrations();
  const form = data.forms.find((item: any) => item.source_id === src.id);
  const serialized = JSON.stringify(form);
  assert.ok(serialized.includes('Bedrijfsnaam'));
  assert.ok(
    serialized.includes('Productmodel'),
    'Zakelijke verborgen productcontext blijft inventariseerbaar',
  );
  assert.equal(serialized.includes('private-entry-value-not-metadata'), false);
  assert.equal(serialized.includes('private-entry-default-not-metadata'), false);
  assert.equal(serialized.includes('private-compound-entry-not-metadata'), false);
  assert.equal(serialized.includes('CAPTCHA'), false);
  assert.equal(serialized.includes('Wachtwoord'), false);
  assert.equal(serialized.includes(process.env.TEST_GF_MAIN_SECRET!), false);
  const seller = await h.login(await h.seedUser('seller', 'Gravity-verkoper'));
  assert.equal((await seller.request('/api/integrations')).status, 403);
  assert.equal((await h.raw('/api/integrations')).status, 401);
  const download = await admin.request('/api/integrations/wordpress.zip');
  assert.equal(download.status, 200);
  assert.ok(download.headers.get('content-type')?.includes('application/zip'));
  const zip = await JSZip.loadAsync(Buffer.from(await download.arrayBuffer()));
  for (const path of [
    'optimat-sales-hub/optimat-sales-hub.php',
    'optimat-sales-hub/includes/gravity.php',
    'optimat-sales-hub/includes/gravity-attachments.php',
  ])
    assert.ok(zip.file(path), `Installeerbaar plug-inbestand ontbreekt: ${path}`);
  assert.equal(
    Object.keys(zip.files).some((path) => path.includes('/tests/')),
    false,
  );
  assert.equal((await seller.request('/api/integrations/wordpress.zip')).status, 403);
});

test('inventaris-herhaling en nieuwe bronmetadata wijzigen geen beheerde mapping, doelbinding of mappingversie', async () => {
  const src = await source();
  const baseTime = Date.now() - 180_000;
  const first = inventory(src.site_url, { generated_at: new Date(baseTime).toISOString() });
  assert.equal(
    (
      await h.signed(`/api/connectors/${src.id}/sync`, first, {
        secret: process.env.TEST_GF_MAIN_SECRET,
      })
    ).status,
    202,
  );
  const firstForm = (await integrations()).forms.find((item: any) => item.source_id === src.id);
  const mapped = await admin.request('/api/integrations/forms', 'POST', {
    source_id: src.id,
    provider: 'gravity',
    form_id: '17',
    name: 'Beheerde formuliernaam',
    purpose: 'commercial',
    version: firstForm.version,
    mapping: { '1': 'company_name', '2': 'email' },
  });
  assert.ok(mapped.ok, await mapped.clone().text());
  const saved = (await integrations()).forms.find((item: any) => item.source_id === src.id);
  assert.equal(saved.version, firstForm.version + 1);
  assert.equal(
    (
      await h.signed(`/api/connectors/${src.id}/sync`, first, {
        secret: process.env.TEST_GF_MAIN_SECRET,
      })
    ).status,
    202,
  );
  const second = inventory(src.site_url, {
    generated_at: new Date(baseTime + 60_000).toISOString(),
  });
  second.forms[0].purpose = 'recruitment';
  second.forms[0].enabled = true;
  second.forms[0].name = 'Nieuwe naam uit WordPress';
  assert.equal(
    (
      await h.signed(`/api/connectors/${src.id}/sync`, second, {
        secret: process.env.TEST_GF_MAIN_SECRET,
      })
    ).status,
    202,
  );
  const afterSync = (await integrations()).forms.find((item: any) => item.source_id === src.id);
  assert.equal(afterSync.version, saved.version);
  assert.equal(afterSync.purpose, 'commercial');
  assert.deepEqual(afterSync.mapping, { '1': 'company_name', '2': 'email' });
  const stale = inventory(src.site_url, {
    generated_at: new Date(baseTime - 60_000).toISOString(),
  });
  stale.forms[0].name = 'VEROUDERDE NAAM';
  stale.complete = false;
  assert.equal(
    (
      await h.signed(`/api/connectors/${src.id}/sync`, stale, {
        secret: process.env.TEST_GF_MAIN_SECRET,
      })
    ).status,
    202,
  );
  const final = await integrations();
  const finalForm = final.forms.find((item: any) => item.source_id === src.id);
  assert.equal(JSON.stringify(finalForm).includes('VEROUDERDE NAAM'), false);
  assert.equal(finalForm.version, saved.version);
  assert.equal(
    Boolean(final.sources.find((item: any) => item.id === src.id).inventory_complete),
    true,
  );
});

test('Gravity-entry wacht op gecontroleerde mapping; compound-ID’s, lange labels en 500 keuzes verwerken zonder verkoopsopvolging te overschrijven', async () => {
  const src = await source();
  const meta = inventory(src.site_url);
  assert.equal(
    (
      await h.signed(`/api/connectors/${src.id}/sync`, meta, {
        secret: process.env.TEST_GF_MAIN_SECRET,
      })
    ).status,
    202,
  );
  const form = (await integrations()).forms.find((item: any) => item.source_id === src.id);
  assert.equal(form.purpose, 'unclassified');
  const payload = {
    event_id: randomUUID(),
    submission_id: 'gravity-entry-901',
    version: 1,
    occurred_at: new Date().toISOString(),
    submitted_at: '2026-10-01T08:00:00.000Z',
    provider: 'gravity',
    form_id: '17',
    form_name: 'Gravity-contract',
    purpose: 'commercial',
    intents: ['brochure', 'quote'],
    language: 'nl_BE',
    fields: [
      { id: '1', label: 'Bedrijfsnaam', type: 'text', value: 'Fictieve Gravity Schrijnwerkerij' },
      { id: '2', label: 'E-mailadres', type: 'email', value: 'gravity@example.invalid' },
      {
        id: '3',
        label: 'Contactpersoon',
        type: 'name',
        value: {
          '3.3': { label: 'Voornaam', value: 'Fictieve' },
          '3.6': { label: 'Achternaam', value: 'Contactpersoon' },
        },
      },
      { id: '3.3', label: 'Voornaam', type: 'name', value: 'Fictieve' },
      { id: '3.6', label: 'Achternaam', type: 'name', value: 'Contactpersoon' },
      {
        id: '4',
        label: 'Adres',
        type: 'address',
        value: {
          '4.1': { label: 'Straat', value: 'Fictieve straat 1' },
          '4.3': { label: 'Gemeente', value: 'Gent' },
          '4.5': { label: 'Postcode', value: '9000' },
          '4.6': { label: 'Land', value: 'België' },
        },
      },
      {
        id: '5',
        label: 'A'.repeat(500),
        type: 'select',
        value: 'keuze499',
        options: Array.from({ length: 500 }, (_, i) => `keuze${i}`),
      },
      { id: '6', label: 'Bericht', type: 'textarea', value: 'Eerste bronvraag' },
    ],
  };
  const accepted = await h.signed(`/api/webhooks/${src.id}`, payload, {
    secret: process.env.TEST_GF_MAIN_SECRET,
  });
  assert.equal(accepted.status, 202, await accepted.clone().text());
  const { processPending } = await import('../server/intake.ts');
  await processPending();
  const waiting = h.db
    .prepare('SELECT status FROM events WHERE event_id=?')
    .get(payload.event_id) as any;
  assert.equal(waiting.status, 'awaiting_mapping');
  assert.equal(
    Number(
      (h.db.prepare('SELECT count(*) n FROM requests WHERE source_id=?').get(src.id) as any).n,
    ),
    0,
  );
  const configured = await admin.request('/api/integrations/forms', 'POST', {
    source_id: src.id,
    provider: 'gravity',
    form_id: '17',
    name: form.name,
    purpose: 'commercial',
    version: form.version,
    mapping: {
      '1': 'company_name',
      '2': 'email',
      '3.3': 'name',
      '3.6': 'name',
      '4.1': 'address',
      '4.3': 'city',
      '4.5': 'postcode',
      '4.6': 'country',
      '6': 'message',
    },
  });
  assert.ok(configured.ok, await configured.clone().text());
  await processPending();
  const list = (await (await admin.request(`/api/requests?source=${src.id}`)).json()) as any;
  assert.equal(list.items.length, 1);
  const request = list.items[0];
  const detail = (await (await admin.request(`/api/requests/${request.id}`)).json()) as any;
  assert.equal(detail.contact.name, 'Fictieve Contactpersoon');
  assert.equal(detail.location.address, 'Fictieve straat 1');
  assert.equal(detail.location.country, 'BE');
  assert.equal(detail.location.city, 'Gent');
  assert.equal(detail.fields.find((field: any) => field.id === '5').options.length, 500);
  assert.equal(detail.request.submitted_at, '2026-10-01T08:00:00.000Z');
  const seller = await h.seedUser('seller', 'Gravity-opvolger');
  const assignment = await admin.request(`/api/requests/${request.id}`, 'PATCH', {
    version: detail.request.version,
    owner_id: seller.id,
  });
  assert.ok(assignment.ok, await assignment.clone().text());
  const session = await h.login(seller);
  const note = await session.request(`/api/requests/${request.id}/activities`, 'POST', {
    kind: 'note',
    body: 'Verkopersnotitie die bronupdates niet vervangen',
  });
  assert.equal(note.status, 201);
  const update = {
    ...payload,
    event_id: randomUUID(),
    version: 2,
    occurred_at: new Date().toISOString(),
    fields: payload.fields.map((field) =>
      field.id === '6' ? { ...field, value: 'Aangevulde Gravity-bronvraag' } : field,
    ),
  };
  assert.equal(
    (await h.signed(`/api/webhooks/${src.id}`, update, { secret: process.env.TEST_GF_MAIN_SECRET }))
      .status,
    202,
  );
  await processPending();
  const updated = (await (await session.request(`/api/requests/${request.id}`)).json()) as any;
  assert.equal(updated.request.owner_id, seller.id);
  assert.equal(updated.request.message, 'Aangevulde Gravity-bronvraag');
  assert.ok(
    updated.activities.some(
      (item: any) => item.body === 'Verkopersnotitie die bronupdates niet vervangen',
    ),
  );
});
