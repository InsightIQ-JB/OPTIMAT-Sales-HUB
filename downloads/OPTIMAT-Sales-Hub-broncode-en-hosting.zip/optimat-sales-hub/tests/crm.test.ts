import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { makeHarness } from './helpers.ts';
let h: Awaited<ReturnType<typeof makeHarness>>;
before(async () => {
  h = await makeHarness();
});
after(async () => {
  await h?.close();
});

async function fixture() {
  const admin = await h.seedUser('admin', 'crm-admin'),
    seller = await h.seedUser('seller', 'crm-owner'),
    other = await h.seedUser('seller', 'crm-other');
  const a = await h.login(admin),
    s = await h.login(seller),
    o = await h.login(other);
  const { sourceId, formId } = h.seedSource();
  const cid = randomUUID();
  const location = randomUUID();
  const req1 = randomUUID(),
    req2 = randomUUID();
  h.db
    .prepare(
      'INSERT INTO companies(id,name,country,owner_id,created_at,updated_at) VALUES(?,?,?,?,?,?)',
    )
    .run(cid, '=Fictief exportbedrijf', 'BE', seller.id, h.now(), h.now());
  h.db
    .prepare('INSERT INTO locations(id,company_id,country) VALUES(?,?,?)')
    .run(location, cid, 'BE');
  for (const requestId of [req1, req2])
    h.db
      .prepare(
        'INSERT INTO requests(id,source_id,form_id,provider,submission_id,source_occurred_at,company_id,location_id,owner_id,submitted_at,received_at,updated_at,intents_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',
      )
      .run(
        requestId,
        sourceId,
        formId,
        'contract',
        randomUUID(),
        h.now(),
        cid,
        location,
        seller.id,
        h.now(),
        h.now(),
        h.now(),
        '["brochure","quote"]',
      );
  return { a, s, o, cid, location, req1, req2, seller, admin };
}

test('twee aanvragen delen één verkoopkans; KPI, heropening en financiële telling blijven juist', async () => {
  const f = await fixture();
  const created = await f.s.request(`/api/requests/${f.req1}/opportunities`, 'POST', {
    title: 'Fictieve nestingmachine',
    amount: 125000,
    stage: 'quote',
  });
  assert.equal(created.status, 201, await created.clone().text());
  let opportunity = ((await created.json()) as any).opportunity;
  const linked = await f.s.request(`/api/opportunities/${opportunity.id}/requests`, 'POST', {
    request_id: f.req2,
  });
  assert.equal(linked.status, 200, await linked.clone().text());
  const pre = (await (await f.s.request('/api/reports')).json()) as any;
  assert.equal(pre.metrics.requests, 2);
  assert.equal(pre.metrics.opportunities, 1);
  assert.equal(pre.metrics.open_pipeline_value, 125000);
  const lostWithoutReason = await f.s.request(`/api/opportunities/${opportunity.id}`, 'PATCH', {
    version: opportunity.version,
    stage: 'lost',
    closed_at: h.now(),
  });
  assert.equal(lostWithoutReason.status, 400);
  const won = await f.s.request(`/api/opportunities/${opportunity.id}`, 'PATCH', {
    version: opportunity.version,
    stage: 'won',
    closed_at: h.now(),
  });
  assert.equal(won.status, 200, await won.clone().text());
  opportunity = ((await won.json()) as any).opportunity;
  const report = (await (await f.s.request('/api/reports')).json()) as any;
  assert.equal(report.metrics.won_value, 125000);
  assert.equal(report.metrics.lead_conversion, 1);
  assert.equal(report.metrics.win_ratio, 1);
  assert.equal(report.metrics.open_pipeline_value, 0);
  const otherReport = (await (await f.o.request('/api/reports')).json()) as any;
  assert.equal(otherReport.metrics.requests, 0);
  assert.equal(otherReport.metrics.won_value, 0);
  const reopened = await f.s.request(`/api/opportunities/${opportunity.id}`, 'PATCH', {
    version: opportunity.version,
    stage: 'negotiation',
  });
  assert.equal(reopened.status, 200, await reopened.clone().text());
  const after = (await (await f.s.request('/api/reports')).json()) as any;
  assert.equal(after.metrics.open_pipeline_value, 125000);
  assert.equal(after.metrics.won_value, 0);
  assert.equal(after.metrics.win_ratio, null);
  assert.equal(after.metrics.lead_conversion, 0);
  assert.equal(
    (
      h.db
        .prepare('SELECT COUNT(*) n FROM opportunity_history WHERE opportunity_id=?')
        .get(opportunity.id) as any
    ).n,
    4,
  );
});

test('map deelt rechten, postcodeprecisie en ontbrekende locaties zonder fictieve markers', async () => {
  const f = await fixture();
  const missing = (await (await f.s.request('/api/map')).json()) as any;
  assert.equal(missing.items.length, 0);
  assert.equal(missing.missing.length, 2);
  const set = await f.s.request(`/api/companies/${f.cid}/location`, 'POST', {
    version: 1,
    latitude: 50.8503,
    longitude: 4.3517,
    precision: 'postcode',
    country: 'BE',
    postcode: '1000',
    city: 'Brussel',
  });
  assert.equal(set.status, 200, await set.clone().text());
  const map = (await (await f.s.request('/api/map')).json()) as any;
  assert.equal(map.items.length, 2);
  assert.equal(map.missing.length, 0);
  assert.equal(map.items[0].precision, 'postcode');
  const other = (await (await f.o.request('/api/map')).json()) as any;
  assert.equal(other.items.length, 0);
  const stale = await f.s.request(`/api/companies/${f.cid}/location`, 'POST', {
    version: 1,
    latitude: 51,
    longitude: 4,
    precision: 'address',
    country: 'BE',
  });
  assert.equal(stale.status, 409);
});

test('exports beschermen spreadsheetcellen en management kan geen verkoopdossiers wijzigen', async () => {
  const f = await fixture();
  const csv = await f.s.request('/api/reports/export.csv');
  assert.equal(csv.status, 200);
  assert.ok((await csv.text()).includes("'=Fictief exportbedrijf"));
  const xlsx = await f.s.request('/api/reports/export.xlsx');
  assert.equal(xlsx.status, 200);
  assert.equal(
    xlsx.headers.get('content-type'),
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  );
  assert.ok((await xlsx.arrayBuffer()).byteLength > 1000);
  const management = await h.login(await h.seedUser('management', 'crm-read-only'));
  const mut = await management.request(`/api/requests/${f.req1}/activities`, 'POST', {
    kind: 'note',
    body: 'Mag niet',
  });
  assert.equal(mut.status, 403);
  const userOther = await f.o.request(`/api/companies/${f.cid}`);
  assert.equal(userOther.status, 404);
});

test('KBO is expliciet ongeconfigureerd en prospectimport maakt geen websiteaanvragen', async () => {
  const f = await fixture();
  const status = (await (await f.a.request('/api/prospecting/status')).json()) as any;
  assert.equal(status.configured, false);
  assert.equal((await f.a.request('/api/prospecting/search?q=hout')).status, 503);
  const before = (h.db.prepare('SELECT COUNT(*) n FROM requests').get() as any).n;
  const noLegal = await f.a.request('/api/prospecting/import', 'POST', {
    name: 'Fictieve prospect',
    country: 'BE',
    enterprise_number: '0202239951',
    legal_person: false,
  });
  assert.equal(noLegal.status, 400);
  const imported = await f.a.request('/api/prospecting/import', 'POST', {
    name: 'Fictieve prospect',
    country: 'BE',
    enterprise_number: 'BE 0202.239.951',
    legal_person: true,
  });
  assert.equal(imported.status, 201, await imported.clone().text());
  assert.equal((h.db.prepare('SELECT COUNT(*) n FROM requests').get() as any).n, before);
  const duplicate = await f.a.request('/api/prospecting/import', 'POST', {
    name: 'Tweede naam',
    country: 'BE',
    enterprise_number: '0202239951',
    legal_person: true,
  });
  assert.equal(duplicate.status, 409);
  const preview = (await (
    await f.a.request('/api/prospecting/companies/import', 'POST', {
      rows: [{ name: 'Nederlandse prospect', country: 'NL', city: 'Eindhoven' }],
      commit: false,
    })
  ).json()) as any;
  assert.equal(preview.count, 0);
  assert.equal(preview.issues.length, 0);
  const commit = await f.a.request('/api/prospecting/companies/import', 'POST', {
    rows: [{ name: 'Nederlandse prospect', country: 'NL', city: 'Eindhoven' }],
    commit: true,
  });
  assert.equal(commit.status, 200, await commit.clone().text());
  assert.equal(((await commit.json()) as any).count, 1);
});

test('gewonnen kans zonder bedrag telt wel; fasehistorie en eigenaar bij afsluiten blijven controleerbaar', async () => {
  const f = await fixture();
  const created = await f.s.request(`/api/requests/${f.req1}/opportunities`, 'POST', {
    title: 'Fictieve kans met onbekend bedrag',
  });
  assert.equal(created.status, 201);
  let opportunity = ((await created.json()) as any).opportunity;
  const baseline = '2026-01-01T00:00:00.000Z';
  const { snapshotRequest } = await import('../server/history.ts');
  h.db
    .prepare('UPDATE requests SET submitted_at=?,received_at=?,updated_at=? WHERE id=?')
    .run(baseline, baseline, baseline, f.req1);
  snapshotRequest(f.req1, baseline);
  opportunity.created_at = baseline;
  h.db.prepare('UPDATE opportunities SET created_at=? WHERE id=?').run(baseline, opportunity.id);
  h.db
    .prepare('UPDATE opportunity_history SET created_at=?,snapshot_json=? WHERE opportunity_id=?')
    .run(baseline, JSON.stringify(opportunity), opportunity.id);
  const historical = (await (
    await f.s.request('/api/reports?as_of=2026-01-02T00:00:00.000Z')
  ).json()) as any;
  assert.equal(historical.metrics.open_count, 1);
  assert.equal(historical.metrics.missing_values, 1);
  const won = await f.s.request(`/api/opportunities/${opportunity.id}`, 'PATCH', {
    version: opportunity.version,
    stage: 'won',
    closed_at: h.now(),
  });
  assert.equal(won.status, 200, await won.clone().text());
  opportunity = ((await won.json()) as any).opportunity;
  assert.equal(opportunity.owner_at_close, f.seller.id);
  const report = (await (await f.s.request('/api/reports')).json()) as any;
  assert.equal(report.metrics.won_count, 1);
  assert.equal(report.metrics.won_without_value, 1);
  assert.equal(report.metrics.won_value, 0);
  const reassigned = await f.a.request(`/api/opportunities/${opportunity.id}`, 'PATCH', {
    version: opportunity.version,
    owner_id: (f.o.user as any).id,
  });
  assert.equal(reassigned.status, 200, await reassigned.clone().text());
  const updated = ((await reassigned.json()) as any).opportunity;
  assert.equal(
    updated.owner_at_close,
    f.seller.id,
    'Herverdeling herschrijft eigenaar bij afsluiten niet',
  );
  const ownerReport = (await (
    await f.a.request(`/api/reports?ownership=at_close&owner=${f.seller.id}`)
  ).json()) as any;
  assert.equal(ownerReport.metrics.won_count, 1);
  const beforeWon = (await (
    await f.a.request('/api/reports?as_of=2026-01-02T00:00:00.000Z')
  ).json()) as any;
  assert.ok(beforeWon.metrics.open_count >= 1);
  const stale = await f.a.request(`/api/opportunities/${opportunity.id}`, 'PATCH', {
    version: 1,
    stage: 'quote',
  });
  assert.equal(stale.status, 409);
});

test('zoek-, bron- en landfilters volgen dezelfde rechten in lijst, kaart, dashboard en export', async () => {
  const f = await fixture();
  h.db
    .prepare('UPDATE requests SET machine=?,brand=? WHERE id=?')
    .run('Fictieve special nesting', 'HOMAG', f.req1);
  const search = await f.s.request('/api/requests?search=special');
  assert.equal(search.status, 200, await search.clone().text());
  assert.equal(((await search.json()) as any).items.length, 1);
  const literal = await f.s.request('/api/requests?search=%25');
  assert.equal(literal.status, 200);
  assert.equal(((await literal.json()) as any).items.length, 0);
  const source = await f.s.request('/api/requests?source=contract');
  assert.equal(source.status, 200, await source.clone().text());
  assert.equal(((await source.json()) as any).items.length, 2);
  const report = (await (await f.s.request('/api/reports?brand=HOMAG')).json()) as any;
  assert.equal(report.metrics.requests, 1);
  const map = (await (await f.s.request('/api/map?brand=HOMAG')).json()) as any;
  assert.equal(map.missing.length, 1);
  const csv = await (await f.s.request('/api/reports/export.csv?brand=HOMAG')).text();
  assert.equal(csv.split('\r\n').length, 2);
  assert.ok(
    !JSON.stringify(map).includes('geocoding_queue'),
    'Verkoper ontvangt geen globale operationele wachtrijtellingen',
  );
  const other = (await (
    await f.o.request('/api/requests?source=contract&search=special')
  ).json()) as any;
  assert.equal(other.items.length, 0);
});

test('nullwaardes kunnen vereiste wacht-, verlies- en afsluitgegevens niet wissen; tijdzones worden genormaliseerd', async () => {
  const f = await fixture();
  const waited = await f.s.request(`/api/requests/${f.req1}`, 'PATCH', {
    version: 1,
    status: 'waiting',
    follow_up_at: '2026-11-02T10:00:00+01:00',
  });
  assert.equal(waited.status, 200);
  const waiting = ((await waited.json()) as any).request;
  assert.equal(waiting.follow_up_at, '2026-11-02T09:00:00.000Z');
  assert.equal(
    (
      await f.s.request(`/api/requests/${f.req1}`, 'PATCH', {
        version: waiting.version,
        follow_up_at: null,
      })
    ).status,
    400,
  );
  const created = await f.s.request(`/api/requests/${f.req1}/opportunities`, 'POST', {
    title: 'Fictieve kans voor validatie',
  });
  let opportunity = ((await created.json()) as any).opportunity;
  const lost = await f.s.request(`/api/opportunities/${opportunity.id}`, 'PATCH', {
    version: opportunity.version,
    stage: 'lost',
    loss_reason: 'Geen investeringsbudget',
    closed_at: '2026-10-01T10:00:00+02:00',
  });
  assert.equal(lost.status, 200);
  opportunity = ((await lost.json()) as any).opportunity;
  assert.equal(opportunity.closed_at, '2026-10-01T08:00:00.000Z');
  assert.equal(
    (
      await f.s.request(`/api/opportunities/${opportunity.id}`, 'PATCH', {
        version: opportunity.version,
        loss_reason: null,
      })
    ).status,
    400,
  );
  assert.equal(
    (
      await f.s.request(`/api/opportunities/${opportunity.id}`, 'PATCH', {
        version: opportunity.version,
        closed_at: null,
      })
    ).status,
    400,
  );
});

test('historische aanvraagfilters en exports bewaren eigenaar, status en spamclassificatie zonder oude toegang te verlenen', async () => {
  const f = await fixture();
  const { snapshotRequest } = await import('../server/history.ts');
  const baseline = '2026-10-01T09:00:00.000Z';
  for (const requestId of [f.req1, f.req2]) {
    h.db
      .prepare('UPDATE requests SET submitted_at=?,received_at=?,updated_at=? WHERE id=?')
      .run(baseline, baseline, baseline, requestId);
    snapshotRequest(requestId, baseline);
  }
  const asOf = '2026-10-02T09:00:00.000Z';
  const changed = await f.a.request(`/api/requests/${f.req1}`, 'PATCH', {
    version: 1,
    owner_id: (f.o.user as any).id,
    status: 'contacted',
  });
  assert.equal(changed.status, 200, await changed.clone().text());
  const old = (await (
    await f.a.request(`/api/reports?as_of=${asOf}&owner=${f.seller.id}&status=new`)
  ).json()) as any;
  assert.equal(old.metrics.requests, 2);
  const current = (await (
    await f.a.request(`/api/reports?owner=${f.seller.id}&status=new`)
  ).json()) as any;
  assert.equal(current.metrics.requests, 1);
  const sellerPast = (await (await f.s.request(`/api/reports?as_of=${asOf}`)).json()) as any;
  assert.equal(
    sellerPast.metrics.requests,
    1,
    'Oude eigenaar krijgt geen oude toegang tot een herverdeeld dossier',
  );
  const csv = await (
    await f.a.request(`/api/reports/export.csv?as_of=${asOf}&owner=${f.seller.id}&status=new`)
  ).text();
  assert.equal(csv.split('\r\n').length, 3);
  const spam = await f.a.request(`/api/requests/${f.req2}`, 'PATCH', {
    version: 1,
    status: 'closed',
    close_reason: 'spam',
  });
  assert.equal(spam.status, 200, await spam.clone().text());
  const afterSpam = (await (await f.a.request(`/api/reports?owner=${f.seller.id}`)).json()) as any;
  assert.equal(afterSpam.metrics.requests, 0);
  const historical = (await (
    await f.a.request(`/api/reports?as_of=${asOf}&owner=${f.seller.id}`)
  ).json()) as any;
  assert.equal(historical.metrics.requests, 2);
  assert.equal(
    (await f.s.request(`/api/requests/${f.req2}`, 'PATCH', { version: 2, is_spam: false })).status,
    403,
  );
});

test('een verkoopkans krijgt uitsluitend markers van expliciet gekoppelde vestigingen', async () => {
  const f = await fixture();
  const loc2 = randomUUID();
  h.db
    .prepare(
      'INSERT INTO locations(id,company_id,country,latitude,longitude,precision) VALUES(?,?,?,?,?,?)',
    )
    .run(loc2, f.cid, 'BE', 51.2, 3.2, 'address');
  h.db.prepare('UPDATE requests SET location_id=? WHERE id=?').run(loc2, f.req2);
  const created = await f.s.request(`/api/requests/${f.req1}/opportunities`, 'POST', {
    title: 'Kans zonder eigen locatie',
  });
  const opportunity = ((await created.json()) as any).opportunity;
  const map = (await (await f.s.request('/api/map')).json()) as any;
  assert.equal(
    map.items.filter((i: any) => i.kind === 'opportunity').length,
    0,
    'Andere aanvraag van hetzelfde bedrijf mag geen locatie lenen',
  );
  const linked = await f.s.request(`/api/opportunities/${opportunity.id}/requests`, 'POST', {
    request_id: f.req2,
  });
  assert.equal(linked.status, 200);
  const after = (await (await f.s.request('/api/map')).json()) as any;
  const pins = after.items.filter((i: any) => i.kind === 'opportunity');
  assert.equal(pins.length, 1);
  assert.equal(pins[0].latitude, 51.2);
});

test('teamrechten beperken aanvragen, bedrijven, kansen, taken, exports en herverdeling op de server', async () => {
  const f = await fixture();
  const managerA = await h.seedUser('manager', 'team-a-manager'),
    managerB = await h.seedUser('manager', 'team-b-manager');
  h.db.prepare('UPDATE users SET team_id=? WHERE id IN (?,?)').run('A', managerA.id, f.seller.id);
  h.db
    .prepare('UPDATE users SET team_id=? WHERE id IN (?,?)')
    .run('B', managerB.id, (f.o.user as any).id);
  const a = await h.login(managerA),
    b = await h.login(managerB);
  const created = await f.s.request(`/api/requests/${f.req1}/opportunities`, 'POST', {
    title: 'Team A machine',
  });
  const opportunity = ((await created.json()) as any).opportunity;
  assert.equal((await a.request(`/api/requests/${f.req1}`)).status, 200);
  assert.equal((await b.request(`/api/requests/${f.req1}`)).status, 404);
  assert.equal((await b.request(`/api/companies/${f.cid}`)).status, 404);
  assert.equal(
    (
      await b.request(`/api/opportunities/${opportunity.id}`, 'PATCH', {
        version: 1,
        stage: 'quote',
      })
    ).status,
    404,
  );
  assert.equal(((await (await b.request('/api/opportunities')).json()) as any).items.length, 0);
  assert.equal(((await (await b.request('/api/reports')).json()) as any).metrics.requests, 0);
  assert.equal(((await (await b.request('/api/map')).json()) as any).items.length, 0);
  assert.equal(((await (await b.request('/api/tasks')).json()) as any).items.length, 0);
  assert.ok(!(await (await b.request('/api/reports/export.csv')).text()).includes(f.req1));
  assert.equal(
    (
      await a.request(`/api/requests/${f.req1}`, 'PATCH', {
        version: 1,
        owner_id: (f.o.user as any).id,
      })
    ).status,
    400,
    'Teammanager kan niet aan een ander team toewijzen',
  );
  assert.equal(
    (
      await f.a.request(`/api/requests/${f.req1}`, 'PATCH', {
        version: 1,
        owner_id: (f.o.user as any).id,
      })
    ).status,
    200,
    'Beheerder kan teams overschrijden',
  );
});

test('een later gekoppelde aanvraag verandert de conversie van een vroegere peildatum niet', async () => {
  const f = await fixture();
  const { snapshotRequest } = await import('../server/history.ts');
  const baseline = '2026-10-01T09:00:00.000Z',
    closed = '2026-10-02T09:00:00.000Z',
    asOf = '2026-10-03T09:00:00.000Z';
  for (const requestId of [f.req1, f.req2]) {
    h.db
      .prepare('UPDATE requests SET submitted_at=?,received_at=?,updated_at=? WHERE id=?')
      .run(baseline, baseline, baseline, requestId);
    snapshotRequest(requestId, baseline);
  }
  const created = await f.s.request(`/api/requests/${f.req1}/opportunities`, 'POST', {
    title: 'Historische gedeelde kans',
    amount: 1000,
  });
  const op = ((await created.json()) as any).opportunity;
  const won = await f.s.request(`/api/opportunities/${op.id}`, 'PATCH', {
    version: 1,
    stage: 'won',
    closed_at: closed,
  });
  assert.equal(won.status, 200);
  h.db.prepare('UPDATE opportunities SET created_at=? WHERE id=?').run(baseline, op.id);
  const histories = h.db
    .prepare('SELECT * FROM opportunity_history WHERE opportunity_id=? ORDER BY rowid')
    .all(op.id) as any[];
  for (const [index, entry] of histories.entries()) {
    const snapshot = JSON.parse(entry.snapshot_json);
    snapshot.created_at = baseline;
    h.db
      .prepare('UPDATE opportunity_history SET created_at=?,snapshot_json=? WHERE id=?')
      .run(index === 0 ? baseline : closed, JSON.stringify(snapshot), entry.id);
  }
  const linked = await f.s.request(`/api/opportunities/${op.id}/requests`, 'POST', {
    request_id: f.req2,
  });
  assert.equal(linked.status, 200);
  const historical = (await (await f.s.request(`/api/reports?as_of=${asOf}`)).json()) as any;
  assert.equal(historical.metrics.requests, 2);
  assert.equal(historical.metrics.lead_conversion, 0.5);
  const current = (await (await f.s.request('/api/reports')).json()) as any;
  assert.equal(current.metrics.lead_conversion, 1);
  assert.equal(current.metrics.won_value, 1000);
});
