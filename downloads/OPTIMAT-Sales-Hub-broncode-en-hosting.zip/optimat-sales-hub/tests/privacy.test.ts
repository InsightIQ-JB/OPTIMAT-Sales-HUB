import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, readdirSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { randomUUID } from 'node:crypto';
import { makeHarness } from './helpers.ts';
let h: Awaited<ReturnType<typeof makeHarness>>;
let attachmentDir: string;
before(async () => {
  attachmentDir = mkdtempSync(join(tmpdir(), 'optimat-private-files-'));
  process.env.ATTACHMENT_DIR = attachmentDir;
  h = await makeHarness();
});
after(async () => {
  await h?.close();
  rmSync(attachmentDir, { recursive: true, force: true });
});
function seedRequest(ownerId: string, companyId?: string) {
  const t = h.now(),
    company = companyId || randomUUID(),
    request = randomUUID(),
    contact = randomUUID();
  if (!companyId)
    h.db
      .prepare(
        'INSERT INTO companies(id,name,country,owner_id,created_at,updated_at) VALUES (?,?,?,?,?,?)',
      )
      .run(company, 'Synthetisch testbedrijf', 'BE', ownerId, t, t);
  h.db
    .prepare('INSERT INTO contacts(id,company_id,name,email,created_at) VALUES (?,?,?,?,?)')
    .run(contact, company, 'Testpersoon', `${contact}@example.invalid`, t);
  h.db
    .prepare(
      'INSERT INTO requests(id,provider,submission_id,source_occurred_at,company_id,contact_id,owner_id,purpose,submitted_at,received_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
    )
    .run(request, 'synthetic', randomUUID(), t, company, contact, ownerId, 'commercial', t, t, t);
  return { request, company, contact };
}

test('private bijlagen controleren inhoud, autorisatie en downloadintegriteit', async () => {
  const owner = await h.seedUser('seller', 'bijlage-eigenaar'),
    other = await h.seedUser('seller', 'andere-verkoper'),
    management = await h.seedUser('management', 'lezend-management');
  const a = await h.login(owner),
    b = await h.login(other),
    m = await h.login(management);
  const record = seedRequest(owner.id);
  const body = {
    name: 'offerte.pdf',
    mime: 'application/pdf',
    content_base64: Buffer.from('%PDF-1.4\nSynthetic contract document').toString('base64'),
  };
  const uploaded = await a.request(`/api/requests/${record.request}/attachments`, 'POST', body);
  assert.equal(uploaded.status, 201, await uploaded.clone().text());
  const payload = (await uploaded.json()) as { attachment: { id: string; name: string } };
  assert.equal(payload.attachment.name, 'offerte.pdf');
  assert.equal(
    JSON.stringify(payload).includes('storage_key'),
    false,
    'Private opslagpad blijft geheim',
  );
  const listed = await a.request(`/api/requests/${record.request}/attachments`);
  assert.equal(listed.status, 200);
  const downloaded = await a.request(`/api/attachments/${payload.attachment.id}`);
  assert.equal(downloaded.status, 200);
  assert.equal(downloaded.headers.get('x-content-type-options'), 'nosniff');
  assert.match(downloaded.headers.get('content-disposition') || '', /^attachment/);
  assert.equal(await downloaded.text(), '%PDF-1.4\nSynthetic contract document');
  assert.equal((await b.request(`/api/attachments/${payload.attachment.id}`)).status, 404);
  assert.equal((await b.request(`/api/requests/${record.request}/attachments`)).status, 404);
  assert.equal(
    (await m.request(`/api/requests/${record.request}/attachments`, 'POST', body)).status,
    403,
  );
  assert.equal(
    (
      await a.request(`/api/requests/${record.request}/attachments`, 'POST', {
        ...body,
        content_base64: Buffer.from('<script>bad</script>').toString('base64'),
      })
    ).status,
    400,
  );
  assert.equal(
    (
      await a.request(`/api/requests/${record.request}/attachments`, 'POST', {
        ...body,
        mime: 'image/svg+xml',
      })
    ).status,
    400,
  );
});

test('gerichte verwijdering wist payloads en private bestanden maar behoudt een ander dossier', async () => {
  const admin = await h.seedUser('admin', 'privacybeheer'),
    seller = await h.seedUser('seller', 'privacyverkoper');
  const a = await h.login(admin),
    s = await h.login(seller);
  const record = seedRequest(seller.id),
    remaining = seedRequest(seller.id, record.company);
  const source = h.seedSource();
  h.db
    .prepare('UPDATE requests SET source_id=?,form_id=?,submission_id=?,provider=? WHERE id=?')
    .run(source.sourceId, source.formId, 'privacy-submission', 'contract', record.request);
  h.db
    .prepare(
      'INSERT INTO events(id,source_id,event_id,submission_id,provider,form_id,source_version,occurred_at,received_at,payload_json,payload_hash,status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
    )
    .run(
      randomUUID(),
      source.sourceId,
      randomUUID(),
      'privacy-submission',
      'contract',
      '42',
      1,
      h.now(),
      h.now(),
      JSON.stringify({ personal: 'sensitive source fields' }),
      'hash',
      'processed',
    );
  h.db
    .prepare(
      'INSERT INTO events(id,source_id,event_id,submission_id,provider,form_id,source_version,occurred_at,received_at,payload_json,payload_hash,status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
    )
    .run(
      randomUUID(),
      source.sourceId,
      randomUUID(),
      'unrelated-submission',
      'contract',
      '42',
      1,
      h.now(),
      h.now(),
      JSON.stringify({ personal: 'other dossier source fields' }),
      'hash',
      'processed',
    );
  const attachment = await s.request(`/api/requests/${record.request}/attachments`, 'POST', {
    name: 'beeld.png',
    mime: 'image/png',
    content_base64: Buffer.from([137, 80, 78, 71, 13, 10, 26, 10, 1]).toString('base64'),
  });
  assert.equal(attachment.status, 201);
  const attachmentId = ((await attachment.json()) as any).attachment.id;
  const exported = await a.request(`/api/admin/privacy/requests/${record.request}/export`);
  assert.equal(exported.status, 200);
  const exportBody = (await exported.json()) as any;
  assert.equal(exportBody.request.id, record.request);
  assert.equal(exportBody.contact.id, record.contact);
  assert.equal(JSON.stringify(exportBody).includes('storage_key'), false);
  assert.equal(
    (await s.request(`/api/admin/privacy/requests/${record.request}/export`)).status,
    403,
  );
  assert.equal(
    (
      await a.request(`/api/admin/privacy/requests/${record.request}`, 'DELETE', {
        version: 3,
        reason: 'Privacyverzoek test',
      })
    ).status,
    409,
  );
  const removed = await a.request(`/api/admin/privacy/requests/${record.request}`, 'DELETE', {
    version: 1,
    reason: 'Privacyverzoek synthetische test',
  });
  assert.equal(removed.status, 200, await removed.clone().text());
  assert.equal(((await removed.json()) as any).cleanup_pending, 0);
  assert.equal(h.db.prepare('SELECT id FROM requests WHERE id=?').get(record.request), undefined);
  assert.ok(h.db.prepare('SELECT id FROM requests WHERE id=?').get(remaining.request));
  assert.ok(h.db.prepare('SELECT id FROM companies WHERE id=?').get(record.company));
  assert.equal(h.db.prepare('SELECT id FROM contacts WHERE id=?').get(record.contact), undefined);
  assert.ok(h.db.prepare('SELECT id FROM contacts WHERE id=?').get(remaining.contact));
  assert.equal(
    h.db.prepare('SELECT id FROM events WHERE submission_id=?').get('privacy-submission'),
    undefined,
  );
  assert.ok(
    h.db.prepare('SELECT id FROM events WHERE submission_id=?').get('unrelated-submission'),
  );
  assert.equal((await a.request(`/api/attachments/${attachmentId}`)).status, 404);
  assert.equal(
    readdirSync(attachmentDir).length,
    1,
    'Alleen de bijlage uit het andere testdossier blijft behouden',
  );
  const replayPayload = {
    event_id: randomUUID(),
    submission_id: 'privacy-submission',
    version: 2,
    occurred_at: h.now(),
    submitted_at: h.now(),
    provider: 'contract',
    form_id: '42',
    form_name: 'Privacy replay contract test',
    purpose: 'commercial',
    intents: ['brochure'],
    fields: [
      { id: 'company', label: 'Bedrijf', type: 'text', value: 'Mag niet opnieuw verschijnen' },
    ],
  };
  const replay = await h.signed(`/api/webhooks/${source.sourceId}`, replayPayload);
  assert.equal(replay.status, 202);
  assert.equal(((await replay.json()) as any).status, 'ignored_erased');
  const { processPending } = await import('../server/intake.ts');
  await processPending();
  assert.equal(
    h.db
      .prepare('SELECT id FROM requests WHERE source_id=? AND submission_id=?')
      .get(source.sourceId, 'privacy-submission'),
    undefined,
  );
  assert.equal(
    h.db
      .prepare('SELECT id FROM events WHERE source_id=? AND submission_id=?')
      .get(source.sourceId, 'privacy-submission'),
    undefined,
    'Verwijderde persoonsgegevens worden ook bij herlevering niet opnieuw bewaard',
  );
  const retention = await a.request('/api/admin/privacy/retention');
  assert.equal(retention.status, 200);
  assert.equal(((await retention.json()) as any).enforcement, 'manual_review');
});
