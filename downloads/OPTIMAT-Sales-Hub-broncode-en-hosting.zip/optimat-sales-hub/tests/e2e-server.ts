// Isolated browser-test process. Never imports or populates the default CRM database.
process.env.DB_PATH = ':memory:';
process.env.NODE_ENV = 'test';
process.env.APP_URL = 'http://127.0.0.1:3100';
process.env.OPTIMAT_WP_MAIN_SECRET = 'synthetic-browser-main-gravity-key';
process.env.OPTIMAT_WP_KDT_SECRET = 'synthetic-browser-kdt-gravity-key';
const { db, id, now } = await import('../server/db.ts');
const { hashPassword } = await import('../server/auth.ts');
const { receiveEvent, processPending } = await import('../server/intake.ts');
const { createApp } = await import('../server/app.ts');
for (const [uid, email, name, role] of [
  ['browser-admin', 'browser-admin@example.invalid', 'Fictieve Beheerder', 'admin'],
  ['browser-seller', 'browser-seller@example.invalid', 'Fictieve Verkoper', 'seller'],
  ['browser-other', 'browser-other@example.invalid', 'Andere Verkoper', 'seller'],
]) {
  db.prepare(
    'INSERT INTO users(id,email,name,password_hash,role,created_at) VALUES(?,?,?,?,?,?)',
  ).run(uid, email, name, hashPassword('Browser-test-password-2026!'), role, now());
}
const source = 'browser-source',
  form = 'browser-form';
db.prepare('INSERT INTO sources(id,name,site_url,secret_env,created_at) VALUES(?,?,?,?,?)').run(
  source,
  'Fictieve browserbron',
  'https://browser.example.invalid',
  'UNCONFIGURED_BROWSER_SECRET',
  now(),
);
db.prepare(
  'INSERT INTO forms(id,source_id,provider,form_id,name,purpose,mapping_json,version,coverage,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)',
).run(
  form,
  source,
  'contract',
  'browser-42',
  'Fictief brochure/offerte',
  'commercial',
  JSON.stringify({
    company: 'company_name',
    vat: 'enterprise_number',
    country: 'country',
    email: 'email',
    name: 'name',
    phone: 'phone',
    message: 'message',
    postcode: 'postcode',
    city: 'city',
  }),
  1,
  'contract_tested',
  now(),
);
receiveEvent(source, {
  event_id: id(),
  submission_id: 'browser-submission',
  version: 1,
  occurred_at: now(),
  submitted_at: now(),
  provider: 'contract',
  form_id: 'browser-42',
  form_name: 'Fictief brochure/offerte',
  purpose: 'commercial',
  intents: ['brochure', 'quote'],
  fields: [
    { id: 'company', label: 'Bedrijf', type: 'text', value: 'Fictief Browserbedrijf' },
    { id: 'vat', label: 'Ondernemingsnummer', type: 'text', value: '0202239951' },
    { id: 'country', label: 'Land', type: 'text', value: 'BE' },
    { id: 'name', label: 'Contactpersoon', type: 'text', value: 'Fictieve Contactpersoon' },
    { id: 'email', label: 'E-mail', type: 'email', value: 'fictief@example.invalid' },
    { id: 'phone', label: 'Telefoon', type: 'tel', value: '+32000000000' },
    {
      id: 'message',
      label: 'Vraag',
      type: 'textarea',
      value: 'Fictieve browseracceptatievraag: brochure én offerte.',
    },
    { id: 'postcode', label: 'Postcode', type: 'text', value: '9000' },
    { id: 'city', label: 'Gemeente', type: 'text', value: 'Gent' },
  ],
});
await processPending();
db.prepare('UPDATE requests SET owner_id=?').run('browser-seller');
const request = db.prepare('SELECT id,company_id FROM requests LIMIT 1').get() as {
  id: string;
  company_id: string;
};
db.prepare(
  'INSERT INTO opportunities(id,company_id,owner_id,title,stage,amount,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)',
).run(
  'browser-mobile-opportunity',
  request.company_id,
  'browser-seller',
  'Fictieve mobiele kans',
  'qualified',
  1000,
  now(),
  now(),
);
db.prepare('INSERT INTO opportunity_requests VALUES(?,?)').run(
  'browser-mobile-opportunity',
  request.id,
);
const server = createApp().listen(3100, '127.0.0.1', () =>
  console.log('Isolated browser acceptance server listening'),
);
const shutdown = () =>
  server.close(() => {
    db.close();
    process.exit(0);
  });
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

export {};
