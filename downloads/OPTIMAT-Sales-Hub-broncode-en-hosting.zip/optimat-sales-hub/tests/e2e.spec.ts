import { test, expect, type Page } from '@playwright/test';
import { createHmac, randomUUID } from 'node:crypto';
async function login(page: Page, email: string) {
  await page.goto('/');
  await page.getByLabel('E-mailadres').fill(email);
  await page.getByLabel('Wachtwoord', { exact: true }).fill('Browser-test-password-2026!');
  await page.getByRole('button', { name: 'Aanmelden', exact: true }).click();
  await expect(
    page.getByRole('heading', { name: 'Goed werk begint met overzicht.' }),
  ).toBeVisible();
}
async function requestId(page: Page) {
  const response = await page.request.get('/api/requests');
  expect(response.ok()).toBeTruthy();
  const data = await response.json();
  return data.items[0].id as string;
}

test('desktop: aanvraagfiche, toewijzing, contactactie, taak en verkooppipeline blijven bewaard', async ({
  page,
}) => {
  await login(page, 'browser-admin@example.invalid');
  const id = await requestId(page);
  await page.goto(`/requests/${id}`);
  await expect(
    page.getByRole('heading', { name: 'Fictief Browserbedrijf', exact: true }),
  ).toBeVisible();
  await page.getByRole('combobox', { name: /^Eigenaar/ }).selectOption('browser-seller');
  await expect(page.getByRole('status').filter({ hasText: 'Opgeslagen' })).toBeVisible();
  await page.getByLabel('Registreer een actie').selectOption('call');
  await page
    .getByRole('textbox', { name: 'Inhoud van de actie' })
    .fill('Browseracceptatie: werkelijk gesprek geregistreerd.');
  await page.getByRole('button', { name: 'Actie opslaan' }).click();
  await expect(
    page.getByText('Browseracceptatie: werkelijk gesprek geregistreerd.', { exact: true }),
  ).toBeVisible();
  await page
    .getByLabel('Nieuwe taak', { exact: true })
    .fill('Browseracceptatie: offerte terugbellen');
  await page.getByLabel('Datum en tijd', { exact: true }).fill('2026-11-02T10:00');
  await page.getByRole('button', { name: 'Taak plannen' }).click();
  await expect(
    page.getByText('Browseracceptatie: offerte terugbellen', { exact: true }),
  ).toBeVisible();
  await page.getByRole('combobox', { name: /^Status/ }).selectOption('contacted');
  await expect(page.getByRole('combobox', { name: /^Status/ })).toHaveValue('contacted');
  await page.reload();
  await expect(page.getByRole('combobox', { name: /^Status/ })).toHaveValue('contacted');
  await expect(
    page.getByText('Browseracceptatie: werkelijk gesprek geregistreerd.', { exact: true }),
  ).toBeVisible();
  await expect(
    page.getByText('Browseracceptatie: offerte terugbellen', { exact: true }),
  ).toBeVisible();
  await page.getByRole('button', { name: /^Verkoopkansen/ }).click();
  await page.getByLabel('Titel nieuwe verkoopkans').fill('Browseracceptatie CNC-investering');
  await page.getByLabel('Indicatieve waarde (€)').fill('45000');
  await page.getByRole('button', { name: 'Verkoopkans aanmaken' }).click();
  await expect(page.getByText('Browseracceptatie CNC-investering', { exact: true })).toBeVisible();
  await page.getByRole('link', { name: 'Verkoopkansen', exact: true }).click();
  await expect(page.getByText('Browseracceptatie CNC-investering', { exact: true })).toBeVisible();
  await expect(page.locator('body')).not.toContainText('De actie is niet gelukt.');
  await page.goto(`/requests/${id}`);
  await page.getByRole('checkbox', { name: 'Testaanvraag', exact: true }).click();
  await expect(page.getByRole('checkbox', { name: 'Testaanvraag', exact: true })).toBeChecked();
  await expect(page.getByRole('status').filter({ hasText: 'Testaanvraag' })).toBeVisible();
  const excluded = await (await page.request.get('/api/reports')).json();
  expect(excluded.metrics.requests).toBe(0);
  await page.getByRole('checkbox', { name: 'Testaanvraag', exact: true }).click();
  await expect(page.getByRole('checkbox', { name: 'Testaanvraag', exact: true })).not.toBeChecked();
  await expect(page.getByRole('status').filter({ hasText: 'Testaanvraag' })).toHaveCount(0);
  const included = await (await page.request.get('/api/reports')).json();
  expect(included.metrics.requests).toBe(1);
});

test('mobiel 390px: eigenaar kan fiche openen, bellen/mailen, notitie opslaan en taak plannen', async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await login(page, 'browser-seller@example.invalid');
  const id = await requestId(page);
  await page.goto(`/requests/${id}`);
  await expect(
    page.getByRole('heading', { name: 'Fictief Browserbedrijf', exact: true }),
  ).toBeVisible();
  await expect(page.getByRole('link', { name: 'Bellen', exact: true })).toHaveAttribute(
    'href',
    /^tel:/,
  );
  await expect(page.getByRole('link', { name: 'Mailen', exact: true })).toHaveAttribute(
    'href',
    /^mailto:/,
  );
  await page
    .getByRole('textbox', { name: 'Inhoud van de actie' })
    .fill('Mobiele browseracceptatie: eigen notitie.');
  await page.getByRole('button', { name: 'Actie opslaan' }).click();
  await expect(
    page.getByText('Mobiele browseracceptatie: eigen notitie.', { exact: true }),
  ).toBeVisible();
  await page.getByLabel('Nieuwe taak', { exact: true }).fill('Mobiele browseracceptatie: opvolgen');
  await page.getByLabel('Datum en tijd', { exact: true }).fill('2026-11-03T11:00');
  await page.getByRole('button', { name: 'Taak plannen' }).click();
  await expect(
    page.getByText('Mobiele browseracceptatie: opvolgen', { exact: true }),
  ).toBeVisible();
  await page.reload();
  await expect(
    page.getByText('Mobiele browseracceptatie: eigen notitie.', { exact: true }),
  ).toBeVisible();
  const horizontal = await page.evaluate(() => ({
    width: window.innerWidth,
    scroll: document.documentElement.scrollWidth,
  }));
  expect(horizontal.scroll).toBeLessThanOrEqual(horizontal.width);
  await page.screenshot({ path: 'test-results/mobile-request.png', fullPage: true });
  await page.goto('/opportunities');
  await page
    .getByRole('combobox', { name: 'Fase van Fictieve mobiele kans', exact: true })
    .selectOption('quote');
  await expect(
    page.getByRole('combobox', { name: 'Fase van Fictieve mobiele kans', exact: true }),
  ).toHaveValue('quote');
  await page.reload();
  await expect(
    page.getByRole('combobox', { name: 'Fase van Fictieve mobiele kans', exact: true }),
  ).toHaveValue('quote');
  const pipelineWidth = await page.evaluate(() => ({
    width: window.innerWidth,
    scroll: document.documentElement.scrollWidth,
  }));
  expect(pipelineWidth.scroll).toBeLessThanOrEqual(pipelineWidth.width);
});

test('andere verkoper kan een beveiligde aanvraag-URL en de intake niet lezen', async ({
  browser,
}) => {
  const owner = await browser.newContext();
  const ownerPage = await owner.newPage();
  await login(ownerPage, 'browser-seller@example.invalid');
  const id = await requestId(ownerPage);
  const other = await browser.newContext();
  const page = await other.newPage();
  await login(page, 'browser-other@example.invalid');
  await page.goto(`/requests/${id}`);
  await expect(page.getByRole('alert')).toContainText('Aanvraag niet gevonden');
  const api = await page.request.get(`/api/requests/${id}`);
  expect(api.status()).toBe(404);
  const list = await (await page.request.get('/api/requests')).json();
  expect(list.items).toHaveLength(0);
  await other.close();
  await owner.close();
});

test('Gravity Forms: twee bronverbindingen, ondertekende inventaris en versievaste mapping via keuzelijsten', async ({
  page,
}) => {
  await login(page, 'browser-admin@example.invalid');
  await page.goto('/settings');
  for (const name of [
    'OPTIMAT Group (Gravity Forms) registreren',
    'KDT (Gravity Forms) registreren',
  ]) {
    const registered = page.waitForResponse(
      (response) =>
        response.url().endsWith('/api/integrations/sources') &&
        response.request().method() === 'POST',
    );
    await page.getByRole('button', { name, exact: true }).click();
    expect((await registered).status()).toBe(201);
  }
  const initial = await (await page.request.get('/api/integrations')).json();
  const sources = [
    {
      site: 'www.optimat-group.com',
      title: 'GF OPTIMAT brochure',
      secret: 'synthetic-browser-main-gravity-key',
    },
    {
      site: 'kdt.optimat-group.com',
      title: 'GF KDT offerte',
      secret: 'synthetic-browser-kdt-gravity-key',
    },
  ];
  for (const fixture of sources) {
    const source = initial.sources.find(
      (item: any) => new URL(item.site_url).hostname === fixture.site,
    );
    expect(source).toBeTruthy();
    const payload = {
      kind: 'gravity_inventory',
      event_id: randomUUID(),
      connector_version: 'browser-contract-0.2',
      site_url: source.site_url,
      generated_at: new Date().toISOString(),
      complete: true,
      forms: [
        {
          form_id: '17',
          name: fixture.title,
          active: true,
          enabled: false,
          purpose: 'unclassified',
          base_intents: [],
          fields: [
            { id: '1', label: 'Bedrijfsnaam', type: 'text' },
            { id: '2', label: 'E-mailadres', type: 'email' },
            { id: '3', label: 'Productmodel', type: 'hidden', hidden: true },
          ],
        },
      ],
      reconciliation: { supported: true, status: 'not_started' },
    };
    const data = JSON.stringify(payload),
      timestamp = String(Math.floor(Date.now() / 1000));
    const signature = createHmac('sha256', fixture.secret)
      .update(`${timestamp}.${data}`)
      .digest('hex');
    const synced = await page.request.post(`/api/connectors/${source.id}/sync`, {
      data,
      headers: {
        'content-type': 'application/json',
        'x-optimat-timestamp': timestamp,
        'x-optimat-signature': signature,
      },
    });
    expect(synced.status()).toBe(202);
    expect((await synced.json()).event_id).toBe(payload.event_id);
  }
  await page.getByRole('button', { name: 'Vernieuwen', exact: true }).click();
  await expect(page.getByText('GF OPTIMAT brochure', { exact: true })).toBeVisible();
  await expect(page.getByText('GF KDT offerte', { exact: true })).toBeVisible();
  await page.getByRole('tab', { name: 'Formuliermapping', exact: true }).click();
  const row = page.getByRole('row').filter({ hasText: 'GF OPTIMAT brochure' });
  await row.getByRole('button', { name: 'Bewerken', exact: true }).click();
  await page
    .getByRole('combobox', { name: 'CRM-veld voor Bedrijfsnaam (1)', exact: true })
    .selectOption('company_name');
  await page
    .getByRole('combobox', { name: 'CRM-veld voor E-mailadres (2)', exact: true })
    .selectOption('email');
  await page
    .getByRole('combobox', { name: 'Doel / routing', exact: true })
    .selectOption('commercial');
  const saved = page.waitForResponse(
    (response) =>
      response.url().endsWith('/api/integrations/forms') && response.request().method() === 'POST',
  );
  await page.getByRole('button', { name: 'Mapping opslaan', exact: true }).click();
  const first = await saved;
  expect(first.status()).toBe(200);
  expect((await first.json()).version).toBe(2);
  await expect(
    page.getByLabel('Huidige versie (controle op gelijktijdige wijzigingen)', { exact: true }),
  ).toHaveValue('2');
  await page
    .getByRole('combobox', { name: 'CRM-veld voor Productmodel (3)', exact: true })
    .selectOption('model');
  const resaved = page.waitForResponse(
    (response) =>
      response.url().endsWith('/api/integrations/forms') && response.request().method() === 'POST',
  );
  await page.getByRole('button', { name: 'Mapping opslaan', exact: true }).click();
  expect((await resaved).status()).toBe(200);
  const final = await (await page.request.get('/api/integrations')).json();
  const result = final.forms.find((form: any) => form.name === 'GF OPTIMAT brochure');
  expect(result.version).toBe(3);
  expect(result.mapping).toEqual({ '1': 'company_name', '2': 'email', '3': 'model' });
  expect(
    final.sources
      .filter((source: any) =>
        sources.some((fixture) => new URL(source.site_url).hostname === fixture.site),
      )
      .every((source: any) => source.status !== 'live_tested'),
  ).toBeTruthy();
  await expect(page.getByRole('alert')).toHaveCount(0);
});
