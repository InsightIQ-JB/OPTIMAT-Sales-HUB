import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync, readdirSync, copyFileSync, statSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { DatabaseSync } from 'node:sqlite';

test('backup-CLI maakt een consistente private database die via migratie hersteld kan worden', async () => {
  const folder = mkdtempSync(join(tmpdir(), 'optimat-backup-contract-'));
  process.env.DB_PATH = join(folder, 'source.sqlite');
  const { db } = await import('../server/db.ts');
  try {
    db.prepare('INSERT INTO settings VALUES (?,?)').run(
      'backup_contract',
      JSON.stringify({ synthetic: true, description: 'Fictief herstelbewijs' }),
    );
    const output = join(folder, 'backups');
    const command = spawnSync(process.execPath, ['--import', 'tsx', 'scripts/backup.ts'], {
      cwd: process.cwd(),
      encoding: 'utf8',
      env: { ...process.env, DB_PATH: process.env.DB_PATH, BACKUP_DIR: output },
    });
    assert.equal(command.status, 0, command.stderr);
    const files = readdirSync(output).filter((name) => name.endsWith('.sqlite'));
    assert.equal(files.length, 1);
    const backupPath = join(output, files[0]);
    assert.equal(
      statSync(backupPath).mode & 0o777,
      0o600,
      'Databasebackup is alleen leesbaar voor de eigenaar',
    );
    const restored = join(folder, 'restored.sqlite');
    copyFileSync(backupPath, restored);
    const migration = spawnSync(process.execPath, ['--import', 'tsx', 'scripts/migrate.ts'], {
      cwd: process.cwd(),
      encoding: 'utf8',
      env: { ...process.env, DB_PATH: restored },
    });
    assert.equal(migration.status, 0, migration.stderr);
    const check = new DatabaseSync(restored, { readOnly: true });
    try {
      assert.equal(check.prepare('PRAGMA integrity_check').get()?.integrity_check, 'ok');
      const setting = check
        .prepare('SELECT value_json FROM settings WHERE key=?')
        .get('backup_contract') as { value_json: string };
      assert.equal(JSON.parse(setting.value_json).description, 'Fictief herstelbewijs');
      assert.ok(Number(check.prepare('SELECT count(*) n FROM schema_migrations').get()?.n) > 0);
    } finally {
      check.close();
    }
  } finally {
    db.close();
    rmSync(folder, { recursive: true, force: true });
  }
});
