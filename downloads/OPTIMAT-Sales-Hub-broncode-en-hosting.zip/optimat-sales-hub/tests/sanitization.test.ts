import { test } from 'node:test';
import assert from 'node:assert/strict';
process.env.DB_PATH = ':memory:';
const { cleanFields, eventSchema, normalizeCountry } = await import('../server/intake.ts');
const { db } = await import('../server/db.ts');
test('ontvanger verwijdert technische geheimen ook zonder WordPress-adapter', () => {
  const forbidden = [
    'ip',
    'nonce',
    'csrf',
    'api_key',
    'session_id',
    'captcha',
    'msclkid',
    'password',
  ];
  const fields = forbidden.map((id) => ({ id, label: id, type: 'hidden', value: 'sensitive' }));
  const result = cleanFields([
    ...fields,
    {
      id: 'business',
      label: 'Machine-interesse',
      type: 'compound',
      value: { message: 'CNC', csrf: 'secret', options: ['nesting', 'boren'] },
    },
  ]);
  assert.equal(result.length, 1);
  assert.deepEqual(result[0].value, { message: 'CNC', options: ['nesting', 'boren'] });
});
test('connectorgrenzen zijn bruikbaar op ontvanger en landen worden expliciet genormaliseerd', () => {
  const input = {
    event_id: 'boundary',
    submission_id: 'source-id',
    version: 1,
    occurred_at: new Date().toISOString(),
    submitted_at: new Date().toISOString(),
    provider: 'contract',
    form_id: 'f'.repeat(191),
    form_name: 'n'.repeat(200),
    purpose: 'commercial',
    intents: ['brochure', 'quote'],
    fields: [{ id: 'id', label: 'l'.repeat(500), type: 'text', value: 'original' }],
  };
  assert.equal(eventSchema.parse(input).fields[0].value, 'original');
  assert.equal(normalizeCountry('België'), 'BE');
  assert.equal(normalizeCountry('Nederland'), 'NL');
  assert.equal(normalizeCountry('Luxembourg'), 'LU');
  assert.equal(normalizeCountry(''), '');
});
process.on('exit', () => db.close());
