import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { XMLParser } from 'fast-xml-parser';
import { KBO_ENDPOINT, kboStatus, searchKbo } from '../server/kbo.ts';
import { HttpError } from '../server/errors.ts';

const env = {
  KBO_ENABLED: 'true',
  KBO_TERMS_CONFIRMED: 'true',
  BCE_WS_USERNAME: 'synthetic-kbo-user',
  BCE_WS_PASSWORD: 'synthetic-kbo-password',
};
const enterprise = (type = 'ELP', number = '0123456749') =>
  `<dat:Enterprise><dat:Number>${number}</dat:Number><dat:TypeOfEnterprise>${type}</dat:TypeOfEnterprise><dat:PrimaryDenomination><dat:Language>nl</dat:Language><dat:Value>Hout &amp; Vorm Test BV</dat:Value></dat:PrimaryDenomination><dat:JuridicalSituation><dat:Status><dat:Code>AC</dat:Code></dat:Status></dat:JuridicalSituation><dat:Address><dat:TypeOfAddress><dat:Code>REGO</dat:Code></dat:TypeOfAddress><dat:Street><dat:Description><dat:Language>nl</dat:Language><dat:Value>Teststraat</dat:Value></dat:Description></dat:Street><dat:HouseNumber>17</dat:HouseNumber><dat:Zipcode>9000</dat:Zipcode><dat:Municipality><dat:Description><dat:Language>nl</dat:Language><dat:Value>Gent</dat:Value></dat:Description></dat:Municipality><dat:Country><dat:Code>150</dat:Code></dat:Country></dat:Address><dat:ContactInformation><dat:ContactType>004</dat:ContactType><dat:Description><dat:Value>E-mailadres</dat:Value></dat:Description><dat:Value>sales@example.invalid</dat:Value></dat:ContactInformation><dat:Activity><dat:Code>31000</dat:Code><dat:Version>2025</dat:Version></dat:Activity></dat:Enterprise>`;
const envelope = (body: string, status = '00001') =>
  `<?xml version="1.0"?><soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:dat="http://economie.fgov.be/kbopub/webservices/v1/datamodel"><soap:Body><Reply><ReplyStatus><Code>${status}</Code></ReplyStatus><SnapshotDate>2026-10-27</SnapshotDate>${body}</Reply></soap:Body></soap:Envelope>`;
const transport = (xml: string, status = 200): typeof fetch =>
  (async () => new Response(xml, { status })) as typeof fetch;
const errorWith = (status: number) => (e: unknown) => e instanceof HttpError && e.status === status;

test('KBO blijft zonder expliciete activering, voorwaarden en credentials offline', async () => {
  let calls = 0;
  const send = (async () => {
    calls++;
    throw Error('network should not run');
  }) as typeof fetch;
  for (const settings of [
    {},
    { ...env, KBO_ENABLED: 'false' },
    { ...env, KBO_TERMS_CONFIRMED: 'false' },
    { ...env, BCE_WS_PASSWORD: '' },
  ]) {
    assert.equal(kboStatus(settings).configured, false);
    await assert.rejects(searchKbo({ q: 'Hout' }, { env: settings, fetch: send }), errorWith(503));
  }
  assert.equal(calls, 0);
  assert.equal(kboStatus(env).status, 'configured_not_live_tested');
  assert.equal(kboStatus(env).live_verified, false);
  assert.equal(JSON.stringify(kboStatus(env)).includes(env.BCE_WS_PASSWORD), false);
});

test('nummerzoekopdracht gebruikt vast HTTPS-endpoint, verse WSSE-digest en begrensde timeout', async () => {
  let calls = 0;
  const send = (async (url: unknown, options?: RequestInit) => {
    calls++;
    assert.equal(url, KBO_ENDPOINT);
    assert.equal(options?.method, 'POST');
    assert.equal(options?.redirect, 'error');
    assert.equal(
      options?.headers && new Headers(options.headers).get('SOAPAction'),
      '"http://fgov.economie.be/kbopub/ReadEnterprise"',
    );
    assert.ok(options?.signal);
    assert.equal(options.signal.aborted, false);
    const xml = String(options?.body);
    assert.equal(xml.includes('<dat:EnterpriseNumber>0123456749</dat:EnterpriseNumber>'), true);
    assert.equal(xml.includes(env.BCE_WS_PASSWORD), false);
    const parsed = new XMLParser({
      removeNSPrefix: true,
      parseTagValue: false,
      ignoreAttributes: false,
    }).parse(xml);
    const security = parsed.Envelope.Header.Security,
      token = security.UsernameToken;
    const digest = createHash('sha1')
      .update(Buffer.from(token.Nonce['#text'], 'base64'))
      .update(token.Created)
      .update(env.BCE_WS_PASSWORD)
      .digest('base64');
    assert.equal(token.Password['#text'], digest);
    assert.equal(Buffer.from(token.Nonce['#text'], 'base64').length, 24);
    assert.ok(Date.parse(security.Timestamp.Expires) > Date.parse(token.Created));
    return new Response(envelope(enterprise()));
  }) as typeof fetch;
  const result = await searchKbo({ q: 'BE 0123.456.749' }, { env, fetch: send });
  assert.equal(calls, 1);
  assert.equal(result.items.length, 1);
  assert.deepEqual(result.items[0], {
    enterprise_number: '0123456749',
    name: 'Hout & Vorm Test BV',
    country: 'BE',
    legal_person: true,
    active: true,
    address: 'Teststraat 17',
    postcode: '9000',
    city: 'Gent',
    email: 'sales@example.invalid',
    phone: '',
    website: '',
    activities: [{ code: '31000', version: '2025' }],
    data_source: 'KBO Public Search webservice',
    source_updated_at: '2026-10-27',
    match_confidence: 'enterprise_number',
  });
  assert.equal(result.live_verified, false);
});

test('naamzoekopdracht escaped XML, behoudt bronmetadata en sluit natuurlijke personen uit', async () => {
  const send = (async (_url: unknown, options?: RequestInit) => {
    const body = String(options?.body);
    assert.ok(body.includes('<mes:Phoneme>Hout</mes:Phoneme>'));
    assert.ok(body.includes('<mes:Phoneme>&amp;</mes:Phoneme>'));
    assert.ok(body.includes('<mes:Phoneme>&lt;Vorm&gt;</mes:Phoneme>'));
    assert.ok(body.includes('<mes:TypeOfEnterprise>ELP</mes:TypeOfEnterprise>'));
    assert.equal(/<(?:mes|dat):(?:NaceCode|SectorCode|ActivityCode)>47(?:<|\d)/.test(body), false);
    return new Response(
      envelope(enterprise() + enterprise('EPP', '0202239951') + enterprise(), '00008'),
    );
  }) as typeof fetch;
  const result = await searchKbo({ q: 'Hout & <Vorm>' }, { env, fetch: send });
  assert.equal(result.items.length, 1);
  assert.equal(result.items[0].legal_person, true);
  assert.equal(result.truncated, true);
  assert.equal(result.snapshotDate, '2026-10-27');
});

test('onbewezen filters en ongeldig nummer leiden niet tot KBO-aanroepen', async () => {
  let calls = 0;
  const send = (async () => {
    calls++;
    return new Response(envelope(''));
  }) as typeof fetch;
  for (const input of [
    { q: 'Hout', postcode: '9000' },
    { q: 'Hout', activity: '31000' },
    { q: '0123456700' },
    { q: 'A' },
  ])
    await assert.rejects(searchKbo(input, { env, fetch: send }), errorWith(422));
  assert.equal(calls, 0);
});

test('SOAP-faults geven bruikbare fouten zonder upstreamgegevens te lekken', async () => {
  const fault = (message: string) =>
    `<Envelope><Body><Fault><faultstring>${message}</faultstring></Fault></Body></Envelope>`;
  await assert.rejects(
    searchKbo(
      { q: 'Hout' },
      { env, fetch: transport(fault('FailedAuthentication synthetic-secret'), 500) },
    ),
    (e: unknown) => errorWith(502)(e) && !String(e).includes('synthetic-secret'),
  );
  await assert.rejects(
    searchKbo({ q: 'Hout' }, { env, fetch: transport(fault('quota exceeded'), 500) }),
    errorWith(503),
  );
  await assert.rejects(
    searchKbo({ q: 'Hout' }, { env, fetch: transport(fault('terms of service'), 500) }),
    errorWith(503),
  );
  await assert.rejects(
    searchKbo(
      { q: 'Hout' },
      {
        env,
        fetch: (async () => {
          throw Error('timeout synthetic-secret');
        }) as typeof fetch,
      },
    ),
    errorWith(502),
  );
});

test('XML-entiteiten, ongeldige XML en te grote responses worden afgewezen', async () => {
  for (const xml of [
    '<!DOCTYPE foo [<!ENTITY secret SYSTEM "file:///etc/passwd">]><foo>&secret;</foo>',
    '<Envelope><unclosed>',
    'x'.repeat(2000001),
  ])
    await assert.rejects(searchKbo({ q: 'Hout' }, { env, fetch: transport(xml) }), errorWith(502));
});

test('lege bronresultaten en ongeldige ondernemingsnummers creëren geen prospects', async () => {
  const none = await searchKbo({ q: 'Hout' }, { env, fetch: transport(envelope('', '00010')) });
  assert.deepEqual(none.items, []);
  const invalid = await searchKbo(
    { q: 'Hout' },
    { env, fetch: transport(envelope(enterprise('ELP', '0123456700'))) },
  );
  assert.deepEqual(invalid.items, []);
});
