import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createHmac } from 'node:crypto';
import { makeHarness } from './helpers.ts';
let h: Awaited<ReturnType<typeof makeHarness>>;
before(async () => {
  h = await makeHarness();
});
after(async () => {
  await h.close();
});
test('exacte PHP Gravity Forms-outboxbytes leveren complete fiches met compoundvelden en lege JSON-context', async () => {
  const source = h.seedSource();
  h.db.prepare('UPDATE forms SET provider=?,form_id=?,mapping_json=? WHERE id=?').run(
    'gravity',
    '17',
    JSON.stringify({
      '1': 'company_name',
      '2.3': 'name',
      '2.6': 'name',
      '3.1': 'address',
      '3.3': 'city',
      '8': 'machine',
    }),
    source.formId,
  );
  const { processPending } = await import('../server/intake.ts');
  for (const file of ['gravity-wire.json', 'gravity-empty-context-wire.json']) {
    const raw = readFileSync(new URL('./fixtures/' + file, import.meta.url), 'utf8');
    const entry = JSON.parse(raw);
    const timestamp = String(Math.floor(Date.now() / 1000));
    const signature = createHmac('sha256', process.env.TEST_WP_SECRET!)
      .update(timestamp + '.')
      .update(raw)
      .digest('hex');
    for (let retry = 0; retry < 3; retry++) {
      const response = await h.raw(`/api/webhooks/${source.sourceId}`, {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          'x-optimat-timestamp': timestamp,
          'x-optimat-signature': signature,
        },
        body: raw,
      });
      assert.equal(response.status, 202, await response.clone().text());
      assert.equal((await response.json()).event_id, entry.event_id);
    }
    await processPending();
    const request = h.db
      .prepare(
        'SELECT r.*,c.name company_name,ct.name contact_name,l.address,l.city FROM requests r JOIN companies c ON c.id=r.company_id JOIN contacts ct ON ct.id=r.contact_id JOIN locations l ON l.id=r.location_id WHERE r.source_id=? AND r.submission_id=?',
      )
      .get(source.sourceId, entry.submission_id) as any;
    assert.equal(request.company_name, 'SYNTHETISCHE PHP-WIRE TESTFIRMA');
    assert.equal(request.contact_name, 'Jan Test');
    assert.equal(request.address, 'Teststraat');
    assert.equal(request.city, 'Gent');
    assert.equal(request.machine, 'CNC');
    assert.equal(request.submitted_at, '2020-01-01T09:00:00.000Z');
    assert.deepEqual(JSON.parse(request.intents_json), ['brochure', 'quote']);
    const fields = JSON.parse(request.fields_json);
    assert.equal(fields.find((f: any) => f.id === '7').value['7.1'].value, 'Ja, offerte');
    assert.equal(fields.find((f: any) => f.id === '7').options.length, 2);
  }
  assert.equal((h.db.prepare('SELECT count(*) n FROM events').get() as any).n, 2);
  assert.equal((h.db.prepare('SELECT count(*) n FROM requests').get() as any).n, 2);
  assert.equal((h.db.prepare('SELECT count(*) n FROM opportunities').get() as any).n, 0);
});
