import { test, before, after, mock } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { randomUUID } from 'node:crypto';
let folder: string, db: typeof import('../server/db.ts').db, now: () => string;
let geocoding: typeof import('../server/geocoding.ts');
let clock = Date.now();
before(async () => {
  folder = mkdtempSync(join(tmpdir(), 'optimat-geocoding-'));
  process.env.DB_PATH = join(folder, 'geocoding.sqlite');
  process.env.NODE_ENV = 'test';
  const database = await import('../server/db.ts');
  db = database.db;
  now = database.now;
  db.exec(readFileSync(new URL('../migrations/003.sql', import.meta.url), 'utf8'));
  geocoding = await import('../server/geocoding.ts');
  mock.method(Date, 'now', () => clock);
});
after(() => {
  mock.restoreAll();
  db?.close();
  rmSync(folder, { recursive: true, force: true });
  delete process.env.GEOCODING_URL;
  delete process.env.GEOCODING_TERMS_CONFIRMED;
});
function seedLocation(input: Record<string, unknown> = {}) {
  const company = randomUUID(),
    location = randomUUID();
  db.prepare('INSERT INTO companies(id,name,country,created_at,updated_at) VALUES (?,?,?,?,?)').run(
    company,
    'Synthetische geocode-test',
    'BE',
    now(),
    now(),
  );
  db.prepare(
    'INSERT INTO locations(id,company_id,country,address,postcode,city,latitude,longitude,manually_confirmed) VALUES (?,?,?,?,?,?,?,?,?)',
  ).run(
    location,
    company,
    String(input.country ?? 'BE'),
    String(input.address ?? 'Voorbeeldstraat 1'),
    String(input.postcode ?? '1000'),
    String(input.city ?? 'Brussel'),
    typeof input.latitude === 'number' ? input.latitude : null,
    typeof input.longitude === 'number' ? input.longitude : null,
    Number(input.manually_confirmed ?? 0),
  );
  return location;
}
function location(id: string) {
  return db.prepare('SELECT * FROM locations WHERE id=?').get(id) as any;
}
function job(id: string) {
  return db.prepare('SELECT * FROM geocode_jobs WHERE location_id=?').get(id) as any;
}
function response(
  country: string,
  coordinates: number[] = [4.3517, 50.8503],
  properties: Record<string, unknown> = { housenumber: '1' },
) {
  return new Response(
    JSON.stringify({
      type: 'FeatureCollection',
      features: [
        {
          type: 'Feature',
          geometry: { type: 'Point', coordinates },
          properties: { countrycode: country, postcode: '1000', ...properties },
        },
      ],
    }),
    { status: 200, headers: { 'Content-Type': 'application/json' } },
  );
}
function enable() {
  process.env.GEOCODING_URL = 'https://licensed-geocoder.example.invalid/api';
  process.env.GEOCODING_TERMS_CONFIRMED = 'true';
}
async function run(fetcher: typeof fetch) {
  clock += 2000;
  return geocoding.processGeocoding(1, fetcher);
}

test('geocodering doet geen externe requests zonder HTTPS-provider en bevestigde voorwaarden', async () => {
  const id = seedLocation();
  let calls = 0;
  const fetcher = (async () => {
    calls++;
    return response('BE');
  }) as typeof fetch;
  delete process.env.GEOCODING_URL;
  delete process.env.GEOCODING_TERMS_CONFIRMED;
  assert.equal((await run(fetcher)).status, 'not_configured');
  assert.equal(job(id).status, 'pending');
  process.env.GEOCODING_URL = 'https://licensed-geocoder.example.invalid/api';
  assert.equal((await run(fetcher)).status, 'terms_not_confirmed');
  process.env.GEOCODING_URL = 'http://insecure.example.invalid/api';
  process.env.GEOCODING_TERMS_CONFIRMED = 'true';
  assert.equal((await run(fetcher)).status, 'invalid_url');
  assert.equal(calls, 0);
  assert.equal(location(id).latitude, null);
  enable();
  await run((async (url: URL | RequestInfo) => {
    calls++;
    const query = new URL(String(url));
    assert.match(query.searchParams.get('q') || '', /Belgium/);
    assert.equal(query.searchParams.get('limit'), '1');
    return response('BE');
  }) as typeof fetch);
  assert.equal(calls, 1);
  assert.equal(location(id).latitude, 50.8503);
  assert.equal(location(id).precision, 'address');
  assert.equal(job(id).status, 'completed');
  assert.equal(geocoding.geocodingStatus().provider, 'licensed-geocoder.example.invalid');
});

test('Benelux-landcontrole, postcodeprecisie en ontbrekend land voorkomen verzonnen markers', async () => {
  enable();
  const nl = seedLocation({ country: 'NL', address: '', postcode: '1012', city: 'Amsterdam' });
  await run((async (url: URL | RequestInfo) => {
    assert.match(new URL(String(url)).searchParams.get('q') || '', /Netherlands/);
    return response('NL', [4.8952, 52.3702], {
      housenumber: null,
      postcode: '1012',
      type: 'postcode',
    });
  }) as typeof fetch);
  assert.equal(location(nl).longitude, 4.8952);
  assert.equal(location(nl).precision, 'postcode');
  const lu = seedLocation({ country: 'LU', postcode: '1111', city: 'Luxembourg' });
  await run((async (url: URL | RequestInfo) => {
    assert.match(new URL(String(url)).searchParams.get('q') || '', /Luxembourg/);
    return response('BE');
  }) as typeof fetch);
  assert.equal(location(lu).latitude, null);
  assert.equal(job(lu).status, 'failed');
  assert.equal(job(lu).error_code, 'COUNTRY_MISMATCH');
  const unknown = seedLocation({ country: '' });
  let calls = 0;
  await run((async () => {
    calls++;
    return response('BE');
  }) as typeof fetch);
  assert.equal(calls, 0);
  assert.equal(job(unknown), undefined);
  assert.equal(location(unknown).latitude, null);
});

test('handmatig bevestigde, bestaande en gelijktijdig gewijzigde locaties worden behouden', async () => {
  enable();
  const manual = seedLocation({ latitude: 50, longitude: 4, manually_confirmed: 1 });
  const existing = seedLocation({ latitude: 51, longitude: 5 });
  let calls = 0;
  await run((async () => {
    calls++;
    return response('BE');
  }) as typeof fetch);
  assert.equal(calls, 0);
  assert.equal(job(manual), undefined);
  assert.equal(job(existing), undefined);
  const changing = seedLocation();
  await run((async () => {
    db.prepare(
      'UPDATE locations SET manually_confirmed=1,latitude=49.6117,longitude=6.1319,version=version+1 WHERE id=?',
    ).run(changing);
    return response('BE');
  }) as typeof fetch);
  assert.equal(location(changing).latitude, 49.6117);
  assert.equal(job(changing).status, 'skipped');
  assert.equal(job(changing).error_code, 'LOCATION_CHANGED');
});

test('providerstoring heeft duurzame begrensde retries en adreswijziging maakt een nieuwe poging mogelijk', async () => {
  enable();
  const id = seedLocation();
  let calls = 0;
  const failing = (async () => {
    calls++;
    return new Response('unavailable', { status: 503 });
  }) as typeof fetch;
  for (let attempt = 1; attempt <= 5; attempt++) {
    if (attempt > 1)
      db.prepare('UPDATE geocode_jobs SET next_attempt_at=? WHERE location_id=?').run(
        '2000-01-01T00:00:00.000Z',
        id,
      );
    await run(failing);
    assert.equal(job(id).attempts, attempt);
    assert.equal(job(id).status, attempt === 5 ? 'failed' : 'retry');
  }
  assert.equal(calls, 5);
  assert.equal(job(id).error_code, 'PROVIDER_HTTP_ERROR');
  assert.equal(location(id).latitude, null);
  await run(failing);
  assert.equal(calls, 5, 'Mislukte taak wordt niet onbeperkt herhaald');
  db.prepare('UPDATE locations SET address=?,version=version+1 WHERE id=?').run(
    'Andere straat 2',
    id,
  );
  await run((async () => response('BE', [4.4, 50.9])) as typeof fetch);
  assert.equal(job(id).status, 'completed');
  assert.equal(job(id).attempts, 1);
  assert.equal(location(id).latitude, 50.9);
});
