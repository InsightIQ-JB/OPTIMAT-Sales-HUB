import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync, readdirSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { randomUUID } from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';
import { makeHarness } from './helpers.ts';
let h: Awaited<ReturnType<typeof makeHarness>>, files: string;
before(async () => {
  files = mkdtempSync(join(tmpdir(), 'optimat-source-media-'));
  process.env.ATTACHMENT_DIR = files;
  h = await makeHarness();
});
after(async () => {
  await h?.close();
  rmSync(files, { recursive: true, force: true });
});
function seedSource() {
  const source = h.seedSource();
  h.db.prepare("UPDATE forms SET provider='gravity' WHERE id=?").run(source.formId);
  return source;
}
function payload(extra: Record<string, unknown> = {}) {
  return {
    event_id: randomUUID(),
    provider: 'gravity',
    form_id: '42',
    submission_id: randomUUID(),
    attachment_key: '4:synthetic-checksum',
    name: 'bron-offerte.pdf',
    mime: 'application/pdf',
    content_base64: Buffer.from('%PDF-1.4\nSynthetic source attachment').toString('base64'),
    ...extra,
  };
}
function seedRequest(source: ReturnType<typeof seedSource>, submissionId: string, ownerId: string) {
  const t = h.now(),
    company = randomUUID(),
    request = randomUUID();
  h.db
    .prepare('INSERT INTO companies(id,name,country,created_at,updated_at) VALUES (?,?,?,?,?)')
    .run(company, 'Synthetische mediabron', 'BE', t, t);
  h.db
    .prepare(
      'INSERT INTO requests(id,source_id,form_id,provider,submission_id,source_occurred_at,company_id,owner_id,submitted_at,received_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
    )
    .run(
      request,
      source.sourceId,
      source.formId,
      'gravity',
      submissionId,
      t,
      company,
      ownerId,
      t,
      t,
      t,
    );
  return request;
}
const route = (sourceId: string) => `/api/connectors/${sourceId}/attachments`;

test('signed source media waits for request/mapping and stores one private attachment across retries', async () => {
  const seller = await h.seedUser('seller', 'bron-media-eigenaar'),
    other = await h.seedUser('seller', 'bron-media-andere');
  const owner = await h.login(seller),
    outsider = await h.login(other);
  const source = seedSource(),
    input = payload();
  const notReady = await h.signed(route(source.sourceId), input);
  assert.equal(notReady.status, 409);
  assert.equal(((await notReady.json()) as any).retryable, true);
  assert.equal(readdirSync(files).length, 0);
  h.db.prepare("UPDATE forms SET purpose='unclassified' WHERE id=?").run(source.formId);
  const mapping = await h.signed(route(source.sourceId), input);
  assert.equal(mapping.status, 409);
  assert.equal(((await mapping.json()) as any).code, 'FORM_MAPPING_REQUIRED');
  h.db.prepare("UPDATE forms SET purpose='commercial' WHERE id=?").run(source.formId);
  const request = seedRequest(source, input.submission_id, seller.id);
  // A later commercial request remains eligible even if an older source version was excluded.
  h.db
    .prepare(
      'INSERT INTO events(id,source_id,event_id,submission_id,provider,form_id,source_version,occurred_at,received_at,payload_json,payload_hash,status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
    )
    .run(
      randomUUID(),
      source.sourceId,
      randomUUID(),
      input.submission_id,
      'gravity',
      '42',
      1,
      h.now(),
      h.now(),
      '{}',
      'synthetic-old-excluded',
      'excluded',
    );
  const accepted = await h.signed(route(source.sourceId), input);
  assert.equal(accepted.status, 202, await accepted.clone().text());
  const receipt = (await accepted.json()) as any;
  assert.equal(receipt.event_id, input.event_id);
  assert.equal(receipt.status, 'received');
  for (let i = 0; i < 3; i++) {
    const retry = await h.signed(route(source.sourceId), input);
    assert.equal(retry.status, 202);
    assert.equal(((await retry.json()) as any).attachment_id, receipt.attachment_id);
  }
  assert.equal(
    (h.db.prepare('SELECT count(*) AS n FROM attachments WHERE request_id=?').get(request) as any)
      .n,
    1,
  );
  assert.equal(readdirSync(files).length, 1);
  const dbAttachment = h.db
    .prepare('SELECT uploaded_by FROM attachments WHERE id=?')
    .get(receipt.attachment_id) as any;
  assert.equal(dbAttachment.uploaded_by, null, 'System uploads do not invent a personal account');
  const listed = await owner.request(`/api/requests/${request}/attachments`);
  assert.equal(listed.status, 200);
  assert.equal(((await listed.json()) as any).items.length, 1);
  const downloaded = await owner.request(`/api/attachments/${receipt.attachment_id}`);
  assert.equal(downloaded.status, 200);
  assert.equal(await downloaded.text(), '%PDF-1.4\nSynthetic source attachment');
  assert.equal((await outsider.request(`/api/attachments/${receipt.attachment_id}`)).status, 404);
  const conflict = await h.signed(route(source.sourceId), {
    ...input,
    content_base64: Buffer.from('%PDF-1.4\nChanged bytes').toString('base64'),
  });
  assert.equal(conflict.status, 409);
  assert.equal(((await conflict.json()) as any).retryable, false);
  const invalid = await h.signed(route(source.sourceId), {
    ...input,
    attachment_key: 'other',
    content_base64: Buffer.from('<script>not pdf</script>').toString('base64'),
  });
  assert.equal(invalid.status, 400);
  assert.equal(readdirSync(files).length, 1);
  process.env.TEST_MEDIA_PREVIOUS_SECRET = 'synthetic-previous-media-source-key';
  h.db
    .prepare('UPDATE sources SET previous_secret_env=? WHERE id=?')
    .run('TEST_MEDIA_PREVIOUS_SECRET', source.sourceId);
  const rotating = await h.signed(route(source.sourceId), input, {
    secret: process.env.TEST_MEDIA_PREVIOUS_SECRET,
  });
  assert.equal(
    rotating.status,
    202,
    'Previous per-source signing secret remains valid during explicit rotation',
  );
  h.db.prepare('UPDATE sources SET previous_secret_env=NULL WHERE id=?').run(source.sourceId);
  assert.equal(
    (
      await h.signed(route(source.sourceId), input, {
        secret: process.env.TEST_MEDIA_PREVIOUS_SECRET,
      })
    ).status,
    401,
    'Retiring the previous key removes its upload access',
  );
  delete process.env.TEST_MEDIA_PREVIOUS_SECRET;
  assert.equal(
    (await h.signed(route(source.sourceId), input, { secret: 'incorrect-synthetic-key' })).status,
    401,
  );
  assert.equal(
    (await h.signed(route(source.sourceId), input, { timestamp: '1000000000' })).status,
    401,
  );
});

test('noncommercial and erased source media is acknowledged without storing files or receipts', async () => {
  const seller = await h.seedUser('seller', 'bron-media-privacy'),
    admin = await h.seedUser('admin', 'bron-media-admin');
  const a = await h.login(admin);
  const source = seedSource(),
    input = payload();
  h.db.prepare("UPDATE forms SET purpose='recruitment' WHERE id=?").run(source.formId);
  const beforeFiles = readdirSync(files).length;
  const excluded = await h.signed(route(source.sourceId), input);
  assert.equal(excluded.status, 202);
  assert.equal(((await excluded.json()) as any).status, 'ignored_noncommercial');
  assert.equal(readdirSync(files).length, beforeFiles);
  h.db.prepare("UPDATE forms SET purpose='commercial' WHERE id=?").run(source.formId);
  const request = seedRequest(source, input.submission_id, seller.id);
  const uploaded = await h.signed(route(source.sourceId), input);
  assert.equal(uploaded.status, 202);
  assert.equal(readdirSync(files).length, beforeFiles + 1);
  const erased = await a.request(`/api/admin/privacy/requests/${request}`, 'DELETE', {
    version: 1,
    reason: 'Synthetisch privacyverzoek',
  });
  assert.equal(erased.status, 200, await erased.clone().text());
  assert.equal(readdirSync(files).length, beforeFiles);
  assert.equal(
    h.db.prepare('SELECT id FROM source_attachment_receipts WHERE request_id=?').get(request),
    undefined,
  );
  const replay = await h.signed(route(source.sourceId), input);
  assert.equal(replay.status, 202);
  assert.equal(((await replay.json()) as any).status, 'ignored_erased');
  assert.equal(readdirSync(files).length, beforeFiles);
  assert.equal(
    h.db
      .prepare('SELECT id FROM source_attachment_receipts WHERE submission_id=?')
      .get(input.submission_id),
    undefined,
  );
});

test('media migration preserves existing personal attachment rows and foreign-key deletion', () => {
  const legacy = new DatabaseSync(':memory:');
  try {
    legacy.exec('PRAGMA foreign_keys=ON;');
    legacy.exec(readFileSync(new URL('../migrations/001.sql', import.meta.url), 'utf8'));
    legacy.exec(readFileSync(new URL('../migrations/002.sql', import.meta.url), 'utf8'));
    const t = new Date().toISOString();
    legacy
      .prepare('INSERT INTO users(id,email,name,role,created_at) VALUES (?,?,?,?,?)')
      .run('legacy-user', 'migration@example.invalid', 'Synthetic existing user', 'admin', t);
    legacy
      .prepare('INSERT INTO companies(id,name,created_at,updated_at) VALUES (?,?,?,?)')
      .run('legacy-company', 'Synthetic existing company', t, t);
    legacy
      .prepare(
        'INSERT INTO requests(id,provider,submission_id,source_occurred_at,company_id,submitted_at,received_at,updated_at) VALUES (?,?,?,?,?,?,?,?)',
      )
      .run('legacy-request', 'synthetic', 'legacy-submission', t, 'legacy-company', t, t, t);
    legacy
      .prepare('INSERT INTO attachments VALUES (?,?,?,?,?,?,?,?,?)')
      .run(
        'legacy-attachment',
        'legacy-request',
        'opaque-existing-key',
        'legacy.pdf',
        'application/pdf',
        5,
        'synthetic-hash',
        'legacy-user',
        t,
      );
    legacy.exec(readFileSync(new URL('../migrations/007.sql', import.meta.url), 'utf8'));
    const row = legacy
      .prepare('SELECT * FROM attachments WHERE id=?')
      .get('legacy-attachment') as any;
    assert.equal(row.uploaded_by, 'legacy-user');
    assert.equal(row.storage_key, 'opaque-existing-key');
    legacy.prepare('DELETE FROM requests WHERE id=?').run('legacy-request');
    assert.equal(
      legacy.prepare('SELECT id FROM attachments WHERE id=?').get('legacy-attachment'),
      undefined,
    );
    assert.equal(legacy.prepare('PRAGMA foreign_key_check').all().length, 0);
  } finally {
    legacy.close();
  }
});
