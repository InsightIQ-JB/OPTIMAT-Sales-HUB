import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { makeHarness } from './helpers.ts';
let h: Awaited<ReturnType<typeof makeHarness>>;
before(async () => {
  h = await makeHarness();
});
after(async () => {
  await h?.close();
});

test('persoonlijke sessies, CSRF, uitnodiging en intrekking worden server-side afgedwongen', async () => {
  const admin = await h.seedUser('admin', 'beheerder');
  const seller = await h.seedUser('seller', 'verkoper');
  const a = await h.login(admin),
    s = await h.login(seller);
  const anonymous = await h.raw('/api/requests');
  assert.equal(anonymous.status, 401);
  assert.equal((await s.request('/api/admin/users')).status, 403);
  const users = await a.request('/api/admin/users');
  assert.equal(users.status, 200);
  assert.equal(JSON.stringify(await users.json()).includes('password_hash'), false);
  const withoutCsrf = await h.raw('/api/admin/invitations', {
    method: 'POST',
    headers: { cookie: a.cookie, 'content-type': 'application/json' },
    body: JSON.stringify({ email: 'invited@example.invalid', name: 'Uitgenodigd', role: 'seller' }),
  });
  assert.equal(withoutCsrf.status, 403);
  const hostileOrigin = await a.request(
    '/api/admin/invitations',
    'POST',
    { email: 'invited@example.invalid', name: 'Uitgenodigd', role: 'seller' },
    { Origin: 'https://untrusted.example.invalid' },
  );
  assert.equal(hostileOrigin.status, 403);
  const invited = await a.request('/api/admin/invitations', 'POST', {
    email: 'invited@example.invalid',
    name: 'Uitgenodigd',
    role: 'seller',
  });
  assert.ok(invited.ok, await invited.clone().text());
  const invite = (await invited.json()) as { token: string };
  assert.ok(invite.token);
  const acceptBody = {
    token: invite.token,
    password: 'New-invited-password-2026!',
    name: 'Uitgenodigd',
  };
  const accepted = await h.raw('/api/auth/accept-invite', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(acceptBody),
  });
  assert.ok(accepted.ok, await accepted.clone().text());
  const replay = await h.raw('/api/auth/accept-invite', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(acceptBody),
  });
  assert.ok(replay.status >= 400, 'Een uitnodiging kan maar één keer worden gebruikt');
  const account = await h.login({
    email: 'invited@example.invalid',
    password: acceptBody.password,
  });
  assert.equal((await account.request('/api/auth/me')).status, 200);
  const user = h.db
    .prepare('SELECT id FROM users WHERE email=?')
    .get('invited@example.invalid') as { id: string };
  const revoked = await a.request(`/api/admin/users/${user.id}`, 'PATCH', { active: false });
  assert.ok(revoked.ok, await revoked.clone().text());
  assert.equal((await account.request('/api/auth/me')).status, 401);
  const logout = await s.request('/api/auth/logout', 'POST', {});
  assert.ok(logout.ok);
  assert.equal((await s.request('/api/auth/me')).status, 401);
});

test('verkeerd wachtwoord geeft geen accountgegevens prijs', async () => {
  const user = await h.seedUser('manager', 'manager');
  const response = await h.raw('/api/auth/login', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ email: user.email, password: 'Incorrect-password-2026!' }),
  });
  assert.equal(response.status, 401);
  const body = await response.text();
  assert.equal(body.includes('password_hash'), false);
  assert.equal(body.includes(user.email), false);
});
