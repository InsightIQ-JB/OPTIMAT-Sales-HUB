import { test } from 'node:test';
import assert from 'node:assert/strict';
import { periodBoundary } from '../server/time.ts';
test('Brussels date filters include the actual civil day over DST transitions', () => {
  assert.equal(periodBoundary('2026-03-29'), '2026-03-28T23:00:00.000Z');
  assert.equal(periodBoundary('2026-03-29', true), '2026-03-29T21:59:59.999Z');
  assert.equal(periodBoundary('2026-10-25'), '2026-10-24T22:00:00.000Z');
  assert.equal(periodBoundary('2026-10-25', true), '2026-10-25T22:59:59.999Z');
  assert.throws(() => periodBoundary('2026-02-30'));
});
