import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { makeHarness } from './helpers.ts';
import type { IntakeEvent } from '../shared/domain.ts';
let h: Awaited<ReturnType<typeof makeHarness>>;
before(async () => {
  h = await makeHarness();
});
after(async () => {
  await h?.close();
});
function event(
  submissionId: string,
  version = 1,
  overrides: Partial<IntakeEvent> = {},
): IntakeEvent {
  return {
    event_id: randomUUID(),
    submission_id: submissionId,
    version,
    occurred_at: new Date().toISOString(),
    submitted_at: '2026-10-01T09:00:00.000Z',
    provider: 'contract',
    form_id: '42',
    form_name: 'Brochure en offerte',
    purpose: 'commercial',
    language: 'nl',
    intents: ['brochure', 'quote'],
    fields: [
      { id: 'company', label: 'Bedrijf', type: 'text', value: 'Fictief Contractbedrijf' },
      { id: 'vat', label: 'Ondernemingsnummer', type: 'text', value: 'BE 0202.239.951' },
      { id: 'country', label: 'Land', type: 'text', value: 'BE' },
      { id: 'person', label: 'Naam', type: 'text', value: 'Fictieve Contactpersoon' },
      { id: 'email', label: 'E-mail', type: 'email', value: 'contract@example.invalid' },
      { id: 'message', label: 'Vraag', type: 'textarea', value: 'Graag brochure en een offerte.' },
      { id: 'machine', label: 'Machine', type: 'text', value: 'CNC/nesting' },
      {
        id: 'new-field',
        label: 'Werkstukmaten',
        type: 'multiselect',
        value: ['1200', '2400'],
        options: ['1200', '2400'],
      },
      {
        id: 'g-recaptcha-response',
        label: 'CAPTCHA',
        type: 'hidden',
        value: 'do-not-persist-token',
      },
    ],
    context: {
      business_unit: 'Wood',
      brand: 'HOMAG',
      product_url: 'https://contract.example.invalid/product',
    },
    ...overrides,
  };
}

test('ondertekende ontvangst, idempotentie, bronversies en commerciële opvolging vormen één werkende stroom', async () => {
  const { sourceId } = h.seedSource();
  const admin = await h.seedUser('admin', 'intake-admin'),
    seller = await h.seedUser('seller', 'eigenaar'),
    other = await h.seedUser('seller', 'andere');
  const a = await h.login(admin),
    s = await h.login(seller),
    o = await h.login(other);
  const { processPending } = await import('../server/intake.ts');
  const first = event('submission-1');
  const started = Date.now();
  for (let i = 0; i < 3; i++) {
    const response = await h.signed(`/api/webhooks/${sourceId}`, first);
    assert.ok(response.ok, await response.clone().text());
    const receipt = (await response.json()) as { accepted: boolean; event_id: string };
    assert.equal(receipt.accepted, true);
    assert.equal(
      receipt.event_id,
      first.event_id,
      'Het ontvangstbewijs echoot de bron-event-ID voor de connector',
    );
  }
  assert.equal(
    (h.db.prepare('SELECT COUNT(*) n FROM events').get() as { n: number }).n,
    1,
    'Herlevering heeft één duurzaam event',
  );
  await processPending();
  assert.ok(Date.now() - started < 15_000, 'Contract-inname binnen 15 seconden');
  const all = await a.request('/api/requests');
  assert.equal(all.status, 200);
  const list = (await all.json()) as { items: Array<Record<string, any>> };
  assert.equal(list.items.length, 1);
  const request = list.items[0];
  const detail = (await (await a.request(`/api/requests/${request.id}`)).json()) as any;
  assert.ok(JSON.stringify(detail).includes('Werkstukmaten'));
  assert.equal(JSON.stringify(detail).includes('do-not-persist-token'), false);
  assert.deepEqual(JSON.parse(detail.request.intents_json), ['brochure', 'quote']);
  const assigned = await a.request(`/api/requests/${request.id}`, 'PATCH', {
    version: detail.request.version,
    owner_id: seller.id,
  });
  assert.ok(assigned.ok, await assigned.clone().text());
  const visible = await s.request(`/api/requests/${request.id}`);
  assert.equal(visible.status, 200);
  assert.equal((await o.request(`/api/requests/${request.id}`)).status, 404);
  assert.equal(((await (await o.request('/api/requests')).json()) as any).items.length, 0);
  const otherMap = (await (await o.request('/api/map')).json()) as any;
  assert.equal(otherMap.items.length, 0);
  const otherReport = (await (await o.request('/api/reports')).json()) as any;
  assert.equal(otherReport.metrics.requests, 0);
  const otherExport = await o.request('/api/reports/export.csv');
  assert.equal((await otherExport.text()).includes('Fictief Contractbedrijf'), false);
  const note = await s.request(`/api/requests/${request.id}/activities`, 'POST', {
    kind: 'note',
    body: 'Verkopersnotitie blijft behouden',
  });
  assert.ok(note.ok, await note.clone().text());
  const contact = await s.request(`/api/requests/${request.id}/activities`, 'POST', {
    kind: 'call',
    body: 'Gesprek met contactpersoon',
  });
  assert.ok(contact.ok, await contact.clone().text());
  const task = await s.request(`/api/requests/${request.id}/tasks`, 'POST', {
    title: 'Offerte opvolgen',
    due_at: '2026-11-01T09:00:00.000Z',
  });
  assert.ok(task.ok, await task.clone().text());
  const beforeUpdate = (await (await s.request(`/api/requests/${request.id}`)).json()) as any;
  const updated = event('submission-1', 2);
  updated.fields = updated.fields.map((field) =>
    field.id === 'message' ? { ...field, value: 'Aangevulde bronvraag' } : field,
  );
  assert.ok((await h.signed(`/api/webhooks/${sourceId}`, updated)).ok);
  await processPending();
  const stale = event('submission-1', 1, { occurred_at: '2026-09-01T00:00:00.000Z' });
  assert.ok((await h.signed(`/api/webhooks/${sourceId}`, stale)).ok);
  await processPending();
  const afterUpdate = (await (await s.request(`/api/requests/${request.id}`)).json()) as any;
  assert.equal(afterUpdate.request.owner_id, seller.id);
  assert.equal(afterUpdate.request.message, 'Aangevulde bronvraag');
  assert.ok(
    afterUpdate.activities.some(
      (activity: any) => activity.body === 'Verkopersnotitie blijft behouden',
    ),
  );
  assert.ok(afterUpdate.tasks.some((item: any) => item.title === 'Offerte opvolgen'));
  const conflict = await s.request(`/api/requests/${request.id}`, 'PATCH', {
    version: beforeUpdate.request.version,
    status: 'contacted',
  });
  assert.equal(conflict.status, 409, 'Stale bewerkingen moeten zichtbaar conflicteren');
  const second = event('submission-2');
  assert.ok((await h.signed(`/api/webhooks/${sourceId}`, second)).ok);
  await processPending();
  assert.equal((h.db.prepare('SELECT COUNT(*) n FROM requests').get() as { n: number }).n, 2);
  assert.equal(
    (h.db.prepare('SELECT COUNT(*) n FROM companies').get() as { n: number }).n,
    1,
    'Geldig ondernemingsnummer koppelt dezelfde rechtspersoon',
  );
  assert.equal(
    (h.db.prepare('SELECT COUNT(*) n FROM opportunities').get() as { n: number }).n,
    0,
    'Brochure/offerte-intentie maakt niet automatisch een kans',
  );
});

test('verkeerde handtekening en verlopen aflevertimestamp worden geweigerd zonder opslag', async () => {
  const { sourceId } = h.seedSource();
  const payload = event('invalid-signature');
  const count = () =>
    Number((h.db.prepare('SELECT COUNT(*) n FROM events').get() as { n: number }).n);
  const before = count();
  const invalid = await h.signed(`/api/webhooks/${sourceId}`, payload, {
    secret: 'wrong-contract-key',
  });
  assert.equal(invalid.status, 401);
  const expired = await h.signed(`/api/webhooks/${sourceId}`, payload, {
    timestamp: String(Math.floor(Date.now() / 1000) - 3600),
  });
  assert.equal(expired.status, 401);
  assert.equal(count(), before);
});

test('tijdelijke verwerkingsstoring bewaart het event en herstelt zonder halve CRM-records', async () => {
  const { sourceId } = h.seedSource();
  const { processPending } = await import('../server/intake.ts');
  const payload = event('retry-after-storage-failure');
  const before = Number((h.db.prepare('SELECT COUNT(*) n FROM requests').get() as { n: number }).n);
  const accepted = await h.signed(`/api/webhooks/${sourceId}`, payload);
  assert.equal(accepted.status, 202);
  h.db.exec(
    "CREATE TRIGGER contract_fail_insert BEFORE INSERT ON requests BEGIN SELECT RAISE(FAIL,'synthetic storage failure'); END;",
  );
  try {
    await processPending();
  } finally {
    h.db.exec('DROP TRIGGER contract_fail_insert');
  }
  const failed = h.db.prepare('SELECT * FROM events WHERE event_id=?').get(payload.event_id) as any;
  assert.equal(failed.status, 'retry');
  assert.equal(failed.attempts, 1);
  assert.equal(failed.error_code, 'PROCESSING_FAILED');
  assert.equal(
    Number((h.db.prepare('SELECT COUNT(*) n FROM requests').get() as { n: number }).n),
    before,
  );
  h.db.prepare('UPDATE events SET next_attempt_at=NULL WHERE id=?').run(failed.id);
  await processPending();
  const recovered = h.db
    .prepare('SELECT * FROM events WHERE event_id=?')
    .get(payload.event_id) as any;
  assert.equal(recovered.status, 'processed');
  assert.equal(
    Number((h.db.prepare('SELECT COUNT(*) n FROM requests').get() as { n: number }).n),
    before + 1,
  );
});

test('support, recruitment en nieuwsbrief worden uitgesloten van commerciële intake', async () => {
  const { sourceId } = h.seedSource();
  const { processPending } = await import('../server/intake.ts');
  const before = Number((h.db.prepare('SELECT COUNT(*) n FROM requests').get() as { n: number }).n);
  for (const purpose of ['support', 'recruitment', 'newsletter'] as const) {
    const payload = event(`excluded-${purpose}`, 1, { purpose });
    assert.equal((await h.signed(`/api/webhooks/${sourceId}`, payload)).status, 202);
    await processPending();
    const stored = h.db
      .prepare('SELECT status FROM events WHERE event_id=?')
      .get(payload.event_id) as { status: string };
    assert.equal(stored.status, 'excluded');
  }
  assert.equal(
    Number((h.db.prepare('SELECT COUNT(*) n FROM requests').get() as { n: number }).n),
    before,
  );
});

test('automatische achtergrondwerker maakt een ondertekende aanvraag binnen 15 seconden zichtbaar', async () => {
  const { sourceId } = h.seedSource();
  const { startWorker } = await import('../server/intake.ts');
  const stop = startWorker();
  const payload = event('automatic-worker-latency');
  const started = performance.now();
  try {
    const response = await h.signed(`/api/webhooks/${sourceId}`, payload);
    assert.equal(response.status, 202);
    let found: unknown;
    while (performance.now() - started < 15_000) {
      found = h.db
        .prepare(
          'SELECT r.id FROM requests r JOIN events e ON e.source_id=r.source_id AND e.submission_id=r.submission_id WHERE e.event_id=?',
        )
        .get(payload.event_id);
      if (found) break;
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
    assert.ok(
      found,
      'Dezelfde automatische werker als de server moet binnen 15 seconden verwerken',
    );
    assert.ok(performance.now() - started < 15_000);
  } finally {
    stop();
  }
});

test('event-ID-conflicten en veilige brongeheimrotatie worden op de ontvanger afgedwongen', async () => {
  const { sourceId } = h.seedSource();
  const payload = event('rotation-contract');
  const first = await h.signed(`/api/webhooks/${sourceId}`, payload);
  assert.equal(first.status, 202);
  const changed = { ...payload, form_name: 'Afwijkende inhoud onder dezelfde event-ID' };
  assert.equal((await h.signed(`/api/webhooks/${sourceId}`, changed)).status, 409);
  process.env.TEST_OLD_WP_SECRET = 'test-only-old-rotation-key';
  h.db
    .prepare('UPDATE sources SET previous_secret_env=? WHERE id=?')
    .run('TEST_OLD_WP_SECRET', sourceId);
  const legacy = event('legitimate-retry-during-rotation');
  assert.equal(
    (
      await h.signed(`/api/webhooks/${sourceId}`, legacy, {
        secret: process.env.TEST_OLD_WP_SECRET,
      })
    ).status,
    202,
  );
  h.db.prepare('UPDATE sources SET previous_secret_env=NULL WHERE id=?').run(sourceId);
  const afterRotation = event('after-old-key-revoked');
  assert.equal(
    (
      await h.signed(`/api/webhooks/${sourceId}`, afterRotation, {
        secret: process.env.TEST_OLD_WP_SECRET,
      })
    ).status,
    401,
  );
  assert.equal((await h.signed(`/api/webhooks/${sourceId}`, afterRotation)).status, 202);
});
